import React, { useEffect, useState } from 'react';
import { BellRing, Moon, Smartphone, Sun, Tablet, Wifi, WifiOff } from 'lucide-react';
import { AndroidDeviceSimulator } from './components/AndroidDeviceSimulator';
import { ArchitectureBlueprintView } from './components/ArchitectureBlueprintView';
import { KotlinSourceExplorer } from './components/KotlinSourceExplorer';
import { RoomInspectorPanel } from './components/RoomInspectorPanel';
import { ANDROID_SOURCE_FILES } from './data/kotlinCodebase';
import { INITIAL_CLIENTS, INITIAL_INVOICES, INITIAL_PRODUCTS } from './data/seedData';
import {
  Client,
  Invoice,
  PendingSyncOp,
  Product,
  PushNotificationAlert,
  UserRole,
} from './types/wholesale';

type WorkspaceSection = 'simulator' | 'architecture' | 'source' | 'tests';

const STORAGE_KEY = 'wholesale_ledger_mad_state_v1';

export default function App() {
  const [section, setSection] = useState<WorkspaceSection>('simulator');
  const [selectedFileId, setSelectedFileId] = useState<string>('libs-versions-toml');
  const [darkMode, setDarkMode] = useState<boolean>(false);
  const [formFactor, setFormFactor] = useState<'phone' | 'tablet'>('phone');
  const [isOnline, setIsOnline] = useState<boolean>(true);
  const [isBiometricUnlocked, setIsBiometricUnlocked] = useState<boolean>(true);
  const [role, setRole] = useState<UserRole>('ADMIN');
  const [activeAlert, setActiveAlert] = useState<PushNotificationAlert | null>(null);

  const [clients, setClients] = useState<Client[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) return JSON.parse(saved).clients ?? INITIAL_CLIENTS;
    } catch {
      // Ignore storage parse failure
    }
    return INITIAL_CLIENTS;
  });

  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) return JSON.parse(saved).products ?? INITIAL_PRODUCTS;
    } catch {
      // Ignore storage parse failure
    }
    return INITIAL_PRODUCTS;
  });

  const [invoices, setInvoices] = useState<Invoice[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) return JSON.parse(saved).invoices ?? INITIAL_INVOICES;
    } catch {
      // Ignore storage parse failure
    }
    return INITIAL_INVOICES;
  });

  const [pendingOps, setPendingOps] = useState<PendingSyncOp[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) return JSON.parse(saved).pendingOps ?? [];
    } catch {
      // Ignore storage parse failure
    }
    return [];
  });

  useEffect(() => {
    const root = document.documentElement;
    if (darkMode) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [darkMode]);

  useEffect(() => {
    try {
      localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({ clients, products, invoices, pendingOps })
      );
    } catch {
      // Ignore storage quota errors
    }
  }, [clients, products, invoices, pendingOps]);

  const flushSyncOutbox = () => {
    if (!isOnline || pendingOps.length === 0) return;
    setClients((prev) => prev.map((c) => ({ ...c, syncState: 'SYNCED' })));
    setProducts((prev) => prev.map((p) => ({ ...p, syncState: 'SYNCED' })));
    setInvoices((prev) => prev.map((i) => ({ ...i, syncState: 'SYNCED' })));
    setPendingOps([]);
  };

  useEffect(() => {
    if (isOnline && pendingOps.length > 0) {
      const timer = setTimeout(() => {
        flushSyncOutbox();
      }, 900);
      return () => clearTimeout(timer);
    }
  }, [isOnline]);

  const enqueueOp = (
    entityType: PendingSyncOp['entityType'],
    entityId: string,
    operation: PendingSyncOp['operation'],
    payloadSummary: string
  ) => {
    if (isOnline) return;
    setPendingOps((prev) => {
      const filtered = prev.filter((op) => !(op.entityType === entityType && op.entityId === entityId));
      return [
        ...filtered,
        {
          id: `${entityType}_${entityId}`,
          entityType,
          entityId,
          operation,
          payloadSummary,
          queuedAt: new Date().toISOString(),
          retryCount: 0,
        },
      ];
    });
  };

  const handleSaveClient = (client: Client): string | null => {
    if (!client.businessName.trim() || !client.email.trim()) {
      return 'Business name and email are required.';
    }
    const existing = clients.find((c) => c.id === client.id);
    if (existing && existing.creditLimitCents !== client.creditLimitCents && role !== 'ADMIN') {
      return 'Only Administrators can modify client credit limits.';
    }
    const nextClient: Client = {
      ...client,
      syncState: isOnline ? 'SYNCED' : 'PENDING_UPLOAD',
      updatedAt: new Date().toISOString(),
    };
    setClients((prev) =>
      prev.some((c) => c.id === nextClient.id)
        ? prev.map((c) => (c.id === nextClient.id ? nextClient : c))
        : [nextClient, ...prev]
    );
    enqueueOp('CLIENT', nextClient.id, 'UPSERT', `Upsert ${nextClient.businessName}`);
    return null;
  };

  const handleDeleteClient = (id: string): string | null => {
    if (role !== 'ADMIN') {
      return 'Insufficient permissions: Staff role cannot delete wholesale records.';
    }
    const target = clients.find((c) => c.id === id);
    setClients((prev) => prev.filter((c) => c.id !== id));
    enqueueOp('CLIENT', id, 'DELETE', `Delete ${target?.businessName ?? id}`);
    return null;
  };

  const handleSaveProduct = (product: Product): string | null => {
    if (!product.sku.trim() || !product.name.trim()) {
      return 'SKU and product name are required.';
    }
    const nextProduct: Product = {
      ...product,
      syncState: isOnline ? 'SYNCED' : 'PENDING_UPLOAD',
      updatedAt: new Date().toISOString(),
    };
    setProducts((prev) =>
      prev.some((p) => p.id === nextProduct.id)
        ? prev.map((p) => (p.id === nextProduct.id ? nextProduct : p))
        : [nextProduct, ...prev]
    );
    enqueueOp('PRODUCT', nextProduct.id, 'UPSERT', `Upsert ${nextProduct.sku} (qty ${nextProduct.stockQuantity})`);
    if (nextProduct.stockQuantity <= nextProduct.reorderThreshold) {
      setActiveAlert({
        id: `alert_${Date.now()}`,
        channel: 'LOCAL_STOCK',
        title: `Low Stock: ${nextProduct.sku}`,
        body: `${nextProduct.name} dropped to ${nextProduct.stockQuantity} ${nextProduct.unitLabel} (threshold ${nextProduct.reorderThreshold}).`,
        timestamp: new Date().toISOString(),
      });
    }
    return null;
  };

  const handleDeleteProduct = (id: string): string | null => {
    if (role !== 'ADMIN') {
      return 'Insufficient permissions: Staff role cannot delete wholesale records.';
    }
    const target = products.find((p) => p.id === id);
    setProducts((prev) => prev.filter((p) => p.id !== id));
    enqueueOp('PRODUCT', id, 'DELETE', `Delete ${target?.sku ?? id}`);
    return null;
  };

  const handleSaveInvoice = (invoice: Invoice): string | null => {
    if (!invoice.clientId || invoice.items.length === 0) {
      return 'Invoice requires a client and at least one line item.';
    }
    const nextInvoice: Invoice = {
      ...invoice,
      syncState: isOnline ? 'SYNCED' : 'PENDING_UPLOAD',
      updatedAt: new Date().toISOString(),
    };
    setInvoices((prev) =>
      prev.some((i) => i.id === nextInvoice.id)
        ? prev.map((i) => (i.id === nextInvoice.id ? nextInvoice : i))
        : [nextInvoice, ...prev]
    );
    enqueueOp('INVOICE', nextInvoice.id, 'UPSERT', `Upsert ${nextInvoice.invoiceNumber}`);
    return null;
  };

  const handleDeleteInvoice = (id: string): string | null => {
    if (role !== 'ADMIN') {
      return 'Insufficient permissions: Staff role cannot delete wholesale records.';
    }
    const target = invoices.find((i) => i.id === id);
    setInvoices((prev) => prev.filter((i) => i.id !== id));
    enqueueOp('INVOICE', id, 'DELETE', `Delete ${target?.invoiceNumber ?? id}`);
    return null;
  };

  const handleDownloadAllSource = () => {
    const bundle = ANDROID_SOURCE_FILES.map(
      (f) => `================================================================================\nFILE: ${f.path}\nSUMMARY: ${f.summary}\n================================================================================\n\n${f.code}`
    ).join('\n\n');
    const blob = new Blob([bundle], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'WholesaleLedger-Android-MAD-Source.txt';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleOpenFileFromArchitecture = (fileId: string) => {
    setSelectedFileId(fileId);
    setSection('source');
  };

  const triggerSampleFcm = () => {
    setActiveAlert({
      id: `fcm_${Date.now()}`,
      channel: 'FCM_CRITICAL',
      title: 'Overdue Invoice Alert · INV-2026-1043',
      body: 'Pacific Provisions Market ($6,314.00) is 10 days past Net-15 terms.',
      timestamp: new Date().toISOString(),
    });
  };

  return (
    <div className="min-h-screen bg-neutral-50 dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 transition-colors">
      {/* 3-Zone Top Bar Contract */}
      <header className="border-b border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900">
        <div className="max-w-[1360px] mx-auto px-6 py-4 flex items-center justify-between gap-8">
          <a
            href="#top"
            onClick={(e) => {
              e.preventDefault();
              setSection('simulator');
            }}
            className="font-display text-lg font-bold tracking-tight text-neutral-900 dark:text-neutral-100 whitespace-nowrap shrink-0"
          >
            WholesaleLedger
          </a>

          <nav className="hidden md:flex items-center gap-6 text-sm font-medium">
            {(
              [
                { id: 'simulator', label: 'Interactive App' },
                { id: 'architecture', label: 'Architecture' },
                { id: 'source', label: 'Kotlin Source' },
                { id: 'tests', label: 'Tests & R8' },
              ] as { id: WorkspaceSection; label: string }[]
            ).map((nav) => (
              <button
                key={nav.id}
                type="button"
                onClick={() => {
                  setSection(nav.id);
                  if (nav.id === 'tests') {
                    setSelectedFileId('test-repository');
                  }
                }}
                className={`whitespace-nowrap shrink-0 pb-0.5 transition-colors ${
                  section === nav.id
                    ? 'text-blue-600 dark:text-blue-400 border-b-2 border-blue-600 dark:border-blue-400'
                    : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-100'
                }`}
              >
                {nav.label}
              </button>
            ))}
          </nav>

          <button
            type="button"
            onClick={handleDownloadAllSource}
            className="px-4 py-2 text-xs font-semibold rounded-lg bg-blue-600 hover:bg-blue-700 text-white transition-colors whitespace-nowrap shrink-0"
          >
            Download Kotlin Bundle
          </button>
        </div>
      </header>

      {/* Mobile Nav Bar */}
      <div className="md:hidden border-b border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 px-4 py-2 flex items-center gap-2 overflow-x-auto">
        {(
          [
            { id: 'simulator', label: 'Interactive App' },
            { id: 'architecture', label: 'Architecture' },
            { id: 'source', label: 'Kotlin Source' },
            { id: 'tests', label: 'Tests & R8' },
          ] as { id: WorkspaceSection; label: string }[]
        ).map((nav) => (
          <button
            key={nav.id}
            type="button"
            onClick={() => {
              setSection(nav.id);
              if (nav.id === 'tests') setSelectedFileId('test-repository');
            }}
            className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap shrink-0 ${
              section === nav.id
                ? 'bg-neutral-900 text-white dark:bg-neutral-100 dark:text-neutral-900'
                : 'text-neutral-600 dark:text-neutral-400'
            }`}
          >
            {nav.label}
          </button>
        ))}
      </div>

      <main className="max-w-[1360px] mx-auto px-6 py-8 space-y-6">
        {/* Hero Intro & Workspace Toolbar */}
        <section className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 pb-6 border-b border-neutral-200 dark:border-neutral-800">
          <div className="max-w-2xl">
            <p className="text-xs text-neutral-500 dark:text-neutral-400">
              Kotlin · Jetpack Compose Material 3 · Clean Architecture · Room + WorkManager · Hilt KSP
            </p>
            <h1 className="mt-1.5 text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100 [text-wrap:balance]">
              Offline-First B2B Wholesale Inventory, Invoicing &amp; Client Workbench
            </h1>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Form Factor Toggle */}
            <div className="inline-flex items-center p-1 rounded-lg bg-neutral-200/70 dark:bg-neutral-800">
              <button
                type="button"
                onClick={() => setFormFactor('phone')}
                className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  formFactor === 'phone'
                    ? 'bg-white dark:bg-neutral-900 text-neutral-900 dark:text-neutral-100 shadow-xs'
                    : 'text-neutral-600 dark:text-neutral-400'
                }`}
              >
                <Smartphone className="w-3.5 h-3.5" />
                Phone
              </button>
              <button
                type="button"
                onClick={() => setFormFactor('tablet')}
                className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  formFactor === 'tablet'
                    ? 'bg-white dark:bg-neutral-900 text-neutral-900 dark:text-neutral-100 shadow-xs'
                    : 'text-neutral-600 dark:text-neutral-400'
                }`}
              >
                <Tablet className="w-3.5 h-3.5" />
                Tablet
              </button>
            </div>

            {/* Online/Offline Network Switch */}
            <button
              type="button"
              onClick={() => setIsOnline((v) => !v)}
              className={`inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 ${
                isOnline
                  ? 'border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 text-neutral-800 dark:text-neutral-200'
                  : 'border-amber-300 dark:border-amber-700 bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-300'
              }`}
            >
              {isOnline ? <Wifi className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" /> : <WifiOff className="w-3.5 h-3.5" />}
              {isOnline ? 'Network: Online' : 'Network: Offline'}
            </button>

            {/* RBAC Role Switch */}
            <div className="inline-flex items-center p-1 rounded-lg bg-neutral-200/70 dark:bg-neutral-800">
              {(['ADMIN', 'STAFF'] as UserRole[]).map((r) => (
                <button
                  key={r}
                  type="button"
                  onClick={() => setRole(r)}
                  className={`px-2.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                    role === r
                      ? 'bg-white dark:bg-neutral-900 text-neutral-900 dark:text-neutral-100 shadow-xs'
                      : 'text-neutral-600 dark:text-neutral-400'
                  }`}
                >
                  {r === 'ADMIN' ? 'Admin' : 'Staff'}
                </button>
              ))}
            </div>

            {/* FCM Alert Trigger */}
            <button
              type="button"
              onClick={triggerSampleFcm}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 text-neutral-700 dark:text-neutral-200 hover:bg-neutral-50 dark:hover:bg-neutral-800 transition-colors whitespace-nowrap shrink-0"
            >
              <BellRing className="w-3.5 h-3.5" />
              Simulate FCM
            </button>

            {/* Theme Toggle */}
            <button
              type="button"
              onClick={() => setDarkMode((d) => !d)}
              aria-label={darkMode ? 'Switch to light theme' : 'Switch to dark theme'}
              className="p-2 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 text-neutral-700 dark:text-neutral-200 hover:bg-neutral-50 dark:hover:bg-neutral-800 transition-colors"
            >
              {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
          </div>
        </section>

        {/* Active View */}
        {section === 'simulator' && (
          <div className="grid grid-cols-1 xl:grid-cols-12 gap-8 items-start">
            <div className={formFactor === 'tablet' ? 'xl:col-span-8' : 'xl:col-span-6'}>
              <AndroidDeviceSimulator
                formFactor={formFactor}
                isOnline={isOnline}
                isBiometricUnlocked={isBiometricUnlocked}
                role={role}
                clients={clients}
                products={products}
                invoices={invoices}
                pendingCount={pendingOps.length}
                activeAlert={activeAlert}
                onUnlockBiometric={() => setIsBiometricUnlocked(true)}
                onLockVault={() => setIsBiometricUnlocked(false)}
                onSyncNow={flushSyncOutbox}
                onSaveClient={handleSaveClient}
                onDeleteClient={handleDeleteClient}
                onSaveProduct={handleSaveProduct}
                onDeleteProduct={handleDeleteProduct}
                onSaveInvoice={handleSaveInvoice}
                onDeleteInvoice={handleDeleteInvoice}
                onDismissAlert={() => setActiveAlert(null)}
              />
            </div>
            <div className={formFactor === 'tablet' ? 'xl:col-span-4' : 'xl:col-span-6'}>
              <RoomInspectorPanel
                clients={clients}
                products={products}
                invoices={invoices}
                pendingOps={pendingOps}
                isOnline={isOnline}
                isBiometricUnlocked={isBiometricUnlocked}
                role={role}
                onSyncNow={flushSyncOutbox}
              />
            </div>
          </div>
        )}

        {section === 'architecture' && (
          <ArchitectureBlueprintView onOpenFile={handleOpenFileFromArchitecture} />
        )}

        {section === 'source' && (
          <KotlinSourceExplorer
            key="source-all"
            selectedFileId={selectedFileId}
            onSelectFile={setSelectedFileId}
            moduleFilter="all"
          />
        )}

        {section === 'tests' && (
          <KotlinSourceExplorer
            key="source-tests"
            selectedFileId={selectedFileId}
            onSelectFile={setSelectedFileId}
            moduleFilter="tests"
          />
        )}
      </main>
    </div>
  );
}
