import { AndroidSourceFile } from '../types/wholesale';

export const GRADLE_DOMAIN_DATA_FILES: AndroidSourceFile[] = [
  {
    id: 'libs-versions-toml',
    path: 'gradle/libs.versions.toml',
    module: 'gradle',
    title: 'Version Catalog (libs.versions.toml)',
    language: 'toml',
    summary: 'Centralized MAD dependency catalog with Kotlin 2.1, Compose BOM, Hilt KSP, Room, Retrofit, Kotlinx Serialization, WorkManager, Biometric, and FCM.',
    code: `[versions]
agp = "8.8.0"
kotlin = "2.1.10"
ksp = "2.1.10-1.0.29"
composeBom = "2025.02.00"
material3Adaptive = "1.1.0"
hilt = "2.55"
hiltExt = "1.2.0"
room = "2.7.0"
datastore = "1.1.3"
navigationCompose = "2.8.8"
retrofit = "2.11.0"
okhttp = "4.12.0"
kotlinxSerialization = "1.8.0"
workManager = "2.10.0"
biometric = "1.1.0"
firebaseBom = "33.9.0"
coroutines = "1.10.1"
turbine = "1.2.0"
mockk = "1.13.16"
junit = "4.13.2"

[libraries]
androidx-core-ktx = { group = "androidx.core", name = "core-ktx", version = "1.15.0" }
androidx-activity-compose = { group = "androidx.activity", name = "activity-compose", version = "1.10.0" }
androidx-lifecycle-runtime-compose = { group = "androidx.lifecycle", name = "lifecycle-runtime-compose", version = "2.8.7" }
androidx-lifecycle-viewmodel-compose = { group = "androidx.lifecycle", name = "lifecycle-viewmodel-compose", version = "2.8.7" }

# Compose Material 3 & Adaptive
androidx-compose-bom = { group = "androidx.compose", name = "compose-bom", version.ref = "composeBom" }
androidx-compose-ui = { group = "androidx.compose.ui", name = "ui" }
androidx-compose-ui-tooling-preview = { group = "androidx.compose.ui", name = "ui-tooling-preview" }
androidx-compose-material3 = { group = "androidx.compose.material3", name = "material3" }
androidx-compose-material3-adaptive = { group = "androidx.compose.material3.adaptive", name = "adaptive", version.ref = "material3Adaptive" }
androidx-compose-material3-adaptive-layout = { group = "androidx.compose.material3.adaptive", name = "adaptive-layout", version.ref = "material3Adaptive" }
androidx-compose-material3-adaptive-nav = { group = "androidx.compose.material3.adaptive", name = "adaptive-navigation", version.ref = "material3Adaptive" }
androidx-compose-material-icons = { group = "androidx.compose.material", name = "material-icons-extended" }
androidx-navigation-compose = { group = "androidx.navigation", name = "navigation-compose", version.ref = "navigationCompose" }

# Hilt DI
hilt-android = { group = "com.google.dagger", name = "hilt-android", version.ref = "hilt" }
hilt-compiler = { group = "com.google.dagger", name = "hilt-android-compiler", version.ref = "hilt" }
hilt-navigation-compose = { group = "androidx.hilt", name = "hilt-navigation-compose", version.ref = "hiltExt" }
hilt-work = { group = "androidx.hilt", name = "hilt-work", version.ref = "hiltExt" }
hilt-ext-compiler = { group = "androidx.hilt", name = "hilt-compiler", version.ref = "hiltExt" }

# Room & DataStore
room-runtime = { group = "androidx.room", name = "room-runtime", version.ref = "room" }
room-ktx = { group = "androidx.room", name = "room-ktx", version.ref = "room" }
room-compiler = { group = "androidx.room", name = "room-compiler", version.ref = "room" }
datastore-preferences = { group = "androidx.datastore", name = "datastore-preferences", version.ref = "datastore" }

# Networking & Serialization
retrofit-core = { group = "com.squareup.retrofit2", name = "retrofit", version.ref = "retrofit" }
retrofit-kotlinx-serialization = { group = "com.squareup.retrofit2", name = "converter-kotlinx-serialization", version.ref = "retrofit" }
okhttp-logging = { group = "com.squareup.okhttp3", name = "logging-interceptor", version.ref = "okhttp" }
kotlinx-serialization-json = { group = "org.jetbrains.kotlinx", name = "kotlinx-serialization-json", version.ref = "kotlinxSerialization" }

# WorkManager, Security & FCM
work-runtime-ktx = { group = "androidx.work", name = "work-runtime-ktx", version.ref = "workManager" }
androidx-biometric = { group = "androidx.biometric", name = "biometric", version.ref = "biometric" }
firebase-bom = { group = "com.google.firebase", name = "firebase-bom", version.ref = "firebaseBom" }
firebase-messaging = { group = "com.google.firebase", name = "firebase-messaging-ktx" }

# Testing
junit = { group = "junit", name = "junit", version.ref = "junit" }
kotlinx-coroutines-test = { group = "org.jetbrains.kotlinx", name = "kotlinx-coroutines-test", version.ref = "coroutines" }
turbine = { group = "app.cash.turbine", name = "turbine", version.ref = "turbine" }
mockk = { group = "io.mockk", name = "mockk", version.ref = "mockk" }

[plugins]
android-application = { id = "com.android.application", version.ref = "agp" }
android-library = { id = "com.android.library", version.ref = "agp" }
kotlin-android = { id = "org.jetbrains.kotlin.android", version.ref = "kotlin" }
kotlin-jvm = { id = "org.jetbrains.kotlin.jvm", version.ref = "kotlin" }
kotlin-compose = { id = "org.jetbrains.kotlin.plugin.compose", version.ref = "kotlin" }
kotlin-serialization = { id = "org.jetbrains.kotlin.plugin.serialization", version.ref = "kotlin" }
hilt = { id = "com.google.dagger.hilt.android", version.ref = "hilt" }
ksp = { id = "com.google.devtools.ksp", version.ref = "ksp" }
`,
  },
  {
    id: 'settings-gradle',
    path: 'settings.gradle.kts',
    module: 'gradle',
    title: 'Multi-Module Settings (settings.gradle.kts)',
    language: 'kotlin',
    summary: 'Declares Clean Architecture modules (:app, :core:domain, :core:data, :core:presentation) with strict repository resolution.',
    code: `pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\\\.android.*")
                includeGroupByRegex("com\\\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "WholesaleLedger"
include(":app")
include(":core:domain")
include(":core:data")
include(":core:presentation")
`,
  },
  {
    id: 'app-build-gradle',
    path: 'app/build.gradle.kts',
    module: 'gradle',
    title: 'App Module Gradle (app/build.gradle.kts)',
    language: 'kotlin',
    summary: 'Configures release R8 shrinking, resource shrinking, Hilt KSP, Jetpack Compose, and module dependencies.',
    code: `plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.kotlin.serialization)
    alias(libs.plugins.hilt)
    alias(libs.plugins.ksp)
}

android {
    namespace = "com.wholesaleledger.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.wholesaleledger.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 104
        versionName = "1.4.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            applicationIdSuffix = ".debug"
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    implementation(project(":core:domain"))
    implementation(project(":core:data"))
    implementation(project(":core:presentation"))

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.material3)

    implementation(libs.hilt.android)
    ksp(libs.hilt.compiler)
    implementation(libs.hilt.work)
    ksp(libs.hilt.ext.compiler)

    implementation(libs.work.runtime.ktx)
    implementation(platform(libs.firebase.bom))
    implementation(libs.firebase.messaging)
}
`,
  },
  {
    id: 'domain-models',
    path: 'core/domain/src/main/kotlin/com/wholesaleledger/domain/model/Models.kt',
    module: 'domain',
    title: 'Domain Models (Models.kt)',
    language: 'kotlin',
    summary: 'Pure Kotlin immutable business entities (Client, Product, Invoice, InvoiceLineItem), RBAC UserRole, SyncState, and DashboardMetrics.',
    code: `package com.wholesaleledger.domain.model

import java.time.Instant

enum class UserRole {
    ADMIN,
    STAFF;

    val canDeleteRecords: Boolean get() = this == ADMIN
    val canExportFullLedger: Boolean get() = this == ADMIN
    val canAdjustCreditLimits: Boolean get() = this == ADMIN
}

enum class SyncState {
    SYNCED,
    PENDING_UPLOAD,
    PENDING_DELETE,
    CONFLICT
}

enum class InvoiceStatus {
    DRAFT,
    PENDING,
    PAID,
    OVERDUE
}

data class UserSession(
    val userId: String,
    val displayName: String,
    val email: String,
    val role: UserRole,
    val accessToken: String,
    val refreshToken: String,
    val expiresAtEpochMillis: Long
)

data class Client(
    val id: String,
    val businessName: String,
    val contactName: String,
    val email: String,
    val phone: String,
    val paymentTermsDays: Int,
    val creditLimitCents: Long,
    val outstandingBalanceCents: Long,
    val syncState: SyncState,
    val updatedAt: Instant
)

data class Product(
    val id: String,
    val sku: String,
    val name: String,
    val category: String,
    val unitPriceCents: Long,
    val stockQuantity: Int,
    val reorderThreshold: Int,
    val unitLabel: String,
    val syncState: SyncState,
    val updatedAt: Instant
) {
    val isLowStock: Boolean get() = stockQuantity <= reorderThreshold
}

data class InvoiceLineItem(
    val productId: String,
    val productName: String,
    val sku: String,
    val quantity: Int,
    val unitPriceCents: Long
) {
    val lineTotalCents: Long get() = quantity.toLong() * unitPriceCents
}

data class Invoice(
    val id: String,
    val invoiceNumber: String,
    val clientId: String,
    val clientName: String,
    val status: InvoiceStatus,
    val issuedDateIso: String,
    val dueDateIso: String,
    val items: List<InvoiceLineItem>,
    val totalCents: Long,
    val notes: String,
    val syncState: SyncState,
    val updatedAt: Instant
)

data class DashboardMetrics(
    val totalPaidRevenueCents: Long,
    val pendingReceivablesCents: Long,
    val overdueCount: Int,
    val lowStockProducts: List<Product>,
    val pendingSyncOperations: Int,
    val recentInvoices: List<Invoice>
)

sealed interface DomainResult<out T> {
    data class Success<T>(val data: T) : DomainResult<T>
    data class Error(val message: String, val cause: Throwable? = null) : DomainResult<Nothing>
}
`,
  },
  {
    id: 'domain-repository',
    path: 'core/domain/src/main/kotlin/com/wholesaleledger/domain/repository/WholesaleRepository.kt',
    module: 'domain',
    title: 'Repository Contract (WholesaleRepository.kt)',
    language: 'kotlin',
    summary: 'Clean Architecture repository boundary decoupling domain use cases from Room, Retrofit, Keystore, and WorkManager.',
    code: `package com.wholesaleledger.domain.repository

import com.wholesaleledger.domain.model.Client
import com.wholesaleledger.domain.model.DashboardMetrics
import com.wholesaleledger.domain.model.DomainResult
import com.wholesaleledger.domain.model.Invoice
import com.wholesaleledger.domain.model.InvoiceStatus
import com.wholesaleledger.domain.model.Product
import com.wholesaleledger.domain.model.UserSession
import kotlinx.coroutines.flow.Flow

interface WholesaleRepository {
    fun observeSession(): Flow<UserSession?>
    fun observeDashboardMetrics(): Flow<DashboardMetrics>
    fun observeClients(query: String): Flow<List<Client>>
    fun observeProducts(query: String, category: String?): Flow<List<Product>>
    fun observeInvoices(query: String, status: InvoiceStatus?): Flow<List<Invoice>>

    suspend fun getClientById(id: String): Client?
    suspend fun getProductById(id: String): Product?
    suspend fun getInvoiceById(id: String): Invoice?

    suspend fun upsertClient(client: Client): DomainResult<Client>
    suspend fun deleteClient(clientId: String): DomainResult<Unit>

    suspend fun upsertProduct(product: Product): DomainResult<Product>
    suspend fun deleteProduct(productId: String): DomainResult<Unit>

    suspend fun upsertInvoice(invoice: Invoice): DomainResult<Invoice>
    suspend fun deleteInvoice(invoiceId: String): DomainResult<Unit>

    suspend fun syncPendingOperations(): DomainResult<Int>
    suspend fun saveSession(session: UserSession)
    suspend fun clearSession()
    suspend fun registerFcmToken(token: String)
}
`,
  },
  {
    id: 'domain-usecases',
    path: 'core/domain/src/main/kotlin/com/wholesaleledger/domain/usecase/UseCases.kt',
    module: 'domain',
    title: 'Business Logic UseCases (UseCases.kt)',
    language: 'kotlin',
    summary: 'Encapsulates RBAC validation, invoice line-item totals calculation, low-stock threshold checks, and offline-first write orchestration.',
    code: `package com.wholesaleledger.domain.usecase

import com.wholesaleledger.domain.model.Client
import com.wholesaleledger.domain.model.DashboardMetrics
import com.wholesaleledger.domain.model.DomainResult
import com.wholesaleledger.domain.model.Invoice
import com.wholesaleledger.domain.model.InvoiceStatus
import com.wholesaleledger.domain.model.Product
import com.wholesaleledger.domain.model.SyncState
import com.wholesaleledger.domain.model.UserRole
import com.wholesaleledger.domain.repository.WholesaleRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import java.time.Instant
import java.util.UUID
import javax.inject.Inject

class ObserveDashboardMetricsUseCase @Inject constructor(
    private val repository: WholesaleRepository
) {
    operator fun invoke(): Flow<DashboardMetrics> = repository.observeDashboardMetrics()
}

class ObserveInventoryUseCase @Inject constructor(
    private val repository: WholesaleRepository
) {
    operator fun invoke(query: String, category: String?): Flow<List<Product>> =
        repository.observeProducts(query = query.trim(), category = category)
}

class ObserveClientsUseCase @Inject constructor(
    private val repository: WholesaleRepository
) {
    operator fun invoke(query: String): Flow<List<Client>> =
        repository.observeClients(query = query.trim())
}

class ObserveInvoicesUseCase @Inject constructor(
    private val repository: WholesaleRepository
) {
    operator fun invoke(query: String, status: InvoiceStatus?): Flow<List<Invoice>> =
        repository.observeInvoices(query = query.trim(), status = status)
}

class SaveProductUseCase @Inject constructor(
    private val repository: WholesaleRepository
) {
    suspend operator fun invoke(product: Product): DomainResult<Product> {
        if (product.sku.isBlank() || product.name.isBlank()) {
            return DomainResult.Error("SKU and product name are required.")
        }
        if (product.unitPriceCents < 0 || product.stockQuantity < 0) {
            return DomainResult.Error("Price and stock quantity must be zero or positive.")
        }
        val normalized = product.copy(
            id = product.id.ifBlank { UUID.randomUUID().toString() },
            sku = product.sku.trim().uppercase(),
            name = product.name.trim(),
            syncState = SyncState.PENDING_UPLOAD,
            updatedAt = Instant.now()
        )
        return repository.upsertProduct(normalized)
    }
}

class SaveClientUseCase @Inject constructor(
    private val repository: WholesaleRepository
) {
    suspend operator fun invoke(client: Client): DomainResult<Client> {
        if (client.businessName.isBlank() || client.email.isBlank()) {
            return DomainResult.Error("Business name and email are required.")
        }
        val session = repository.observeSession().first()
        val existing = if (client.id.isNotBlank()) repository.getClientById(client.id) else null
        if (existing != null &&
            existing.creditLimitCents != client.creditLimitCents &&
            session?.role != UserRole.ADMIN
        ) {
            return DomainResult.Error("Only Administrators can modify client credit limits.")
        }
        val normalized = client.copy(
            id = client.id.ifBlank { UUID.randomUUID().toString() },
            businessName = client.businessName.trim(),
            syncState = SyncState.PENDING_UPLOAD,
            updatedAt = Instant.now()
        )
        return repository.upsertClient(normalized)
    }
}

class SaveInvoiceUseCase @Inject constructor(
    private val repository: WholesaleRepository
) {
    suspend operator fun invoke(invoice: Invoice): DomainResult<Invoice> {
        if (invoice.clientId.isBlank() || invoice.items.isEmpty()) {
            return DomainResult.Error("An invoice requires a client and at least one line item.")
        }
        val calculatedTotal = invoice.items.sumOf { it.lineTotalCents }
        val normalized = invoice.copy(
            id = invoice.id.ifBlank { UUID.randomUUID().toString() },
            totalCents = calculatedTotal,
            syncState = SyncState.PENDING_UPLOAD,
            updatedAt = Instant.now()
        )
        return repository.upsertInvoice(normalized)
    }
}

class DeleteRecordWithRbacUseCase @Inject constructor(
    private val repository: WholesaleRepository
) {
    enum class TargetType { CLIENT, PRODUCT, INVOICE }

    suspend operator fun invoke(type: TargetType, id: String): DomainResult<Unit> {
        val session = repository.observeSession().first()
            ?: return DomainResult.Error("Authentication required to delete records.")

        if (!session.role.canDeleteRecords) {
            return DomainResult.Error("Insufficient permissions: Staff role cannot delete wholesale records.")
        }

        return when (type) {
            TargetType.CLIENT -> repository.deleteClient(id)
            TargetType.PRODUCT -> repository.deleteProduct(id)
            TargetType.INVOICE -> repository.deleteInvoice(id)
        }
    }
}

class TriggerOfflineSyncUseCase @Inject constructor(
    private val repository: WholesaleRepository
) {
    suspend operator fun invoke(): DomainResult<Int> = repository.syncPendingOperations()
}
`,
  },
  {
    id: 'data-entities',
    path: 'core/data/src/main/kotlin/com/wholesaleledger/data/local/Entities.kt',
    module: 'data',
    title: 'Room Entities & Outbox (Entities.kt)',
    language: 'kotlin',
    summary: 'Normalized SQLite schema with ForeignKey cascade rules, search indices, TypeConverters, and a transactional PendingSyncEntity outbox table.',
    code: `package com.wholesaleledger.data.local

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import com.wholesaleledger.domain.model.InvoiceStatus
import com.wholesaleledger.domain.model.SyncState
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Entity(
    tableName = "clients",
    indices = [Index(value = ["business_name"]), Index(value = ["sync_state"])]
)
data class ClientEntity(
    @PrimaryKey val id: String,
    @ColumnInfo(name = "business_name") val businessName: String,
    @ColumnInfo(name = "contact_name") val contactName: String,
    val email: String,
    val phone: String,
    @ColumnInfo(name = "payment_terms_days") val paymentTermsDays: Int,
    @ColumnInfo(name = "credit_limit_cents") val creditLimitCents: Long,
    @ColumnInfo(name = "outstanding_balance_cents") val outstandingBalanceCents: Long,
    @ColumnInfo(name = "sync_state") val syncState: SyncState,
    @ColumnInfo(name = "updated_at_epoch_ms") val updatedAtEpochMs: Long
)

@Entity(
    tableName = "products",
    indices = [Index(value = ["sku"], unique = true), Index(value = ["category"])]
)
data class ProductEntity(
    @PrimaryKey val id: String,
    val sku: String,
    val name: String,
    val category: String,
    @ColumnInfo(name = "unit_price_cents") val unitPriceCents: Long,
    @ColumnInfo(name = "stock_quantity") val stockQuantity: Int,
    @ColumnInfo(name = "reorder_threshold") val reorderThreshold: Int,
    @ColumnInfo(name = "unit_label") val unitLabel: String,
    @ColumnInfo(name = "sync_state") val syncState: SyncState,
    @ColumnInfo(name = "updated_at_epoch_ms") val updatedAtEpochMs: Long
)

@Serializable
data class InvoiceLineItemJson(
    val productId: String,
    val productName: String,
    val sku: String,
    val quantity: Int,
    val unitPriceCents: Long
)

@Entity(
    tableName = "invoices",
    foreignKeys = [
        ForeignKey(
            entity = ClientEntity::class,
            parentColumns = ["id"],
            childColumns = ["client_id"],
            onDelete = ForeignKey.RESTRICT
        )
    ],
    indices = [Index(value = ["client_id"]), Index(value = ["status"]), Index(value = ["invoice_number"], unique = true)]
)
data class InvoiceEntity(
    @PrimaryKey val id: String,
    @ColumnInfo(name = "invoice_number") val invoiceNumber: String,
    @ColumnInfo(name = "client_id") val clientId: String,
    @ColumnInfo(name = "client_name") val clientName: String,
    val status: InvoiceStatus,
    @ColumnInfo(name = "issued_date_iso") val issuedDateIso: String,
    @ColumnInfo(name = "due_date_iso") val dueDateIso: String,
    @ColumnInfo(name = "line_items_json") val lineItemsJson: String,
    @ColumnInfo(name = "total_cents") val totalCents: Long,
    val notes: String,
    @ColumnInfo(name = "sync_state") val syncState: SyncState,
    @ColumnInfo(name = "updated_at_epoch_ms") val updatedAtEpochMs: Long
)

@Entity(
    tableName = "pending_sync_ops",
    indices = [Index(value = ["entity_type", "entity_id"], unique = true)]
)
data class PendingSyncOpEntity(
    @PrimaryKey val id: String,
    @ColumnInfo(name = "entity_type") val entityType: String,
    @ColumnInfo(name = "entity_id") val entityId: String,
    val operation: String,
    @ColumnInfo(name = "payload_json") val payloadJson: String,
    @ColumnInfo(name = "queued_at_epoch_ms") val queuedAtEpochMs: Long,
    @ColumnInfo(name = "retry_count") val retryCount: Int = 0
)

class WholesaleTypeConverters {
    private val json = Json { ignoreUnknownKeys = true }

    @TypeConverter
    fun fromSyncState(value: SyncState): String = value.name

    @TypeConverter
    fun toSyncState(value: String): SyncState = SyncState.valueOf(value)

    @TypeConverter
    fun fromInvoiceStatus(value: InvoiceStatus): String = value.name

    @TypeConverter
    fun toInvoiceStatus(value: String): InvoiceStatus = InvoiceStatus.valueOf(value)

    @TypeConverter
    fun fromLineItems(items: List<InvoiceLineItemJson>): String = json.encodeToString(items)

    @TypeConverter
    fun toLineItems(raw: String): List<InvoiceLineItemJson> = json.decodeFromString(raw)
}
`,
  },
  {
    id: 'data-daos',
    path: 'core/data/src/main/kotlin/com/wholesaleledger/data/local/Daos.kt',
    module: 'data',
    title: 'Room DAOs & AppDatabase (Daos.kt)',
    language: 'kotlin',
    summary: 'Reactive Flow queries for instant local search/filtering, low-stock threshold alerts, and transactional outbox operations.',
    code: `package com.wholesaleledger.data.local

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.wholesaleledger.domain.model.InvoiceStatus
import com.wholesaleledger.domain.model.SyncState
import kotlinx.coroutines.flow.Flow

@Dao
interface ClientDao {
    @Query("""
        SELECT * FROM clients
        WHERE sync_state != 'PENDING_DELETE'
          AND (:query = '' OR business_name LIKE '%' || :query || '%' OR contact_name LIKE '%' || :query || '%')
        ORDER BY business_name ASC
    """)
    fun observeClients(query: String): Flow<List<ClientEntity>>

    @Query("SELECT * FROM clients WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): ClientEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(clients: List<ClientEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(client: ClientEntity)

    @Query("UPDATE clients SET sync_state = :state, updated_at_epoch_ms = :updatedAt WHERE id = :id")
    suspend fun markSyncState(id: String, state: SyncState, updatedAt: Long)

    @Query("DELETE FROM clients WHERE id = :id")
    suspend fun hardDelete(id: String)
}

@Dao
interface ProductDao {
    @Query("""
        SELECT * FROM products
        WHERE sync_state != 'PENDING_DELETE'
          AND (:category IS NULL OR category = :category)
          AND (:query = '' OR name LIKE '%' || :query || '%' OR sku LIKE '%' || :query || '%')
        ORDER BY name ASC
    """)
    fun observeProducts(query: String, category: String?): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE sync_state != 'PENDING_DELETE' AND stock_quantity <= reorder_threshold ORDER BY stock_quantity ASC")
    fun observeLowStockProducts(): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): ProductEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(products: List<ProductEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(product: ProductEntity)

    @Query("UPDATE products SET sync_state = :state, updated_at_epoch_ms = :updatedAt WHERE id = :id")
    suspend fun markSyncState(id: String, state: SyncState, updatedAt: Long)

    @Query("DELETE FROM products WHERE id = :id")
    suspend fun hardDelete(id: String)
}

@Dao
interface InvoiceDao {
    @Query("""
        SELECT * FROM invoices
        WHERE sync_state != 'PENDING_DELETE'
          AND (:status IS NULL OR status = :status)
          AND (:query = '' OR invoice_number LIKE '%' || :query || '%' OR client_name LIKE '%' || :query || '%')
        ORDER BY issued_date_iso DESC
    """)
    fun observeInvoices(query: String, status: InvoiceStatus?): Flow<List<InvoiceEntity>>

    @Query("SELECT COALESCE(SUM(total_cents), 0) FROM invoices WHERE status = 'PAID' AND sync_state != 'PENDING_DELETE'")
    fun observeTotalPaidRevenue(): Flow<Long>

    @Query("SELECT COALESCE(SUM(total_cents), 0) FROM invoices WHERE status IN ('PENDING', 'OVERDUE') AND sync_state != 'PENDING_DELETE'")
    fun observePendingReceivables(): Flow<Long>

    @Query("SELECT COUNT(*) FROM invoices WHERE status = 'OVERDUE' AND sync_state != 'PENDING_DELETE'")
    fun observeOverdueCount(): Flow<Int>

    @Query("SELECT * FROM invoices WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): InvoiceEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(invoices: List<InvoiceEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(invoice: InvoiceEntity)

    @Query("UPDATE invoices SET sync_state = :state, updated_at_epoch_ms = :updatedAt WHERE id = :id")
    suspend fun markSyncState(id: String, state: SyncState, updatedAt: Long)

    @Query("DELETE FROM invoices WHERE id = :id")
    suspend fun hardDelete(id: String)
}

@Dao
interface PendingSyncDao {
    @Query("SELECT COUNT(*) FROM pending_sync_ops")
    fun observePendingCount(): Flow<Int>

    @Query("SELECT * FROM pending_sync_ops ORDER BY queued_at_epoch_ms ASC")
    suspend fun getAllPending(): List<PendingSyncOpEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun enqueue(op: PendingSyncOpEntity)

    @Query("DELETE FROM pending_sync_ops WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("UPDATE pending_sync_ops SET retry_count = retry_count + 1 WHERE id = :id")
    suspend fun incrementRetry(id: String)
}

@Database(
    entities = [
        ClientEntity::class,
        ProductEntity::class,
        InvoiceEntity::class,
        PendingSyncOpEntity::class
    ],
    version = 1,
    exportSchema = true
)
@TypeConverters(WholesaleTypeConverters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun clientDao(): ClientDao
    abstract fun productDao(): ProductDao
    abstract fun invoiceDao(): InvoiceDao
    abstract fun pendingSyncDao(): PendingSyncDao
}
`,
  },
  {
    id: 'data-api-service',
    path: 'core/data/src/main/kotlin/com/wholesaleledger/data/remote/WholesaleApiService.kt',
    module: 'data',
    title: 'Retrofit API & DTOs (WholesaleApiService.kt)',
    language: 'kotlin',
    summary: 'Kotlinx Serialization DTOs and Retrofit suspend endpoints for pull deltas, idempotent upserts, deletes, and FCM token registration.',
    code: `package com.wholesaleledger.data.remote

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path
import retrofit2.http.Query

@Serializable
data class ClientDto(
    val id: String,
    @SerialName("business_name") val businessName: String,
    @SerialName("contact_name") val contactName: String,
    val email: String,
    val phone: String,
    @SerialName("payment_terms_days") val paymentTermsDays: Int,
    @SerialName("credit_limit_cents") val creditLimitCents: Long,
    @SerialName("outstanding_balance_cents") val outstandingBalanceCents: Long,
    @SerialName("updated_at_epoch_ms") val updatedAtEpochMs: Long
)

@Serializable
data class ProductDto(
    val id: String,
    val sku: String,
    val name: String,
    val category: String,
    @SerialName("unit_price_cents") val unitPriceCents: Long,
    @SerialName("stock_quantity") val stockQuantity: Int,
    @SerialName("reorder_threshold") val reorderThreshold: Int,
    @SerialName("unit_label") val unitLabel: String,
    @SerialName("updated_at_epoch_ms") val updatedAtEpochMs: Long
)

@Serializable
data class InvoiceLineItemDto(
    @SerialName("product_id") val productId: String,
    @SerialName("product_name") val productName: String,
    val sku: String,
    val quantity: Int,
    @SerialName("unit_price_cents") val unitPriceCents: Long
)

@Serializable
data class InvoiceDto(
    val id: String,
    @SerialName("invoice_number") val invoiceNumber: String,
    @SerialName("client_id") val clientId: String,
    @SerialName("client_name") val clientName: String,
    val status: String,
    @SerialName("issued_date_iso") val issuedDateIso: String,
    @SerialName("due_date_iso") val dueDateIso: String,
    val items: List<InvoiceLineItemDto>,
    @SerialName("total_cents") val totalCents: Long,
    val notes: String,
    @SerialName("updated_at_epoch_ms") val updatedAtEpochMs: Long
)

@Serializable
data class SyncDeltaResponse(
    val clients: List<ClientDto>,
    val products: List<ProductDto>,
    val invoices: List<InvoiceDto>,
    @SerialName("server_epoch_ms") val serverEpochMs: Long
)

@Serializable
data class FcmTokenRequest(
    val token: String,
    val platform: String = "ANDROID"
)

interface WholesaleApiService {
    @GET("v1/sync/delta")
    suspend fun fetchDelta(@Query("since") sinceEpochMs: Long): SyncDeltaResponse

    @PUT("v1/clients/{id}")
    suspend fun upsertClient(@Path("id") id: String, @Body dto: ClientDto): ClientDto

    @DELETE("v1/clients/{id}")
    suspend fun deleteClient(@Path("id") id: String)

    @PUT("v1/products/{id}")
    suspend fun upsertProduct(@Path("id") id: String, @Body dto: ProductDto): ProductDto

    @DELETE("v1/products/{id}")
    suspend fun deleteProduct(@Path("id") id: String)

    @PUT("v1/invoices/{id}")
    suspend fun upsertInvoice(@Path("id") id: String, @Body dto: InvoiceDto): InvoiceDto

    @DELETE("v1/invoices/{id}")
    suspend fun deleteInvoice(@Path("id") id: String)

    @POST("v1/notifications/fcm-token")
    suspend fun registerFcmToken(@Body body: FcmTokenRequest)
}
`,
  },
  {
    id: 'data-keystore',
    path: 'core/data/src/main/kotlin/com/wholesaleledger/data/security/AndroidKeystoreTokenManager.kt',
    module: 'data',
    title: 'Android Keystore AES-GCM + DataStore (AndroidKeystoreTokenManager.kt)',
    language: 'kotlin',
    summary: 'Non-deprecated hardware-backed AES-256-GCM encryption via AndroidKeyStore paired with Jetpack Preferences DataStore for session & role storage.',
    code: `package com.wholesaleledger.data.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.wholesaleledger.domain.model.UserRole
import com.wholesaleledger.domain.model.UserSession
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.inject.Inject
import javax.inject.Singleton

private val Context.secureSessionStore: DataStore<Preferences> by preferencesDataStore(
    name = "wholesale_secure_session"
)

@Serializable
private data class EncryptedSessionPayload(
    val userId: String,
    val displayName: String,
    val email: String,
    val role: String,
    val accessToken: String,
    val refreshToken: String,
    val expiresAtEpochMillis: Long
)

@Singleton
class AndroidKeystoreTokenManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val json = Json { ignoreUnknownKeys = true }
    private val keyAlias = "wholesale_ledger_session_aes_key"
    private val cipherTransformation = "AES/GCM/NoPadding"
    private val gcmTagLengthBits = 128

    private val encryptedSessionKey = stringPreferencesKey("encrypted_session_blob")
    private val lastSyncKey = longPreferencesKey("last_sync_epoch_ms")

    val sessionFlow: Flow<UserSession?> = context.secureSessionStore.data.map { prefs ->
        val encoded = prefs[encryptedSessionKey] ?: return@map null
        runCatching { decryptSession(encoded) }.getOrNull()
    }

    val lastSyncEpochFlow: Flow<Long> = context.secureSessionStore.data.map { prefs ->
        prefs[lastSyncKey] ?: 0L
    }

    suspend fun saveSession(session: UserSession) {
        val payload = EncryptedSessionPayload(
            userId = session.userId,
            displayName = session.displayName,
            email = session.email,
            role = session.role.name,
            accessToken = session.accessToken,
            refreshToken = session.refreshToken,
            expiresAtEpochMillis = session.expiresAtEpochMillis
        )
        val encryptedBlob = encryptString(json.encodeToString(payload))
        context.secureSessionStore.edit { prefs ->
            prefs[encryptedSessionKey] = encryptedBlob
        }
    }

    suspend fun clearSession() {
        context.secureSessionStore.edit { prefs ->
            prefs.remove(encryptedSessionKey)
        }
    }

    suspend fun updateLastSyncEpoch(epochMs: Long) {
        context.secureSessionStore.edit { prefs ->
            prefs[lastSyncKey] = epochMs
        }
    }

    private fun getOrCreateSecretKey(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existingKey = (keyStore.getEntry(keyAlias, null) as? KeyStore.SecretKeyEntry)?.secretKey
        if (existingKey != null) return existingKey

        val keyGenerator = KeyGenerator.getInstance(
            KeyProperties.KEY_ALGORITHM_AES,
            "AndroidKeyStore"
        )
        val spec = KeyGenParameterSpec.Builder(
            keyAlias,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .setRandomizedEncryptionRequired(true)
            .build()

        keyGenerator.init(spec)
        return keyGenerator.generateKey()
    }

    private fun encryptString(plaintext: String): String {
        val cipher = Cipher.getInstance(cipherTransformation)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateSecretKey())
        val iv = cipher.iv
        val ciphertext = cipher.doFinal(plaintext.toByteArray(Charsets.UTF_8))
        val combined = ByteArray(1 + iv.size + ciphertext.size)
        combined[0] = iv.size.toByte()
        System.arraycopy(iv, 0, combined, 1, iv.size)
        System.arraycopy(ciphertext, 0, combined, 1 + iv.size, ciphertext.size)
        return Base64.encodeToString(combined, Base64.NO_WRAP)
    }

    private fun decryptSession(encodedBlob: String): UserSession {
        val combined = Base64.decode(encodedBlob, Base64.NO_WRAP)
        val ivLength = combined[0].toInt()
        val iv = combined.copyOfRange(1, 1 + ivLength)
        val ciphertext = combined.copyOfRange(1 + ivLength, combined.size)

        val cipher = Cipher.getInstance(cipherTransformation)
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateSecretKey(), GCMParameterSpec(gcmTagLengthBits, iv))
        val plaintext = String(cipher.doFinal(ciphertext), Charsets.UTF_8)
        val payload = json.decodeFromString<EncryptedSessionPayload>(plaintext)

        return UserSession(
            userId = payload.userId,
            displayName = payload.displayName,
            email = payload.email,
            role = UserRole.valueOf(payload.role),
            accessToken = payload.accessToken,
            refreshToken = payload.refreshToken,
            expiresAtEpochMillis = payload.expiresAtEpochMillis
        )
    }
}
`,
  },
  {
    id: 'data-sync-worker',
    path: 'core/data/src/main/kotlin/com/wholesaleledger/data/sync/SyncWorker.kt',
    module: 'data',
    title: 'WorkManager SyncWorker & Scheduler (SyncWorker.kt)',
    language: 'kotlin',
    summary: 'HiltWorker with NetworkType.CONNECTED constraint and exponential backoff for guaranteed background cloud synchronization.',
    code: `package com.wholesaleledger.data.sync

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.wholesaleledger.domain.model.DomainResult
import com.wholesaleledger.domain.repository.WholesaleRepository
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@HiltWorker
class SyncWorker @AssistedInject constructor(
    @Assisted appContext: Context,
    @Assisted params: WorkerParameters,
    private val repository: WholesaleRepository
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        return when (repository.syncPendingOperations()) {
            is DomainResult.Success -> Result.success()
            is DomainResult.Error -> {
                if (runAttemptCount < MAX_RETRIES) Result.retry() else Result.failure()
            }
        }
    }

    companion object {
        private const val MAX_RETRIES = 4
        const val ONE_TIME_WORK_NAME = "wholesale_immediate_sync"
        const val PERIODIC_WORK_NAME = "wholesale_periodic_sync"
    }
}

@Singleton
class WholesaleSyncScheduler @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val networkConnectedConstraints = Constraints.Builder()
        .setRequiredNetworkType(NetworkType.CONNECTED)
        .setRequiresBatteryNotLow(true)
        .build()

    fun enqueueImmediateSync() {
        val request = OneTimeWorkRequestBuilder<SyncWorker>()
            .setConstraints(networkConnectedConstraints)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 15, TimeUnit.SECONDS)
            .build()

        WorkManager.getInstance(context).enqueueUniqueWork(
            SyncWorker.ONE_TIME_WORK_NAME,
            ExistingWorkPolicy.REPLACE,
            request
        )
    }

    fun schedulePeriodicSync() {
        val request = PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES)
            .setConstraints(networkConnectedConstraints)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
            .build()

        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            SyncWorker.PERIODIC_WORK_NAME,
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }
}
`,
  },
  {
    id: 'data-repository-impl',
    path: 'core/data/src/main/kotlin/com/wholesaleledger/data/repository/WholesaleRepositoryImpl.kt',
    module: 'data',
    title: 'Offline-First RepositoryImpl (WholesaleRepositoryImpl.kt)',
    language: 'kotlin',
    summary: 'Writes optimistically to Room + outbox transactionally, schedules WorkManager sync, and reconciles server deltas cleanly.',
    code: `package com.wholesaleledger.data.repository

import androidx.room.withTransaction
import com.wholesaleledger.data.local.AppDatabase
import com.wholesaleledger.data.local.ClientDao
import com.wholesaleledger.data.local.ClientEntity
import com.wholesaleledger.data.local.InvoiceDao
import com.wholesaleledger.data.local.InvoiceEntity
import com.wholesaleledger.data.local.InvoiceLineItemJson
import com.wholesaleledger.data.local.PendingSyncDao
import com.wholesaleledger.data.local.PendingSyncOpEntity
import com.wholesaleledger.data.local.ProductDao
import com.wholesaleledger.data.local.ProductEntity
import com.wholesaleledger.data.remote.ClientDto
import com.wholesaleledger.data.remote.FcmTokenRequest
import com.wholesaleledger.data.remote.InvoiceDto
import com.wholesaleledger.data.remote.InvoiceLineItemDto
import com.wholesaleledger.data.remote.ProductDto
import com.wholesaleledger.data.remote.WholesaleApiService
import com.wholesaleledger.data.security.AndroidKeystoreTokenManager
import com.wholesaleledger.data.sync.WholesaleSyncScheduler
import com.wholesaleledger.domain.model.Client
import com.wholesaleledger.domain.model.DashboardMetrics
import com.wholesaleledger.domain.model.DomainResult
import com.wholesaleledger.domain.model.Invoice
import com.wholesaleledger.domain.model.InvoiceLineItem
import com.wholesaleledger.domain.model.InvoiceStatus
import com.wholesaleledger.domain.model.Product
import com.wholesaleledger.domain.model.SyncState
import com.wholesaleledger.domain.model.UserSession
import com.wholesaleledger.domain.repository.WholesaleRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.time.Instant
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class WholesaleRepositoryImpl @Inject constructor(
    private val database: AppDatabase,
    private val clientDao: ClientDao,
    private val productDao: ProductDao,
    private val invoiceDao: InvoiceDao,
    private val pendingSyncDao: PendingSyncDao,
    private val apiService: WholesaleApiService,
    private val tokenManager: AndroidKeystoreTokenManager,
    private val syncScheduler: WholesaleSyncScheduler
) : WholesaleRepository {

    private val json = Json { ignoreUnknownKeys = true }

    override fun observeSession(): Flow<UserSession?> = tokenManager.sessionFlow

    override fun observeDashboardMetrics(): Flow<DashboardMetrics> = combine(
        invoiceDao.observeTotalPaidRevenue(),
        invoiceDao.observePendingReceivables(),
        invoiceDao.observeOverdueCount(),
        productDao.observeLowStockProducts(),
        pendingSyncDao.observePendingCount(),
        invoiceDao.observeInvoices(query = "", status = null)
    ) { values ->
        val paidRevenue = values[0] as Long
        val pendingReceivables = values[1] as Long
        val overdueCount = values[2] as Int
        @Suppress("UNCHECKED_CAST")
        val lowStock = (values[3] as List<ProductEntity>).map { it.toDomain() }
        val pendingOps = values[4] as Int
        @Suppress("UNCHECKED_CAST")
        val recent = (values[5] as List<InvoiceEntity>).take(5).map { it.toDomain(json) }

        DashboardMetrics(
            totalPaidRevenueCents = paidRevenue,
            pendingReceivablesCents = pendingReceivables,
            overdueCount = overdueCount,
            lowStockProducts = lowStock,
            pendingSyncOperations = pendingOps,
            recentInvoices = recent
        )
    }

    override fun observeClients(query: String): Flow<List<Client>> =
        clientDao.observeClients(query).map { list -> list.map { it.toDomain() } }

    override fun observeProducts(query: String, category: String?): Flow<List<Product>> =
        productDao.observeProducts(query, category).map { list -> list.map { it.toDomain() } }

    override fun observeInvoices(query: String, status: InvoiceStatus?): Flow<List<Invoice>> =
        invoiceDao.observeInvoices(query, status).map { list -> list.map { it.toDomain(json) } }

    override suspend fun getClientById(id: String): Client? = clientDao.getById(id)?.toDomain()

    override suspend fun getProductById(id: String): Product? = productDao.getById(id)?.toDomain()

    override suspend fun getInvoiceById(id: String): Invoice? = invoiceDao.getById(id)?.toDomain(json)

    override suspend fun upsertClient(client: Client): DomainResult<Client> = runCatching {
        val entity = client.toEntity()
        val dto = client.toDto()
        database.withTransaction {
            clientDao.upsert(entity)
            pendingSyncDao.enqueue(
                PendingSyncOpEntity(
                    id = "CLIENT_\${client.id}",
                    entityType = "CLIENT",
                    entityId = client.id,
                    operation = "UPSERT",
                    payloadJson = json.encodeToString(dto),
                    queuedAtEpochMs = System.currentTimeMillis()
                )
            )
        }
        syncScheduler.enqueueImmediateSync()
        client
    }.fold(
        onSuccess = { DomainResult.Success(it) },
        onFailure = { DomainResult.Error(it.localizedMessage ?: "Failed to save client locally.", it) }
    )

    override suspend fun deleteClient(clientId: String): DomainResult<Unit> = runCatching {
        database.withTransaction {
            clientDao.markSyncState(clientId, SyncState.PENDING_DELETE, System.currentTimeMillis())
            pendingSyncDao.enqueue(
                PendingSyncOpEntity(
                    id = "CLIENT_\$clientId",
                    entityType = "CLIENT",
                    entityId = clientId,
                    operation = "DELETE",
                    payloadJson = "{}",
                    queuedAtEpochMs = System.currentTimeMillis()
                )
            )
        }
        syncScheduler.enqueueImmediateSync()
    }.fold(
        onSuccess = { DomainResult.Success(Unit) },
        onFailure = { DomainResult.Error(it.localizedMessage ?: "Failed to delete client.", it) }
    )

    override suspend fun upsertProduct(product: Product): DomainResult<Product> = runCatching {
        val entity = product.toEntity()
        val dto = product.toDto()
        database.withTransaction {
            productDao.upsert(entity)
            pendingSyncDao.enqueue(
                PendingSyncOpEntity(
                    id = "PRODUCT_\${product.id}",
                    entityType = "PRODUCT",
                    entityId = product.id,
                    operation = "UPSERT",
                    payloadJson = json.encodeToString(dto),
                    queuedAtEpochMs = System.currentTimeMillis()
                )
            )
        }
        syncScheduler.enqueueImmediateSync()
        product
    }.fold(
        onSuccess = { DomainResult.Success(it) },
        onFailure = { DomainResult.Error(it.localizedMessage ?: "Failed to save product.", it) }
    )

    override suspend fun deleteProduct(productId: String): DomainResult<Unit> = runCatching {
        database.withTransaction {
            productDao.markSyncState(productId, SyncState.PENDING_DELETE, System.currentTimeMillis())
            pendingSyncDao.enqueue(
                PendingSyncOpEntity(
                    id = "PRODUCT_\$productId",
                    entityType = "PRODUCT",
                    entityId = productId,
                    operation = "DELETE",
                    payloadJson = "{}",
                    queuedAtEpochMs = System.currentTimeMillis()
                )
            )
        }
        syncScheduler.enqueueImmediateSync()
    }.fold(
        onSuccess = { DomainResult.Success(Unit) },
        onFailure = { DomainResult.Error(it.localizedMessage ?: "Failed to delete product.", it) }
    )

    override suspend fun upsertInvoice(invoice: Invoice): DomainResult<Invoice> = runCatching {
        val entity = invoice.toEntity(json)
        val dto = invoice.toDto()
        database.withTransaction {
            invoiceDao.upsert(entity)
            pendingSyncDao.enqueue(
                PendingSyncOpEntity(
                    id = "INVOICE_\${invoice.id}",
                    entityType = "INVOICE",
                    entityId = invoice.id,
                    operation = "UPSERT",
                    payloadJson = json.encodeToString(dto),
                    queuedAtEpochMs = System.currentTimeMillis()
                )
            )
        }
        syncScheduler.enqueueImmediateSync()
        invoice
    }.fold(
        onSuccess = { DomainResult.Success(it) },
        onFailure = { DomainResult.Error(it.localizedMessage ?: "Failed to save invoice.", it) }
    )

    override suspend fun deleteInvoice(invoiceId: String): DomainResult<Unit> = runCatching {
        database.withTransaction {
            invoiceDao.markSyncState(invoiceId, SyncState.PENDING_DELETE, System.currentTimeMillis())
            pendingSyncDao.enqueue(
                PendingSyncOpEntity(
                    id = "INVOICE_\$invoiceId",
                    entityType = "INVOICE",
                    entityId = invoiceId,
                    operation = "DELETE",
                    payloadJson = "{}",
                    queuedAtEpochMs = System.currentTimeMillis()
                )
            )
        }
        syncScheduler.enqueueImmediateSync()
    }.fold(
        onSuccess = { DomainResult.Success(Unit) },
        onFailure = { DomainResult.Error(it.localizedMessage ?: "Failed to delete invoice.", it) }
    )

    override suspend fun syncPendingOperations(): DomainResult<Int> = runCatching {
        val ops = pendingSyncDao.getAllPending()
        var syncedCount = 0

        for (op in ops) {
            try {
                pushOutboxOperation(op)
                pendingSyncDao.deleteById(op.id)
                syncedCount++
            } catch (ex: Exception) {
                pendingSyncDao.incrementRetry(op.id)
                throw ex
            }
        }

        val lastSync = tokenManager.lastSyncEpochFlow.first()
        val delta = apiService.fetchDelta(sinceEpochMs = lastSync)
        database.withTransaction {
            if (delta.clients.isNotEmpty()) {
                clientDao.upsertAll(delta.clients.map { it.toEntity() })
            }
            if (delta.products.isNotEmpty()) {
                productDao.upsertAll(delta.products.map { it.toEntity() })
            }
            if (delta.invoices.isNotEmpty()) {
                invoiceDao.upsertAll(delta.invoices.map { it.toEntity(json) })
            }
        }
        tokenManager.updateLastSyncEpoch(delta.serverEpochMs)
        syncedCount
    }.fold(
        onSuccess = { DomainResult.Success(it) },
        onFailure = { DomainResult.Error(it.localizedMessage ?: "Background sync paused until online.", it) }
    )

    private suspend fun pushOutboxOperation(op: PendingSyncOpEntity) {
        val now = System.currentTimeMillis()
        when (op.entityType) {
            "CLIENT" -> if (op.operation == "DELETE") {
                apiService.deleteClient(op.entityId)
                clientDao.hardDelete(op.entityId)
            } else {
                val dto = json.decodeFromString<ClientDto>(op.payloadJson)
                val remote = apiService.upsertClient(op.entityId, dto)
                clientDao.upsert(remote.toEntity())
            }
            "PRODUCT" -> if (op.operation == "DELETE") {
                apiService.deleteProduct(op.entityId)
                productDao.hardDelete(op.entityId)
            } else {
                val dto = json.decodeFromString<ProductDto>(op.payloadJson)
                val remote = apiService.upsertProduct(op.entityId, dto)
                productDao.upsert(remote.toEntity())
            }
            "INVOICE" -> if (op.operation == "DELETE") {
                apiService.deleteInvoice(op.entityId)
                invoiceDao.hardDelete(op.entityId)
            } else {
                val dto = json.decodeFromString<InvoiceDto>(op.payloadJson)
                val remote = apiService.upsertInvoice(op.entityId, dto)
                invoiceDao.upsert(remote.toEntity(json))
            }
        }
        if (op.operation == "UPSERT") {
            when (op.entityType) {
                "CLIENT" -> clientDao.markSyncState(op.entityId, SyncState.SYNCED, now)
                "PRODUCT" -> productDao.markSyncState(op.entityId, SyncState.SYNCED, now)
                "INVOICE" -> invoiceDao.markSyncState(op.entityId, SyncState.SYNCED, now)
            }
        }
    }

    override suspend fun saveSession(session: UserSession) = tokenManager.saveSession(session)

    override suspend fun clearSession() = tokenManager.clearSession()

    override suspend fun registerFcmToken(token: String) {
        runCatching { apiService.registerFcmToken(FcmTokenRequest(token = token)) }
    }
}

private fun ClientEntity.toDomain() = Client(
    id = id,
    businessName = businessName,
    contactName = contactName,
    email = email,
    phone = phone,
    paymentTermsDays = paymentTermsDays,
    creditLimitCents = creditLimitCents,
    outstandingBalanceCents = outstandingBalanceCents,
    syncState = syncState,
    updatedAt = Instant.ofEpochMilli(updatedAtEpochMs)
)

private fun Client.toEntity() = ClientEntity(
    id = id,
    businessName = businessName,
    contactName = contactName,
    email = email,
    phone = phone,
    paymentTermsDays = paymentTermsDays,
    creditLimitCents = creditLimitCents,
    outstandingBalanceCents = outstandingBalanceCents,
    syncState = syncState,
    updatedAtEpochMs = updatedAt.toEpochMilli()
)

private fun Client.toDto() = ClientDto(
    id = id,
    businessName = businessName,
    contactName = contactName,
    email = email,
    phone = phone,
    paymentTermsDays = paymentTermsDays,
    creditLimitCents = creditLimitCents,
    outstandingBalanceCents = outstandingBalanceCents,
    updatedAtEpochMs = updatedAt.toEpochMilli()
)

private fun ClientDto.toEntity() = ClientEntity(
    id = id,
    businessName = businessName,
    contactName = contactName,
    email = email,
    phone = phone,
    paymentTermsDays = paymentTermsDays,
    creditLimitCents = creditLimitCents,
    outstandingBalanceCents = outstandingBalanceCents,
    syncState = SyncState.SYNCED,
    updatedAtEpochMs = updatedAtEpochMs
)

private fun ProductEntity.toDomain() = Product(
    id = id,
    sku = sku,
    name = name,
    category = category,
    unitPriceCents = unitPriceCents,
    stockQuantity = stockQuantity,
    reorderThreshold = reorderThreshold,
    unitLabel = unitLabel,
    syncState = syncState,
    updatedAt = Instant.ofEpochMilli(updatedAtEpochMs)
)

private fun Product.toEntity() = ProductEntity(
    id = id,
    sku = sku,
    name = name,
    category = category,
    unitPriceCents = unitPriceCents,
    stockQuantity = stockQuantity,
    reorderThreshold = reorderThreshold,
    unitLabel = unitLabel,
    syncState = syncState,
    updatedAtEpochMs = updatedAt.toEpochMilli()
)

private fun Product.toDto() = ProductDto(
    id = id,
    sku = sku,
    name = name,
    category = category,
    unitPriceCents = unitPriceCents,
    stockQuantity = stockQuantity,
    reorderThreshold = reorderThreshold,
    unitLabel = unitLabel,
    updatedAtEpochMs = updatedAt.toEpochMilli()
)

private fun ProductDto.toEntity() = ProductEntity(
    id = id,
    sku = sku,
    name = name,
    category = category,
    unitPriceCents = unitPriceCents,
    stockQuantity = stockQuantity,
    reorderThreshold = reorderThreshold,
    unitLabel = unitLabel,
    syncState = SyncState.SYNCED,
    updatedAtEpochMs = updatedAtEpochMs
)

private fun InvoiceEntity.toDomain(json: Json): Invoice {
    val parsedItems = json.decodeFromString<List<InvoiceLineItemJson>>(lineItemsJson).map {
        InvoiceLineItem(
            productId = it.productId,
            productName = it.productName,
            sku = it.sku,
            quantity = it.quantity,
            unitPriceCents = it.unitPriceCents
        )
    }
    return Invoice(
        id = id,
        invoiceNumber = invoiceNumber,
        clientId = clientId,
        clientName = clientName,
        status = status,
        issuedDateIso = issuedDateIso,
        dueDateIso = dueDateIso,
        items = parsedItems,
        totalCents = totalCents,
        notes = notes,
        syncState = syncState,
        updatedAt = Instant.ofEpochMilli(updatedAtEpochMs)
    )
}

private fun Invoice.toEntity(json: Json): InvoiceEntity {
    val lineItems = items.map {
        InvoiceLineItemJson(it.productId, it.productName, it.sku, it.quantity, it.unitPriceCents)
    }
    return InvoiceEntity(
        id = id,
        invoiceNumber = invoiceNumber,
        clientId = clientId,
        clientName = clientName,
        status = status,
        issuedDateIso = issuedDateIso,
        dueDateIso = dueDateIso,
        lineItemsJson = json.encodeToString(lineItems),
        totalCents = totalCents,
        notes = notes,
        syncState = syncState,
        updatedAtEpochMs = updatedAt.toEpochMilli()
    )
}

private fun Invoice.toDto() = InvoiceDto(
    id = id,
    invoiceNumber = invoiceNumber,
    clientId = clientId,
    clientName = clientName,
    status = status.name,
    issuedDateIso = issuedDateIso,
    dueDateIso = dueDateIso,
    items = items.map {
        InvoiceLineItemDto(it.productId, it.productName, it.sku, it.quantity, it.unitPriceCents)
    },
    totalCents = totalCents,
    notes = notes,
    updatedAtEpochMs = updatedAt.toEpochMilli()
)

private fun InvoiceDto.toEntity(json: Json) = InvoiceEntity(
    id = id,
    invoiceNumber = invoiceNumber,
    clientId = clientId,
    clientName = clientName,
    status = InvoiceStatus.valueOf(status),
    issuedDateIso = issuedDateIso,
    dueDateIso = dueDateIso,
    lineItemsJson = json.encodeToString(
        items.map { InvoiceLineItemJson(it.productId, it.productName, it.sku, it.quantity, it.unitPriceCents) }
    ),
    totalCents = totalCents,
    notes = notes,
    syncState = SyncState.SYNCED,
    updatedAtEpochMs = updatedAtEpochMs
)
`,
  },
  {
    id: 'data-hilt-module',
    path: 'core/data/src/main/kotlin/com/wholesaleledger/data/di/DataModule.kt',
    module: 'data',
    title: 'Hilt DI Bindings (DataModule.kt)',
    language: 'kotlin',
    summary: 'Provides Room AppDatabase, DAOs, OkHttp auth interceptor reading Keystore tokens, Retrofit Kotlinx Serialization client, and Repository binding.',
    code: `package com.wholesaleledger.data.di

import android.content.Context
import androidx.room.Room
import com.wholesaleledger.data.local.AppDatabase
import com.wholesaleledger.data.local.ClientDao
import com.wholesaleledger.data.local.InvoiceDao
import com.wholesaleledger.data.local.PendingSyncDao
import com.wholesaleledger.data.local.ProductDao
import com.wholesaleledger.data.remote.WholesaleApiService
import com.wholesaleledger.data.repository.WholesaleRepositoryImpl
import com.wholesaleledger.data.security.AndroidKeystoreTokenManager
import com.wholesaleledger.domain.repository.WholesaleRepository
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.json.Json
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DataProvidersModule {

    @Provides
    @Singleton
    fun provideJson(): Json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): AppDatabase =
        Room.databaseBuilder(
            context,
            AppDatabase::class.java,
            "wholesale_ledger.db"
        ).fallbackToDestructiveMigration(dropAllTables = false).build()

    @Provides fun provideClientDao(db: AppDatabase): ClientDao = db.clientDao()
    @Provides fun provideProductDao(db: AppDatabase): ProductDao = db.productDao()
    @Provides fun provideInvoiceDao(db: AppDatabase): InvoiceDao = db.invoiceDao()
    @Provides fun providePendingSyncDao(db: AppDatabase): PendingSyncDao = db.pendingSyncDao()

    @Provides
    @Singleton
    fun provideOkHttpClient(tokenManager: AndroidKeystoreTokenManager): OkHttpClient {
        val authInterceptor = Interceptor { chain ->
            val token = runBlocking { tokenManager.sessionFlow.first()?.accessToken }
            val request = chain.request().newBuilder().apply {
                if (!token.isNullOrBlank()) {
                    header("Authorization", "Bearer \$token")
                }
            }.build()
            chain.proceed(request)
        }
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        }
        return OkHttpClient.Builder()
            .addInterceptor(authInterceptor)
            .addInterceptor(logging)
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .build()
    }

    @Provides
    @Singleton
    fun provideWholesaleApi(okHttpClient: OkHttpClient, json: Json): WholesaleApiService {
        val contentType = "application/json".toMediaType()
        return Retrofit.Builder()
            .baseUrl("https://api.wholesaleledger.internal/")
            .client(okHttpClient)
            .addConverterFactory(json.asConverterFactory(contentType))
            .build()
            .create(WholesaleApiService::class.java)
    }
}

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryBindingsModule {
    @Binds
    @Singleton
    abstract fun bindWholesaleRepository(impl: WholesaleRepositoryImpl): WholesaleRepository
}
`,
  },
];
