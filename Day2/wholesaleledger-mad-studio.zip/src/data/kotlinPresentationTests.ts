import { AndroidSourceFile } from '../types/wholesale';

export const PRESENTATION_TEST_FILES: AndroidSourceFile[] = [
  {
    id: 'pres-routes',
    path: 'core/presentation/src/main/kotlin/com/wholesaleledger/presentation/navigation/AppRoutes.kt',
    module: 'presentation',
    title: 'Type-Safe Navigation Routes (AppRoutes.kt)',
    language: 'kotlin',
    summary: 'Kotlinx Serialization typed routes for Jetpack Navigation Compose 2.8+ with adaptive entity destination arguments.',
    code: `package com.wholesaleledger.presentation.navigation

import kotlinx.serialization.Serializable

enum class EntitySection {
    CLIENTS,
    PRODUCTS,
    INVOICES
}

sealed interface AppRoute {
    @Serializable
    data object BiometricGate : AppRoute

    @Serializable
    data object Dashboard : AppRoute

    @Serializable
    data class EntityList(val section: EntitySection) : AppRoute

    @Serializable
    data class EntityDetailEdit(
        val section: EntitySection,
        val entityId: String? = null
    ) : AppRoute
}
`,
  },
  {
    id: 'pres-biometric',
    path: 'core/presentation/src/main/kotlin/com/wholesaleledger/presentation/security/BiometricAuthManager.kt',
    module: 'presentation',
    title: 'BiometricPrompt Manager (BiometricAuthManager.kt)',
    language: 'kotlin',
    summary: 'Hardware-backed BiometricPrompt helper supporting Class 3 Biometrics and device credentials with clean suspend/callback bridging.',
    code: `package com.wholesaleledger.presentation.security

import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import javax.inject.Inject

sealed interface BiometricOutcome {
    data object Authenticated : BiometricOutcome
    data class Failed(val reason: String) : BiometricOutcome
    data object Unavailable : BiometricOutcome
}

class BiometricAuthManager @Inject constructor() {

    fun canAuthenticate(activity: FragmentActivity): Boolean {
        val manager = BiometricManager.from(activity)
        val result = manager.canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_STRONG or
                BiometricManager.Authenticators.DEVICE_CREDENTIAL
        )
        return result == BiometricManager.BIOMETRIC_SUCCESS
    }

    fun authenticate(
        activity: FragmentActivity,
        title: String = "Unlock WholesaleLedger",
        subtitle: String = "Verify identity to decrypt workspace session",
        onResult: (BiometricOutcome) -> Unit
    ) {
        if (!canAuthenticate(activity)) {
            onResult(BiometricOutcome.Unavailable)
            return
        }

        val executor = ContextCompat.getMainExecutor(activity)
        val callback = object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                super.onAuthenticationSucceeded(result)
                onResult(BiometricOutcome.Authenticated)
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                super.onAuthenticationError(errorCode, errString)
                onResult(BiometricOutcome.Failed(errString.toString()))
            }

            override fun onAuthenticationFailed() {
                super.onAuthenticationFailed()
                onResult(BiometricOutcome.Failed("Biometric signature not recognized."))
            }
        }

        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setSubtitle(subtitle)
            .setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_STRONG or
                    BiometricManager.Authenticators.DEVICE_CREDENTIAL
            )
            .build()

        BiometricPrompt(activity, executor, callback).authenticate(promptInfo)
    }
}
`,
  },
  {
    id: 'pres-dashboard-vm',
    path: 'core/presentation/src/main/kotlin/com/wholesaleledger/presentation/dashboard/DashboardViewModel.kt',
    module: 'presentation',
    title: 'DashboardViewModel (DashboardViewModel.kt)',
    language: 'kotlin',
    summary: 'UDF ViewModel exposing immutable DashboardUiState via StateFlow, handling manual sync, RBAC role switching, and one-shot Snackbar/Share events.',
    code: `package com.wholesaleledger.presentation.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wholesaleledger.domain.model.DashboardMetrics
import com.wholesaleledger.domain.model.DomainResult
import com.wholesaleledger.domain.model.Invoice
import com.wholesaleledger.domain.model.Product
import com.wholesaleledger.domain.model.UserRole
import com.wholesaleledger.domain.model.UserSession
import com.wholesaleledger.domain.repository.WholesaleRepository
import com.wholesaleledger.domain.usecase.ObserveDashboardMetricsUseCase
import com.wholesaleledger.domain.usecase.TriggerOfflineSyncUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class DashboardUiState(
    val isLoading: Boolean = true,
    val isSyncing: Boolean = false,
    val session: UserSession? = null,
    val totalPaidRevenueCents: Long = 0L,
    val pendingReceivablesCents: Long = 0L,
    val overdueCount: Int = 0,
    val lowStockProducts: List<Product> = emptyList(),
    val pendingSyncOperations: Int = 0,
    val recentInvoices: List<Invoice> = emptyList()
) {
    val canExportLedger: Boolean get() = session?.role?.canExportFullLedger == true
}

sealed interface DashboardEvent {
    data class ShowMessage(val message: String) : DashboardEvent
}

@HiltViewModel
class DashboardViewModel @Inject constructor(
    observeDashboardMetrics: ObserveDashboardMetricsUseCase,
    private val repository: WholesaleRepository,
    private val triggerOfflineSync: TriggerOfflineSyncUseCase
) : ViewModel() {

    private val isSyncingFlow = MutableStateFlow(false)
    private val _events = Channel<DashboardEvent>(Channel.BUFFERED)
    val events = _events.receiveAsFlow()

    val uiState: StateFlow<DashboardUiState> = combine(
        observeDashboardMetrics(),
        repository.observeSession(),
        isSyncingFlow
    ) { metrics: DashboardMetrics, session: UserSession?, syncing: Boolean ->
        DashboardUiState(
            isLoading = false,
            isSyncing = syncing,
            session = session,
            totalPaidRevenueCents = metrics.totalPaidRevenueCents,
            pendingReceivablesCents = metrics.pendingReceivablesCents,
            overdueCount = metrics.overdueCount,
            lowStockProducts = metrics.lowStockProducts,
            pendingSyncOperations = metrics.pendingSyncOperations,
            recentInvoices = metrics.recentInvoices
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = DashboardUiState()
    )

    fun onSyncNowClicked() {
        if (isSyncingFlow.value) return
        viewModelScope.launch {
            isSyncingFlow.value = true
            when (val result = triggerOfflineSync()) {
                is DomainResult.Success -> _events.send(
                    DashboardEvent.ShowMessage("Synced \${result.data} queued change(s) with server.")
                )
                is DomainResult.Error -> _events.send(
                    DashboardEvent.ShowMessage(result.message)
                )
            }
            isSyncingFlow.value = false
        }
    }

    fun onRoleSwitchForSession(newRole: UserRole) {
        viewModelScope.launch {
            val current = uiState.value.session ?: return@launch
            repository.saveSession(current.copy(role = newRole))
            _events.send(DashboardEvent.ShowMessage("Active role switched to \${newRole.name}"))
        }
    }
}
`,
  },
  {
    id: 'pres-list-detail-vm',
    path: 'core/presentation/src/main/kotlin/com/wholesaleledger/presentation/entities/ListAndDetailViewModels.kt',
    module: 'presentation',
    title: 'List & DetailEdit ViewModels (ListAndDetailViewModels.kt)',
    language: 'kotlin',
    summary: 'Reactive local Room search/filtering ViewModel + full CRUD DetailEditViewModel with RBAC delete enforcement and CSV/PDF export triggers.',
    code: `package com.wholesaleledger.presentation.entities

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.toRoute
import com.wholesaleledger.domain.model.Client
import com.wholesaleledger.domain.model.DomainResult
import com.wholesaleledger.domain.model.Invoice
import com.wholesaleledger.domain.model.InvoiceStatus
import com.wholesaleledger.domain.model.Product
import com.wholesaleledger.domain.model.SyncState
import com.wholesaleledger.domain.model.UserRole
import com.wholesaleledger.domain.repository.WholesaleRepository
import com.wholesaleledger.domain.usecase.DeleteRecordWithRbacUseCase
import com.wholesaleledger.domain.usecase.ObserveClientsUseCase
import com.wholesaleledger.domain.usecase.ObserveInventoryUseCase
import com.wholesaleledger.domain.usecase.ObserveInvoicesUseCase
import com.wholesaleledger.domain.usecase.SaveClientUseCase
import com.wholesaleledger.domain.usecase.SaveInvoiceUseCase
import com.wholesaleledger.domain.usecase.SaveProductUseCase
import com.wholesaleledger.presentation.navigation.AppRoute
import com.wholesaleledger.presentation.navigation.EntitySection
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import javax.inject.Inject

data class EntityListUiState(
    val section: EntitySection = EntitySection.PRODUCTS,
    val searchQuery: String = "",
    val selectedCategory: String? = null,
    val selectedInvoiceStatus: InvoiceStatus? = null,
    val clients: List<Client> = emptyList(),
    val products: List<Product> = emptyList(),
    val invoices: List<Invoice> = emptyList(),
    val userRole: UserRole = UserRole.STAFF
)

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class EntityListViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val observeClients: ObserveClientsUseCase,
    private val observeInventory: ObserveInventoryUseCase,
    private val observeInvoices: ObserveInvoicesUseCase,
    private val deleteRecord: DeleteRecordWithRbacUseCase,
    repository: WholesaleRepository
) : ViewModel() {

    private val route = savedStateHandle.toRoute<AppRoute.EntityList>()
    private val queryFlow = MutableStateFlow("")
    private val categoryFlow = MutableStateFlow<String?>(null)
    private val statusFlow = MutableStateFlow<InvoiceStatus?>(null)
    private val _messages = Channel<String>(Channel.BUFFERED)
    val messages = _messages.receiveAsFlow()

    private val clientsFlow = queryFlow.flatMapLatest { observeClients(it) }
    private val productsFlow = combine(queryFlow, categoryFlow) { q, c -> q to c }
        .flatMapLatest { (q, c) -> observeInventory(q, c) }
    private val invoicesFlow = combine(queryFlow, statusFlow) { q, s -> q to s }
        .flatMapLatest { (q, s) -> observeInvoices(q, s) }

    val uiState: StateFlow<EntityListUiState> = combine(
        queryFlow,
        categoryFlow,
        statusFlow,
        clientsFlow,
        productsFlow,
        invoicesFlow,
        repository.observeSession()
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        EntityListUiState(
            section = route.section,
            searchQuery = values[0] as String,
            selectedCategory = values[1] as String?,
            selectedInvoiceStatus = values[2] as InvoiceStatus?,
            clients = values[3] as List<Client>,
            products = values[4] as List<Product>,
            invoices = values[5] as List<Invoice>,
            userRole = (values[6] as? com.wholesaleledger.domain.model.UserSession)?.role ?: UserRole.STAFF
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = EntityListUiState(section = route.section)
    )

    fun onQueryChanged(query: String) { queryFlow.value = query }
    fun onCategorySelected(category: String?) { categoryFlow.value = category }
    fun onInvoiceStatusSelected(status: InvoiceStatus?) { statusFlow.value = status }

    fun onDeleteEntity(type: DeleteRecordWithRbacUseCase.TargetType, id: String) {
        viewModelScope.launch {
            when (val res = deleteRecord(type, id)) {
                is DomainResult.Success -> _messages.send("Record queued for deletion.")
                is DomainResult.Error -> _messages.send(res.message)
            }
        }
    }
}

data class DetailEditUiState(
    val section: EntitySection = EntitySection.PRODUCTS,
    val isNew: Boolean = true,
    val isSaving: Boolean = false,
    val errorMessage: String? = null,
    val savedSuccessfully: Boolean = false,
    val product: Product = Product(
        id = "", sku = "", name = "", category = "Coffee & Tea",
        unitPriceCents = 0L, stockQuantity = 0, reorderThreshold = 10,
        unitLabel = "case", syncState = SyncState.PENDING_UPLOAD, updatedAt = Instant.now()
    ),
    val client: Client = Client(
        id = "", businessName = "", contactName = "", email = "", phone = "",
        paymentTermsDays = 30, creditLimitCents = 1_000_000L, outstandingBalanceCents = 0L,
        syncState = SyncState.PENDING_UPLOAD, updatedAt = Instant.now()
    ),
    val invoice: Invoice = Invoice(
        id = "", invoiceNumber = "INV-\${LocalDate.now().year}-\${(1000..9999).random()}",
        clientId = "", clientName = "", status = InvoiceStatus.PENDING,
        issuedDateIso = LocalDate.now().toString(),
        dueDateIso = LocalDate.now().plusDays(30).toString(),
        items = emptyList(), totalCents = 0L, notes = "",
        syncState = SyncState.PENDING_UPLOAD, updatedAt = Instant.now()
    ),
    val availableClients: List<Client> = emptyList(),
    val availableProducts: List<Product> = emptyList()
)

@HiltViewModel
class DetailEditViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val repository: WholesaleRepository,
    private val saveProduct: SaveProductUseCase,
    private val saveClient: SaveClientUseCase,
    private val saveInvoice: SaveInvoiceUseCase
) : ViewModel() {

    private val route = savedStateHandle.toRoute<AppRoute.EntityDetailEdit>()
    private val _uiState = MutableStateFlow(
        DetailEditUiState(section = route.section, isNew = route.entityId == null)
    )
    val uiState: StateFlow<DetailEditUiState> = _uiState

    init {
        viewModelScope.launch {
            route.entityId?.let { id ->
                when (route.section) {
                    EntitySection.PRODUCTS -> repository.getProductById(id)?.let { prod ->
                        _uiState.update { it.copy(product = prod) }
                    }
                    EntitySection.CLIENTS -> repository.getClientById(id)?.let { cli ->
                        _uiState.update { it.copy(client = cli) }
                    }
                    EntitySection.INVOICES -> repository.getInvoiceById(id)?.let { inv ->
                        _uiState.update { it.copy(invoice = inv) }
                    }
                }
            }
        }
    }

    fun updateProduct(transform: (Product) -> Product) {
        _uiState.update { it.copy(product = transform(it.product), errorMessage = null) }
    }

    fun updateClient(transform: (Client) -> Client) {
        _uiState.update { it.copy(client = transform(it.client), errorMessage = null) }
    }

    fun updateInvoice(transform: (Invoice) -> Invoice) {
        _uiState.update { it.copy(invoice = transform(it.invoice), errorMessage = null) }
    }

    fun onSave() {
        val state = _uiState.value
        if (state.isSaving) return
        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true, errorMessage = null) }
            val result: DomainResult<*> = when (state.section) {
                EntitySection.PRODUCTS -> saveProduct(state.product)
                EntitySection.CLIENTS -> saveClient(state.client)
                EntitySection.INVOICES -> saveInvoice(state.invoice)
            }
            when (result) {
                is DomainResult.Success -> _uiState.update {
                    it.copy(isSaving = false, savedSuccessfully = true)
                }
                is DomainResult.Error -> _uiState.update {
                    it.copy(isSaving = false, errorMessage = result.message)
                }
            }
        }
    }
}
`,
  },
  {
    id: 'pres-theme',
    path: 'core/presentation/src/main/kotlin/com/wholesaleledger/presentation/theme/WholesaleTheme.kt',
    module: 'presentation',
    title: 'Material 3 Dynamic Theme (WholesaleTheme.kt)',
    language: 'kotlin',
    summary: 'Supports Android 12+ Dynamic Color, curated slate-indigo & emerald light/dark fallback palettes, and edge-to-edge Window insets.',
    code: `package com.wholesaleledger.presentation.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val LightColors = lightColorScheme(
    primary = Color(0xFF1D4ED8),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDBEAFE),
    onPrimaryContainer = Color(0xFF1E3A8A),
    secondary = Color(0xFF0F766E),
    onSecondary = Color.White,
    background = Color(0xFFF8FAFC),
    onBackground = Color(0xFF0F172A),
    surface = Color.White,
    onSurface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFFF1F5F9),
    onSurfaceVariant = Color(0xFF475569),
    error = Color(0xFFDC2626)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF60A5FA),
    onPrimary = Color(0xFF0F172A),
    primaryContainer = Color(0xFF1E3A8A),
    onPrimaryContainer = Color(0xFFDBEAFE),
    secondary = Color(0xFF2DD4BF),
    onSecondary = Color(0xFF0F172A),
    background = Color(0xFF0B1120),
    onBackground = Color(0xFFF1F5F9),
    surface = Color(0xFF111827),
    onSurface = Color(0xFFF1F5F9),
    surfaceVariant = Color(0xFF1E293B),
    onSurfaceVariant = Color(0xFF94A3B8),
    error = Color(0xFFF87171)
)

@Composable
fun WholesaleTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColors
        else -> LightColors
    }

    MaterialTheme(
        colorScheme = colorScheme,
        content = content
    )
}
`,
  },
  {
    id: 'pres-dashboard-screen',
    path: 'core/presentation/src/main/kotlin/com/wholesaleledger/presentation/dashboard/DashboardScreen.kt',
    module: 'presentation',
    title: 'Jetpack Compose DashboardScreen (DashboardScreen.kt)',
    language: 'kotlin',
    summary: 'Adaptive Material 3 Dashboard driven by StateFlow with KPI grid, low-stock restock alerts, pending sync outbox banner, and CSV/PDF export actions.',
    code: `package com.wholesaleledger.presentation.dashboard

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CloudDone
import androidx.compose.material.icons.rounded.CloudUpload
import androidx.compose.material.icons.rounded.FileDownload
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.wholesaleledger.domain.model.Invoice
import com.wholesaleledger.domain.model.Product
import java.text.NumberFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    isExpandedScreen: Boolean,
    onOpenInvoices: () -> Unit,
    onOpenProduct: (String) -> Unit,
    onExportCsvReport: (List<Invoice>) -> Unit,
    viewModel: DashboardViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(Unit) {
        viewModel.events.collect { event ->
            when (event) {
                is DashboardEvent.ShowMessage -> snackbarHostState.showSnackbar(event.message)
            }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("WholesaleLedger", style = MaterialTheme.typography.titleLarge)
                        Text(
                            text = "Role: \${uiState.session?.role?.name ?: "GUEST"}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    FilledTonalButton(
                        onClick = { viewModel.onSyncNowClicked() },
                        enabled = !uiState.isSyncing,
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        if (uiState.isSyncing) {
                            CircularProgressIndicator(modifier = Modifier.height(16.dp), strokeWidth = 2.dp)
                        } else {
                            Icon(
                                imageVector = if (uiState.pendingSyncOperations > 0) Icons.Rounded.CloudUpload else Icons.Rounded.CloudDone,
                                contentDescription = null
                            )
                            Text(
                                text = if (uiState.pendingSyncOperations > 0) " Sync (\${uiState.pendingSyncOperations})" else " Synced",
                                modifier = Modifier.padding(start = 6.dp)
                            )
                        }
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                KpiGridSection(
                    isExpandedScreen = isExpandedScreen,
                    revenueCents = uiState.totalPaidRevenueCents,
                    pendingCents = uiState.pendingReceivablesCents,
                    overdueCount = uiState.overdueCount,
                    lowStockCount = uiState.lowStockProducts.size
                )
            }

            if (uiState.lowStockProducts.isNotEmpty()) {
                item {
                    Text(
                        text = "Low-Stock Threshold Alerts",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                items(uiState.lowStockProducts, key = { it.id }) { product: Product ->
                    OutlinedCard(
                        onClick = { onOpenProduct(product.id) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        ListItem(
                            leadingContent = {
                                Icon(
                                    imageVector = Icons.Rounded.WarningAmber,
                                    contentDescription = "Low Stock",
                                    tint = MaterialTheme.colorScheme.error
                                )
                            },
                            headlineContent = { Text(product.name) },
                            supportingContent = { Text("SKU \${product.sku} · Reorder threshold \${product.reorderThreshold} \${product.unitLabel}") },
                            trailingContent = {
                                Text(
                                    text = "\${product.stockQuantity} left",
                                    color = MaterialTheme.colorScheme.error,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        )
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Recent Wholesale Invoices",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (uiState.canExportLedger) {
                            FilledTonalButton(onClick = { onExportCsvReport(uiState.recentInvoices) }) {
                                Icon(Icons.Rounded.FileDownload, contentDescription = null)
                                Text(" Export CSV", modifier = Modifier.padding(start = 4.dp))
                            }
                        }
                        Button(onClick = onOpenInvoices) {
                            Text("All Invoices")
                        }
                    }
                }
            }

            items(uiState.recentInvoices, key = { it.id }) { invoice ->
                ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                    ListItem(
                        headlineContent = { Text("\${invoice.invoiceNumber} · \${invoice.clientName}") },
                        supportingContent = { Text("Due \${invoice.dueDateIso} · \${invoice.status.name} · \${invoice.syncState.name}") },
                        trailingContent = {
                            Text(
                                text = formatCurrency(invoice.totalCents),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    )
                    HorizontalDivider()
                }
            }
        }
    }
}

@Composable
private fun KpiGridSection(
    isExpandedScreen: Boolean,
    revenueCents: Long,
    pendingCents: Long,
    overdueCount: Int,
    lowStockCount: Int
) {
    val columns = if (isExpandedScreen) 4 else 2
    val cards = listOf(
        "Paid Revenue" to formatCurrency(revenueCents),
        "Open Receivables" to formatCurrency(pendingCents),
        "Overdue Invoices" to overdueCount.toString(),
        "Low-Stock SKUs" to lowStockCount.toString()
    )

    LazyVerticalGrid(
        columns = GridCells.Fixed(columns),
        modifier = Modifier
            .fillMaxWidth()
            .height(if (isExpandedScreen) 110.dp else 220.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        userScrollEnabled = false
    ) {
        items(cards.size) { index ->
            val (label, value) = cards[index]
            ElevatedCard(
                colors = CardDefaults.elevatedCardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(6.dp))
                    Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

private fun formatCurrency(cents: Long): String =
    NumberFormat.getCurrencyInstance(Locale.US).format(cents / 100.0)
`,
  },
  {
    id: 'pres-list-detail-screens',
    path: 'core/presentation/src/main/kotlin/com/wholesaleledger/presentation/entities/ListAndDetailScreens.kt',
    module: 'presentation',
    title: 'ListScreen & DetailEditScreen (ListAndDetailScreens.kt)',
    language: 'kotlin',
    summary: 'Complete Material 3 ListScreen with search/filter chips + RBAC delete action, and DetailEditScreen supporting Create/Update + ShareSheet PDF export.',
    code: `package com.wholesaleledger.presentation.entities

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.wholesaleledger.domain.model.Invoice
import com.wholesaleledger.domain.model.InvoiceStatus
import com.wholesaleledger.domain.usecase.DeleteRecordWithRbacUseCase
import com.wholesaleledger.presentation.navigation.EntitySection
import java.text.NumberFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ListScreen(
    onOpenDetail: (EntitySection, String?) -> Unit,
    onExportInvoicePdf: (Invoice) -> Unit,
    viewModel: EntityListViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(Unit) {
        viewModel.messages.collect { snackbarHostState.showSnackbar(it) }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        floatingActionButton = {
            FloatingActionButton(onClick = { onOpenDetail(state.section, null) }) {
                Icon(Icons.Rounded.Add, contentDescription = "Create record")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = state.searchQuery,
                onValueChange = viewModel::onQueryChanged,
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                placeholder = { Text("Search \${state.section.name.lowercase()} locally...") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
            )

            if (state.section == EntitySection.INVOICES) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        FilterChip(
                            selected = state.selectedInvoiceStatus == null,
                            onClick = { viewModel.onInvoiceStatusSelected(null) },
                            label = { Text("All") }
                        )
                    }
                    items(InvoiceStatus.entries) { status ->
                        FilterChip(
                            selected = state.selectedInvoiceStatus == status,
                            onClick = { viewModel.onInvoiceStatusSelected(status) },
                            label = { Text(status.name) }
                        )
                    }
                }
            }

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 88.dp)
            ) {
                when (state.section) {
                    EntitySection.PRODUCTS -> items(state.products, key = { it.id }) { product ->
                        OutlinedCard(onClick = { onOpenDetail(EntitySection.PRODUCTS, product.id) }) {
                            ListItem(
                                headlineContent = { Text(product.name) },
                                supportingContent = {
                                    Text("\${product.sku} · Stock: \${product.stockQuantity} \${product.unitLabel} · \${product.syncState.name}")
                                },
                                trailingContent = {
                                    Row {
                                        Text(
                                            NumberFormat.getCurrencyInstance(Locale.US).format(product.unitPriceCents / 100.0),
                                            modifier = Modifier.padding(top = 12.dp, end = 4.dp)
                                        )
                                        if (state.userRole.canDeleteRecords) {
                                            IconButton(onClick = {
                                                viewModel.onDeleteEntity(DeleteRecordWithRbacUseCase.TargetType.PRODUCT, product.id)
                                            }) {
                                                Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete product")
                                            }
                                        }
                                    }
                                }
                            )
                        }
                    }

                    EntitySection.CLIENTS -> items(state.clients, key = { it.id }) { client ->
                        OutlinedCard(onClick = { onOpenDetail(EntitySection.CLIENTS, client.id) }) {
                            ListItem(
                                headlineContent = { Text(client.businessName) },
                                supportingContent = { Text("\${client.contactName} · Net-\${client.paymentTermsDays} · \${client.syncState.name}") },
                                trailingContent = {
                                    if (state.userRole.canDeleteRecords) {
                                        IconButton(onClick = {
                                            viewModel.onDeleteEntity(DeleteRecordWithRbacUseCase.TargetType.CLIENT, client.id)
                                        }) {
                                            Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete client")
                                        }
                                    }
                                }
                            )
                        }
                    }

                    EntitySection.INVOICES -> items(state.invoices, key = { it.id }) { invoice ->
                        OutlinedCard(onClick = { onOpenDetail(EntitySection.INVOICES, invoice.id) }) {
                            ListItem(
                                headlineContent = { Text("\${invoice.invoiceNumber} · \${invoice.clientName}") },
                                supportingContent = { Text("\${invoice.status.name} · Due \${invoice.dueDateIso} · \${invoice.syncState.name}") },
                                trailingContent = {
                                    Row {
                                        IconButton(onClick = { onExportInvoicePdf(invoice) }) {
                                            Icon(Icons.Rounded.PictureAsPdf, contentDescription = "Export PDF")
                                        }
                                        if (state.userRole.canDeleteRecords) {
                                            IconButton(onClick = {
                                                viewModel.onDeleteEntity(DeleteRecordWithRbacUseCase.TargetType.INVOICE, invoice.id)
                                            }) {
                                                Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete invoice")
                                            }
                                        }
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailEditScreen(
    onNavigateBack: () -> Unit,
    viewModel: DetailEditViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    LaunchedEffect(state.savedSuccessfully) {
        if (state.savedSuccessfully) onNavigateBack()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (state.isNew) "New \${state.section.name}" else "Edit \${state.section.name}") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            state.errorMessage?.let { msg ->
                Text(msg, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
            }

            when (state.section) {
                EntitySection.PRODUCTS -> {
                    OutlinedTextField(
                        value = state.product.sku,
                        onValueChange = { v -> viewModel.updateProduct { it.copy(sku = v) } },
                        label = { Text("SKU") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = state.product.name,
                        onValueChange = { v -> viewModel.updateProduct { it.copy(name = v) } },
                        label = { Text("Product Name") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = state.product.stockQuantity.toString(),
                        onValueChange = { v -> viewModel.updateProduct { it.copy(stockQuantity = v.toIntOrNull() ?: 0) } },
                        label = { Text("Stock Quantity") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = (state.product.unitPriceCents / 100.0).toString(),
                        onValueChange = { v ->
                            val cents = ((v.toDoubleOrNull() ?: 0.0) * 100).toLong()
                            viewModel.updateProduct { it.copy(unitPriceCents = cents) }
                        },
                        label = { Text("Unit Price (USD)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                EntitySection.CLIENTS -> {
                    OutlinedTextField(
                        value = state.client.businessName,
                        onValueChange = { v -> viewModel.updateClient { it.copy(businessName = v) } },
                        label = { Text("Business Name") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = state.client.contactName,
                        onValueChange = { v -> viewModel.updateClient { it.copy(contactName = v) } },
                        label = { Text("Primary Contact") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = state.client.email,
                        onValueChange = { v -> viewModel.updateClient { it.copy(email = v) } },
                        label = { Text("Accounts Payable Email") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                EntitySection.INVOICES -> {
                    OutlinedTextField(
                        value = state.invoice.invoiceNumber,
                        onValueChange = { v -> viewModel.updateInvoice { it.copy(invoiceNumber = v) } },
                        label = { Text("Invoice Number") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = state.invoice.notes,
                        onValueChange = { v -> viewModel.updateInvoice { it.copy(notes = v) } },
                        label = { Text("Delivery & Terms Notes") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Button(
                onClick = viewModel::onSave,
                enabled = !state.isSaving,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (state.isSaving) "Saving Locally..." else "Save Offline-First")
            }
        }
    }
}
`,
  },
  {
    id: 'pres-adaptive-nav',
    path: 'app/src/main/kotlin/com/wholesaleledger/app/AdaptiveWholesaleApp.kt',
    module: 'presentation',
    title: 'MainActivity & Adaptive NavHost (AdaptiveWholesaleApp.kt)',
    language: 'kotlin',
    summary: 'Edge-to-edge ComponentActivity with Hilt, WindowSizeClass adaptive navigation (Bottom Bar on Phone, Rail on Tablet), and type-safe NavHost.',
    code: `package com.wholesaleledger.app

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.Fingerprint
import androidx.compose.material.icons.rounded.Inventory2
import androidx.compose.material.icons.rounded.People
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.adaptive.currentWindowAdaptiveInfo
import androidx.compose.material3.adaptive.navigationsuite.NavigationSuiteScaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.window.core.layout.WindowWidthSizeClass
import com.wholesaleledger.presentation.dashboard.DashboardScreen
import com.wholesaleledger.presentation.entities.DetailEditScreen
import com.wholesaleledger.presentation.entities.ListScreen
import com.wholesaleledger.presentation.navigation.AppRoute
import com.wholesaleledger.presentation.navigation.EntitySection
import com.wholesaleledger.presentation.platform.WholesaleReportExporter
import com.wholesaleledger.presentation.security.BiometricAuthManager
import com.wholesaleledger.presentation.security.BiometricOutcome
import com.wholesaleledger.presentation.theme.WholesaleTheme
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : FragmentActivity() {

    @Inject lateinit var biometricAuthManager: BiometricAuthManager
    @Inject lateinit var reportExporter: WholesaleReportExporter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            WholesaleTheme {
                AdaptiveWholesaleRoot(
                    activity = this,
                    biometricAuthManager = biometricAuthManager,
                    reportExporter = reportExporter
                )
            }
        }
    }
}

@Composable
fun AdaptiveWholesaleRoot(
    activity: FragmentActivity,
    biometricAuthManager: BiometricAuthManager,
    reportExporter: WholesaleReportExporter
) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentDest = backStackEntry?.destination
    val adaptiveInfo = currentWindowAdaptiveInfo()
    val isExpanded = adaptiveInfo.windowSizeClass.windowWidthSizeClass == WindowWidthSizeClass.EXPANDED

    var authError by remember { mutableStateOf<String?>(null) }

    val showChrome = currentDest?.hasRoute<AppRoute.BiometricGate>() == false

    val navContent: @Composable () -> Unit = {
        NavHost(navController = navController, startDestination = AppRoute.BiometricGate) {
            composable<AppRoute.BiometricGate> {
                Surface(modifier = Modifier.fillMaxSize()) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(24.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Fingerprint,
                            contentDescription = "Biometric Lock",
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "WholesaleLedger Vault",
                            style = MaterialTheme.typography.headlineMedium,
                            modifier = Modifier.padding(top = 16.dp)
                        )
                        authError?.let {
                            Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp))
                        }
                        Button(
                            onClick = {
                                biometricAuthManager.authenticate(activity) { outcome ->
                                    when (outcome) {
                                        BiometricOutcome.Authenticated -> navController.navigate(AppRoute.Dashboard) {
                                            popUpTo<AppRoute.BiometricGate> { inclusive = true }
                                        }
                                        is BiometricOutcome.Failed -> authError = outcome.reason
                                        BiometricOutcome.Unavailable -> authError = "Device lock required to unlock session."
                                    }
                                }
                            },
                            modifier = Modifier.padding(top = 20.dp)
                        ) {
                            Text("Authenticate with Biometrics")
                        }
                    }
                }
            }

            composable<AppRoute.Dashboard> {
                DashboardScreen(
                    isExpandedScreen = isExpanded,
                    onOpenInvoices = { navController.navigate(AppRoute.EntityList(EntitySection.INVOICES)) },
                    onOpenProduct = { id -> navController.navigate(AppRoute.EntityDetailEdit(EntitySection.PRODUCTS, id)) },
                    onExportCsvReport = { invoices -> reportExporter.exportInvoicesCsvAndShare(invoices) }
                )
            }

            composable<AppRoute.EntityList> {
                ListScreen(
                    onOpenDetail = { section, id ->
                        navController.navigate(AppRoute.EntityDetailEdit(section, id))
                    },
                    onExportInvoicePdf = { invoice -> reportExporter.exportInvoicePdfAndShare(invoice) }
                )
            }

            composable<AppRoute.EntityDetailEdit> {
                DetailEditScreen(onNavigateBack = { navController.popBackStack() })
            }
        }
    }

    if (!showChrome) {
        navContent()
    } else {
        NavigationSuiteScaffold(
            navigationSuiteItems = {
                item(
                    selected = currentDest?.hasRoute<AppRoute.Dashboard>() == true,
                    onClick = { navController.navigate(AppRoute.Dashboard) { launchSingleTop = true } },
                    icon = { Icon(Icons.Rounded.Dashboard, contentDescription = null) },
                    label = { Text("Dashboard") }
                )
                item(
                    selected = false,
                    onClick = { navController.navigate(AppRoute.EntityList(EntitySection.CLIENTS)) },
                    icon = { Icon(Icons.Rounded.People, contentDescription = null) },
                    label = { Text("Clients") }
                )
                item(
                    selected = false,
                    onClick = { navController.navigate(AppRoute.EntityList(EntitySection.PRODUCTS)) },
                    icon = { Icon(Icons.Rounded.Inventory2, contentDescription = null) },
                    label = { Text("Products") }
                )
                item(
                    selected = false,
                    onClick = { navController.navigate(AppRoute.EntityList(EntitySection.INVOICES)) },
                    icon = { Icon(Icons.Rounded.ReceiptLong, contentDescription = null) },
                    label = { Text("Invoices") }
                )
            }
        ) {
            navContent()
        }
    }
}
`,
  },
  {
    id: 'pres-exporter-fcm',
    path: 'core/presentation/src/main/kotlin/com/wholesaleledger/presentation/platform/ReportExporterAndFcm.kt',
    module: 'presentation',
    title: 'PDF/CSV ShareSheet & FCM Service (ReportExporterAndFcm.kt)',
    language: 'kotlin',
    summary: 'Generates native PdfDocument invoices & CSV ledgers via FileProvider + Android ShareSheet, plus FirebaseMessagingService with NotificationChannel alerts.',
    code: `package com.wholesaleledger.presentation.platform

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import androidx.core.app.NotificationCompat
import androidx.core.content.FileProvider
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.wholesaleledger.domain.model.Invoice
import com.wholesaleledger.domain.repository.WholesaleRepository
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.text.NumberFormat
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class WholesaleReportExporter @Inject constructor(
    @ApplicationContext private val context: Context
) {
    fun exportInvoicesCsvAndShare(invoices: List<Invoice>) {
        val exportDir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(exportDir, "wholesale_invoices_\${System.currentTimeMillis()}.csv")
        val header = "InvoiceNumber,Client,Status,IssuedDate,DueDate,TotalUSD,SyncState\n"
        val rows = invoices.joinToString("\n") { inv ->
            val usd = String.format(Locale.US, "%.2f", inv.totalCents / 100.0)
            "\"\${inv.invoiceNumber}\",\"\${inv.clientName}\",\${inv.status.name},\${inv.issuedDateIso},\${inv.dueDateIso},\$usd,\${inv.syncState.name}"
        }
        file.writeText(header + rows)
        launchShareSheet(file, mimeType = "text/csv", title = "Share Wholesale CSV Ledger")
    }

    fun exportInvoicePdfAndShare(invoice: Invoice) {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas
        val titlePaint = Paint().apply { textSize = 18f; isFakeBoldText = true }
        val bodyPaint = Paint().apply { textSize = 11f }

        canvas.drawText("WholesaleLedger Invoice \${invoice.invoiceNumber}", 40f, 56f, titlePaint)
        canvas.drawText("Client: \${invoice.clientName}", 40f, 84f, bodyPaint)
        canvas.drawText("Issued: \${invoice.issuedDateIso}   Due: \${invoice.dueDateIso}   Status: \${invoice.status.name}", 40f, 104f, bodyPaint)

        var y = 148f
        invoice.items.forEach { item ->
            val lineTotal = NumberFormat.getCurrencyInstance(Locale.US).format(item.lineTotalCents / 100.0)
            canvas.drawText("\${item.sku}  \${item.productName}  x\${item.quantity}  —  \$lineTotal", 40f, y, bodyPaint)
            y += 22f
        }

        val totalFormatted = NumberFormat.getCurrencyInstance(Locale.US).format(invoice.totalCents / 100.0)
        canvas.drawText("Total Due: \$totalFormatted", 40f, y + 24f, titlePaint)
        document.finishPage(page)

        val exportDir = File(context.cacheDir, "exports").apply { mkdirs() }
        val pdfFile = File(exportDir, "\${invoice.invoiceNumber}.pdf")
        FileOutputStream(pdfFile).use { stream -> document.writeTo(stream) }
        document.close()

        launchShareSheet(pdfFile, mimeType = "application/pdf", title = "Share Invoice \${invoice.invoiceNumber}")
    }

    private fun launchShareSheet(file: File, mimeType: String, title: String) {
        val uri = FileProvider.getUriForFile(context, "\${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(intent, title).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    }
}

@AndroidEntryPoint
class WholesaleMessagingService : FirebaseMessagingService() {

    @Inject lateinit var repository: WholesaleRepository
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        serviceScope.launch { repository.registerFcmToken(token) }
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        val title = message.notification?.title ?: message.data["title"] ?: "WholesaleLedger Alert"
        val body = message.notification?.body ?: message.data["body"] ?: "Check pending inventory or invoice updates."
        showBusinessAlertNotification(title, body)
    }

    private fun showBusinessAlertNotification(title: String, body: String) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "wholesale_critical_alerts"
        val channel = NotificationChannel(
            channelId,
            "Critical Wholesale Alerts",
            NotificationManager.IMPORTANCE_HIGH
        )
        manager.createNotificationChannel(channel)

        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(body)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()

        manager.notify(System.currentTimeMillis().toInt(), notification)
    }
}
`,
  },
  {
    id: 'test-repository',
    path: 'core/data/src/test/kotlin/com/wholesaleledger/data/WholesaleRepositoryImplTest.kt',
    module: 'tests',
    title: 'Repository Unit Test (WholesaleRepositoryImplTest.kt)',
    language: 'kotlin',
    summary: 'Verifies offline-first local write + outbox enqueue behavior, sync flush ordering, and network error resilience using MockK & Coroutines Test.',
    code: `package com.wholesaleledger.data

import androidx.room.withTransaction
import com.wholesaleledger.data.local.AppDatabase
import com.wholesaleledger.data.local.ClientDao
import com.wholesaleledger.data.local.InvoiceDao
import com.wholesaleledger.data.local.PendingSyncDao
import com.wholesaleledger.data.local.PendingSyncOpEntity
import com.wholesaleledger.data.local.ProductDao
import com.wholesaleledger.data.remote.ProductDto
import com.wholesaleledger.data.remote.SyncDeltaResponse
import com.wholesaleledger.data.remote.WholesaleApiService
import com.wholesaleledger.data.repository.WholesaleRepositoryImpl
import com.wholesaleledger.data.security.AndroidKeystoreTokenManager
import com.wholesaleledger.data.sync.WholesaleSyncScheduler
import com.wholesaleledger.domain.model.DomainResult
import com.wholesaleledger.domain.model.Product
import com.wholesaleledger.domain.model.SyncState
import io.mockk.coEvery
import io.mockk.coVerify
import io.mockk.every
import io.mockk.mockk
import io.mockk.mockkStatic
import io.mockk.slot
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.time.Instant

class WholesaleRepositoryImplTest {

    private val database: AppDatabase = mockk(relaxed = true)
    private val clientDao: ClientDao = mockk(relaxed = true)
    private val productDao: ProductDao = mockk(relaxed = true)
    private val invoiceDao: InvoiceDao = mockk(relaxed = true)
    private val pendingSyncDao: PendingSyncDao = mockk(relaxed = true)
    private val apiService: WholesaleApiService = mockk(relaxed = true)
    private val tokenManager: AndroidKeystoreTokenManager = mockk(relaxed = true)
    private val syncScheduler: WholesaleSyncScheduler = mockk(relaxed = true)

    private lateinit var repository: WholesaleRepositoryImpl

    @Before
    fun setUp() {
        mockkStatic("androidx.room.RoomDatabaseKt")
        coEvery { database.withTransaction(any<suspend () -> Any?>()) } coAnswers {
            val block = secondArg<suspend () -> Any?>()
            block.invoke()
        }
        every { tokenManager.lastSyncEpochFlow } returns flowOf(1000L)

        repository = WholesaleRepositoryImpl(
            database = database,
            clientDao = clientDao,
            productDao = productDao,
            invoiceDao = invoiceDao,
            pendingSyncDao = pendingSyncDao,
            apiService = apiService,
            tokenManager = tokenManager,
            syncScheduler = syncScheduler
        )
    }

    @Test
    fun \`upsertProduct saves to Room, enqueues outbox, and schedules WorkManager\`() = runTest {
        val product = Product(
            id = "prd_99",
            sku = "COF-COL-5KG",
            name = "Colombia Huila Beans",
            category = "Coffee & Tea",
            unitPriceCents = 8900,
            stockQuantity = 24,
            reorderThreshold = 10,
            unitLabel = "bag",
            syncState = SyncState.PENDING_UPLOAD,
            updatedAt = Instant.now()
        )

        val outboxSlot = slot<PendingSyncOpEntity>()
        coEvery { pendingSyncDao.enqueue(capture(outboxSlot)) } returns Unit

        val result = repository.upsertProduct(product)

        assertTrue(result is DomainResult.Success)
        coVerify(exactly = 1) { productDao.upsert(match { it.id == "prd_99" }) }
        assertEquals("PRODUCT", outboxSlot.captured.entityType)
        assertEquals("UPSERT", outboxSlot.captured.operation)
        coVerify(exactly = 1) { syncScheduler.enqueueImmediateSync() }
    }

    @Test
    fun \`syncPendingOperations pushes queued ops and deletes them on success\`() = runTest {
        val queuedOp = PendingSyncOpEntity(
            id = "PRODUCT_prd_99",
            entityType = "PRODUCT",
            entityId = "prd_99",
            operation = "UPSERT",
            payloadJson = """{"id":"prd_99","sku":"COF-COL-5KG","name":"Colombia Huila","category":"Coffee","unit_price_cents":8900,"stock_quantity":24,"reorder_threshold":10,"unit_label":"bag","updated_at_epoch_ms":2000}""",
            queuedAtEpochMs = 1500L
        )
        coEvery { pendingSyncDao.getAllPending() } returns listOf(queuedOp)
        coEvery { apiService.upsertProduct("prd_99", any()) } returns ProductDto(
            id = "prd_99", sku = "COF-COL-5KG", name = "Colombia Huila", category = "Coffee",
            unitPriceCents = 8900, stockQuantity = 24, reorderThreshold = 10, unitLabel = "bag", updatedAtEpochMs = 2000L
        )
        coEvery { apiService.fetchDelta(1000L) } returns SyncDeltaResponse(emptyList(), emptyList(), emptyList(), 3000L)

        val result = repository.syncPendingOperations()

        assertEquals(DomainResult.Success(1), result)
        coVerify(exactly = 1) { pendingSyncDao.deleteById("PRODUCT_prd_99") }
        coVerify(exactly = 1) { tokenManager.updateLastSyncEpoch(3000L) }
    }
}
`,
  },
  {
    id: 'test-viewmodel',
    path: 'core/presentation/src/test/kotlin/com/wholesaleledger/presentation/DashboardViewModelTest.kt',
    module: 'tests',
    title: 'ViewModel StateFlow Unit Test (DashboardViewModelTest.kt)',
    language: 'kotlin',
    summary: 'Tests reactive StateFlow KPI aggregation, RBAC export gating, and manual sync snackbar events with Turbine.',
    code: `package com.wholesaleledger.presentation

import app.cash.turbine.test
import com.wholesaleledger.domain.model.DashboardMetrics
import com.wholesaleledger.domain.model.DomainResult
import com.wholesaleledger.domain.model.UserRole
import com.wholesaleledger.domain.model.UserSession
import com.wholesaleledger.domain.repository.WholesaleRepository
import com.wholesaleledger.domain.usecase.ObserveDashboardMetricsUseCase
import com.wholesaleledger.domain.usecase.TriggerOfflineSyncUseCase
import com.wholesaleledger.presentation.dashboard.DashboardEvent
import com.wholesaleledger.presentation.dashboard.DashboardViewModel
import io.mockk.coEvery
import io.mockk.every
import io.mockk.mockk
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class DashboardViewModelTest {

    private val testDispatcher = StandardTestDispatcher()
    private val repository: WholesaleRepository = mockk(relaxed = true)

    private val metricsFlow = MutableStateFlow(
        DashboardMetrics(
            totalPaidRevenueCents = 1_371_000L,
            pendingReceivablesCents = 1_106_900L,
            overdueCount = 1,
            lowStockProducts = emptyList(),
            pendingSyncOperations = 2,
            recentInvoices = emptyList()
        )
    )

    private val sessionFlow = MutableStateFlow(
        UserSession(
            userId = "usr_1",
            displayName = "Alex Mercer",
            email = "alex@wholesaleledger.com",
            role = UserRole.STAFF,
            accessToken = "tok",
            refreshToken = "ref",
            expiresAtEpochMillis = 9_999_999_999L
        )
    )

    @Before
    fun setup() {
        Dispatchers.setMain(testDispatcher)
        every { repository.observeDashboardMetrics() } returns metricsFlow
        every { repository.observeSession() } returns sessionFlow
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun \`uiState reflects reactive Room KPIs and enforces RBAC export flag\`() = runTest {
        val vm = DashboardViewModel(
            observeDashboardMetrics = ObserveDashboardMetricsUseCase(repository),
            repository = repository,
            triggerOfflineSync = TriggerOfflineSyncUseCase(repository)
        )

        vm.uiState.test {
            awaitItem() // Initial empty state
            val staffState = awaitItem()
            assertEquals(1_371_000L, staffState.totalPaidRevenueCents)
            assertEquals(2, staffState.pendingSyncOperations)
            assertFalse(staffState.canExportLedger)

            sessionFlow.value = sessionFlow.value.copy(role = UserRole.ADMIN)
            val adminState = awaitItem()
            assertTrue(adminState.canExportLedger)
        }
    }

    @Test
    fun \`onSyncNowClicked triggers sync use case and emits Snackbar event\`() = runTest {
        coEvery { repository.syncPendingOperations() } returns DomainResult.Success(2)
        val vm = DashboardViewModel(
            observeDashboardMetrics = ObserveDashboardMetricsUseCase(repository),
            repository = repository,
            triggerOfflineSync = TriggerOfflineSyncUseCase(repository)
        )

        vm.events.test {
            vm.onSyncNowClicked()
            testDispatcher.scheduler.advanceUntilIdle()
            val event = awaitItem() as DashboardEvent.ShowMessage
            assertTrue(event.message.contains("Synced 2 queued change(s)"))
        }
    }
}
`,
  },
  {
    id: 'proguard-rules',
    path: 'app/proguard-rules.pro',
    module: 'tests',
    title: 'Release ProGuard / R8 Rules (proguard-rules.pro)',
    language: 'proguard',
    summary: 'Preserves Kotlinx Serialization serializers, Retrofit annotations, Room entities/DAOs, Hilt generated classes, BiometricPrompt, and FCM.',
    code: `# Kotlinx Serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** { *** Companion; }
-keepclasseswithmembers class kotlinx.serialization.json.** { kotlinx.serialization.KSerializer serializer(...); }
-keep,includedescriptorclasses class com.wholesaleledger.**$$serializer { *; }
-keepclassmembers class com.wholesaleledger.** {
    *** Companion;
}
-keepclasseswithmembers class com.wholesaleledger.** {
    kotlinx.serialization.KSerializer serializer(...);
}

# Retrofit & OkHttp
-keepattributes Signature, Exceptions
-keepclassmembers,allowshrinking,allowobfuscation interface * {
    @retrofit2.http.* <methods>;
}
-dontwarn org.codehaus.mojo.animal_sniffer.IgnoreJRERequirement
-dontwarn okhttp3.**

# Room Persistence
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
-dontwarn androidx.room.paging.**

# Dagger Hilt & WorkManager
-keep class dagger.hilt.** { *; }
-keep class * extends androidx.hilt.work.HiltWorkerFactory { *; }

# Biometric & FCM
-keep class androidx.biometric.** { *; }
-keepclassmembers class * extends com.google.firebase.messaging.FirebaseMessagingService {
    <init>();
}
`,
  },
];
