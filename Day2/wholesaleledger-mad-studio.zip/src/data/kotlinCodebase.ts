import { GRADLE_DOMAIN_DATA_FILES } from './kotlinGradleDomainData';
import { PRESENTATION_TEST_FILES } from './kotlinPresentationTests';
import { AndroidSourceFile } from '../types/wholesale';

export const ANDROID_SOURCE_FILES: AndroidSourceFile[] = [
  ...GRADLE_DOMAIN_DATA_FILES,
  ...PRESENTATION_TEST_FILES,
];
