export type UserRole = 'ADMIN' | 'STAFF';

export type SyncState = 'SYNCED' | 'PENDING_UPLOAD' | 'PENDING_DELETE' | 'CONFLICT';

export type InvoiceStatus = 'DRAFT' | 'PENDING' | 'PAID' | 'OVERDUE';

export type EntityTab = 'dashboard' | 'clients' | 'products' | 'invoices';

export interface Client {
  id: string;
  businessName: string;
  contactName: string;
  email: string;
  phone: string;
  paymentTermsDays: number;
  creditLimitCents: number;
  outstandingBalanceCents: number;
  syncState: SyncState;
  updatedAt: string;
}

export interface Product {
  id: string;
  sku: string;
  name: string;
  category: string;
  unitPriceCents: number;
  stockQuantity: number;
  reorderThreshold: number;
  unitLabel: string;
  syncState: SyncState;
  updatedAt: string;
}

export interface InvoiceLineItem {
  productId: string;
  productName: string;
  sku: string;
  quantity: number;
  unitPriceCents: number;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  clientId: string;
  clientName: string;
  status: InvoiceStatus;
  dueDate: string;
  issuedDate: string;
  items: InvoiceLineItem[];
  totalCents: number;
  notes: string;
  syncState: SyncState;
  updatedAt: string;
}

export interface PendingSyncOp {
  id: string;
  entityType: 'CLIENT' | 'PRODUCT' | 'INVOICE';
  entityId: string;
  operation: 'UPSERT' | 'DELETE';
  payloadSummary: string;
  queuedAt: string;
  retryCount: number;
}

export interface PushNotificationAlert {
  id: string;
  channel: 'FCM_CRITICAL' | 'LOCAL_STOCK' | 'SYNC_STATUS';
  title: string;
  body: string;
  timestamp: string;
}

export interface AndroidSourceFile {
  id: string;
  path: string;
  module: 'gradle' | 'domain' | 'data' | 'presentation' | 'tests';
  title: string;
  language: 'kotlin' | 'toml' | 'proguard';
  summary: string;
  code: string;
}
