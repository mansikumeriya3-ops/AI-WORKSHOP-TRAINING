import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowLeft,
  Bell,
  CloudCheck,
  CloudUpload,
  Download,
  FileText,
  Fingerprint,
  LayoutDashboard,
  Lock,
  Package,
  Plus,
  Receipt,
  Search,
  Share2,
  Trash2,
  Users,
  WifiOff,
  X,
} from 'lucide-react';
import {
  Client,
  EntityTab,
  Invoice,
  InvoiceLineItem,
  InvoiceStatus,
  Product,
  PushNotificationAlert,
  UserRole,
} from '../types/wholesale';

interface AndroidDeviceSimulatorProps {
  formFactor: 'phone' | 'tablet';
  isOnline: boolean;
  isBiometricUnlocked: boolean;
  role: UserRole;
  clients: Client[];
  products: Product[];
  invoices: Invoice[];
  pendingCount: number;
  activeAlert: PushNotificationAlert | null;
  onUnlockBiometric: () => void;
  onLockVault: () => void;
  onSyncNow: () => void;
  onSaveClient: (client: Client) => string | null;
  onDeleteClient: (id: string) => string | null;
  onSaveProduct: (product: Product) => string | null;
  onDeleteProduct: (id: string) => string | null;
  onSaveInvoice: (invoice: Invoice) => string | null;
  onDeleteInvoice: (id: string) => string | null;
  onDismissAlert: () => void;
}

type DetailTarget =
  | { type: 'clients'; item: Client | null }
  | { type: 'products'; item: Product | null }
  | { type: 'invoices'; item: Invoice | null };

const formatUsd = (cents: number) =>
  new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(cents / 100);

export const AndroidDeviceSimulator: React.FC<AndroidDeviceSimulatorProps> = ({
  formFactor,
  isOnline,
  isBiometricUnlocked,
  role,
  clients,
  products,
  invoices,
  pendingCount,
  activeAlert,
  onUnlockBiometric,
  onLockVault,
  onSyncNow,
  onSaveClient,
  onDeleteClient,
  onSaveProduct,
  onDeleteProduct,
  onSaveInvoice,
  onDeleteInvoice,
  onDismissAlert,
}) => {
  const [activeTab, setActiveTab] = useState<EntityTab>('dashboard');
  const [searchQuery, setSearchQuery] = useState('');
  const [invoiceStatusFilter, setInvoiceStatusFilter] = useState<InvoiceStatus | 'ALL'>('ALL');
  const [productCategoryFilter, setProductCategoryFilter] = useState<string>('ALL');
  const [detailTarget, setDetailTarget] = useState<DetailTarget | null>(null);
  const [snackbar, setSnackbar] = useState<string | null>(null);
  const [sharePreview, setSharePreview] = useState<{ title: string; filename: string; content: string; mime: string } | null>(null);

  const showToast = (msg: string) => {
    setSnackbar(msg);
    setTimeout(() => {
      setSnackbar((curr) => (curr === msg ? null : curr));
    }, 3200);
  };

  const metrics = useMemo(() => {
    const paidRevenue = invoices
      .filter((i) => i.status === 'PAID')
      .reduce((acc, i) => acc + i.totalCents, 0);
    const pendingReceivables = invoices
      .filter((i) => i.status === 'PENDING' || i.status === 'OVERDUE')
      .reduce((acc, i) => acc + i.totalCents, 0);
    const overdueCount = invoices.filter((i) => i.status === 'OVERDUE').length;
    const lowStockProducts = products.filter((p) => p.stockQuantity <= p.reorderThreshold);
    return { paidRevenue, pendingReceivables, overdueCount, lowStockProducts };
  }, [invoices, products]);

  const categories = useMemo(
    () => ['ALL', ...Array.from(new Set(products.map((p) => p.category)))],
    [products]
  );

  const filteredClients = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return clients.filter(
      (c) =>
        q === '' ||
        c.businessName.toLowerCase().includes(q) ||
        c.contactName.toLowerCase().includes(q)
    );
  }, [clients, searchQuery]);

  const filteredProducts = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return products.filter((p) => {
      const catOk = productCategoryFilter === 'ALL' || p.category === productCategoryFilter;
      const qOk = q === '' || p.name.toLowerCase().includes(q) || p.sku.toLowerCase().includes(q);
      return catOk && qOk;
    });
  }, [products, productCategoryFilter, searchQuery]);

  const filteredInvoices = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return invoices.filter((inv) => {
      const stOk = invoiceStatusFilter === 'ALL' || inv.status === invoiceStatusFilter;
      const qOk =
        q === '' ||
        inv.invoiceNumber.toLowerCase().includes(q) ||
        inv.clientName.toLowerCase().includes(q);
      return stOk && qOk;
    });
  }, [invoices, invoiceStatusFilter, searchQuery]);

  const handleExportCsv = () => {
    if (role !== 'ADMIN') {
      showToast('Insufficient permissions: Only Admins can export full financial ledgers.');
      return;
    }
    const header = 'InvoiceNumber,Client,Status,IssuedDate,DueDate,TotalUSD,SyncState';
    const rows = invoices.map(
      (inv) =>
        `"${inv.invoiceNumber}","${inv.clientName}",${inv.status},${inv.issuedDate},${inv.dueDate},${(
          inv.totalCents / 100
        ).toFixed(2)},${inv.syncState}`
    );
    const csvContent = [header, ...rows].join('\n');
    setSharePreview({
      title: 'Wholesale CSV Ledger',
      filename: `wholesale_invoices_${new Date().toISOString().slice(0, 10)}.csv`,
      content: csvContent,
      mime: 'text/csv',
    });
  };

  const handleExportInvoicePdf = (invoice: Invoice) => {
    const lines = [
      `WHOLESALELEDGER INVOICE ${invoice.invoiceNumber}`,
      `Client: ${invoice.clientName}`,
      `Issued: ${invoice.issuedDate}   Due: ${invoice.dueDate}   Status: ${invoice.status}`,
      '------------------------------------------------------------',
      ...invoice.items.map(
        (item) =>
          `${item.sku} | ${item.productName} | Qty ${item.quantity} x ${formatUsd(
            item.unitPriceCents
          )} = ${formatUsd(item.quantity * item.unitPriceCents)}`
      ),
      '------------------------------------------------------------',
      `TOTAL DUE: ${formatUsd(invoice.totalCents)}`,
      invoice.notes ? `Notes: ${invoice.notes}` : '',
    ].filter(Boolean);

    setSharePreview({
      title: `Invoice ${invoice.invoiceNumber} (PdfDocument)`,
      filename: `${invoice.invoiceNumber}.txt`,
      content: lines.join('\n'),
      mime: 'text/plain',
    });
  };

  const triggerDownload = (filename: string, content: string, mime: string) => {
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
    showToast(`Exported ${filename}`);
    setSharePreview(null);
  };

  const navItems: { id: EntityTab; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'clients', label: 'Clients', icon: Users },
    { id: 'products', label: 'Products', icon: Package },
    { id: 'invoices', label: 'Invoices', icon: Receipt },
  ];

  const isTablet = formFactor === 'tablet';

  return (
    <div className="flex flex-col items-center">
      <div
        className={`relative rounded-[28px] border-[6px] border-neutral-800 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-950 shadow-xl overflow-hidden transition-all duration-200 flex flex-col ${
          isTablet ? 'w-full max-w-[780px] h-[680px]' : 'w-full max-w-[396px] h-[720px]'
        }`}
      >
        {/* Android Status Bar */}
        <div className="px-5 py-2 flex items-center justify-between text-[11px] font-mono bg-white dark:bg-neutral-900 border-b border-neutral-200/80 dark:border-neutral-800 text-neutral-600 dark:text-neutral-300 shrink-0">
          <span className="tabular-nums">22:55</span>
          <div className="flex items-center gap-3">
            {!isOnline && (
              <span className="inline-flex items-center gap-1 text-amber-600 dark:text-amber-400 font-medium">
                <WifiOff className="w-3 h-3" />
                Offline
              </span>
            )}
            <span>{isOnline ? '5G · Online' : 'Room Cache'}</span>
          </div>
        </div>

        {/* Simulated FCM / Local Heads-Up Notification */}
        {activeAlert && (
          <div className="mx-3 mt-2 p-3 rounded-xl bg-neutral-900 dark:bg-neutral-800 text-white shadow-lg flex items-start justify-between gap-3 z-30 shrink-0">
            <div className="flex items-start gap-2.5 min-w-0">
              <Bell className="w-4 h-4 text-blue-400 mt-0.5 shrink-0" />
              <div className="min-w-0">
                <p className="text-[11px] font-mono text-blue-300">
                  {activeAlert.channel === 'FCM_CRITICAL' ? 'FCM Push · High Priority' : 'Local Stock Alert'}
                </p>
                <p className="text-xs font-semibold truncate">{activeAlert.title}</p>
                <p className="text-[11px] text-neutral-300 leading-snug">{activeAlert.body}</p>
              </div>
            </div>
            <button
              type="button"
              onClick={onDismissAlert}
              aria-label="Dismiss notification"
              className="p-1 text-neutral-400 hover:text-white"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Biometric Gate */}
        {!isBiometricUnlocked ? (
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-center bg-white dark:bg-neutral-950">
            <div className="w-16 h-16 rounded-2xl bg-blue-50 dark:bg-blue-950/50 border border-blue-200 dark:border-blue-800 flex items-center justify-center text-blue-600 dark:text-blue-400">
              <Fingerprint className="w-8 h-8" />
            </div>
            <h3 className="mt-5 text-lg font-semibold text-neutral-900 dark:text-neutral-100">
              WholesaleLedger Vault
            </h3>
            <p className="mt-2 text-xs text-neutral-500 dark:text-neutral-400 max-w-xs leading-relaxed">
              BiometricPrompt verifies device credentials before AndroidKeyStore decrypts your {role} session token.
            </p>
            <button
              type="button"
              onClick={onUnlockBiometric}
              className="mt-6 px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold transition-colors"
            >
              Authenticate with Biometrics
            </button>
          </div>
        ) : (
          <div className="flex-1 flex min-h-0">
            {/* Tablet NavigationRail */}
            {isTablet && (
              <nav className="w-20 border-r border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 flex flex-col items-center py-4 gap-3 shrink-0">
                {navItems.map((item) => {
                  const Icon = item.icon;
                  const active = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => {
                        setActiveTab(item.id);
                        setDetailTarget(null);
                      }}
                      className={`w-14 py-2 rounded-xl flex flex-col items-center gap-1 transition-colors ${
                        active
                          ? 'bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300'
                          : 'text-neutral-500 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      <span className="text-[10px] font-medium">{item.label}</span>
                    </button>
                  );
                })}
              </nav>
            )}

            {/* Main Device Viewport */}
            <div className="flex-1 flex flex-col min-w-0 min-h-0">
              {/* TopAppBar */}
              <header className="px-4 py-3 bg-white dark:bg-neutral-900 border-b border-neutral-200 dark:border-neutral-800 flex items-center justify-between gap-2 shrink-0">
                <div className="min-w-0">
                  <h3 className="text-sm font-semibold text-neutral-900 dark:text-neutral-100 truncate">
                    {detailTarget
                      ? `${detailTarget.item ? 'Edit' : 'New'} ${detailTarget.type.slice(0, -1)}`
                      : activeTab === 'dashboard'
                      ? 'WholesaleLedger'
                      : activeTab.charAt(0).toUpperCase() + activeTab.slice(1)}
                  </h3>
                  <p className="text-[11px] text-neutral-500 dark:text-neutral-400">
                    Role: {role} · {isOnline ? 'Online' : 'Offline Mode'}
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={onSyncNow}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[11px] font-medium bg-neutral-100 dark:bg-neutral-800 text-neutral-800 dark:text-neutral-200 hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-colors"
                  >
                    {pendingCount > 0 ? (
                      <>
                        <CloudUpload className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                        <span className="tabular-nums">Sync ({pendingCount})</span>
                      </>
                    ) : (
                      <>
                        <CloudCheck className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                        <span>Synced</span>
                      </>
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={onLockVault}
                    aria-label="Lock session"
                    className="p-1.5 rounded-lg text-neutral-500 hover:bg-neutral-100 dark:hover:bg-neutral-800"
                  >
                    <Lock className="w-3.5 h-3.5" />
                  </button>
                </div>
              </header>

              {/* Content Area (Adaptive 2-Pane on Tablet when editing, Single Pane on Phone) */}
              <div className="flex-1 flex min-h-0 overflow-hidden relative">
                {/* Primary Screen */}
                <div
                  className={`flex-1 overflow-y-auto p-4 space-y-4 ${
                    isTablet && detailTarget ? 'border-r border-neutral-200 dark:border-neutral-800' : ''
                  } ${!isTablet && detailTarget ? 'hidden' : 'block'}`}
                >
                  {activeTab === 'dashboard' && (
                    <>
                      <div className={`grid gap-2.5 ${isTablet ? 'grid-cols-4' : 'grid-cols-2'}`}>
                        <div className="p-3 rounded-xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800">
                          <p className="text-[11px] text-neutral-500 dark:text-neutral-400">Paid Revenue</p>
                          <p className="mt-1 text-base font-bold text-neutral-900 dark:text-neutral-100 tabular-nums">
                            {formatUsd(metrics.paidRevenue)}
                          </p>
                        </div>
                        <div className="p-3 rounded-xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800">
                          <p className="text-[11px] text-neutral-500 dark:text-neutral-400">Receivables</p>
                          <p className="mt-1 text-base font-bold text-neutral-900 dark:text-neutral-100 tabular-nums">
                            {formatUsd(metrics.pendingReceivables)}
                          </p>
                        </div>
                        <div className="p-3 rounded-xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800">
                          <p className="text-[11px] text-neutral-500 dark:text-neutral-400">Overdue</p>
                          <p className="mt-1 text-base font-bold text-red-600 dark:text-red-400 tabular-nums">
                            {metrics.overdueCount}
                          </p>
                        </div>
                        <div className="p-3 rounded-xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800">
                          <p className="text-[11px] text-neutral-500 dark:text-neutral-400">Low-Stock SKUs</p>
                          <p className="mt-1 text-base font-bold text-amber-600 dark:text-amber-400 tabular-nums">
                            {metrics.lowStockProducts.length}
                          </p>
                        </div>
                      </div>

                      {metrics.lowStockProducts.length > 0 && (
                        <div className="space-y-2">
                          <h4 className="text-xs font-semibold text-neutral-700 dark:text-neutral-300">
                            Low-Stock Threshold Alerts
                          </h4>
                          <div className="space-y-2">
                            {metrics.lowStockProducts.map((prod) => (
                              <button
                                key={prod.id}
                                type="button"
                                onClick={() => {
                                  setActiveTab('products');
                                  setDetailTarget({ type: 'products', item: prod });
                                }}
                                className="w-full text-left p-3 rounded-xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 hover:border-amber-400 dark:hover:border-amber-600 flex items-center justify-between gap-2 transition-colors"
                              >
                                <div className="flex items-start gap-2.5 min-w-0">
                                  <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400 mt-0.5 shrink-0" />
                                  <div className="min-w-0">
                                    <p className="text-xs font-medium text-neutral-900 dark:text-neutral-100 truncate">
                                      {prod.name}
                                    </p>
                                    <p className="text-[11px] text-neutral-500 dark:text-neutral-400">
                                      {prod.sku} · Reorder at {prod.reorderThreshold}
                                    </p>
                                  </div>
                                </div>
                                <span className="text-xs font-mono font-semibold text-red-600 dark:text-red-400 shrink-0 tabular-nums">
                                  {prod.stockQuantity} {prod.unitLabel}
                                </span>
                              </button>
                            ))}
                          </div>
                        </div>
                      )}

                      <div className="space-y-2">
                        <div className="flex items-center justify-between gap-2">
                          <h4 className="text-xs font-semibold text-neutral-700 dark:text-neutral-300">
                            Recent Invoices
                          </h4>
                          <button
                            type="button"
                            onClick={handleExportCsv}
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-medium bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 hover:bg-blue-100 dark:hover:bg-blue-900/60"
                          >
                            <Download className="w-3 h-3" />
                            Export CSV
                          </button>
                        </div>

                        <div className="space-y-2">
                          {invoices.slice(0, 4).map((inv) => (
                            <div
                              key={inv.id}
                              className="p-3 rounded-xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 flex items-center justify-between gap-2"
                            >
                              <div className="min-w-0">
                                <p className="text-xs font-medium text-neutral-900 dark:text-neutral-100 truncate">
                                  {inv.invoiceNumber} · {inv.clientName}
                                </p>
                                <p className="text-[11px] text-neutral-500 dark:text-neutral-400">
                                  {inv.status} · Due {inv.dueDate} · {inv.syncState}
                                </p>
                              </div>
                              <span className="text-xs font-mono font-semibold text-neutral-900 dark:text-neutral-100 tabular-nums shrink-0">
                                {formatUsd(inv.totalCents)}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </>
                  )}

                  {activeTab !== 'dashboard' && (
                    <>
                      <div className="flex items-center gap-2">
                        <div className="relative flex-1">
                          <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
                          <input
                            type="text"
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            placeholder={`Search ${activeTab} locally...`}
                            className="w-full pl-8 pr-3 py-2 text-xs rounded-xl border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-2 focus:ring-blue-600"
                          />
                        </div>
                        <button
                          type="button"
                          onClick={() => setDetailTarget({ type: activeTab, item: null })}
                          aria-label={`Add ${activeTab}`}
                          className="p-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white shrink-0"
                        >
                          <Plus className="w-4 h-4" />
                        </button>
                      </div>

                      {activeTab === 'products' && (
                        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                          {categories.map((cat) => (
                            <button
                              key={cat}
                              type="button"
                              onClick={() => setProductCategoryFilter(cat)}
                              className={`px-2.5 py-1 rounded-lg text-[11px] font-medium whitespace-nowrap shrink-0 transition-colors ${
                                productCategoryFilter === cat
                                  ? 'bg-neutral-900 text-white dark:bg-neutral-100 dark:text-neutral-900'
                                  : 'bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 text-neutral-600 dark:text-neutral-400'
                              }`}
                            >
                              {cat === 'ALL' ? 'All SKUs' : cat}
                            </button>
                          ))}
                        </div>
                      )}

                      {activeTab === 'invoices' && (
                        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                          {(['ALL', 'PENDING', 'OVERDUE', 'PAID', 'DRAFT'] as const).map((st) => (
                            <button
                              key={st}
                              type="button"
                              onClick={() => setInvoiceStatusFilter(st)}
                              className={`px-2.5 py-1 rounded-lg text-[11px] font-medium whitespace-nowrap shrink-0 transition-colors ${
                                invoiceStatusFilter === st
                                  ? 'bg-neutral-900 text-white dark:bg-neutral-100 dark:text-neutral-900'
                                  : 'bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 text-neutral-600 dark:text-neutral-400'
                              }`}
                            >
                              {st}
                            </button>
                          ))}
                        </div>
                      )}

                      {activeTab === 'clients' && (
                        <div className="space-y-2">
                          {filteredClients.map((c) => (
                            <div
                              key={c.id}
                              className="p-3 rounded-xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 flex items-center justify-between gap-2"
                            >
                              <button
                                type="button"
                                onClick={() => setDetailTarget({ type: 'clients', item: c })}
                                className="text-left min-w-0 flex-1"
                              >
                                <p className="text-xs font-semibold text-neutral-900 dark:text-neutral-100 truncate">
                                  {c.businessName}
                                </p>
                                <p className="text-[11px] text-neutral-500 dark:text-neutral-400 truncate">
                                  {c.contactName} · Net-{c.paymentTermsDays} · {c.syncState}
                                </p>
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  const err = onDeleteClient(c.id);
                                  showToast(err ?? `Deleted ${c.businessName}`);
                                }}
                                aria-label={`Delete ${c.businessName}`}
                                className="p-1.5 rounded-lg text-neutral-400 hover:text-red-600 dark:hover:text-red-400"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          ))}
                        </div>
                      )}

                      {activeTab === 'products' && (
                        <div className="space-y-2">
                          {filteredProducts.map((p) => (
                            <div
                              key={p.id}
                              className="p-3 rounded-xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 flex items-center justify-between gap-2"
                            >
                              <button
                                type="button"
                                onClick={() => setDetailTarget({ type: 'products', item: p })}
                                className="text-left min-w-0 flex-1"
                              >
                                <p className="text-xs font-semibold text-neutral-900 dark:text-neutral-100 truncate">
                                  {p.name}
                                </p>
                                <p className="text-[11px] text-neutral-500 dark:text-neutral-400 truncate">
                                  {p.sku} · {p.stockQuantity} {p.unitLabel} · {formatUsd(p.unitPriceCents)} · {p.syncState}
                                </p>
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  const err = onDeleteProduct(p.id);
                                  showToast(err ?? `Deleted ${p.sku}`);
                                }}
                                aria-label={`Delete ${p.sku}`}
                                className="p-1.5 rounded-lg text-neutral-400 hover:text-red-600 dark:hover:text-red-400"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          ))}
                        </div>
                      )}

                      {activeTab === 'invoices' && (
                        <div className="space-y-2">
                          {filteredInvoices.map((inv) => (
                            <div
                              key={inv.id}
                              className="p-3 rounded-xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 flex items-center justify-between gap-2"
                            >
                              <button
                                type="button"
                                onClick={() => setDetailTarget({ type: 'invoices', item: inv })}
                                className="text-left min-w-0 flex-1"
                              >
                                <p className="text-xs font-semibold text-neutral-900 dark:text-neutral-100 truncate">
                                  {inv.invoiceNumber} · {inv.clientName}
                                </p>
                                <p className="text-[11px] text-neutral-500 dark:text-neutral-400 truncate">
                                  {inv.status} · {formatUsd(inv.totalCents)} · {inv.syncState}
                                </p>
                              </button>
                              <div className="flex items-center gap-1 shrink-0">
                                <button
                                  type="button"
                                  onClick={() => handleExportInvoicePdf(inv)}
                                  aria-label={`Export PDF for ${inv.invoiceNumber}`}
                                  className="p-1.5 rounded-lg text-neutral-500 hover:text-blue-600 dark:hover:text-blue-400"
                                >
                                  <FileText className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => {
                                    const err = onDeleteInvoice(inv.id);
                                    showToast(err ?? `Deleted ${inv.invoiceNumber}`);
                                  }}
                                  aria-label={`Delete ${inv.invoiceNumber}`}
                                  className="p-1.5 rounded-lg text-neutral-400 hover:text-red-600 dark:hover:text-red-400"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </>
                  )}
                </div>

                {/* DetailEditScreen (Inline 2nd Pane on Tablet, Full Screen on Phone) */}
                {detailTarget && (
                  <InDeviceDetailEditPane
                    target={detailTarget}
                    clients={clients}
                    products={products}
                    onClose={() => setDetailTarget(null)}
                    onSaveClient={(c) => {
                      const err = onSaveClient(c);
                      if (err) return err;
                      showToast(`Saved ${c.businessName} (${isOnline ? 'Synced' : 'Queued Offline'})`);
                      setDetailTarget(null);
                      return null;
                    }}
                    onSaveProduct={(p) => {
                      const err = onSaveProduct(p);
                      if (err) return err;
                      showToast(`Saved ${p.sku} (${isOnline ? 'Synced' : 'Queued Offline'})`);
                      setDetailTarget(null);
                      return null;
                    }}
                    onSaveInvoice={(inv) => {
                      const err = onSaveInvoice(inv);
                      if (err) return err;
                      showToast(`Saved ${inv.invoiceNumber} (${isOnline ? 'Synced' : 'Queued Offline'})`);
                      setDetailTarget(null);
                      return null;
                    }}
                  />
                )}

                {/* Android ShareSheet Overlay */}
                {sharePreview && (
                  <div className="absolute inset-0 bg-black/50 flex items-end justify-center z-40">
                    <div className="w-full bg-white dark:bg-neutral-900 rounded-t-2xl p-4 space-y-3 border-t border-neutral-200 dark:border-neutral-800">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Share2 className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                          <h4 className="text-xs font-semibold text-neutral-900 dark:text-neutral-100">
                            Android ShareSheet · {sharePreview.title}
                          </h4>
                        </div>
                        <button
                          type="button"
                          onClick={() => setSharePreview(null)}
                          className="p-1 text-neutral-400 hover:text-neutral-700"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                      <pre className="p-2.5 rounded-lg bg-neutral-100 dark:bg-neutral-950 text-[10px] font-mono text-neutral-700 dark:text-neutral-300 max-h-36 overflow-auto whitespace-pre-wrap">
                        {sharePreview.content}
                      </pre>
                      <button
                        type="button"
                        onClick={() =>
                          triggerDownload(sharePreview.filename, sharePreview.content, sharePreview.mime)
                        }
                        className="w-full py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold"
                      >
                        Download {sharePreview.filename}
                      </button>
                    </div>
                  </div>
                )}

                {/* M3 Snackbar */}
                {snackbar && (
                  <div className="absolute bottom-3 left-3 right-3 px-3.5 py-2.5 rounded-xl bg-neutral-900 dark:bg-neutral-100 text-white dark:text-neutral-900 text-xs font-medium shadow-lg z-30">
                    {snackbar}
                  </div>
                )}
              </div>

              {/* Phone Bottom NavigationBar */}
              {!isTablet && (
                <nav className="grid grid-cols-4 border-t border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 shrink-0">
                  {navItems.map((item) => {
                    const Icon = item.icon;
                    const active = activeTab === item.id;
                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => {
                          setActiveTab(item.id);
                          setDetailTarget(null);
                        }}
                        className={`py-2.5 flex flex-col items-center gap-1 transition-colors ${
                          active
                            ? 'text-blue-600 dark:text-blue-400'
                            : 'text-neutral-500 dark:text-neutral-400'
                        }`}
                      >
                        <Icon className="w-4 h-4" />
                        <span className="text-[10px] font-medium">{item.label}</span>
                      </button>
                    );
                  })}
                </nav>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

interface InDeviceDetailEditPaneProps {
  target: DetailTarget;
  clients: Client[];
  products: Product[];
  onClose: () => void;
  onSaveClient: (c: Client) => string | null;
  onSaveProduct: (p: Product) => string | null;
  onSaveInvoice: (i: Invoice) => string | null;
}

const InDeviceDetailEditPane: React.FC<InDeviceDetailEditPaneProps> = ({
  target,
  clients,
  products,
  onClose,
  onSaveClient,
  onSaveProduct,
  onSaveInvoice,
}) => {
  const [error, setError] = useState<string | null>(null);

  const [clientForm, setClientForm] = useState<Client>(() =>
    target.type === 'clients' && target.item
      ? target.item
      : {
          id: `cli_${Date.now()}`,
          businessName: '',
          contactName: '',
          email: '',
          phone: '+1 (503) 555-0100',
          paymentTermsDays: 30,
          creditLimitCents: 1500000,
          outstandingBalanceCents: 0,
          syncState: 'PENDING_UPLOAD',
          updatedAt: new Date().toISOString(),
        }
  );

  const [productForm, setProductForm] = useState<Product>(() =>
    target.type === 'products' && target.item
      ? target.item
      : {
          id: `prd_${Date.now()}`,
          sku: '',
          name: '',
          category: 'Coffee & Tea',
          unitPriceCents: 4500,
          stockQuantity: 25,
          reorderThreshold: 10,
          unitLabel: 'case',
          syncState: 'PENDING_UPLOAD',
          updatedAt: new Date().toISOString(),
        }
  );

  const [invoiceForm, setInvoiceForm] = useState<Invoice>(() => {
    if (target.type === 'invoices' && target.item) return target.item;
    const defaultClient = clients[0];
    const defaultProduct = products[0];
    const initialItems: InvoiceLineItem[] = defaultProduct
      ? [
          {
            productId: defaultProduct.id,
            productName: defaultProduct.name,
            sku: defaultProduct.sku,
            quantity: 5,
            unitPriceCents: defaultProduct.unitPriceCents,
          },
        ]
      : [];
    return {
      id: `inv_${Date.now()}`,
      invoiceNumber: `INV-2026-${Math.floor(1100 + Math.random() * 8800)}`,
      clientId: defaultClient?.id ?? '',
      clientName: defaultClient?.businessName ?? '',
      status: 'PENDING',
      issuedDate: '2026-11-22',
      dueDate: '2026-12-22',
      items: initialItems,
      totalCents: initialItems.reduce((s, it) => s + it.quantity * it.unitPriceCents, 0),
      notes: '',
      syncState: 'PENDING_UPLOAD',
      updatedAt: new Date().toISOString(),
    };
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (target.type === 'clients') {
      const err = onSaveClient(clientForm);
      if (err) setError(err);
    } else if (target.type === 'products') {
      const err = onSaveProduct(productForm);
      if (err) setError(err);
    } else {
      const totalCents = invoiceForm.items.reduce((s, i) => s + i.quantity * i.unitPriceCents, 0);
      const err = onSaveInvoice({ ...invoiceForm, totalCents });
      if (err) setError(err);
    }
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="w-full md:w-[340px] bg-white dark:bg-neutral-900 overflow-y-auto p-4 space-y-3 shrink-0"
    >
      <div className="flex items-center justify-between">
        <button
          type="button"
          onClick={onClose}
          className="inline-flex items-center gap-1 text-xs font-medium text-neutral-600 dark:text-neutral-300"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          Back
        </button>
        <span className="text-[11px] font-mono text-neutral-400">Room Write</span>
      </div>

      {error && (
        <p className="p-2.5 rounded-lg bg-red-50 dark:bg-red-950/50 text-xs text-red-700 dark:text-red-300">
          {error}
        </p>
      )}

      {target.type === 'clients' && (
        <>
          <label className="block space-y-1">
            <span className="text-[11px] font-medium text-neutral-600 dark:text-neutral-400">Business Name</span>
            <input
              type="text"
              required
              value={clientForm.businessName}
              onChange={(e) => setClientForm({ ...clientForm, businessName: e.target.value })}
              className="w-full px-3 py-2 text-xs rounded-lg border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100"
            />
          </label>
          <label className="block space-y-1">
            <span className="text-[11px] font-medium text-neutral-600 dark:text-neutral-400">Contact Name</span>
            <input
              type="text"
              required
              value={clientForm.contactName}
              onChange={(e) => setClientForm({ ...clientForm, contactName: e.target.value })}
              className="w-full px-3 py-2 text-xs rounded-lg border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100"
            />
          </label>
          <label className="block space-y-1">
            <span className="text-[11px] font-medium text-neutral-600 dark:text-neutral-400">AP Email</span>
            <input
              type="email"
              required
              value={clientForm.email}
              onChange={(e) => setClientForm({ ...clientForm, email: e.target.value })}
              className="w-full px-3 py-2 text-xs rounded-lg border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100"
            />
          </label>
          <label className="block space-y-1">
            <span className="text-[11px] font-medium text-neutral-600 dark:text-neutral-400">Credit Limit (USD)</span>
            <input
              type="number"
              min={0}
              value={Math.round(clientForm.creditLimitCents / 100)}
              onChange={(e) =>
                setClientForm({ ...clientForm, creditLimitCents: Math.max(0, Number(e.target.value)) * 100 })
              }
              className="w-full px-3 py-2 text-xs rounded-lg border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 font-mono"
            />
          </label>
        </>
      )}

      {target.type === 'products' && (
        <>
          <label className="block space-y-1">
            <span className="text-[11px] font-medium text-neutral-600 dark:text-neutral-400">SKU</span>
            <input
              type="text"
              required
              value={productForm.sku}
              onChange={(e) => setProductForm({ ...productForm, sku: e.target.value.toUpperCase() })}
              className="w-full px-3 py-2 text-xs rounded-lg border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 font-mono"
            />
          </label>
          <label className="block space-y-1">
            <span className="text-[11px] font-medium text-neutral-600 dark:text-neutral-400">Product Name</span>
            <input
              type="text"
              required
              value={productForm.name}
              onChange={(e) => setProductForm({ ...productForm, name: e.target.value })}
              className="w-full px-3 py-2 text-xs rounded-lg border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100"
            />
          </label>
          <div className="grid grid-cols-2 gap-2">
            <label className="block space-y-1">
              <span className="text-[11px] font-medium text-neutral-600 dark:text-neutral-400">Stock Qty</span>
              <input
                type="number"
                min={0}
                value={productForm.stockQuantity}
                onChange={(e) => setProductForm({ ...productForm, stockQuantity: Math.max(0, Number(e.target.value)) })}
                className="w-full px-3 py-2 text-xs rounded-lg border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 font-mono"
              />
            </label>
            <label className="block space-y-1">
              <span className="text-[11px] font-medium text-neutral-600 dark:text-neutral-400">Unit Price ($)</span>
              <input
                type="number"
                step="0.01"
                min={0}
                value={(productForm.unitPriceCents / 100).toFixed(2)}
                onChange={(e) =>
                  setProductForm({ ...productForm, unitPriceCents: Math.round(Number(e.target.value) * 100) })
                }
                className="w-full px-3 py-2 text-xs rounded-lg border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 font-mono"
              />
            </label>
          </div>
        </>
      )}

      {target.type === 'invoices' && (
        <>
          <label className="block space-y-1">
            <span className="text-[11px] font-medium text-neutral-600 dark:text-neutral-400">Invoice #</span>
            <input
              type="text"
              required
              value={invoiceForm.invoiceNumber}
              onChange={(e) => setInvoiceForm({ ...invoiceForm, invoiceNumber: e.target.value })}
              className="w-full px-3 py-2 text-xs rounded-lg border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 font-mono"
            />
          </label>
          <label className="block space-y-1">
            <span className="text-[11px] font-medium text-neutral-600 dark:text-neutral-400">Client</span>
            <select
              value={invoiceForm.clientId}
              onChange={(e) => {
                const chosen = clients.find((c) => c.id === e.target.value);
                if (chosen) {
                  setInvoiceForm({ ...invoiceForm, clientId: chosen.id, clientName: chosen.businessName });
                }
              }}
              className="w-full px-3 py-2 text-xs rounded-lg border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100"
            >
              {clients.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.businessName}
                </option>
              ))}
            </select>
          </label>
          <label className="block space-y-1">
            <span className="text-[11px] font-medium text-neutral-600 dark:text-neutral-400">Status</span>
            <select
              value={invoiceForm.status}
              onChange={(e) => setInvoiceForm({ ...invoiceForm, status: e.target.value as InvoiceStatus })}
              className="w-full px-3 py-2 text-xs rounded-lg border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100"
            >
              <option value="DRAFT">DRAFT</option>
              <option value="PENDING">PENDING</option>
              <option value="PAID">PAID</option>
              <option value="OVERDUE">OVERDUE</option>
            </select>
          </label>
          <div className="space-y-1.5">
            <span className="text-[11px] font-medium text-neutral-600 dark:text-neutral-400">Line Items</span>
            {invoiceForm.items.map((item, idx) => (
              <div key={idx} className="flex items-center justify-between gap-2 text-xs p-2 rounded-lg bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800">
                <span className="truncate">{item.sku}</span>
                <input
                  type="number"
                  min={1}
                  value={item.quantity}
                  onChange={(e) => {
                    const qty = Math.max(1, Number(e.target.value));
                    const next = invoiceForm.items.map((it, i) => (i === idx ? { ...it, quantity: qty } : it));
                    setInvoiceForm({ ...invoiceForm, items: next });
                  }}
                  className="w-16 px-2 py-1 text-right font-mono rounded border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900"
                />
              </div>
            ))}
          </div>
          <label className="block space-y-1">
            <span className="text-[11px] font-medium text-neutral-600 dark:text-neutral-400">Notes</span>
            <textarea
              rows={2}
              value={invoiceForm.notes}
              onChange={(e) => setInvoiceForm({ ...invoiceForm, notes: e.target.value })}
              className="w-full px-3 py-2 text-xs rounded-lg border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100"
            />
          </label>
        </>
      )}

      <button
        type="submit"
        className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold transition-colors"
      >
        Save Offline-First
      </button>
    </form>
  );
};
