import React, { useMemo, useState } from 'react';
import { Check, Copy, FileCode2, Search } from 'lucide-react';
import { ANDROID_SOURCE_FILES } from '../data/kotlinCodebase';
import { AndroidSourceFile } from '../types/wholesale';

interface KotlinSourceExplorerProps {
  selectedFileId: string;
  onSelectFile: (id: string) => void;
  moduleFilter?: 'all' | AndroidSourceFile['module'];
}

const MODULE_LABELS: { id: 'all' | AndroidSourceFile['module']; label: string }[] = [
  { id: 'all', label: 'All Layers' },
  { id: 'gradle', label: 'Gradle' },
  { id: 'domain', label: ':core:domain' },
  { id: 'data', label: ':core:data' },
  { id: 'presentation', label: ':presentation' },
  { id: 'tests', label: 'Tests & R8' },
];

export const KotlinSourceExplorer: React.FC<KotlinSourceExplorerProps> = ({
  selectedFileId,
  onSelectFile,
  moduleFilter: initialModule = 'all',
}) => {
  const [moduleFilter, setModuleFilter] = useState<'all' | AndroidSourceFile['module']>(initialModule);
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const filteredFiles = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return ANDROID_SOURCE_FILES.filter((file) => {
      const matchesModule = moduleFilter === 'all' || file.module === moduleFilter;
      const matchesQuery =
        q === '' ||
        file.path.toLowerCase().includes(q) ||
        file.title.toLowerCase().includes(q) ||
        file.code.toLowerCase().includes(q);
      return matchesModule && matchesQuery;
    });
  }, [moduleFilter, searchQuery]);

  const activeFile =
    filteredFiles.find((f) => f.id === selectedFileId) ||
    ANDROID_SOURCE_FILES.find((f) => f.id === selectedFileId) ||
    filteredFiles[0] ||
    ANDROID_SOURCE_FILES[0];

  const handleCopy = async (file: AndroidSourceFile) => {
    try {
      await navigator.clipboard.writeText(file.code);
      setCopiedId(file.id);
      setTimeout(() => setCopiedId(null), 1800);
    } catch {
      // Fallback ignored if clipboard blocked
    }
  };

  const codeLines = activeFile.code.split('\n');

  return (
    <div className="border border-neutral-200 dark:border-neutral-800 rounded-xl bg-white dark:bg-neutral-900 overflow-hidden">
      <div className="px-4 py-3 border-b border-neutral-200 dark:border-neutral-800 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-1 p-1 rounded-lg bg-neutral-100 dark:bg-neutral-800 overflow-x-auto">
          {MODULE_LABELS.map((m) => (
            <button
              key={m.id}
              type="button"
              onClick={() => {
                setModuleFilter(m.id);
                const firstMatch = ANDROID_SOURCE_FILES.find((f) => m.id === 'all' || f.module === m.id);
                if (firstMatch) onSelectFile(firstMatch.id);
              }}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                moduleFilter === m.id
                  ? 'bg-white dark:bg-neutral-900 text-neutral-900 dark:text-neutral-100 shadow-xs'
                  : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-100'
              }`}
            >
              {m.label}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Filter Kotlin files or symbols..."
            aria-label="Filter Kotlin files or symbols"
            className="w-full pl-8 pr-3 py-1.5 text-xs rounded-lg border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 placeholder:text-neutral-400 focus:outline-none focus:ring-2 focus:ring-blue-600"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 min-h-[620px]">
        <div className="lg:col-span-4 xl:col-span-3 border-b lg:border-b-0 lg:border-r border-neutral-200 dark:border-neutral-800 divide-y divide-neutral-100 dark:divide-neutral-800/80 max-h-[300px] lg:max-h-[700px] overflow-y-auto">
          {filteredFiles.length === 0 ? (
            <div className="p-6 text-center text-xs text-neutral-500 dark:text-neutral-400">
              No source files match &ldquo;{searchQuery}&rdquo;.
            </div>
          ) : (
            filteredFiles.map((file) => {
              const isSelected = file.id === activeFile.id;
              return (
                <button
                  key={file.id}
                  type="button"
                  onClick={() => onSelectFile(file.id)}
                  className={`w-full text-left px-4 py-3 transition-colors flex items-start gap-2.5 ${
                    isSelected
                      ? 'bg-blue-50/70 dark:bg-blue-950/30'
                      : 'hover:bg-neutral-50 dark:hover:bg-neutral-800/40'
                  }`}
                >
                  <FileCode2
                    className={`w-4 h-4 mt-0.5 shrink-0 ${
                      isSelected ? 'text-blue-600 dark:text-blue-400' : 'text-neutral-400'
                    }`}
                  />
                  <div className="min-w-0">
                    <p
                      className={`text-xs font-medium truncate ${
                        isSelected
                          ? 'text-blue-700 dark:text-blue-300'
                          : 'text-neutral-900 dark:text-neutral-100'
                      }`}
                    >
                      {file.title}
                    </p>
                    <p className="mt-0.5 text-[11px] font-mono text-neutral-500 dark:text-neutral-400 truncate">
                      {file.path}
                    </p>
                  </div>
                </button>
              );
            })
          )}
        </div>

        <div className="lg:col-span-8 xl:col-span-9 flex flex-col min-w-0 bg-neutral-950 text-neutral-100">
          <div className="px-5 py-3.5 border-b border-neutral-800 flex flex-wrap items-center justify-between gap-3 bg-neutral-900">
            <div className="min-w-0">
              <p className="text-xs font-mono text-neutral-300 truncate">{activeFile.path}</p>
              <p className="mt-0.5 text-xs text-neutral-400">{activeFile.summary}</p>
            </div>
            <div className="flex items-center gap-3 shrink-0">
              <span className="text-xs font-mono tabular-nums text-neutral-400">
                {codeLines.length} lines · {activeFile.language}
              </span>
              <button
                type="button"
                onClick={() => handleCopy(activeFile)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md bg-neutral-800 hover:bg-neutral-700 text-neutral-100 transition-colors whitespace-nowrap shrink-0"
              >
                {copiedId === activeFile.id ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    Copied
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    Copy File
                  </>
                )}
              </button>
            </div>
          </div>

          <div className="overflow-auto max-h-[620px] p-4 text-xs font-mono leading-relaxed">
            <table className="w-full border-collapse">
              <tbody>
                {codeLines.map((line, index) => (
                  <tr key={index} className="hover:bg-neutral-900/60">
                    <td className="select-none pr-4 text-right text-neutral-600 tabular-nums align-top w-10">
                      {index + 1}
                    </td>
                    <td className="whitespace-pre text-neutral-100">{line || ' '}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
