import React, { useState } from 'react';
import { Database, KeyRound, RefreshCw, ShieldCheck } from 'lucide-react';
import { Client, Invoice, PendingSyncOp, Product, UserRole } from '../types/wholesale';

interface RoomInspectorPanelProps {
  clients: Client[];
  products: Product[];
  invoices: Invoice[];
  pendingOps: PendingSyncOp[];
  isOnline: boolean;
  isBiometricUnlocked: boolean;
  role: UserRole;
  onSyncNow: () => void;
}

type TableView = 'outbox' | 'products' | 'clients' | 'invoices';

export const RoomInspectorPanel: React.FC<RoomInspectorPanelProps> = ({
  clients,
  products,
  invoices,
  pendingOps,
  isOnline,
  isBiometricUnlocked,
  role,
  onSyncNow,
}) => {
  const [table, setTable] = useState<TableView>('outbox');

  return (
    <aside className="flex flex-col border border-neutral-200 dark:border-neutral-800 rounded-xl bg-white dark:bg-neutral-900 overflow-hidden">
      <div className="px-5 py-4 border-b border-neutral-200 dark:border-neutral-800 flex items-center justify-between gap-4">
        <div className="flex items-center gap-2.5 min-w-0">
          <Database className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0" />
          <h2 className="text-sm font-semibold text-neutral-900 dark:text-neutral-100 truncate">
            Room SQLite &amp; Keystore State
          </h2>
        </div>
        <button
          type="button"
          onClick={onSyncNow}
          disabled={!isOnline || pendingOps.length === 0}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-neutral-200 dark:border-neutral-700 text-neutral-700 dark:text-neutral-200 hover:bg-neutral-50 dark:hover:bg-neutral-800 disabled:opacity-40 disabled:cursor-not-allowed transition-colors whitespace-nowrap shrink-0"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          Flush Outbox
        </button>
      </div>

      <div className="grid grid-cols-2 divide-x divide-neutral-200 dark:divide-neutral-800 border-b border-neutral-200 dark:border-neutral-800 bg-neutral-50/60 dark:bg-neutral-950/40">
        <div className="px-4 py-3">
          <div className="flex items-center gap-1.5 text-xs text-neutral-500 dark:text-neutral-400">
            <KeyRound className="w-3.5 h-3.5" />
            <span>AndroidKeyStore</span>
          </div>
          <p className="mt-1 text-xs font-medium text-neutral-900 dark:text-neutral-100">
            {isBiometricUnlocked ? 'AES-256-GCM Unlocked' : 'Locked (Biometric Gate)'}
          </p>
        </div>
        <div className="px-4 py-3">
          <div className="flex items-center gap-1.5 text-xs text-neutral-500 dark:text-neutral-400">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>RBAC Policy</span>
          </div>
          <p className="mt-1 text-xs font-medium text-neutral-900 dark:text-neutral-100">
            {role === 'ADMIN' ? 'Admin (Full CRUD + Export)' : 'Staff (No Delete / Ledger Export)'}
          </p>
        </div>
      </div>

      <div className="px-4 pt-3 pb-2 border-b border-neutral-200 dark:border-neutral-800 flex items-center gap-1 overflow-x-auto">
        {(
          [
            { id: 'outbox', label: `pending_sync_ops (${pendingOps.length})` },
            { id: 'products', label: `products (${products.length})` },
            { id: 'clients', label: `clients (${clients.length})` },
            { id: 'invoices', label: `invoices (${invoices.length})` },
          ] as { id: TableView; label: string }[]
        ).map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setTable(item.id)}
            className={`px-2.5 py-1.5 text-xs font-mono rounded-md transition-colors whitespace-nowrap shrink-0 ${
              table === item.id
                ? 'bg-neutral-900 text-white dark:bg-neutral-100 dark:text-neutral-900'
                : 'text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800'
            }`}
          >
            {item.label}
          </button>
        ))}
      </div>

      <div className="p-4 max-h-[540px] overflow-y-auto">
        {table === 'outbox' && (
          <>
            {pendingOps.length === 0 ? (
              <div className="py-10 text-center">
                <p className="text-sm font-medium text-neutral-700 dark:text-neutral-300">
                  Sync Outbox Empty
                </p>
                <p className="mt-1 text-xs text-neutral-500 dark:text-neutral-400 max-w-xs mx-auto">
                  Switch the simulator to Offline mode and create, edit, or delete records to inspect transactional Room outbox rows.
                </p>
              </div>
            ) : (
              <div className="divide-y divide-neutral-200 dark:divide-neutral-800">
                {pendingOps.map((op) => (
                  <div key={op.id} className="py-3 first:pt-0 last:pb-0">
                    <div className="flex items-center justify-between gap-2 text-xs">
                      <span className="font-mono font-semibold text-amber-700 dark:text-amber-400">
                        {op.operation} · {op.entityType}
                      </span>
                      <span className="font-mono tabular-nums text-neutral-500 dark:text-neutral-400">
                        retries: {op.retryCount}
                      </span>
                    </div>
                    <p className="mt-1 text-xs text-neutral-700 dark:text-neutral-300 truncate">
                      {op.payloadSummary}
                    </p>
                    <p className="mt-0.5 text-[11px] font-mono text-neutral-400">
                      id={op.entityId} · {new Date(op.queuedAt).toLocaleTimeString()}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </>
        )}

        {table === 'products' && (
          <div className="divide-y divide-neutral-200 dark:divide-neutral-800">
            {products.map((p) => (
              <div key={p.id} className="py-2.5 flex items-center justify-between gap-3 text-xs">
                <div className="min-w-0">
                  <p className="font-mono font-medium text-neutral-900 dark:text-neutral-100 truncate">
                    {p.sku} · {p.name}
                  </p>
                  <p className="text-neutral-500 dark:text-neutral-400">
                    stock={p.stockQuantity} · threshold={p.reorderThreshold} · {p.syncState}
                  </p>
                </div>
                <span className="font-mono tabular-nums text-neutral-700 dark:text-neutral-300 shrink-0">
                  ${(p.unitPriceCents / 100).toFixed(2)}
                </span>
              </div>
            ))}
          </div>
        )}

        {table === 'clients' && (
          <div className="divide-y divide-neutral-200 dark:divide-neutral-800">
            {clients.map((c) => (
              <div key={c.id} className="py-2.5 flex items-center justify-between gap-3 text-xs">
                <div className="min-w-0">
                  <p className="font-medium text-neutral-900 dark:text-neutral-100 truncate">
                    {c.businessName}
                  </p>
                  <p className="font-mono text-neutral-500 dark:text-neutral-400">
                    terms=Net{c.paymentTermsDays} · {c.syncState}
                  </p>
                </div>
                <span className="font-mono tabular-nums text-neutral-700 dark:text-neutral-300 shrink-0">
                  ${(c.outstandingBalanceCents / 100).toLocaleString()}
                </span>
              </div>
            ))}
          </div>
        )}

        {table === 'invoices' && (
          <div className="divide-y divide-neutral-200 dark:divide-neutral-800">
            {invoices.map((inv) => (
              <div key={inv.id} className="py-2.5 flex items-center justify-between gap-3 text-xs">
                <div className="min-w-0">
                  <p className="font-mono font-medium text-neutral-900 dark:text-neutral-100 truncate">
                    {inv.invoiceNumber} · {inv.clientName}
                  </p>
                  <p className="font-mono text-neutral-500 dark:text-neutral-400">
                    status={inv.status} · items={inv.items.length} · {inv.syncState}
                  </p>
                </div>
                <span className="font-mono tabular-nums text-neutral-700 dark:text-neutral-300 shrink-0">
                  ${(inv.totalCents / 100).toLocaleString()}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </aside>
  );
};
