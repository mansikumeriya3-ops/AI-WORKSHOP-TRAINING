import React from 'react';
import { ArrowRight, Bell, Database, Layers, Lock, RefreshCw, Smartphone } from 'lucide-react';

interface ArchitectureBlueprintViewProps {
  onOpenFile: (fileId: string) => void;
}

export const ArchitectureBlueprintView: React.FC<ArchitectureBlueprintViewProps> = ({ onOpenFile }) => {
  const modules = [
    {
      name: ':app',
      role: 'Application Shell & Adaptive Entry',
      dependencies: ':core:presentation · :core:domain · :core:data',
      details:
        'Hosts MainActivity with edge-to-edge Window insets, Hilt @HiltAndroidApp, NavigationSuiteScaffold (Bottom Bar on Phone, NavigationRail on Tablet/Foldable), and R8 release shrinking.',
      fileId: 'pres-adaptive-nav',
    },
    {
      name: ':core:presentation',
      role: 'Jetpack Compose UI + UDF ViewModels',
      dependencies: ':core:domain',
      details:
        'Exposes immutable UiState via StateFlow (SharingStarted.WhileSubscribed(5000)), Channel one-shot events, BiometricPrompt authentication, PdfDocument/CSV ShareSheet export, and FCM MessagingService.',
      fileId: 'pres-dashboard-screen',
    },
    {
      name: ':core:domain',
      role: 'Pure Kotlin Business Rules & Contracts',
      dependencies: 'Zero Android Framework Dependencies',
      details:
        'Defines Client, Product, Invoice, UserRole RBAC policies, WholesaleRepository interface, and single-responsibility UseCases (SaveInvoiceUseCase, DeleteRecordWithRbacUseCase).',
      fileId: 'domain-usecases',
    },
    {
      name: ':core:data',
      role: 'Offline-First Persistence, Sync & Security',
      dependencies: ':core:domain',
      details:
        'Room SQLite with transactional PendingSyncOpEntity outbox, Retrofit + Kotlinx Serialization API, HiltWorker WorkManager sync with exponential backoff, and AndroidKeyStore AES-256-GCM + DataStore.',
      fileId: 'data-repository-impl',
    },
  ];

  const pipelines = [
    {
      icon: Database,
      title: '01. Offline-First Transactional Outbox',
      steps: [
        'Write entity + PendingSyncOpEntity inside Room database.withTransaction { }',
        'UI immediately updates via reactive Room Flow<List<T>> emissions',
        'WholesaleSyncScheduler enqueues OneTimeWorkRequest with NetworkType.CONNECTED',
        'SyncWorker drains FIFO outbox to Retrofit API, then pulls delta since lastSyncEpoch',
      ],
      fileId: 'data-sync-worker',
    },
    {
      icon: Lock,
      title: '02. Keystore AES-256-GCM & Biometric RBAC',
      steps: [
        'BiometricPrompt verifies BIOMETRIC_STRONG or DEVICE_CREDENTIAL before unlocking session',
        'KeyGenParameterSpec generates 256-bit hardware-backed AES/GCM/NoPadding key',
        'Encrypted IV + Ciphertext blob persists in Jetpack Preferences DataStore (zero deprecated EncryptedSharedPreferences)',
        'Domain UseCases enforce UserRole.ADMIN vs UserRole.STAFF on deletes, credit limits, and ledger exports',
      ],
      fileId: 'data-keystore',
    },
    {
      icon: Smartphone,
      title: '03. Adaptive Compose & Type-Safe Navigation',
      steps: [
        '@Serializable AppRoute sealed interfaces eliminate fragile string route arguments',
        'currentWindowAdaptiveInfo() switches NavigationBar (compact) to NavigationRail (expanded)',
        'Material 3 Dynamic Color (API 31+) with curated light/dark fallback color schemes',
        'SavedStateHandle.toRoute<AppRoute>() hydrates DetailEditViewModel cleanly across process death',
      ],
      fileId: 'pres-routes',
    },
    {
      icon: Bell,
      title: '04. PDF/CSV ShareSheet & FCM Business Alerts',
      steps: [
        'WholesaleReportExporter draws native android.graphics.pdf.PdfDocument invoices and RFC-4180 CSVs',
        'FileProvider grants temporary URI read permissions to Intent.ACTION_SEND chooser',
        'WholesaleMessagingService registers FCM tokens and dispatches high-priority NotificationChannel alerts',
        'Room observeLowStockProducts() Flow drives real-time Dashboard threshold warnings',
      ],
      fileId: 'pres-exporter-fcm',
    },
  ];

  return (
    <div className="space-y-8">
      <section className="border border-neutral-200 dark:border-neutral-800 rounded-xl bg-white dark:bg-neutral-900 p-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-6 border-b border-neutral-200 dark:border-neutral-800">
          <div>
            <p className="text-xs font-medium text-blue-600 dark:text-blue-400">
              Clean Architecture · Unidirectional Data Flow
            </p>
            <h2 className="mt-1 text-xl font-semibold text-neutral-900 dark:text-neutral-100">
              Multi-Module Dependency Graph &amp; Reactive Data Flow
            </h2>
          </div>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 max-w-md">
            Every layer adheres to strict dependency inversion: outer frameworks depend inward on pure Kotlin domain contracts.
          </p>
        </div>

        <div className="mt-6 flex flex-wrap items-center gap-3 text-xs font-mono text-neutral-700 dark:text-neutral-300 pb-6 border-b border-neutral-200 dark:border-neutral-800">
          <span className="px-3 py-1.5 rounded-md bg-neutral-100 dark:bg-neutral-800">Room Flow</span>
          <ArrowRight className="w-3.5 h-3.5 text-neutral-400" />
          <span className="px-3 py-1.5 rounded-md bg-neutral-100 dark:bg-neutral-800">WholesaleRepositoryImpl</span>
          <ArrowRight className="w-3.5 h-3.5 text-neutral-400" />
          <span className="px-3 py-1.5 rounded-md bg-neutral-100 dark:bg-neutral-800">Domain UseCases</span>
          <ArrowRight className="w-3.5 h-3.5 text-neutral-400" />
          <span className="px-3 py-1.5 rounded-md bg-neutral-100 dark:bg-neutral-800">ViewModel StateFlow</span>
          <ArrowRight className="w-3.5 h-3.5 text-neutral-400" />
          <span className="px-3 py-1.5 rounded-md bg-blue-600 text-white">Compose Material 3</span>
        </div>

        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
          {modules.map((mod) => (
            <div
              key={mod.name}
              className="p-5 rounded-lg border border-neutral-200 dark:border-neutral-800 bg-neutral-50/50 dark:bg-neutral-950/50 flex flex-col justify-between gap-4"
            >
              <div>
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <Layers className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                    <h3 className="font-mono text-sm font-semibold text-neutral-900 dark:text-neutral-100">
                      {mod.name}
                    </h3>
                  </div>
                  <span className="text-xs text-neutral-500 dark:text-neutral-400">{mod.role}</span>
                </div>
                <p className="mt-2 text-xs font-mono text-neutral-500 dark:text-neutral-400">
                  deps: {mod.dependencies}
                </p>
                <p className="mt-3 text-sm text-neutral-700 dark:text-neutral-300 leading-relaxed">
                  {mod.details}
                </p>
              </div>
              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => onOpenFile(mod.fileId)}
                  className="inline-flex items-center gap-1.5 text-xs font-medium text-blue-600 dark:text-blue-400 hover:underline"
                >
                  Inspect module source
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {pipelines.map((pipe) => {
          const Icon = pipe.icon;
          return (
            <div
              key={pipe.title}
              className="border border-neutral-200 dark:border-neutral-800 rounded-xl bg-white dark:bg-neutral-900 p-6 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center gap-2.5">
                  <Icon className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0" />
                  <h3 className="text-base font-semibold text-neutral-900 dark:text-neutral-100">
                    {pipe.title}
                  </h3>
                </div>
                <ol className="mt-4 space-y-2.5">
                  {pipe.steps.map((step, idx) => (
                    <li key={idx} className="flex items-start gap-3 text-sm text-neutral-700 dark:text-neutral-300">
                      <span className="font-mono text-xs text-neutral-400 mt-0.5 tabular-nums">
                        0{idx + 1}
                      </span>
                      <span>{step}</span>
                    </li>
                  ))}
                </ol>
              </div>
              <div className="mt-5 pt-4 border-t border-neutral-200 dark:border-neutral-800 flex justify-between items-center">
                <span className="text-xs text-neutral-500 dark:text-neutral-400 flex items-center gap-1.5">
                  <RefreshCw className="w-3.5 h-3.5" />
                  Zero deprecated APIs
                </span>
                <button
                  type="button"
                  onClick={() => onOpenFile(pipe.fileId)}
                  className="text-xs font-medium text-blue-600 dark:text-blue-400 hover:underline"
                >
                  View implementation
                </button>
              </div>
            </div>
          );
        })}
      </section>
    </div>
  );
};
