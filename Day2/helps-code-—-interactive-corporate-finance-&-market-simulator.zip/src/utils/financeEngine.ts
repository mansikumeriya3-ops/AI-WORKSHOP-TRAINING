import {
  BalanceSheet,
  CashFlowStatement,
  FinancialRatioItem,
  HealthStatus,
  HistoricalYearRow,
  IncomeStatement,
  SandboxState,
} from '../types/finance';

export const SHARES_OUTSTANDING = 2_500_000;
export const ANNUAL_DEPRECIATION = 450_000;
export const INTEREST_RATE = 0.06;
export const TAX_RATE = 0.21;
export const DIVIDEND_PAYOUT_RATIO = 0.15;

// Baseline beginning-of-year balance sheet constants so double-entry reconciles cleanly
const BEG_DEBT = 3_500_000;
const BEG_PAID_IN_CAPITAL = 6_000_000;
const BEG_RETAINED_EARNINGS = 1_800_000;
const BEG_AP = 475_000;
const BEG_ACCRUED = 360_000;
const BEG_AR = 1_500_000;
const BEG_INVENTORY = 712_500;
const BEG_PPE = 4_200_000;
const BEG_CASH =
  BEG_DEBT +
  BEG_PAID_IN_CAPITAL +
  BEG_RETAINED_EARNINGS +
  BEG_AP +
  BEG_ACCRUED -
  (BEG_AR + BEG_INVENTORY + BEG_PPE); // $5,722,500

export const DEFAULT_SANDBOX_STATE: SandboxState = {
  revenue: 12_500_000,
  cogs: 4_750_000,
  opex: 4_500_000,
  debt: 3_500_000,
  fixedAssets: 4_200_000,
  sharePrice: 28.4,
};

export interface DerivedFinancials {
  incomeStatement: IncomeStatement;
  balanceSheet: BalanceSheet;
  cashFlowStatement: CashFlowStatement;
  ratios: FinancialRatioItem[];
  eps: number;
  marketCap: number;
  peRatio: number | null;
  intrinsicSharePrice: number;
}

export function calculateFinancials(state: SandboxState): DerivedFinancials {
  const { revenue, cogs, opex, debt, fixedAssets, sharePrice } = state;

  // 1. Income Statement
  const grossProfit = revenue - cogs;
  const grossMargin = revenue > 0 ? grossProfit / revenue : 0;
  const ebit = grossProfit - opex;
  const interestExpense = debt * INTEREST_RATE;
  const ebt = ebit - interestExpense;
  const taxExpense = ebt > 0 ? ebt * TAX_RATE : 0;
  const netIncome = ebt - taxExpense;
  const dividends = netIncome > 0 ? netIncome * DIVIDEND_PAYOUT_RATIO : 0;
  const additionToRetainedEarnings = netIncome - dividends;

  const incomeStatement: IncomeStatement = {
    revenue,
    cogs,
    grossProfit,
    grossMargin,
    opex,
    depreciation: ANNUAL_DEPRECIATION,
    ebit,
    interestExpense,
    ebt,
    taxExpense,
    netIncome,
    dividends,
    additionToRetainedEarnings,
  };

  // 2. Working Capital & Capital Structure
  const accountsReceivable = Math.round(revenue * 0.12);
  const inventory = Math.round(cogs * 0.15);
  const accountsPayable = Math.round(cogs * 0.1);
  const accruedLiabilities = Math.round(opex * 0.08);

  const shortTermDebt = Math.round(debt * 0.2);
  const longTermDebt = debt - shortTermDebt;

  const paidInCapital = BEG_PAID_IN_CAPITAL;
  const priorRetainedEarnings = BEG_RETAINED_EARNINGS;
  const totalRetainedEarnings = priorRetainedEarnings + additionToRetainedEarnings;
  const totalEquity = paidInCapital + totalRetainedEarnings;

  // 3. Cash Flow Statement (Operating, Investing, Financing)
  const changeInReceivables = accountsReceivable - BEG_AR;
  const changeInInventory = inventory - BEG_INVENTORY;
  const changeInPayables = accountsPayable - BEG_AP;
  const changeInAccrued = accruedLiabilities - BEG_ACCRUED;

  const operatingCashFlow =
    netIncome +
    ANNUAL_DEPRECIATION -
    changeInReceivables -
    changeInInventory +
    changeInPayables +
    changeInAccrued;

  const capex = fixedAssets + ANNUAL_DEPRECIATION - BEG_PPE;
  const investingCashFlow = -capex;

  const debtChange = debt - BEG_DEBT;
  const rawFinancingCashFlow = debtChange - dividends;

  const rawEndingCash =
    BEG_CASH + operatingCashFlow + investingCashFlow + rawFinancingCashFlow;

  // If operational losses or heavy CapEx push cash below $0, model a revolving credit overdraft
  // so Assets = Liabilities + Equity remains strictly true and Cash floors at $0.
  const creditLineOverdraft = rawEndingCash < 0 ? Math.abs(rawEndingCash) : 0;
  const endingCash = rawEndingCash < 0 ? 0 : rawEndingCash;
  const financingCashFlow = rawFinancingCashFlow + creditLineOverdraft;
  const netCashChange = operatingCashFlow + investingCashFlow + financingCashFlow;

  const cashFlowStatement: CashFlowStatement = {
    beginningCash: BEG_CASH,
    netIncome,
    depreciation: ANNUAL_DEPRECIATION,
    changeInReceivables,
    changeInInventory,
    changeInPayables,
    changeInAccrued,
    operatingCashFlow,
    capex,
    investingCashFlow,
    debtChange,
    dividendsPaid: dividends,
    overdraftDraw: creditLineOverdraft,
    financingCashFlow,
    netCashChange,
    endingCash,
  };

  // 4. Balance Sheet
  const totalCurrentAssets = endingCash + accountsReceivable + inventory;
  const totalAssets = totalCurrentAssets + fixedAssets;

  const totalCurrentLiabilities =
    accountsPayable + accruedLiabilities + shortTermDebt + creditLineOverdraft;
  const totalLiabilities = totalCurrentLiabilities + longTermDebt;
  const totalLiabilitiesAndEquity = totalLiabilities + totalEquity;
  const balanceDelta = Math.round(totalAssets - totalLiabilitiesAndEquity);

  const balanceSheet: BalanceSheet = {
    cash: endingCash,
    accountsReceivable,
    inventory,
    totalCurrentAssets,
    fixedAssets,
    totalAssets,
    accountsPayable,
    accruedLiabilities,
    shortTermDebt,
    creditLineOverdraft,
    totalCurrentLiabilities,
    longTermDebt,
    totalLiabilities,
    paidInCapital,
    priorRetainedEarnings,
    currentRetainedEarnings: additionToRetainedEarnings,
    totalRetainedEarnings,
    totalEquity,
    totalLiabilitiesAndEquity,
    balanceDelta,
  };

  // 5. Key Financial Ratios
  const currentRatio =
    totalCurrentLiabilities > 0 ? totalCurrentAssets / totalCurrentLiabilities : 0;
  const quickRatio =
    totalCurrentLiabilities > 0
      ? (endingCash + accountsReceivable) / totalCurrentLiabilities
      : 0;
  const netProfitMargin = revenue > 0 ? (netIncome / revenue) * 100 : 0;
  const roe = totalEquity > 0 ? (netIncome / totalEquity) * 100 : 0;
  const debtToEquity = totalEquity > 0 ? (debt + creditLineOverdraft) / totalEquity : 9.99;
  const interestCoverage = interestExpense > 0 ? ebit / interestExpense : ebit > 0 ? 25 : 0;

  const currentStatus: HealthStatus =
    currentRatio >= 1.5 ? 'Healthy' : currentRatio >= 1.0 ? 'Warning' : 'Critical';
  const quickStatus: HealthStatus =
    quickRatio >= 1.1 ? 'Healthy' : quickRatio >= 0.8 ? 'Warning' : 'Critical';
  const marginStatus: HealthStatus =
    netProfitMargin >= 12 ? 'Healthy' : netProfitMargin >= 4 ? 'Warning' : 'Critical';
  const roeStatus: HealthStatus =
    roe >= 15 ? 'Healthy' : roe >= 6 ? 'Warning' : 'Critical';
  const dteStatus: HealthStatus =
    debtToEquity <= 0.8 ? 'Healthy' : debtToEquity <= 1.5 ? 'Warning' : 'Critical';
  const coverageStatus: HealthStatus =
    interestCoverage >= 4 ? 'Healthy' : interestCoverage >= 1.8 ? 'Warning' : 'Critical';

  const clampPct = (n: number) => Math.max(4, Math.min(100, n));

  const ratios: FinancialRatioItem[] = [
    {
      id: 'current-ratio',
      category: 'Liquidity',
      name: 'Current Ratio',
      value: currentRatio,
      formattedValue: `${currentRatio.toFixed(2)}x`,
      status: currentStatus,
      benchmark: 'Target: >= 1.50x',
      formula: 'Current Assets / Current Liabilities',
      explanation:
        'Measures whether Helps Code has enough short-term assets (cash, receivables, inventory) to cover bills due within 12 months.',
      gaugePercent: clampPct((currentRatio / 3.5) * 100),
    },
    {
      id: 'quick-ratio',
      category: 'Liquidity',
      name: 'Quick Ratio (Acid Test)',
      value: quickRatio,
      formattedValue: `${quickRatio.toFixed(2)}x`,
      status: quickStatus,
      benchmark: 'Target: >= 1.10x',
      formula: '(Cash + Accounts Receivable) / Current Liabilities',
      explanation:
        'Stricter liquidity check excluding inventory. Shows if immediate liquid cash and incoming invoices cover short-term debt.',
      gaugePercent: clampPct((quickRatio / 3.0) * 100),
    },
    {
      id: 'net-profit-margin',
      category: 'Profitability',
      name: 'Net Profit Margin',
      value: netProfitMargin,
      formattedValue: `${netProfitMargin.toFixed(1)}%`,
      status: marginStatus,
      benchmark: 'Target: >= 12.0%',
      formula: '(Net Income / Revenue) x 100',
      explanation:
        'Percentage of every revenue dollar that remains as pure profit after COGS, R&D, operating expenses, interest, and taxes.',
      gaugePercent: clampPct(((netProfitMargin + 10) / 40) * 100),
    },
    {
      id: 'roe',
      category: 'Profitability',
      name: 'Return on Equity (ROE)',
      value: roe,
      formattedValue: `${roe.toFixed(1)}%`,
      status: roeStatus,
      benchmark: 'Target: >= 15.0%',
      formula: '(Net Income / Total Shareholders Equity) x 100',
      explanation:
        'Measures how efficiently Helps Code generates profit from each dollar invested by shareholders.',
      gaugePercent: clampPct(((roe + 10) / 45) * 100),
    },
    {
      id: 'debt-to-equity',
      category: 'Leverage',
      name: 'Debt-to-Equity Ratio',
      value: debtToEquity,
      formattedValue: `${debtToEquity.toFixed(2)}x`,
      status: dteStatus,
      benchmark: 'Target: <= 0.80x',
      formula: 'Total Debt / Total Shareholders Equity',
      explanation:
        'Reveals capital structure risk. Higher ratios mean Helps Code relies heavily on borrowed capital rather than equity.',
      gaugePercent: clampPct(100 - (debtToEquity / 2.5) * 100),
    },
    {
      id: 'interest-coverage',
      category: 'Leverage',
      name: 'Interest Coverage',
      value: interestCoverage,
      formattedValue: `${Math.min(99.9, Math.max(-20, interestCoverage)).toFixed(1)}x`,
      status: coverageStatus,
      benchmark: 'Target: >= 4.0x',
      formula: 'Operating Income (EBIT) / Interest Expense',
      explanation:
        'Indicates how easily operating profits pay annual interest obligations on corporate debt.',
      gaugePercent: clampPct((interestCoverage / 16) * 100),
    },
  ];

  // 6. Equity Valuation Metrics
  const eps = netIncome / SHARES_OUTSTANDING;
  const marketCap = sharePrice * SHARES_OUTSTANDING;
  const peRatio = eps > 0.05 ? sharePrice / eps : null;

  // Fundamental anchor price driven by Sandbox EBITDA/Net Income + Revenue multiple - Debt
  const revenueMultipleValue = revenue * 4.2;
  const earningsValue = Math.max(0, netIncome) * 18;
  const enterpriseValue = revenueMultipleValue * 0.5 + earningsValue * 0.5;
  const equityValue = Math.max(
    5_000_000,
    enterpriseValue + endingCash - debt - creditLineOverdraft
  );
  const intrinsicSharePrice = Number((equityValue / SHARES_OUTSTANDING).toFixed(2));

  return {
    incomeStatement,
    balanceSheet,
    cashFlowStatement,
    ratios,
    eps,
    marketCap,
    peRatio,
    intrinsicSharePrice,
  };
}

export function buildHistoricalTrend(current: DerivedFinancials): HistoricalYearRow[] {
  const y5 = current.incomeStatement;
  return [
    {
      year: 'Year 1',
      revenue: 4_800_000,
      cogs: 2_112_000,
      grossProfit: 2_688_000,
      opex: 2_420_000,
      netIncome: 142_000,
    },
    {
      year: 'Year 2',
      revenue: 6_450_000,
      cogs: 2_709_000,
      grossProfit: 3_741_000,
      opex: 3_010_000,
      netIncome: 465_000,
    },
    {
      year: 'Year 3',
      revenue: 8_300_000,
      cogs: 3_320_000,
      grossProfit: 4_980_000,
      opex: 3_620_000,
      netIncome: 924_000,
    },
    {
      year: 'Year 4',
      revenue: 10_400_000,
      cogs: 4_056_000,
      grossProfit: 6_344_000,
      opex: 4_110_000,
      netIncome: 1_595_000,
    },
    {
      year: 'Year 5 (Live)',
      revenue: y5.revenue,
      cogs: y5.cogs,
      grossProfit: y5.grossProfit,
      opex: y5.opex,
      netIncome: y5.netIncome,
    },
  ];
}

export function formatCurrency(value: number): string {
  const abs = Math.abs(Math.round(value));
  const formatted = abs.toLocaleString('en-US');
  return value < 0 ? `-$${formatted}` : `$${formatted}`;
}

export function formatCompactCurrency(value: number): string {
  const sign = value < 0 ? '-' : '';
  const abs = Math.abs(value);
  if (abs >= 1_000_000_000) {
    return `${sign}$${(abs / 1_000_000_000).toFixed(2)}B`;
  }
  if (abs >= 1_000_000) {
    return `${sign}$${(abs / 1_000_000).toFixed(2)}M`;
  }
  if (abs >= 1_000) {
    return `${sign}$${(abs / 1_000).toFixed(0)}K`;
  }
  return `${sign}$${abs.toFixed(0)}`;
}

export function formatPercent(value: number, decimals = 1): string {
  return `${value >= 0 ? '' : '-'}${Math.abs(value).toFixed(decimals)}%`;
}
