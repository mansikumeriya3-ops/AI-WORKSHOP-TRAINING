export type ModuleId =
  | 'statements'
  | 'ratios'
  | 'trends'
  | 'forecasting'
  | 'budgeting'
  | 'planning'
  | 'market';

export interface SandboxState {
  revenue: number;        // Annualized revenue ($)
  cogs: number;           // Cost of Goods Sold ($)
  opex: number;           // Operating Expenses ($) - includes $450k non-cash depreciation
  debt: number;           // Total Debt ($)
  fixedAssets: number;    // Net PP&E ($)
  sharePrice: number;     // Market Share Price ($)
}

export interface IncomeStatement {
  revenue: number;
  cogs: number;
  grossProfit: number;
  grossMargin: number;
  opex: number;
  depreciation: number;
  ebit: number;
  interestExpense: number;
  ebt: number;
  taxExpense: number;
  netIncome: number;
  dividends: number;
  additionToRetainedEarnings: number;
}

export interface BalanceSheet {
  // Assets
  cash: number;
  accountsReceivable: number;
  inventory: number;
  totalCurrentAssets: number;
  fixedAssets: number;
  totalAssets: number;
  // Liabilities
  accountsPayable: number;
  accruedLiabilities: number;
  shortTermDebt: number;
  creditLineOverdraft: number;
  totalCurrentLiabilities: number;
  longTermDebt: number;
  totalLiabilities: number;
  // Equity
  paidInCapital: number;
  priorRetainedEarnings: number;
  currentRetainedEarnings: number;
  totalRetainedEarnings: number;
  totalEquity: number;
  // Check
  totalLiabilitiesAndEquity: number;
  balanceDelta: number;
}

export interface CashFlowStatement {
  beginningCash: number;
  netIncome: number;
  depreciation: number;
  changeInReceivables: number;
  changeInInventory: number;
  changeInPayables: number;
  changeInAccrued: number;
  operatingCashFlow: number;
  capex: number;
  investingCashFlow: number;
  debtChange: number;
  dividendsPaid: number;
  overdraftDraw: number;
  financingCashFlow: number;
  netCashChange: number;
  endingCash: number;
}

export type HealthStatus = 'Healthy' | 'Warning' | 'Critical';

export interface FinancialRatioItem {
  id: string;
  category: 'Liquidity' | 'Profitability' | 'Leverage';
  name: string;
  value: number;
  formattedValue: string;
  status: HealthStatus;
  benchmark: string;
  formula: string;
  explanation: string;
  gaugePercent: number; // 0 to 100
}

export interface HistoricalYearRow {
  year: string;
  revenue: number;
  cogs: number;
  grossProfit: number;
  opex: number;
  netIncome: number;
}

export interface GlossaryEntry {
  id: string;
  term: string;
  category: string;
  definition: string;
  formula: string;
  helpsCodeContext: string;
}

export interface StockTick {
  timestamp: string;
  price: number;
  eventLabel?: string;
}

export interface TradeOrder {
  id: string;
  timestamp: string;
  side: 'BUY' | 'SELL';
  shares: number;
  price: number;
  total: number;
}

export interface MarketNewsEvent {
  id: string;
  title: string;
  summary: string;
  impactPercent: number;
  sentiment: 'positive' | 'negative' | 'neutral';
  timestamp: string;
}
