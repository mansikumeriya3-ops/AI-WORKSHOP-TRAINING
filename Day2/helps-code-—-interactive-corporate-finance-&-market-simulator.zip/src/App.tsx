import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Activity,
  BarChart3,
  BookOpen,
  Compass,
  FileSpreadsheet,
  Gauge,
  Menu,
  Moon,
  PieChart,
  Sun,
  TrendingUp,
  X,
} from 'lucide-react';
import { ModuleId, SandboxState } from './types/finance';
import {
  calculateFinancials,
  DEFAULT_SANDBOX_STATE,
  formatCompactCurrency,
} from './utils/financeEngine';
import { SandboxDrawer } from './components/SandboxDrawer';
import { Module1Statements } from './components/modules/Module1Statements';
import { Module2Ratios } from './components/modules/Module2Ratios';
import { Module3Trends } from './components/modules/Module3Trends';
import { Module4Forecasting } from './components/modules/Module4Forecasting';
import { Module5Budgeting } from './components/modules/Module5Budgeting';
import { Module6Planning } from './components/modules/Module6Planning';
import { Module7StockMarket } from './components/modules/Module7StockMarket';

const NAV_ITEMS: {
  id: ModuleId;
  index: string;
  label: string;
  subtitle: string;
  icon: React.ComponentType<{ className?: string }>;
}[] = [
  {
    id: 'statements',
    index: '01',
    label: 'Financial Statements',
    subtitle: 'Income, Balance Sheet & Cash',
    icon: FileSpreadsheet,
  },
  {
    id: 'ratios',
    index: '02',
    label: 'Ratio Analysis',
    subtitle: 'Liquidity, Profit & Leverage',
    icon: Gauge,
  },
  {
    id: 'trends',
    index: '03',
    label: 'Trend Analysis',
    subtitle: '5-Year Horizontal & Vertical',
    icon: BarChart3,
  },
  {
    id: 'forecasting',
    index: '04',
    label: 'Forecasting',
    subtitle: 'Best, Base & Worst Scenarios',
    icon: TrendingUp,
  },
  {
    id: 'budgeting',
    index: '05',
    label: 'Budgeting',
    subtitle: '$1M Resource Allocation',
    icon: PieChart,
  },
  {
    id: 'planning',
    index: '06',
    label: 'Financial Planning',
    subtitle: 'Break-Even & Cash Runway',
    icon: Compass,
  },
  {
    id: 'market',
    index: '07',
    label: 'Stock Market',
    subtitle: 'HLC Ticker & Mock Portfolio',
    icon: Activity,
  },
];

export default function App() {
  const [activeModule, setActiveModule] = useState<ModuleId>('statements');
  const [sandbox, setSandbox] = useState<SandboxState>(DEFAULT_SANDBOX_STATE);
  const [learnMode, setLearnMode] = useState<boolean>(true);
  const [isDark, setIsDark] = useState<boolean>(false);
  const [mobileNavOpen, setMobileNavOpen] = useState<boolean>(false);

  useEffect(() => {
    const root = document.documentElement;
    if (isDark) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [isDark]);

  const handleSandboxChange = useCallback((next: SandboxState) => {
    setSandbox(next);
  }, []);

  const financials = useMemo(() => calculateFinancials(sandbox), [sandbox]);

  const handleSelectModule = (id: ModuleId) => {
    setActiveModule(id);
    setMobileNavOpen(false);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 transition-colors dark:bg-slate-950 dark:text-slate-100">
      {/* Top Corporate Header */}
      <header className="sticky top-0 z-40 border-b border-slate-200 bg-white/95 backdrop-blur dark:border-slate-800 dark:bg-slate-900/95">
        <div className="mx-auto flex max-w-[1440px] items-center justify-between gap-4 px-4 py-3 sm:px-6">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setMobileNavOpen((o) => !o)}
              aria-label="Toggle module navigation"
              className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-100 lg:hidden dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              {mobileNavOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
            </button>

            <div className="flex items-center gap-3">
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-slate-900 font-display text-sm font-extrabold tracking-tight text-white dark:bg-emerald-600">
                HC
              </div>
              <div>
                <h1 className="font-display text-lg font-bold leading-tight tracking-tight text-slate-900 dark:text-slate-100">
                  Helps Code
                </h1>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Interactive Corporate Finance &amp; Market Simulator
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={() => setLearnMode((l) => !l)}
              aria-pressed={learnMode}
              className={`inline-flex items-center gap-1.5 whitespace-nowrap rounded-lg border px-3 py-1.5 text-xs font-semibold transition-colors ${
                learnMode
                  ? 'border-emerald-300 bg-emerald-50 text-emerald-800 dark:border-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300'
                  : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-slate-800'
              }`}
            >
              <BookOpen className="h-3.5 w-3.5" />
              <span>Learn Mode: {learnMode ? 'On' : 'Off'}</span>
            </button>

            <button
              type="button"
              onClick={() => setIsDark((d) => !d)}
              aria-label={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
              className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-700 transition-colors hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              {isDark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </button>
          </div>
        </div>
      </header>

      {/* Persistent Live Company Sandbox Controls */}
      <SandboxDrawer
        sandbox={sandbox}
        onChange={handleSandboxChange}
        netIncome={financials.incomeStatement.netIncome}
        cash={financials.balanceSheet.cash}
        marketCap={financials.marketCap}
      />

      {/* Main Workspace: Left Sidebar + Active Module Canvas */}
      <div className="mx-auto flex max-w-[1440px] flex-col lg:flex-row">
        {/* Left Navigation Sidebar */}
        <aside
          className={`${
            mobileNavOpen ? 'block' : 'hidden'
          } w-full shrink-0 border-b border-slate-200 bg-white p-4 lg:block lg:w-64 lg:border-r lg:border-b-0 dark:border-slate-800 dark:bg-slate-900/50`}
        >
          <div className="mb-3 px-2">
            <span className="text-xs font-semibold text-slate-400 dark:text-slate-500">
              Curriculum Modules
            </span>
          </div>

          <nav aria-label="Finance Simulation Modules" className="space-y-1">
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              const active = activeModule === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => handleSelectModule(item.id)}
                  aria-current={active ? 'page' : undefined}
                  className={`flex w-full items-start gap-3 rounded-lg px-3 py-2.5 text-left transition-colors ${
                    active
                      ? 'bg-slate-900 text-white dark:bg-emerald-600/20 dark:text-emerald-300'
                      : 'text-slate-700 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800/70'
                  }`}
                >
                  <Icon
                    className={`mt-0.5 h-4 w-4 shrink-0 ${
                      active
                        ? 'text-emerald-400 dark:text-emerald-400'
                        : 'text-slate-400 dark:text-slate-500'
                    }`}
                  />
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-sm font-semibold">
                      {item.index}. {item.label}
                    </div>
                    <div
                      className={`truncate text-xs ${
                        active
                          ? 'text-slate-300 dark:text-emerald-200/80'
                          : 'text-slate-500 dark:text-slate-400'
                      }`}
                    >
                      {item.subtitle}
                    </div>
                  </div>
                </button>
              );
            })}
          </nav>

          {/* Compact CFO Snapshot in Sidebar */}
          <div className="mt-6 border-t border-slate-200 pt-4 dark:border-slate-800">
            <span className="px-2 text-xs font-semibold text-slate-400 dark:text-slate-500">
              CFO Snapshot
            </span>
            <div className="mt-2.5 space-y-2 px-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-500 dark:text-slate-400">Net Profit Margin</span>
                <span
                  className={`font-mono font-semibold ${
                    financials.incomeStatement.netIncome >= 0
                      ? 'text-emerald-600 dark:text-emerald-400'
                      : 'text-rose-600 dark:text-rose-400'
                  }`}
                >
                  {sandbox.revenue > 0
                    ? `${((financials.incomeStatement.netIncome / sandbox.revenue) * 100).toFixed(1)}%`
                    : '0.0%'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500 dark:text-slate-400">Cash Position</span>
                <span className="font-mono font-semibold text-slate-900 dark:text-slate-100">
                  {formatCompactCurrency(financials.balanceSheet.cash)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500 dark:text-slate-400">HLC Share Price</span>
                <span className="font-mono font-semibold text-slate-900 dark:text-slate-100">
                  ${sandbox.sharePrice.toFixed(2)}
                </span>
              </div>
            </div>
          </div>
        </aside>

        {/* Active Module Content Viewport */}
        <main className="min-w-0 flex-1 p-4 sm:p-6 lg:p-8">
          {activeModule === 'statements' && (
            <Module1Statements
              sandbox={sandbox}
              onUpdateSandbox={handleSandboxChange}
              financials={financials}
              learnMode={learnMode}
              isDark={isDark}
            />
          )}
          {activeModule === 'ratios' && (
            <Module2Ratios financials={financials} learnMode={learnMode} />
          )}
          {activeModule === 'trends' && (
            <Module3Trends
              financials={financials}
              learnMode={learnMode}
              isDark={isDark}
            />
          )}
          {activeModule === 'forecasting' && (
            <Module4Forecasting
              financials={financials}
              learnMode={learnMode}
              isDark={isDark}
            />
          )}
          {activeModule === 'budgeting' && (
            <Module5Budgeting learnMode={learnMode} isDark={isDark} />
          )}
          {activeModule === 'planning' && (
            <Module6Planning
              financials={financials}
              learnMode={learnMode}
              isDark={isDark}
            />
          )}
          {activeModule === 'market' && (
            <Module7StockMarket
              sandbox={sandbox}
              onUpdateSandbox={handleSandboxChange}
              financials={financials}
              learnMode={learnMode}
              isDark={isDark}
            />
          )}
        </main>
      </div>
    </div>
  );
}
