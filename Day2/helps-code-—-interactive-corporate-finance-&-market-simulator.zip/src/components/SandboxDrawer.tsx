import React, { useState } from 'react';
import { ChevronDown, ChevronUp, RotateCcw, SlidersHorizontal } from 'lucide-react';
import { SandboxState } from '../types/finance';
import { DEFAULT_SANDBOX_STATE, formatCompactCurrency } from '../utils/financeEngine';

interface SandboxDrawerProps {
  sandbox: SandboxState;
  onChange: (next: SandboxState) => void;
  netIncome: number;
  cash: number;
  marketCap: number;
}

const PRESETS: { label: string; state: SandboxState }[] = [
  {
    label: 'Baseline',
    state: DEFAULT_SANDBOX_STATE,
  },
  {
    label: 'Hypergrowth',
    state: {
      revenue: 21_500_000,
      cogs: 7_300_000,
      opex: 6_800_000,
      debt: 2_500_000,
      fixedAssets: 5_400_000,
      sharePrice: 46.8,
    },
  },
  {
    label: 'Margin Squeeze',
    state: {
      revenue: 10_200_000,
      cogs: 5_600_000,
      opex: 4_300_000,
      debt: 4_800_000,
      fixedAssets: 4_600_000,
      sharePrice: 14.2,
    },
  },
  {
    label: 'High Leverage',
    state: {
      revenue: 14_000_000,
      cogs: 5_400_000,
      opex: 4_900_000,
      debt: 12_500_000,
      fixedAssets: 7_200_000,
      sharePrice: 21.5,
    },
  },
];

export const SandboxDrawer: React.FC<SandboxDrawerProps> = ({
  sandbox,
  onChange,
  netIncome,
  cash,
  marketCap,
}) => {
  const [expanded, setExpanded] = useState(true);

  const updateField = (key: keyof SandboxState, value: number) => {
    onChange({
      ...sandbox,
      [key]: value,
    });
  };

  return (
    <section
      aria-label="Live Company Sandbox Controls"
      className="border-b border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900"
    >
      <div className="mx-auto max-w-[1440px] px-4 py-3 sm:px-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-4">
            <button
              type="button"
              onClick={() => setExpanded((prev) => !prev)}
              className="inline-flex items-center gap-2 text-sm font-semibold text-slate-900 hover:text-slate-700 dark:text-slate-100 dark:hover:text-emerald-400"
            >
              <SlidersHorizontal className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
              <span>Live Company Sandbox</span>
              {expanded ? (
                <ChevronUp className="h-4 w-4 text-slate-400" />
              ) : (
                <ChevronDown className="h-4 w-4 text-slate-400" />
              )}
            </button>

            <div className="hidden items-center gap-3 text-xs text-slate-500 md:flex dark:text-slate-400">
              <span>
                Revenue{' '}
                <strong className="font-mono text-slate-900 dark:text-slate-100">
                  {formatCompactCurrency(sandbox.revenue)}
                </strong>
              </span>
              <span aria-hidden="true">·</span>
              <span>
                Net Income{' '}
                <strong
                  className={`font-mono ${
                    netIncome >= 0
                      ? 'text-emerald-600 dark:text-emerald-400'
                      : 'text-rose-600 dark:text-rose-400'
                  }`}
                >
                  {formatCompactCurrency(netIncome)}
                </strong>
              </span>
              <span aria-hidden="true">·</span>
              <span>
                Cash{' '}
                <strong className="font-mono text-slate-900 dark:text-slate-100">
                  {formatCompactCurrency(cash)}
                </strong>
              </span>
              <span aria-hidden="true">·</span>
              <span>
                Market Cap{' '}
                <strong className="font-mono text-slate-900 dark:text-slate-100">
                  {formatCompactCurrency(marketCap)}
                </strong>
              </span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            {PRESETS.map((preset) => (
              <button
                key={preset.label}
                type="button"
                onClick={() => onChange(preset.state)}
                className="whitespace-nowrap rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1 text-xs font-medium text-slate-700 transition-colors hover:border-slate-300 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700"
              >
                {preset.label}
              </button>
            ))}
            <button
              type="button"
              onClick={() => onChange(DEFAULT_SANDBOX_STATE)}
              title="Reset to Baseline"
              className="inline-flex items-center gap-1 whitespace-nowrap rounded-lg px-2.5 py-1 text-xs font-medium text-slate-500 transition-colors hover:bg-slate-100 hover:text-slate-800 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-slate-200"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              <span>Reset</span>
            </button>
          </div>
        </div>

        {expanded && (
          <div className="mt-3 grid grid-cols-1 gap-4 border-t border-slate-100 pt-3 sm:grid-cols-2 lg:grid-cols-6 dark:border-slate-800/80">
            <div>
              <div className="mb-1.5 flex items-center justify-between text-xs">
                <label
                  htmlFor="sb-revenue"
                  className="font-medium text-slate-600 dark:text-slate-300"
                >
                  Annual Revenue
                </label>
                <span className="font-mono font-semibold text-slate-900 dark:text-slate-100">
                  {formatCompactCurrency(sandbox.revenue)}
                </span>
              </div>
              <input
                id="sb-revenue"
                type="range"
                min={4_000_000}
                max={30_000_000}
                step={250_000}
                value={sandbox.revenue}
                onChange={(e) => updateField('revenue', Number(e.target.value))}
                className="fin-slider w-full"
              />
            </div>

            <div>
              <div className="mb-1.5 flex items-center justify-between text-xs">
                <label
                  htmlFor="sb-cogs"
                  className="font-medium text-slate-600 dark:text-slate-300"
                >
                  COGS
                </label>
                <span className="font-mono font-semibold text-slate-900 dark:text-slate-100">
                  {formatCompactCurrency(sandbox.cogs)}
                </span>
              </div>
              <input
                id="sb-cogs"
                type="range"
                min={1_000_000}
                max={18_000_000}
                step={150_000}
                value={sandbox.cogs}
                onChange={(e) => updateField('cogs', Number(e.target.value))}
                className="fin-slider w-full"
              />
            </div>

            <div>
              <div className="mb-1.5 flex items-center justify-between text-xs">
                <label
                  htmlFor="sb-opex"
                  className="font-medium text-slate-600 dark:text-slate-300"
                >
                  Operating Expenses
                </label>
                <span className="font-mono font-semibold text-slate-900 dark:text-slate-100">
                  {formatCompactCurrency(sandbox.opex)}
                </span>
              </div>
              <input
                id="sb-opex"
                type="range"
                min={1_500_000}
                max={14_000_000}
                step={150_000}
                value={sandbox.opex}
                onChange={(e) => updateField('opex', Number(e.target.value))}
                className="fin-slider w-full"
              />
            </div>

            <div>
              <div className="mb-1.5 flex items-center justify-between text-xs">
                <label
                  htmlFor="sb-debt"
                  className="font-medium text-slate-600 dark:text-slate-300"
                >
                  Total Debt
                </label>
                <span className="font-mono font-semibold text-slate-900 dark:text-slate-100">
                  {formatCompactCurrency(sandbox.debt)}
                </span>
              </div>
              <input
                id="sb-debt"
                type="range"
                min={0}
                max={16_000_000}
                step={250_000}
                value={sandbox.debt}
                onChange={(e) => updateField('debt', Number(e.target.value))}
                className="fin-slider w-full"
              />
            </div>

            <div>
              <div className="mb-1.5 flex items-center justify-between text-xs">
                <label
                  htmlFor="sb-assets"
                  className="font-medium text-slate-600 dark:text-slate-300"
                >
                  Fixed Assets (PP&amp;E)
                </label>
                <span className="font-mono font-semibold text-slate-900 dark:text-slate-100">
                  {formatCompactCurrency(sandbox.fixedAssets)}
                </span>
              </div>
              <input
                id="sb-assets"
                type="range"
                min={1_000_000}
                max={12_000_000}
                step={200_000}
                value={sandbox.fixedAssets}
                onChange={(e) => updateField('fixedAssets', Number(e.target.value))}
                className="fin-slider w-full"
              />
            </div>

            <div>
              <div className="mb-1.5 flex items-center justify-between text-xs">
                <label
                  htmlFor="sb-price"
                  className="font-medium text-slate-600 dark:text-slate-300"
                >
                  HLC Share Price
                </label>
                <span className="font-mono font-semibold text-slate-900 dark:text-slate-100">
                  ${sandbox.sharePrice.toFixed(2)}
                </span>
              </div>
              <input
                id="sb-price"
                type="range"
                min={5}
                max={80}
                step={0.2}
                value={sandbox.sharePrice}
                onChange={(e) => updateField('sharePrice', Number(e.target.value))}
                className="fin-slider w-full"
              />
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
