import {
  BarController,
  BarElement,
  CategoryScale,
  Chart as ChartJS,
  Filler,
  Legend,
  LinearScale,
  LineController,
  LineElement,
  PointElement,
  Title,
  Tooltip,
  type ChartOptions,
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  LineController,
  BarController,
  Title,
  Tooltip,
  Legend,
  Filler
);

export function getChartTheme(isDark: boolean) {
  return {
    textColor: isDark ? '#94a3b8' : '#475569',
    titleColor: isDark ? '#f1f5f9' : '#0f172a',
    gridColor: isDark ? 'rgba(148, 163, 184, 0.12)' : 'rgba(15, 23, 42, 0.06)',
    tooltipBg: isDark ? '#0f172a' : '#0f172a',
    tooltipBorder: isDark ? '#334155' : '#1e293b',
  };
}

export function buildBaseOptions(
  isDark: boolean,
  overrides: Partial<ChartOptions<'line' | 'bar'>> = {}
): ChartOptions<any> {
  const t = getChartTheme(isDark);
  return {
    responsive: true,
    maintainAspectRatio: false,
    animation: {
      duration: 280,
    },
    interaction: {
      mode: 'index',
      intersect: false,
    },
    plugins: {
      legend: {
        labels: {
          color: t.textColor,
          font: {
            family: '"DM Sans", system-ui, sans-serif',
            size: 12,
            weight: 500,
          },
          usePointStyle: true,
          boxWidth: 8,
          boxHeight: 8,
          padding: 16,
        },
      },
      tooltip: {
        backgroundColor: t.tooltipBg,
        borderColor: t.tooltipBorder,
        borderWidth: 1,
        titleColor: '#f8fafc',
        bodyColor: '#e2e8f0',
        padding: 10,
        cornerRadius: 8,
        titleFont: {
          family: '"Plus Jakarta Sans", system-ui, sans-serif',
          size: 12,
          weight: 600,
        },
        bodyFont: {
          family: '"IBM Plex Mono", monospace',
          size: 12,
        },
      },
      ...(overrides.plugins || {}),
    },
    scales: {
      x: {
        grid: {
          display: false,
        },
        ticks: {
          color: t.textColor,
          font: {
            family: '"DM Sans", system-ui, sans-serif',
            size: 11,
          },
        },
      },
      y: {
        grid: {
          color: t.gridColor,
        },
        ticks: {
          color: t.textColor,
          font: {
            family: '"IBM Plex Mono", monospace',
            size: 11,
          },
        },
      },
      ...(overrides.scales || {}),
    },
    ...overrides,
  };
}
