import React, { useEffect, useRef, useState } from 'react';
import { BookOpen, HelpCircle, X } from 'lucide-react';
import { GLOSSARY } from '../data/glossary';

interface InfoTooltipProps {
  termKey: keyof typeof GLOSSARY;
  align?: 'left' | 'right';
}

export const InfoTooltip: React.FC<InfoTooltipProps> = ({ termKey, align = 'left' }) => {
  const [open, setOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const entry = GLOSSARY[termKey];

  useEffect(() => {
    if (!open) return;
    const handleOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
    };
    document.addEventListener('mousedown', handleOutside);
    document.addEventListener('keydown', handleEsc);
    return () => {
      document.removeEventListener('mousedown', handleOutside);
      document.removeEventListener('keydown', handleEsc);
    };
  }, [open]);

  if (!entry) return null;

  return (
    <div ref={containerRef} className="relative inline-flex items-center">
      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          setOpen((prev) => !prev);
        }}
        aria-label={`Learn about ${entry.term}`}
        aria-expanded={open}
        className="inline-flex h-5 w-5 items-center justify-center rounded-full text-slate-400 transition-colors hover:bg-slate-200/70 hover:text-slate-700 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-900 dark:text-slate-500 dark:hover:bg-slate-800 dark:hover:text-slate-200 dark:focus-visible:outline-emerald-400"
      >
        <HelpCircle className="h-3.5 w-3.5" />
      </button>

      {open && (
        <div
          role="dialog"
          aria-label={entry.term}
          className={`absolute top-full z-50 mt-2 w-80 rounded-xl border border-slate-200 bg-white p-4 text-left shadow-xl dark:border-slate-700 dark:bg-slate-900 ${
            align === 'right' ? 'right-0' : 'left-0'
          }`}
        >
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-[11px] font-medium text-emerald-700 dark:text-emerald-400">
                {entry.category}
              </p>
              <h4 className="mt-0.5 text-sm font-semibold text-slate-900 dark:text-slate-100">
                {entry.term}
              </h4>
            </div>
            <button
              type="button"
              onClick={() => setOpen(false)}
              aria-label="Close explanation"
              className="rounded-md p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800 dark:hover:text-slate-200"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>

          <p className="mt-2 text-xs leading-relaxed text-slate-600 dark:text-slate-300">
            {entry.definition}
          </p>

          <div className="mt-3 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 dark:border-slate-800 dark:bg-slate-950">
            <span className="block text-[11px] font-medium text-slate-500 dark:text-slate-400">
              Formula
            </span>
            <code className="mt-0.5 block font-mono text-xs text-slate-900 dark:text-emerald-300">
              {entry.formula}
            </code>
          </div>

          <p className="mt-2.5 text-xs leading-relaxed text-slate-500 dark:text-slate-400">
            <span className="font-medium text-slate-700 dark:text-slate-200">
              At Helps Code:{' '}
            </span>
            {entry.helpsCodeContext}
          </p>
        </div>
      )}
    </div>
  );
};

interface LearnBannerProps {
  learnMode: boolean;
  title: string;
  formula?: string;
  explanation: string;
}

export const LearnBanner: React.FC<LearnBannerProps> = ({
  learnMode,
  title,
  formula,
  explanation,
}) => {
  if (!learnMode) return null;

  return (
    <div className="rounded-xl border border-emerald-200/80 bg-emerald-50/70 px-4 py-3 text-sm dark:border-emerald-900/60 dark:bg-emerald-950/30">
      <div className="flex items-start gap-3">
        <BookOpen className="mt-0.5 h-4 w-4 shrink-0 text-emerald-700 dark:text-emerald-400" />
        <div className="min-w-0 flex-1 space-y-1">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="font-semibold text-slate-900 dark:text-slate-100">
              {title}
            </span>
            {formula && (
              <code className="font-mono text-xs text-emerald-800 dark:text-emerald-300">
                {formula}
              </code>
            )}
          </div>
          <p className="text-xs leading-relaxed text-slate-700 dark:text-slate-300">
            {explanation}
          </p>
        </div>
      </div>
    </div>
  );
};
