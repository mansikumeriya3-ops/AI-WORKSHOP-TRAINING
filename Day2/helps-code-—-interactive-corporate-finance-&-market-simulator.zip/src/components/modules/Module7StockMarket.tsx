import React, { useEffect, useRef, useState } from 'react';
import { Line } from 'react-chartjs-2';
import {
  Activity,
  ArrowDownRight,
  ArrowUpRight,
  Pause,
  Play,
  Sparkles,
  Zap,
} from 'lucide-react';
import {
  DerivedFinancials,
  formatCompactCurrency,
  formatCurrency,
  SHARES_OUTSTANDING,
} from '../../utils/financeEngine';
import {
  MarketNewsEvent,
  SandboxState,
  StockTick,
  TradeOrder,
} from '../../types/finance';
import { InfoTooltip, LearnBanner } from '../InfoTooltip';
import { buildBaseOptions } from '../ChartConfig';

interface Module7Props {
  sandbox: SandboxState;
  onUpdateSandbox: (next: SandboxState) => void;
  financials: DerivedFinancials;
  learnMode: boolean;
  isDark: boolean;
}

const NEWS_TEMPLATES: Omit<MarketNewsEvent, 'id' | 'timestamp'>[] = [
  {
    title: 'Viral Product Launch',
    summary: 'Helps Code AI Code-Reviewer hits #1 on Developer Trends; enterprise signups surge.',
    impactPercent: 9.5,
    sentiment: 'positive',
  },
  {
    title: 'Interest Rate Hike (+75 bps)',
    summary: 'Central bank tightens monetary policy, compressing tech valuation multiples.',
    impactPercent: -6.2,
    sentiment: 'negative',
  },
  {
    title: 'Supply Chain Disruption',
    summary: 'Hardware kit component shortage delays Q4 shipments by 3 weeks.',
    impactPercent: -7.8,
    sentiment: 'negative',
  },
  {
    title: 'Fortune 500 Contract Win',
    summary: 'Three-year multi-million dollar platform license signed with global bank.',
    impactPercent: 7.2,
    sentiment: 'positive',
  },
  {
    title: 'Competitor Price War',
    summary: 'Rival IDE vendor slashes annual enterprise pricing by 20%.',
    impactPercent: -4.9,
    sentiment: 'negative',
  },
];

function nowTimeStr() {
  return new Date().toLocaleTimeString('en-US', {
    hour12: false,
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });
}

export const Module7StockMarket: React.FC<Module7Props> = ({
  sandbox,
  onUpdateSandbox,
  financials,
  learnMode,
  isDark,
}) => {
  const [isStreaming, setIsStreaming] = useState(true);
  const [ticks, setTicks] = useState<StockTick[]>(() => {
    const base = sandbox.sharePrice;
    return Array.from({ length: 18 }, (_, i) => {
      const wave = Math.sin(i * 0.6) * 0.45 + (i - 17) * 0.04;
      return {
        timestamp: `T-${17 - i}`,
        price: Number(Math.max(4, base + wave).toFixed(2)),
      };
    });
  });

  const [newsFeed, setNewsFeed] = useState<MarketNewsEvent[]>([
    {
      id: 'init-1',
      title: 'Market Open — HLC Steady',
      summary: 'Investors weigh Helps Code annual run-rate earnings and balance sheet liquidity.',
      impactPercent: 0,
      sentiment: 'neutral',
      timestamp: nowTimeStr(),
    },
  ]);

  // Mock Portfolio State
  const [portfolioCash, setPortfolioCash] = useState(100_000);
  const [sharesHeld, setSharesHeld] = useState(250);
  const [avgCost, setAvgCost] = useState(26.5);
  const [orderQty, setOrderQty] = useState(50);
  const [orders, setOrders] = useState<TradeOrder[]>([]);
  const [tradeError, setTradeError] = useState<string | null>(null);

  const sandboxRef = useRef(sandbox);
  const intrinsicRef = useRef(financials.intrinsicSharePrice);
  sandboxRef.current = sandbox;
  intrinsicRef.current = financials.intrinsicSharePrice;

  // Live ticker mean-reverts gently toward Sandbox Intrinsic Value + random market noise
  useEffect(() => {
    if (!isStreaming) return;
    const interval = setInterval(() => {
      const currPrice = sandboxRef.current.sharePrice;
      const intrinsic = intrinsicRef.current;
      const pull = (intrinsic - currPrice) * 0.04;
      const noise = (Math.random() - 0.49) * 0.48;
      const nextPrice = Number(Math.max(3.5, Math.min(120, currPrice + pull + noise)).toFixed(2));

      onUpdateSandbox({
        ...sandboxRef.current,
        sharePrice: nextPrice,
      });

      setTicks((prev) => [
        ...prev.slice(-29),
        { timestamp: nowTimeStr(), price: nextPrice },
      ]);
    }, 1500);

    return () => clearInterval(interval);
  }, [isStreaming, onUpdateSandbox]);

  const triggerMarketEvent = (template?: Omit<MarketNewsEvent, 'id' | 'timestamp'>) => {
    const chosen =
      template ?? NEWS_TEMPLATES[Math.floor(Math.random() * NEWS_TEMPLATES.length)];
    const curr = sandbox.sharePrice;
    const shocked = Number(
      Math.max(3.5, Math.min(120, curr * (1 + chosen.impactPercent / 100))).toFixed(2)
    );

    onUpdateSandbox({
      ...sandbox,
      sharePrice: shocked,
    });

    const ts = nowTimeStr();
    setTicks((prev) => [
      ...prev.slice(-29),
      { timestamp: ts, price: shocked, eventLabel: chosen.title },
    ]);

    setNewsFeed((prev) => [
      {
        ...chosen,
        id: `${Date.now()}-${Math.random()}`,
        timestamp: ts,
      },
      ...prev.slice(0, 6),
    ]);
  };

  const handleTrade = (side: 'BUY' | 'SELL') => {
    setTradeError(null);
    const qty = Math.max(1, Math.floor(orderQty));
    const price = sandbox.sharePrice;
    const total = qty * price;

    if (side === 'BUY') {
      if (total > portfolioCash) {
        setTradeError(
          `Insufficient cash (${formatCurrency(portfolioCash)}) to buy ${qty} shares (${formatCurrency(total)}).`
        );
        return;
      }
      const newTotalCost = sharesHeld * avgCost + total;
      const newShares = sharesHeld + qty;
      setPortfolioCash((c) => c - total);
      setSharesHeld(newShares);
      setAvgCost(newTotalCost / newShares);
    } else {
      if (qty > sharesHeld) {
        setTradeError(`You only hold ${sharesHeld} HLC shares to sell.`);
        return;
      }
      setPortfolioCash((c) => c + total);
      setSharesHeld((s) => s - qty);
    }

    setOrders((prev) => [
      {
        id: `${Date.now()}`,
        timestamp: nowTimeStr(),
        side,
        shares: qty,
        price,
        total,
      },
      ...prev.slice(0, 5),
    ]);
  };

  const firstTick = ticks[0]?.price ?? sandbox.sharePrice;
  const sessionDelta = sandbox.sharePrice - firstTick;
  const sessionDeltaPct = firstTick > 0 ? (sessionDelta / firstTick) * 100 : 0;

  const holdingsValue = sharesHeld * sandbox.sharePrice;
  const totalPortfolio = portfolioCash + holdingsValue;
  const unrealizedPnl = sharesHeld * (sandbox.sharePrice - avgCost);

  const chartData = {
    labels: ticks.map((t) => t.timestamp),
    datasets: [
      {
        label: 'HLC Share Price ($)',
        data: ticks.map((t) => t.price),
        borderColor: sessionDelta >= 0 ? '#059669' : '#e11d48',
        backgroundColor:
          sessionDelta >= 0
            ? 'rgba(5, 150, 105, 0.12)'
            : 'rgba(225, 29, 72, 0.12)',
        borderWidth: 2.5,
        pointRadius: ticks.map((t) => (t.eventLabel ? 6 : 2)),
        pointBackgroundColor: ticks.map((t) =>
          t.eventLabel ? '#0284c7' : sessionDelta >= 0 ? '#059669' : '#e11d48'
        ),
        fill: true,
        tension: 0.2,
      },
      {
        label: `Fundamental Intrinsic Value ($${financials.intrinsicSharePrice.toFixed(2)})`,
        data: ticks.map(() => financials.intrinsicSharePrice),
        borderColor: isDark ? '#64748b' : '#94a3b8',
        borderDash: [5, 5],
        borderWidth: 1.5,
        pointRadius: 0,
        fill: false,
      },
    ],
  };

  const chartOptions = buildBaseOptions(isDark, {
    plugins: {
      tooltip: {
        callbacks: {
          label: (ctx: any) => `${ctx.dataset.label}: $${Number(ctx.parsed.y).toFixed(2)}`,
        },
      },
    },
    scales: {
      y: {
        ticks: {
          callback: (val: any) => `$${Number(val).toFixed(2)}`,
        },
      },
    },
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            07. Stock Market Simulator: Helps Code (NASDAQ: HLC)
          </h2>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
            Watch HLC&apos;s live share price gravitate toward your Sandbox fundamental valuation, trigger macro news shocks, and trade a mock portfolio.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setIsStreaming((s) => !s)}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-800 transition-colors hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800"
          >
            {isStreaming ? (
              <>
                <Pause className="h-3.5 w-3.5 text-amber-600" />
                <span>Pause Feed</span>
              </>
            ) : (
              <>
                <Play className="h-3.5 w-3.5 text-emerald-600" />
                <span>Resume Feed</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={() => triggerMarketEvent()}
            className="inline-flex items-center gap-1.5 rounded-lg bg-slate-900 px-3 py-1.5 text-xs font-medium text-white transition-colors hover:bg-slate-800 dark:bg-emerald-600 dark:hover:bg-emerald-500"
          >
            <Zap className="h-3.5 w-3.5" />
            <span>Random Market Event</span>
          </button>
        </div>
      </div>

      <LearnBanner
        learnMode={learnMode}
        title="How Fundamentals & News Drive Stock Valuation"
        formula="Market Cap = Share Price × 2.5M Shares  |  P/E = Share Price / EPS"
        explanation="In the short run, market news shocks (like Rate Hikes or Viral Launches) push HLC price away from fair value. Over time, the ticker drifts toward the dashed Intrinsic Value line calculated directly from your Sandbox Revenue, Net Income, and Debt."
      />

      {/* Valuation Strip */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-5">
        <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
          <span className="flex items-center gap-1 text-xs text-slate-500 dark:text-slate-400">
            <Activity className="h-3.5 w-3.5 text-emerald-600" />
            <span>HLC Live Price</span>
          </span>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="font-mono text-2xl font-bold text-slate-900 dark:text-slate-100">
              ${sandbox.sharePrice.toFixed(2)}
            </span>
            <span
              className={`inline-flex items-center font-mono text-xs font-semibold ${
                sessionDelta >= 0
                  ? 'text-emerald-600 dark:text-emerald-400'
                  : 'text-rose-600 dark:text-rose-400'
              }`}
            >
              {sessionDelta >= 0 ? (
                <ArrowUpRight className="h-3.5 w-3.5" />
              ) : (
                <ArrowDownRight className="h-3.5 w-3.5" />
              )}
              {sessionDelta >= 0 ? '+' : ''}
              {sessionDeltaPct.toFixed(1)}%
            </span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>Market Cap</span>
            <InfoTooltip termKey="marketCap" align="right" />
          </div>
          <p className="mt-1 font-mono text-2xl font-bold text-slate-900 dark:text-slate-100">
            {formatCompactCurrency(financials.marketCap)}
          </p>
          <span className="text-[11px] text-slate-400">
            {(SHARES_OUTSTANDING / 1_000_000).toFixed(1)}M shares
          </span>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>P/E Ratio</span>
            <InfoTooltip termKey="peRatio" align="right" />
          </div>
          <p className="mt-1 font-mono text-2xl font-bold text-slate-900 dark:text-slate-100">
            {financials.peRatio !== null ? `${financials.peRatio.toFixed(1)}x` : 'N/A'}
          </p>
          <span className="text-[11px] text-slate-400">
            {financials.peRatio === null ? 'Negative EPS' : 'Trailing Multiple'}
          </span>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>EPS (Annual)</span>
            <InfoTooltip termKey="eps" align="right" />
          </div>
          <p
            className={`mt-1 font-mono text-2xl font-bold ${
              financials.eps >= 0
                ? 'text-emerald-600 dark:text-emerald-400'
                : 'text-rose-600 dark:text-rose-400'
            }`}
          >
            ${financials.eps.toFixed(2)}
          </p>
          <span className="text-[11px] text-slate-400">From Sandbox Earnings</span>
        </div>

        <div className="col-span-2 rounded-xl border border-slate-200 bg-white p-4 lg:col-span-1 dark:border-slate-800 dark:bg-slate-900">
          <span className="text-xs text-slate-500 dark:text-slate-400">
            Intrinsic Fair Value
          </span>
          <p className="mt-1 font-mono text-2xl font-bold text-sky-600 dark:text-sky-400">
            ${financials.intrinsicSharePrice.toFixed(2)}
          </p>
          <span className="text-[11px] text-slate-400">
            {sandbox.sharePrice < financials.intrinsicSharePrice
              ? 'Undervalued vs. Model'
              : 'Premium vs. Model'}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Live Stock Chart & News Triggers */}
        <div className="space-y-5 lg:col-span-8">
          <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
            <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">
                HLC Intraday Ticker &amp; Fundamental Anchor
              </h3>
              <span className="font-mono text-xs text-slate-500 dark:text-slate-400">
                {isStreaming ? 'Live Simulation (1.5s ticks)' : 'Ticker Paused'}
              </span>
            </div>
            <div className="h-72">
              <Line data={chartData} options={chartOptions} />
            </div>
          </div>

          {/* Market News Event Triggers */}
          <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
            <div className="mb-3 flex items-center justify-between">
              <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                Trigger Market News Shocks
              </h3>
              <span className="text-xs text-slate-500 dark:text-slate-400">
                Click an event to inject immediate volatility
              </span>
            </div>

            <div className="flex flex-wrap gap-2">
              {NEWS_TEMPLATES.map((ev) => (
                <button
                  key={ev.title}
                  type="button"
                  onClick={() => triggerMarketEvent(ev)}
                  className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-medium transition-colors ${
                    ev.sentiment === 'positive'
                      ? 'border-emerald-200 bg-emerald-50/70 text-emerald-800 hover:bg-emerald-100 dark:border-emerald-900/60 dark:bg-emerald-950/40 dark:text-emerald-300 dark:hover:bg-emerald-900/50'
                      : 'border-rose-200 bg-rose-50/70 text-rose-800 hover:bg-rose-100 dark:border-rose-900/60 dark:bg-rose-950/40 dark:text-rose-300 dark:hover:bg-rose-900/50'
                  }`}
                >
                  <Sparkles className="h-3 w-3" />
                  <span>{ev.title}</span>
                  <span className="font-mono">
                    ({ev.impactPercent > 0 ? '+' : ''}
                    {ev.impactPercent}%)
                  </span>
                </button>
              ))}
            </div>

            <div className="mt-4 divide-y divide-slate-100 border-t border-slate-100 dark:divide-slate-800 dark:border-slate-800">
              {newsFeed.slice(0, 4).map((item) => (
                <div key={item.id} className="flex items-start justify-between gap-4 py-2.5 text-xs">
                  <div>
                    <span className="font-semibold text-slate-900 dark:text-slate-100">
                      {item.title}
                    </span>
                    <p className="mt-0.5 text-slate-500 dark:text-slate-400">{item.summary}</p>
                  </div>
                  <div className="shrink-0 text-right font-mono">
                    <span
                      className={
                        item.impactPercent > 0
                          ? 'font-semibold text-emerald-600 dark:text-emerald-400'
                          : item.impactPercent < 0
                            ? 'font-semibold text-rose-600 dark:text-rose-400'
                            : 'text-slate-400'
                      }
                    >
                      {item.impactPercent > 0 ? '+' : ''}
                      {item.impactPercent}%
                    </span>
                    <span className="block text-[11px] text-slate-400">{item.timestamp}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Mock Trading Portfolio */}
        <div className="space-y-5 rounded-xl border border-slate-200 bg-white p-5 lg:col-span-4 dark:border-slate-800 dark:bg-slate-900">
          <div className="border-b border-slate-100 pb-3 dark:border-slate-800">
            <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">
              Mock Trading Portfolio
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Practice buying and selling virtual HLC shares
            </p>
          </div>

          <div className="space-y-2.5 text-sm">
            <div className="flex justify-between">
              <span className="text-slate-500 dark:text-slate-400">Total Account Value</span>
              <span className="font-mono font-bold text-slate-900 dark:text-slate-100">
                {formatCurrency(totalPortfolio)}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500 dark:text-slate-400">Available Buying Cash</span>
              <span className="font-mono font-semibold text-slate-800 dark:text-slate-200">
                {formatCurrency(portfolioCash)}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500 dark:text-slate-400">HLC Shares Held</span>
              <span className="font-mono font-semibold text-slate-800 dark:text-slate-200">
                {sharesHeld.toLocaleString()} shares
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500 dark:text-slate-400">Position Market Value</span>
              <span className="font-mono font-semibold text-slate-800 dark:text-slate-200">
                {formatCurrency(holdingsValue)}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500 dark:text-slate-400">Unrealized P&amp;L</span>
              <span
                className={`font-mono font-semibold ${
                  unrealizedPnl >= 0
                    ? 'text-emerald-600 dark:text-emerald-400'
                    : 'text-rose-600 dark:text-rose-400'
                }`}
              >
                {unrealizedPnl >= 0 ? '+' : ''}
                {formatCurrency(unrealizedPnl)}
              </span>
            </div>
          </div>

          {/* Order Entry */}
          <div className="space-y-3 border-t border-slate-100 pt-4 dark:border-slate-800">
            <div className="flex items-center justify-between text-xs">
              <label htmlFor="order-qty" className="font-medium text-slate-700 dark:text-slate-300">
                Share Quantity
              </label>
              <span className="font-mono text-slate-500 dark:text-slate-400">
                Est. {formatCurrency(orderQty * sandbox.sharePrice)}
              </span>
            </div>

            <input
              id="order-qty"
              type="number"
              min={1}
              max={10000}
              value={orderQty}
              onChange={(e) => setOrderQty(Math.max(1, Number(e.target.value)))}
              className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 font-mono text-sm text-slate-900 focus:border-slate-900 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100 dark:focus:border-emerald-400"
            />

            <div className="flex gap-1.5">
              {[25, 100, 250].map((presetQty) => (
                <button
                  key={presetQty}
                  type="button"
                  onClick={() => setOrderQty(presetQty)}
                  className="flex-1 rounded-md border border-slate-200 py-1 font-mono text-xs text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
                >
                  {presetQty}
                </button>
              ))}
              <button
                type="button"
                onClick={() =>
                  setOrderQty(Math.max(1, Math.floor(portfolioCash / sandbox.sharePrice)))
                }
                className="flex-1 rounded-md border border-slate-200 py-1 font-mono text-xs text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
              >
                Max Buy
              </button>
            </div>

            {tradeError && (
              <p className="text-xs font-medium text-rose-600 dark:text-rose-400">
                {tradeError}
              </p>
            )}

            <div className="grid grid-cols-2 gap-2.5 pt-1">
              <button
                type="button"
                onClick={() => handleTrade('BUY')}
                className="rounded-lg bg-emerald-600 py-2.5 text-xs font-semibold text-white transition-colors hover:bg-emerald-700"
              >
                Buy HLC
              </button>
              <button
                type="button"
                onClick={() => handleTrade('SELL')}
                className="rounded-lg bg-rose-600 py-2.5 text-xs font-semibold text-white transition-colors hover:bg-rose-700"
              >
                Sell HLC
              </button>
            </div>
          </div>

          {/* Recent Trades */}
          <div className="border-t border-slate-100 pt-4 dark:border-slate-800">
            <h4 className="mb-2 text-xs font-semibold text-slate-500 dark:text-slate-400">
              Recent Executions
            </h4>
            {orders.length === 0 ? (
              <p className="text-xs text-slate-400">
                No orders placed yet. Buy or sell HLC shares above to log executions.
              </p>
            ) : (
              <div className="space-y-2">
                {orders.map((o) => (
                  <div
                    key={o.id}
                    className="flex items-center justify-between text-xs"
                  >
                    <span
                      className={`font-mono font-semibold ${
                        o.side === 'BUY'
                          ? 'text-emerald-600 dark:text-emerald-400'
                          : 'text-rose-600 dark:text-rose-400'
                      }`}
                    >
                      {o.side} {o.shares}
                    </span>
                    <span className="font-mono text-slate-600 dark:text-slate-300">
                      @ ${o.price.toFixed(2)}
                    </span>
                    <span className="font-mono text-slate-400">{o.timestamp}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
