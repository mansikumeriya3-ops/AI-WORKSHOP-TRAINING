import React, { useState } from 'react';
import { Bar } from 'react-chartjs-2';
import { AlertTriangle, CheckCircle2, RefreshCw } from 'lucide-react';
import { formatCompactCurrency, formatCurrency } from '../../utils/financeEngine';
import { InfoTooltip, LearnBanner } from '../InfoTooltip';
import { buildBaseOptions } from '../ChartConfig';

interface Module5Props {
  learnMode: boolean;
  isDark: boolean;
}

const TOTAL_BUDGET = 1_000_000;

interface BudgetAlloc {
  rnd: number;
  marketing: number;
  operations: number;
  reserves: number;
}

const STRATEGY_PRESETS: { label: string; alloc: BudgetAlloc }[] = [
  {
    label: 'Balanced Scale',
    alloc: { rnd: 320_000, marketing: 260_000, operations: 250_000, reserves: 170_000 },
  },
  {
    label: 'Aggressive R&D',
    alloc: { rnd: 460_000, marketing: 220_000, operations: 220_000, reserves: 100_000 },
  },
  {
    label: 'Growth Blitz',
    alloc: { rnd: 240_000, marketing: 430_000, operations: 230_000, reserves: 100_000 },
  },
  {
    label: 'Defensive Cash',
    alloc: { rnd: 200_000, marketing: 160_000, operations: 240_000, reserves: 400_000 },
  },
];

export const Module5Budgeting: React.FC<Module5Props> = ({ learnMode, isDark }) => {
  const [alloc, setAlloc] = useState<BudgetAlloc>(STRATEGY_PRESETS[0].alloc);
  // Realistic variance multipliers per department so Actual vs Budget renders immediately
  const [varianceFactors, setVarianceFactors] = useState({
    rnd: 1.04,
    marketing: 1.08,
    operations: 0.96,
    reserves: 0.92,
  });

  const handleSliderChange = (key: keyof BudgetAlloc, nextVal: number) => {
    const clamped = Math.max(0, Math.min(TOTAL_BUDGET, nextVal));
    if (key === 'reserves') {
      // Scale the other three proportionally if reserves changes
      const remaining = TOTAL_BUDGET - clamped;
      const otherSum = alloc.rnd + alloc.marketing + alloc.operations;
      if (otherSum === 0) {
        const third = Math.round(remaining / 3);
        setAlloc({
          rnd: third,
          marketing: third,
          operations: remaining - third * 2,
          reserves: clamped,
        });
      } else {
        const rnd = Math.round((alloc.rnd / otherSum) * remaining);
        const marketing = Math.round((alloc.marketing / otherSum) * remaining);
        const operations = remaining - rnd - marketing;
        setAlloc({ rnd, marketing, operations, reserves: clamped });
      }
      return;
    }

    // Auto-balance using Reserves first, then others if Reserves hits 0
    const otherActive =
      (key !== 'rnd' ? alloc.rnd : 0) +
      (key !== 'marketing' ? alloc.marketing : 0) +
      (key !== 'operations' ? alloc.operations : 0);

    const maxAllowed = TOTAL_BUDGET - otherActive;
    if (clamped <= maxAllowed) {
      setAlloc({
        ...alloc,
        [key]: clamped,
        reserves: TOTAL_BUDGET - otherActive - clamped,
      });
    } else {
      // Compress other two non-reserve buckets proportionally and set reserves = 0
      const excess = clamped - maxAllowed;
      const keys = (['rnd', 'marketing', 'operations'] as const).filter((k) => k !== key);
      const sumKeys = alloc[keys[0]] + alloc[keys[1]];
      if (sumKeys > 0) {
        const k0 = Math.max(0, Math.round(alloc[keys[0]] - (alloc[keys[0]] / sumKeys) * excess));
        const k1 = Math.max(0, TOTAL_BUDGET - clamped - k0);
        setAlloc({
          ...alloc,
          [key]: clamped,
          [keys[0]]: k0,
          [keys[1]]: k1,
          reserves: 0,
        });
      }
    }
  };

  const simulateQuarterClose = () => {
    const randFactor = (min: number, max: number) =>
      Number((min + Math.random() * (max - min)).toFixed(2));
    setVarianceFactors({
      rnd: randFactor(0.94, 1.12),
      marketing: randFactor(0.92, 1.15),
      operations: randFactor(0.9, 1.1),
      reserves: randFactor(0.85, 1.02),
    });
  };

  // Simulated strategic outcomes
  const rndGrowthBoost = ((alloc.rnd / TOTAL_BUDGET) * 28).toFixed(1);
  const marketingDemandLift = ((alloc.marketing / TOTAL_BUDGET) * 34).toFixed(1);
  const opsBottleneck = alloc.operations < 180_000;
  const opsStrain = alloc.operations >= 180_000 && alloc.operations < 220_000;
  const reserveWeeks = Math.round((alloc.reserves / 45_000) * 1.4);

  const departments = [
    { key: 'rnd' as const, label: 'R&D & Engineering', budget: alloc.rnd, factor: varianceFactors.rnd },
    { key: 'marketing' as const, label: 'Marketing & Growth', budget: alloc.marketing, factor: varianceFactors.marketing },
    { key: 'operations' as const, label: 'Operations & Cloud', budget: alloc.operations, factor: varianceFactors.operations },
    { key: 'reserves' as const, label: 'Strategic Reserves', budget: alloc.reserves, factor: varianceFactors.reserves },
  ].map((d) => {
    const actual = Math.round(d.budget * d.factor);
    const variance = d.budget - actual; // Positive = under budget (favorable)
    return { ...d, actual, variance };
  });

  const totalActual = departments.reduce((sum, d) => sum + d.actual, 0);
  const totalVariance = TOTAL_BUDGET - totalActual;

  const chartData = {
    labels: departments.map((d) => d.label),
    datasets: [
      {
        label: 'Planned Budget ($)',
        data: departments.map((d) => d.budget),
        backgroundColor: isDark ? '#334155' : '#0f172a',
        borderRadius: 6,
        barThickness: 26,
      },
      {
        label: 'Simulated Actual Spend ($)',
        data: departments.map((d) => d.actual),
        backgroundColor: departments.map((d) =>
          d.variance >= 0 ? '#059669' : '#e11d48'
        ),
        borderRadius: 6,
        barThickness: 26,
      },
    ],
  };

  const chartOptions = buildBaseOptions(isDark, {
    plugins: {
      tooltip: {
        callbacks: {
          label: (ctx: any) => `${ctx.dataset.label}: ${formatCurrency(ctx.parsed.y)}`,
        },
      },
    },
    scales: {
      y: {
        ticks: {
          callback: (val: any) => formatCompactCurrency(Number(val)),
        },
      },
    },
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            05. Quarterly Budgeting &amp; Resource Allocation
          </h2>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
            Distribute Helps Code&apos;s fixed $1,000,000 quarterly budget across four departments and monitor operational trade-offs and Actual vs. Budget variance.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {STRATEGY_PRESETS.map((p) => (
            <button
              key={p.label}
              type="button"
              onClick={() => setAlloc(p.alloc)}
              className="whitespace-nowrap rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 transition-colors hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-slate-800"
            >
              {p.label}
            </button>
          ))}
        </div>
      </div>

      <LearnBanner
        learnMode={learnMode}
        title="Capital Allocation Trade-Offs & Variance Control"
        formula="Budget Variance = Planned Budget − Actual Spend"
        explanation="Every dollar allocated to Marketing cannot be spent on R&D or held in Reserves. Underfunding Operations below $180K triggers fulfillment and cloud reliability bottlenecks, while zeroing out Reserves leaves Helps Code exposed to sudden cost overruns."
      />

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Allocation Sliders */}
        <div className="space-y-5 rounded-xl border border-slate-200 bg-white p-5 lg:col-span-5 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
            <div>
              <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">
                Allocate $1,000,000 Budget
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Reserves automatically absorb remaining funds
              </p>
            </div>
            <span className="font-mono text-sm font-bold text-emerald-600 dark:text-emerald-400">
              {formatCurrency(TOTAL_BUDGET)}
            </span>
          </div>

          {departments.map((dept) => {
            const pct = ((dept.budget / TOTAL_BUDGET) * 100).toFixed(0);
            return (
              <div key={dept.key}>
                <div className="mb-1.5 flex items-center justify-between text-xs">
                  <label
                    htmlFor={`bg-${dept.key}`}
                    className="font-medium text-slate-700 dark:text-slate-300"
                  >
                    {dept.label}
                  </label>
                  <span className="font-mono font-semibold text-slate-900 dark:text-slate-100">
                    {formatCurrency(dept.budget)} ({pct}%)
                  </span>
                </div>
                <input
                  id={`bg-${dept.key}`}
                  type="range"
                  min={0}
                  max={TOTAL_BUDGET}
                  step={10_000}
                  value={dept.budget}
                  onChange={(e) => handleSliderChange(dept.key, Number(e.target.value))}
                  className="fin-slider w-full"
                />
              </div>
            );
          })}

          {/* Simulated Operational Outcomes */}
          <div className="space-y-2.5 border-t border-slate-100 pt-4 dark:border-slate-800">
            <h4 className="text-xs font-semibold text-slate-500 dark:text-slate-400">
              Simulated Quarterly Outcomes
            </h4>

            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-600 dark:text-slate-300">Long-Term Product Growth Boost</span>
              <span className="font-mono font-semibold text-emerald-600 dark:text-emerald-400">
                +{rndGrowthBoost}% ARR
              </span>
            </div>

            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-600 dark:text-slate-300">Customer Acquisition Lift</span>
              <span className="font-mono font-semibold text-sky-600 dark:text-sky-400">
                +{marketingDemandLift}% Leads
              </span>
            </div>

            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-600 dark:text-slate-300">Operations Capacity Status</span>
              {opsBottleneck ? (
                <span className="inline-flex items-center gap-1 font-semibold text-rose-600 dark:text-rose-400">
                  <AlertTriangle className="h-3.5 w-3.5" />
                  <span>Bottleneck Risk (&lt;$180K)</span>
                </span>
              ) : opsStrain ? (
                <span className="inline-flex items-center gap-1 font-semibold text-amber-600 dark:text-amber-400">
                  <AlertTriangle className="h-3.5 w-3.5" />
                  <span>Tight Capacity</span>
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 font-semibold text-emerald-600 dark:text-emerald-400">
                  <CheckCircle2 className="h-3.5 w-3.5" />
                  <span>Nominal Throughput</span>
                </span>
              )}
            </div>

            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-600 dark:text-slate-300">Contingency Buffer</span>
              <span className="font-mono font-semibold text-slate-900 dark:text-slate-100">
                {reserveWeeks} Weeks Shield
              </span>
            </div>
          </div>
        </div>

        {/* Chart & Variance Table */}
        <div className="space-y-5 lg:col-span-7">
          <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
            <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-1.5">
                <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">
                  Actual vs. Budget Variance
                </h3>
                <InfoTooltip termKey="budgetVariance" />
              </div>

              <button
                type="button"
                onClick={simulateQuarterClose}
                className="inline-flex items-center gap-1.5 rounded-lg bg-slate-900 px-3 py-1.5 text-xs font-medium text-white transition-colors hover:bg-slate-800 dark:bg-emerald-600 dark:hover:bg-emerald-500"
              >
                <RefreshCw className="h-3.5 w-3.5" />
                <span>Simulate Quarter Close</span>
              </button>
            </div>
            <div className="h-64">
              <Bar data={chartData} options={chartOptions} />
            </div>
          </div>

          <div className="overflow-hidden rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
            <table className="w-full text-left text-sm">
              <thead className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600 dark:border-slate-800 dark:bg-slate-950/60 dark:text-slate-400">
                <tr>
                  <th className="px-4 py-3">Department</th>
                  <th className="px-4 py-3 text-right">Budget</th>
                  <th className="px-4 py-3 text-right">Actual</th>
                  <th className="px-4 py-3 text-right">Variance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {departments.map((d) => (
                  <tr key={d.key}>
                    <td className="px-4 py-2.5 font-medium text-slate-900 dark:text-slate-100">
                      {d.label}
                    </td>
                    <td className="px-4 py-2.5 text-right font-mono tabular-nums text-slate-600 dark:text-slate-300">
                      {formatCurrency(d.budget)}
                    </td>
                    <td className="px-4 py-2.5 text-right font-mono tabular-nums text-slate-900 dark:text-slate-100">
                      {formatCurrency(d.actual)}
                    </td>
                    <td
                      className={`px-4 py-2.5 text-right font-mono font-semibold tabular-nums ${
                        d.variance >= 0
                          ? 'text-emerald-600 dark:text-emerald-400'
                          : 'text-rose-600 dark:text-rose-400'
                      }`}
                    >
                      {d.variance >= 0 ? '+' : ''}
                      {formatCurrency(d.variance)}
                    </td>
                  </tr>
                ))}
                <tr className="border-t border-slate-200 bg-slate-50/70 font-semibold dark:border-slate-800 dark:bg-slate-950/40">
                  <td className="px-4 py-2.5 text-slate-900 dark:text-slate-100">
                    Total Quarterly Spend
                  </td>
                  <td className="px-4 py-2.5 text-right font-mono tabular-nums text-slate-900 dark:text-slate-100">
                    {formatCurrency(TOTAL_BUDGET)}
                  </td>
                  <td className="px-4 py-2.5 text-right font-mono tabular-nums text-slate-900 dark:text-slate-100">
                    {formatCurrency(totalActual)}
                  </td>
                  <td
                    className={`px-4 py-2.5 text-right font-mono tabular-nums ${
                      totalVariance >= 0
                        ? 'text-emerald-600 dark:text-emerald-400'
                        : 'text-rose-600 dark:text-rose-400'
                    }`}
                  >
                    {totalVariance >= 0 ? '+' : ''}
                    {formatCurrency(totalVariance)}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
