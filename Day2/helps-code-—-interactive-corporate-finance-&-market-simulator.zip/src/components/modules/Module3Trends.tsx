import React, { useState } from 'react';
import { Chart } from 'react-chartjs-2';
import {
  buildHistoricalTrend,
  DerivedFinancials,
  DerivedFinancials as _,
  formatCompactCurrency,
  formatCurrency,
} from '../../utils/financeEngine';
import { InfoTooltip, LearnBanner } from '../InfoTooltip';
import { buildBaseOptions } from '../ChartConfig';

interface Module3Props {
  financials: DerivedFinancials;
  learnMode: boolean;
  isDark: boolean;
}

type AnalysisView = 'dollars' | 'horizontal' | 'vertical';

export const Module3Trends: React.FC<Module3Props> = ({
  financials,
  learnMode,
  isDark,
}) => {
  const [view, setView] = useState<AnalysisView>('dollars');
  const rows = buildHistoricalTrend(financials);

  // Horizontal YoY % change rows (Year 1 is baseline N/A -> 0 for chart)
  const horizontalRows = rows.map((row, idx) => {
    if (idx === 0) {
      return {
        year: row.year,
        revGrowth: null as number | null,
        profitGrowth: null as number | null,
        grossGrowth: null as number | null,
        opexGrowth: null as number | null,
      };
    }
    const prev = rows[idx - 1];
    const pct = (curr: number, prior: number) =>
      prior !== 0 ? ((curr - prior) / Math.abs(prior)) * 100 : 0;
    return {
      year: row.year,
      revGrowth: pct(row.revenue, prev.revenue),
      profitGrowth: pct(row.netIncome, prev.netIncome),
      grossGrowth: pct(row.grossProfit, prev.grossProfit),
      opexGrowth: pct(row.opex, prev.opex),
    };
  });

  // Vertical Common-Size % of Revenue
  const verticalRows = rows.map((row) => {
    const pct = (val: number) => (row.revenue > 0 ? (val / row.revenue) * 100 : 0);
    return {
      year: row.year,
      revenuePct: 100,
      cogsPct: pct(row.cogs),
      grossMarginPct: pct(row.grossProfit),
      opexPct: pct(row.opex),
      netMarginPct: pct(row.netIncome),
    };
  });

  const cagr =
    rows[0].revenue > 0 && rows[4].revenue > 0
      ? (Math.pow(rows[4].revenue / rows[0].revenue, 1 / 4) - 1) * 100
      : 0;

  // Chart datasets depending on active view
  const chartData =
    view === 'dollars'
      ? {
          labels: rows.map((r) => r.year),
          datasets: [
            {
              type: 'bar' as const,
              label: 'Revenue ($)',
              data: rows.map((r) => r.revenue),
              backgroundColor: isDark ? 'rgba(56, 189, 248, 0.75)' : 'rgba(15, 23, 42, 0.85)',
              borderRadius: 6,
              barThickness: 32,
              yAxisID: 'y',
            },
            {
              type: 'line' as const,
              label: 'Net Income ($)',
              data: rows.map((r) => r.netIncome),
              borderColor: '#059669',
              backgroundColor: '#059669',
              borderWidth: 2.5,
              pointRadius: 5,
              tension: 0.25,
              yAxisID: 'y1',
            },
          ],
        }
      : view === 'horizontal'
        ? {
            labels: horizontalRows.slice(1).map((r) => r.year),
            datasets: [
              {
                type: 'line' as const,
                label: 'Revenue YoY Growth (%)',
                data: horizontalRows.slice(1).map((r) => Number((r.revGrowth ?? 0).toFixed(1))),
                borderColor: isDark ? '#38bdf8' : '#0f172a',
                backgroundColor: isDark ? '#38bdf8' : '#0f172a',
                borderWidth: 2.5,
                pointRadius: 5,
                tension: 0.25,
              },
              {
                type: 'line' as const,
                label: 'Net Profit YoY Growth (%)',
                data: horizontalRows.slice(1).map((r) => Number((r.profitGrowth ?? 0).toFixed(1))),
                borderColor: '#059669',
                backgroundColor: '#059669',
                borderWidth: 2.5,
                pointRadius: 5,
                tension: 0.25,
              },
            ],
          }
        : {
            labels: verticalRows.map((r) => r.year),
            datasets: [
              {
                type: 'bar' as const,
                label: 'Gross Margin (% of Rev)',
                data: verticalRows.map((r) => Number(r.grossMarginPct.toFixed(1))),
                backgroundColor: '#0284c7',
                borderRadius: 6,
                barThickness: 28,
              },
              {
                type: 'bar' as const,
                label: 'OpEx (% of Rev)',
                data: verticalRows.map((r) => Number(r.opexPct.toFixed(1))),
                backgroundColor: '#f59e0b',
                borderRadius: 6,
                barThickness: 28,
              },
              {
                type: 'line' as const,
                label: 'Net Profit Margin (% of Rev)',
                data: verticalRows.map((r) => Number(r.netMarginPct.toFixed(1))),
                borderColor: '#059669',
                backgroundColor: '#059669',
                borderWidth: 2.5,
                pointRadius: 5,
                tension: 0.25,
              },
            ],
          };

  const chartOptions =
    view === 'dollars'
      ? buildBaseOptions(isDark, {
          scales: {
            y: {
              position: 'left',
              title: { display: true, text: 'Revenue ($)' },
              ticks: {
                callback: (val: any) => formatCompactCurrency(Number(val)),
              },
            },
            y1: {
              position: 'right',
              grid: { drawOnChartArea: false },
              title: { display: true, text: 'Net Income ($)' },
              ticks: {
                callback: (val: any) => formatCompactCurrency(Number(val)),
              },
            },
          },
        })
      : buildBaseOptions(isDark, {
          scales: {
            y: {
              ticks: {
                callback: (val: any) => `${val}%`,
              },
            },
          },
        });

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            03. Trend Analysis (Year 1 – Year 5)
          </h2>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
            Track Helps Code&apos;s 5-year trajectory comparing top-line Revenue against Net Profit expansion. Year 5 mirrors your Live Sandbox.
          </p>
        </div>

        {/* Segmented Analysis Toggle */}
        <div className="inline-flex items-center gap-1 rounded-lg bg-slate-200/80 p-1 dark:bg-slate-800">
          <button
            type="button"
            onClick={() => setView('dollars')}
            className={`whitespace-nowrap rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${
              view === 'dollars'
                ? 'bg-white text-slate-900 shadow-sm dark:bg-slate-900 dark:text-slate-100'
                : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
            }`}
          >
            Dollar Growth ($)
          </button>
          <button
            type="button"
            onClick={() => setView('horizontal')}
            className={`whitespace-nowrap rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${
              view === 'horizontal'
                ? 'bg-white text-slate-900 shadow-sm dark:bg-slate-900 dark:text-slate-100'
                : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
            }`}
          >
            Horizontal (% YoY)
          </button>
          <button
            type="button"
            onClick={() => setView('vertical')}
            className={`whitespace-nowrap rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${
              view === 'vertical'
                ? 'bg-white text-slate-900 shadow-sm dark:bg-slate-900 dark:text-slate-100'
                : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
            }`}
          >
            Vertical (% of Rev)
          </button>
        </div>
      </div>

      <LearnBanner
        learnMode={learnMode}
        title={
          view === 'horizontal'
            ? 'Horizontal Analysis (Period-over-Period Growth)'
            : view === 'vertical'
              ? 'Vertical Analysis (Common-Size Statements)'
              : 'Operating Leverage Across Multi-Year Trends'
        }
        formula={
          view === 'horizontal'
            ? 'YoY % = ((Year N − Year N−1) / |Year N−1|) × 100'
            : view === 'vertical'
              ? 'Common-Size % = (Line Item / Total Revenue) × 100'
              : '4-Year Revenue CAGR = (Year 5 / Year 1)^(1/4) − 1'
        }
        explanation={
          view === 'horizontal'
            ? 'Horizontal analysis measures momentum year over year. When Net Profit grows at a higher percentage than Revenue, the business has positive operating leverage.'
            : view === 'vertical'
              ? 'Vertical analysis standardizes every line item as a share of Revenue, making it easy to see Gross Margin expansion and OpEx discipline over time.'
              : 'Compare steady Revenue scaling against Net Profit acceleration. Tweak Year 5 Revenue or OpEx in the Sandbox above to see how current performance shifts the 5-year CAGR.'
        }
      />

      {/* Summary Metrics Strip */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>4-Year Revenue CAGR</span>
            <InfoTooltip termKey="horizontalAnalysis" align="right" />
          </div>
          <p className="mt-1 font-mono text-2xl font-bold text-slate-900 dark:text-slate-100">
            {cagr.toFixed(1)}%
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>Year 5 Gross Margin</span>
            <InfoTooltip termKey="verticalAnalysis" align="right" />
          </div>
          <p className="mt-1 font-mono text-2xl font-bold text-sky-600 dark:text-sky-400">
            {verticalRows[4].grossMarginPct.toFixed(1)}%
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>Year 5 Net Profit Margin</span>
            <InfoTooltip termKey="netIncome" align="right" />
          </div>
          <p
            className={`mt-1 font-mono text-2xl font-bold ${
              verticalRows[4].netMarginPct >= 0
                ? 'text-emerald-600 dark:text-emerald-400'
                : 'text-rose-600 dark:text-rose-400'
            }`}
          >
            {verticalRows[4].netMarginPct.toFixed(1)}%
          </p>
        </div>
      </div>

      {/* Main Chart */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">
            {view === 'dollars' && 'Revenue vs. Net Income (Year 1 – Year 5)'}
            {view === 'horizontal' && 'Horizontal Analysis: Year-over-Year Growth (%)'}
            {view === 'vertical' && 'Vertical Analysis: Cost & Margin Structure (% of Revenue)'}
          </h3>
        </div>
        <div className="h-80">
          <Chart type="bar" data={chartData as any} options={chartOptions} />
        </div>
      </div>

      {/* Multi-Year Data Table */}
      <div className="overflow-hidden rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600 dark:border-slate-800 dark:bg-slate-950/60 dark:text-slate-400">
              <tr>
                <th className="px-4 py-3">Period</th>
                <th className="px-4 py-3 text-right">
                  {view === 'horizontal' ? 'Revenue YoY' : view === 'vertical' ? 'Revenue (%)' : 'Revenue'}
                </th>
                <th className="px-4 py-3 text-right">
                  {view === 'horizontal' ? 'Gross Profit YoY' : view === 'vertical' ? 'Gross Margin' : 'Gross Profit'}
                </th>
                <th className="px-4 py-3 text-right">
                  {view === 'horizontal' ? 'OpEx YoY' : view === 'vertical' ? 'OpEx (% Rev)' : 'Operating Exp.'}
                </th>
                <th className="px-4 py-3 text-right">
                  {view === 'horizontal' ? 'Net Profit YoY' : view === 'vertical' ? 'Net Margin' : 'Net Income'}
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {view === 'dollars' &&
                rows.map((r) => (
                  <tr
                    key={r.year}
                    className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40"
                  >
                    <td className="px-4 py-3 font-medium text-slate-900 dark:text-slate-100">
                      {r.year}
                    </td>
                    <td className="px-4 py-3 text-right font-mono tabular-nums text-slate-700 dark:text-slate-300">
                      {formatCurrency(r.revenue)}
                    </td>
                    <td className="px-4 py-3 text-right font-mono tabular-nums text-slate-700 dark:text-slate-300">
                      {formatCurrency(r.grossProfit)}
                    </td>
                    <td className="px-4 py-3 text-right font-mono tabular-nums text-slate-700 dark:text-slate-300">
                      {formatCurrency(r.opex)}
                    </td>
                    <td
                      className={`px-4 py-3 text-right font-mono font-semibold tabular-nums ${
                        r.netIncome >= 0
                          ? 'text-emerald-600 dark:text-emerald-400'
                          : 'text-rose-600 dark:text-rose-400'
                      }`}
                    >
                      {formatCurrency(r.netIncome)}
                    </td>
                  </tr>
                ))}

              {view === 'horizontal' &&
                horizontalRows.map((r) => (
                  <tr
                    key={r.year}
                    className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40"
                  >
                    <td className="px-4 py-3 font-medium text-slate-900 dark:text-slate-100">
                      {r.year}
                    </td>
                    <td className="px-4 py-3 text-right font-mono tabular-nums text-slate-700 dark:text-slate-300">
                      {r.revGrowth === null ? 'Base' : `${r.revGrowth >= 0 ? '+' : ''}${r.revGrowth.toFixed(1)}%`}
                    </td>
                    <td className="px-4 py-3 text-right font-mono tabular-nums text-slate-700 dark:text-slate-300">
                      {r.grossGrowth === null ? 'Base' : `${r.grossGrowth >= 0 ? '+' : ''}${r.grossGrowth.toFixed(1)}%`}
                    </td>
                    <td className="px-4 py-3 text-right font-mono tabular-nums text-slate-700 dark:text-slate-300">
                      {r.opexGrowth === null ? 'Base' : `${r.opexGrowth >= 0 ? '+' : ''}${r.opexGrowth.toFixed(1)}%`}
                    </td>
                    <td
                      className={`px-4 py-3 text-right font-mono font-semibold tabular-nums ${
                        (r.profitGrowth ?? 0) >= 0
                          ? 'text-emerald-600 dark:text-emerald-400'
                          : 'text-rose-600 dark:text-rose-400'
                      }`}
                    >
                      {r.profitGrowth === null
                        ? 'Base'
                        : `${r.profitGrowth >= 0 ? '+' : ''}${r.profitGrowth.toFixed(1)}%`}
                    </td>
                  </tr>
                ))}

              {view === 'vertical' &&
                verticalRows.map((r) => (
                  <tr
                    key={r.year}
                    className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40"
                  >
                    <td className="px-4 py-3 font-medium text-slate-900 dark:text-slate-100">
                      {r.year}
                    </td>
                    <td className="px-4 py-3 text-right font-mono tabular-nums text-slate-700 dark:text-slate-300">
                      100.0%
                    </td>
                    <td className="px-4 py-3 text-right font-mono tabular-nums text-sky-600 dark:text-sky-400">
                      {r.grossMarginPct.toFixed(1)}%
                    </td>
                    <td className="px-4 py-3 text-right font-mono tabular-nums text-amber-600 dark:text-amber-400">
                      {r.opexPct.toFixed(1)}%
                    </td>
                    <td
                      className={`px-4 py-3 text-right font-mono font-semibold tabular-nums ${
                        r.netMarginPct >= 0
                          ? 'text-emerald-600 dark:text-emerald-400'
                          : 'text-rose-600 dark:text-rose-400'
                      }`}
                    >
                      {r.netMarginPct.toFixed(1)}%
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
