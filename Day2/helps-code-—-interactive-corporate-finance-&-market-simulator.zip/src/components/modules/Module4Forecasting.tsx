import React, { useState } from 'react';
import { Line } from 'react-chartjs-2';
import { DerivedFinancials, formatCompactCurrency, formatCurrency, TAX_RATE } from '../../utils/financeEngine';
import { InfoTooltip, LearnBanner } from '../InfoTooltip';
import { buildBaseOptions } from '../ChartConfig';

interface Module4Props {
  financials: DerivedFinancials;
  learnMode: boolean;
  isDark: boolean;
}

export const Module4Forecasting: React.FC<Module4Props> = ({
  financials,
  learnMode,
  isDark,
}) => {
  const [growthRate, setGrowthRate] = useState(18); // % annual revenue growth
  const [inflationRate, setInflationRate] = useState(4); // % cost inflation
  const [costCutTarget, setCostCutTarget] = useState(3); // % annual OpEx efficiency
  const [metric, setMetric] = useState<'revenue' | 'netIncome'>('netIncome');

  const baseRev = financials.incomeStatement.revenue;
  const baseCogsRatio =
    baseRev > 0 ? financials.incomeStatement.cogs / baseRev : 0.38;
  const baseOpex = financials.incomeStatement.opex;
  const interest = financials.incomeStatement.interestExpense;

  const projectScenario = (
    revMult: number,
    infMult: number,
    cutMult: number
  ) => {
    const years = [0, 1, 2, 3];
    return years.map((t) => {
      if (t === 0) {
        return {
          label: 'Current (Y5)',
          revenue: baseRev,
          netIncome: financials.incomeStatement.netIncome,
        };
      }
      const g = (growthRate * revMult) / 100;
      const inf = (inflationRate * infMult) / 100;
      const cut = (costCutTarget * cutMult) / 100;

      const rev = baseRev * Math.pow(1 + g, t);
      const cogs = rev * Math.min(0.85, baseCogsRatio * Math.pow(1 + inf * 0.45, t));
      const opex = baseOpex * Math.pow(1 + inf - cut, t);
      const ebt = rev - cogs - opex - interest;
      const tax = ebt > 0 ? ebt * TAX_RATE : 0;
      return {
        label: `Year +${t}`,
        revenue: rev,
        netIncome: ebt - tax,
      };
    });
  };

  // Best case: +35% higher growth, 30% lower inflation, +40% stronger efficiency
  const best = projectScenario(1.35, 0.7, 1.4);
  const base = projectScenario(1.0, 1.0, 1.0);
  // Worst case: 45% of expected growth, 1.5x inflation shock, 40% efficiency realization
  const worst = projectScenario(0.45, 1.5, 0.4);

  const chartData = {
    labels: base.map((p) => p.label),
    datasets: [
      {
        label: 'Best Case',
        data: best.map((p) => p[metric]),
        borderColor: '#059669',
        backgroundColor: 'rgba(5, 150, 105, 0.08)',
        borderWidth: 2.5,
        pointRadius: 5,
        tension: 0.25,
        fill: false,
      },
      {
        label: 'Base Case',
        data: base.map((p) => p[metric]),
        borderColor: isDark ? '#38bdf8' : '#0f172a',
        backgroundColor: isDark ? 'rgba(56, 189, 248, 0.1)' : 'rgba(15, 23, 42, 0.06)',
        borderWidth: 2.5,
        pointRadius: 5,
        tension: 0.25,
        fill: false,
      },
      {
        label: 'Worst Case',
        data: worst.map((p) => p[metric]),
        borderColor: '#e11d48',
        backgroundColor: 'rgba(225, 29, 72, 0.08)',
        borderWidth: 2.5,
        borderDash: [6, 4],
        pointRadius: 5,
        tension: 0.25,
        fill: false,
      },
    ],
  };

  const chartOptions = buildBaseOptions(isDark, {
    plugins: {
      tooltip: {
        callbacks: {
          label: (ctx: any) => `${ctx.dataset.label}: ${formatCurrency(ctx.parsed.y)}`,
        },
      },
    },
    scales: {
      y: {
        ticks: {
          callback: (val: any) => formatCompactCurrency(Number(val)),
        },
      },
    },
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            04. Three-Year Scenario Forecasting
          </h2>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
            Stress-test Helps Code&apos;s next 3 years across Best, Base, and Worst case macro and operational conditions.
          </p>
        </div>

        <div className="inline-flex items-center gap-1 rounded-lg bg-slate-200/80 p-1 dark:bg-slate-800">
          <button
            type="button"
            onClick={() => setMetric('netIncome')}
            className={`whitespace-nowrap rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${
              metric === 'netIncome'
                ? 'bg-white text-slate-900 shadow-sm dark:bg-slate-900 dark:text-slate-100'
                : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
            }`}
          >
            Projected Net Income
          </button>
          <button
            type="button"
            onClick={() => setMetric('revenue')}
            className={`whitespace-nowrap rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${
              metric === 'revenue'
                ? 'bg-white text-slate-900 shadow-sm dark:bg-slate-900 dark:text-slate-100'
                : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
            }`}
          >
            Projected Revenue
          </button>
        </div>
      </div>

      <LearnBanner
        learnMode={learnMode}
        title="Compound Growth vs. Cost Inflation"
        formula="Net OpEx Growth = Inflation Rate − Efficiency Target"
        explanation="Small annual gaps compound dramatically over 3 years. Notice how high inflation combined with missed efficiency targets compresses Worst Case Net Income even if top-line Revenue continues to grow."
      />

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Controls Column */}
        <div className="space-y-5 rounded-xl border border-slate-200 bg-white p-5 lg:col-span-4 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
            <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">
              Forecast Assumptions
            </h3>
            <InfoTooltip termKey="scenarioForecasting" align="right" />
          </div>

          <div>
            <div className="mb-1.5 flex justify-between text-xs">
              <label htmlFor="fc-growth" className="font-medium text-slate-700 dark:text-slate-300">
                Expected Annual Revenue Growth
              </label>
              <span className="font-mono font-semibold text-emerald-600 dark:text-emerald-400">
                +{growthRate}% / yr
              </span>
            </div>
            <input
              id="fc-growth"
              type="range"
              min={0}
              max={45}
              step={1}
              value={growthRate}
              onChange={(e) => setGrowthRate(Number(e.target.value))}
              className="fin-slider w-full"
            />
          </div>

          <div>
            <div className="mb-1.5 flex justify-between text-xs">
              <label htmlFor="fc-inf" className="font-medium text-slate-700 dark:text-slate-300">
                Annual Cost Inflation
              </label>
              <span className="font-mono font-semibold text-rose-600 dark:text-rose-400">
                {inflationRate}% / yr
              </span>
            </div>
            <input
              id="fc-inf"
              type="range"
              min={0}
              max={15}
              step={0.5}
              value={inflationRate}
              onChange={(e) => setInflationRate(Number(e.target.value))}
              className="fin-slider w-full"
            />
          </div>

          <div>
            <div className="mb-1.5 flex justify-between text-xs">
              <label htmlFor="fc-cut" className="font-medium text-slate-700 dark:text-slate-300">
                OpEx Cost-Cutting Target
              </label>
              <span className="font-mono font-semibold text-sky-600 dark:text-sky-400">
                -{costCutTarget}% / yr
              </span>
            </div>
            <input
              id="fc-cut"
              type="range"
              min={0}
              max={15}
              step={0.5}
              value={costCutTarget}
              onChange={(e) => setCostCutTarget(Number(e.target.value))}
              className="fin-slider w-full"
            />
          </div>

          {/* Year +3 Outcomes Summary */}
          <div className="space-y-2 border-t border-slate-100 pt-4 dark:border-slate-800">
            <span className="block text-xs font-medium text-slate-500 dark:text-slate-400">
              Year +3 {metric === 'revenue' ? 'Revenue' : 'Net Income'} Spread
            </span>
            <div className="flex items-center justify-between text-sm">
              <span className="font-medium text-emerald-700 dark:text-emerald-400">Best Case</span>
              <span className="font-mono font-semibold text-emerald-700 dark:text-emerald-400">
                {formatCurrency(best[3][metric])}
              </span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="font-medium text-slate-700 dark:text-slate-200">Base Case</span>
              <span className="font-mono font-semibold text-slate-900 dark:text-slate-100">
                {formatCurrency(base[3][metric])}
              </span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="font-medium text-rose-700 dark:text-rose-400">Worst Case</span>
              <span className="font-mono font-semibold text-rose-700 dark:text-rose-400">
                {formatCurrency(worst[3][metric])}
              </span>
            </div>
          </div>
        </div>

        {/* Multi-line Chart */}
        <div className="rounded-xl border border-slate-200 bg-white p-5 lg:col-span-8 dark:border-slate-800 dark:bg-slate-900">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">
                3-Year {metric === 'revenue' ? 'Revenue' : 'Net Income'} Trajectory
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Sensitivity fan anchored to live Year 5 Sandbox baseline
              </p>
            </div>
          </div>
          <div className="h-80">
            <Line data={chartData} options={chartOptions} />
          </div>
        </div>
      </div>
    </div>
  );
};
