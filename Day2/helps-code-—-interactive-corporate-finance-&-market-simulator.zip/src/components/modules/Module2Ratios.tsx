import React from 'react';
import { AlertTriangle, CheckCircle2, XCircle } from 'lucide-react';
import { DerivedFinancials } from '../../utils/financeEngine';
import { FinancialRatioItem, HealthStatus } from '../../types/finance';
import { InfoTooltip, LearnBanner } from '../InfoTooltip';

interface Module2Props {
  financials: DerivedFinancials;
  learnMode: boolean;
}

function StatusIndicator({ status }: { status: HealthStatus }) {
  if (status === 'Healthy') {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-700 dark:text-emerald-400">
        <CheckCircle2 className="h-4 w-4 shrink-0" />
        <span>Healthy</span>
      </span>
    );
  }
  if (status === 'Warning') {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-amber-700 dark:text-amber-400">
        <AlertTriangle className="h-4 w-4 shrink-0" />
        <span>Warning</span>
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-rose-700 dark:text-rose-400">
      <XCircle className="h-4 w-4 shrink-0" />
      <span>Critical</span>
    </span>
  );
}

function RadialGauge({ ratio }: { ratio: FinancialRatioItem }) {
  const radius = 42;
  const circumference = Math.PI * radius; // Semi-circle arc length
  const strokeDashoffset = circumference - (ratio.gaugePercent / 100) * circumference;

  const strokeColor =
    ratio.status === 'Healthy'
      ? '#059669'
      : ratio.status === 'Warning'
        ? '#d97706'
        : '#e11d48';

  return (
    <div className="relative flex flex-col items-center">
      <svg viewBox="0 0 110 64" className="h-20 w-36 overflow-visible">
        {/* Track */}
        <path
          d="M 13 55 A 42 42 0 0 1 97 55"
          fill="none"
          stroke="currentColor"
          strokeWidth="9"
          strokeLinecap="round"
          className="text-slate-200 dark:text-slate-800"
        />
        {/* Active Arc */}
        <path
          d="M 13 55 A 42 42 0 0 1 97 55"
          fill="none"
          stroke={strokeColor}
          strokeWidth="9"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          className="transition-all duration-300 ease-out"
        />
      </svg>
      <div className="-mt-7 text-center">
        <span className="font-mono text-xl font-bold text-slate-900 dark:text-slate-100">
          {ratio.formattedValue}
        </span>
      </div>
    </div>
  );
}

export const Module2Ratios: React.FC<Module2Props> = ({ financials, learnMode }) => {
  const { ratios } = financials;

  const healthyCount = ratios.filter((r) => r.status === 'Healthy').length;
  const warningCount = ratios.filter((r) => r.status === 'Warning').length;
  const criticalCount = ratios.filter((r) => r.status === 'Critical').length;

  const glossaryMap: Record<string, string> = {
    'current-ratio': 'currentRatio',
    'quick-ratio': 'currentRatio',
    'net-profit-margin': 'netIncome',
    roe: 'roe',
    'debt-to-equity': 'debtToEquity',
    'interest-coverage': 'debtToEquity',
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            02. Ratio Analysis &amp; Health Check
          </h2>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
            Real-time diagnostic ratios calculated from Helps Code&apos;s live Income Statement and Balance Sheet.
          </p>
        </div>

        <div className="flex items-center gap-4 text-xs font-medium">
          <span className="text-emerald-700 dark:text-emerald-400">
            <strong className="font-mono">{healthyCount}</strong> Healthy
          </span>
          <span aria-hidden="true" className="text-slate-300 dark:text-slate-700">
            ·
          </span>
          <span className="text-amber-700 dark:text-amber-400">
            <strong className="font-mono">{warningCount}</strong> Warning
          </span>
          <span aria-hidden="true" className="text-slate-300 dark:text-slate-700">
            ·
          </span>
          <span className="text-rose-700 dark:text-rose-400">
            <strong className="font-mono">{criticalCount}</strong> Critical
          </span>
        </div>
      </div>

      <LearnBanner
        learnMode={learnMode}
        title="Why Analysts Use Ratios Instead of Raw Dollars"
        formula="Liquidity (Short-Term Safety)  ·  Profitability (Margin & ROE)  ·  Leverage (Debt Risk)"
        explanation="A company earning $2M profit could be thriving or struggling depending on its revenue scale and debt load. Ratios normalize raw dollar figures so investors can grade corporate health fairly. Try raising Total Debt in the Sandbox above to watch Leverage ratios shift toward Critical."
      />

      {/* Ratio Cards Grid */}
      <div className="grid grid-cols-1 gap-5 md:grid-cols-2 xl:grid-cols-3">
        {ratios.map((ratio) => (
          <article
            key={ratio.id}
            className="flex flex-col justify-between rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900"
          >
            <div>
              <div className="flex items-start justify-between gap-3">
                <div>
                  <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
                    {ratio.category} · {ratio.benchmark}
                  </span>
                  <div className="mt-0.5 flex items-center gap-1.5">
                    <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">
                      {ratio.name}
                    </h3>
                    {glossaryMap[ratio.id] && (
                      <InfoTooltip termKey={glossaryMap[ratio.id] as any} />
                    )}
                  </div>
                </div>
                <StatusIndicator status={ratio.status} />
              </div>

              <div className="my-5 flex justify-center">
                <RadialGauge ratio={ratio} />
              </div>

              <p className="text-xs leading-relaxed text-slate-600 dark:text-slate-300">
                {ratio.explanation}
              </p>
            </div>

            <div className="mt-4 border-t border-slate-100 pt-3 dark:border-slate-800">
              <span className="block text-[11px] font-medium text-slate-400">
                Formula
              </span>
              <code className="mt-0.5 block font-mono text-xs text-slate-700 dark:text-slate-300">
                {ratio.formula}
              </code>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
};
