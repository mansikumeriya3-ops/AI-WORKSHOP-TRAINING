import React, { useState } from 'react';
import { Bar, Line } from 'react-chartjs-2';
import { AlertTriangle, CheckCircle2 } from 'lucide-react';
import { DerivedFinancials, formatCompactCurrency, formatCurrency } from '../../utils/financeEngine';
import { InfoTooltip, LearnBanner } from '../InfoTooltip';
import { buildBaseOptions } from '../ChartConfig';

interface Module6Props {
  financials: DerivedFinancials;
  learnMode: boolean;
  isDark: boolean;
}

export const Module6Planning: React.FC<Module6Props> = ({
  financials,
  learnMode,
  isDark,
}) => {
  // Break-Even Unit Economics
  const [fixedCosts, setFixedCosts] = useState(310_000); // Monthly fixed overhead ($)
  const [variableCost, setVariableCost] = useState(85);   // Variable cost per unit ($)
  const [unitPrice, setUnitPrice] = useState(240);        // Selling price per unit ($)

  // Runway Controls (can sync from Sandbox or stress-test custom burn)
  const [burnOverride, setBurnOverride] = useState<number | null>(null);

  const contributionMargin = unitPrice - variableCost;
  const canBreakEven = contributionMargin > 0;
  const breakEvenUnits = canBreakEven ? Math.ceil(fixedCosts / contributionMargin) : null;
  const breakEvenRevenue = breakEvenUnits !== null ? breakEvenUnits * unitPrice : null;

  // Build linear coordinates for Break-Even Chart
  const maxUnits =
    breakEvenUnits !== null ? Math.max(2000, Math.ceil(breakEvenUnits * 2)) : 5000;
  const stepCount = 8;
  const unitPoints = Array.from({ length: stepCount + 1 }, (_, i) =>
    Math.round((maxUnits / stepCount) * i)
  );

  const breakEvenChartData = {
    datasets: [
      {
        label: 'Total Revenue ($)',
        data: unitPoints.map((u) => ({ x: u, y: u * unitPrice })),
        borderColor: '#059669',
        backgroundColor: '#059669',
        borderWidth: 2.5,
        pointRadius: 2,
        tension: 0,
      },
      {
        label: 'Total Costs (Fixed + Variable)',
        data: unitPoints.map((u) => ({ x: u, y: fixedCosts + u * variableCost })),
        borderColor: '#e11d48',
        backgroundColor: '#e11d48',
        borderWidth: 2.5,
        pointRadius: 2,
        tension: 0,
      },
      {
        label: 'Fixed Costs Baseline',
        data: unitPoints.map((u) => ({ x: u, y: fixedCosts })),
        borderColor: isDark ? '#64748b' : '#94a3b8',
        borderDash: [5, 5],
        borderWidth: 1.5,
        pointRadius: 0,
      },
      ...(breakEvenUnits !== null && breakEvenRevenue !== null
        ? [
            {
              label: `Break-Even Point (${breakEvenUnits.toLocaleString()} units)`,
              data: [{ x: breakEvenUnits, y: breakEvenRevenue }],
              borderColor: '#0284c7',
              backgroundColor: '#0284c7',
              pointRadius: 8,
              pointHoverRadius: 10,
              showLine: false,
            },
          ]
        : []),
    ],
  };

  const breakEvenOptions = buildBaseOptions(isDark, {
    plugins: {
      tooltip: {
        callbacks: {
          title: (items: any[]) =>
            items[0] ? `Volume: ${Math.round(items[0].parsed.x).toLocaleString()} units` : '',
          label: (ctx: any) => `${ctx.dataset.label}: ${formatCurrency(ctx.parsed.y)}`,
        },
      },
    },
    scales: {
      x: {
        type: 'linear',
        min: 0,
        max: maxUnits,
        title: {
          display: true,
          text: 'Monthly Units Sold',
        },
        ticks: {
          callback: (val: any) => Number(val).toLocaleString(),
        },
      },
      y: {
        min: 0,
        title: {
          display: true,
          text: 'Monthly Dollars ($)',
        },
        ticks: {
          callback: (val: any) => formatCompactCurrency(Number(val)),
        },
      },
    },
  });

  // Cash Runway Calculation
  const cashOnHand = financials.balanceSheet.cash;
  const sandboxMonthlyNetCash = financials.cashFlowStatement.operatingCashFlow / 12;
  // Positive monthly burn means losing cash; negative burn means generating cash
  const defaultMonthlyBurn = Math.round(-sandboxMonthlyNetCash);
  const monthlyBurn = burnOverride !== null ? burnOverride : defaultMonthlyBurn;

  const isCashFlowPositive = monthlyBurn <= 0;
  const runwayMonths =
    !isCashFlowPositive && monthlyBurn > 0 ? cashOnHand / monthlyBurn : Infinity;

  // 12-Month Cash Projection
  const months = Array.from({ length: 12 }, (_, i) => `M${i + 1}`);
  const cashProjection = months.map((_, i) =>
    Math.max(0, cashOnHand - monthlyBurn * (i + 1))
  );

  const runwayChartData = {
    labels: months,
    datasets: [
      {
        label: 'Projected Cash Balance ($)',
        data: cashProjection,
        backgroundColor: cashProjection.map((c) =>
          c > 1_000_000 ? '#059669' : c > 0 ? '#d97706' : '#e11d48'
        ),
        borderRadius: 5,
      },
    ],
  };

  const runwayChartOptions = buildBaseOptions(isDark, {
    plugins: {
      legend: { display: false },
      tooltip: {
        callbacks: {
          label: (ctx: any) => `Cash Balance: ${formatCurrency(ctx.parsed.y)}`,
        },
      },
    },
    scales: {
      y: {
        min: 0,
        ticks: {
          callback: (val: any) => formatCompactCurrency(Number(val)),
        },
      },
    },
  });

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
          06. Financial Planning: Break-Even &amp; Cash Runway
        </h2>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
          Calculate exact unit volume required to cover costs and track how long Helps Code&apos;s cash balance survives under burn scenarios.
        </p>
      </div>

      <LearnBanner
        learnMode={learnMode}
        title="Unit Economics & Cash Survival"
        formula="Break-Even Units = Fixed Costs / (Price − Variable Cost)  |  Runway = Cash / Monthly Burn"
        explanation="The Break-Even intersection is where the green Revenue line crosses the red Total Cost line. Below that point, Helps Code loses money; above it, every unit adds Contribution Margin to profit. Meanwhile, Cash Runway warns CFOs months before liquidity runs dry."
      />

      {/* Section 1: Break-Even Analysis */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div className="space-y-5 rounded-xl border border-slate-200 bg-white p-5 lg:col-span-4 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
            <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">
              Break-Even Parameters
            </h3>
            <InfoTooltip termKey="breakEven" align="right" />
          </div>

          <div>
            <div className="mb-1.5 flex justify-between text-xs">
              <label htmlFor="be-fixed" className="font-medium text-slate-700 dark:text-slate-300">
                Monthly Fixed Costs
              </label>
              <span className="font-mono font-semibold text-slate-900 dark:text-slate-100">
                {formatCurrency(fixedCosts)}
              </span>
            </div>
            <input
              id="be-fixed"
              type="range"
              min={50_000}
              max={900_000}
              step={10_000}
              value={fixedCosts}
              onChange={(e) => setFixedCosts(Number(e.target.value))}
              className="fin-slider w-full"
            />
          </div>

          <div>
            <div className="mb-1.5 flex justify-between text-xs">
              <label htmlFor="be-var" className="font-medium text-slate-700 dark:text-slate-300">
                Variable Cost per Unit
              </label>
              <span className="font-mono font-semibold text-rose-600 dark:text-rose-400">
                ${variableCost}
              </span>
            </div>
            <input
              id="be-var"
              type="range"
              min={15}
              max={300}
              step={5}
              value={variableCost}
              onChange={(e) => setVariableCost(Number(e.target.value))}
              className="fin-slider w-full"
            />
          </div>

          <div>
            <div className="mb-1.5 flex justify-between text-xs">
              <label htmlFor="be-price" className="font-medium text-slate-700 dark:text-slate-300">
                Selling Price per Unit
              </label>
              <span className="font-mono font-semibold text-emerald-600 dark:text-emerald-400">
                ${unitPrice}
              </span>
            </div>
            <input
              id="be-price"
              type="range"
              min={40}
              max={500}
              step={5}
              value={unitPrice}
              onChange={(e) => setUnitPrice(Number(e.target.value))}
              className="fin-slider w-full"
            />
          </div>

          <div className="space-y-2 border-t border-slate-100 pt-4 dark:border-slate-800">
            <div className="flex justify-between text-xs">
              <span className="text-slate-500 dark:text-slate-400">Contribution Margin / Unit</span>
              <span
                className={`font-mono font-semibold ${
                  contributionMargin > 0
                    ? 'text-emerald-600 dark:text-emerald-400'
                    : 'text-rose-600 dark:text-rose-400'
                }`}
              >
                ${contributionMargin}
              </span>
            </div>

            {canBreakEven && breakEvenUnits !== null && breakEvenRevenue !== null ? (
              <>
                <div className="flex justify-between text-sm">
                  <span className="font-medium text-slate-700 dark:text-slate-200">
                    Break-Even Volume
                  </span>
                  <span className="font-mono font-bold text-sky-600 dark:text-sky-400">
                    {breakEvenUnits.toLocaleString()} units/mo
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="font-medium text-slate-700 dark:text-slate-200">
                    Break-Even Revenue
                  </span>
                  <span className="font-mono font-bold text-slate-900 dark:text-slate-100">
                    {formatCurrency(breakEvenRevenue)}/mo
                  </span>
                </div>
              </>
            ) : (
              <div className="flex items-start gap-2 rounded-lg bg-rose-50 p-3 text-xs text-rose-700 dark:bg-rose-950/40 dark:text-rose-300">
                <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
                <span>
                  Unit Price must exceed Variable Cost (${variableCost}) to achieve a positive contribution margin.
                </span>
              </div>
            )}
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5 lg:col-span-8 dark:border-slate-800 dark:bg-slate-900">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">
                Break-Even Intersection Curve
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Blue marker pinpoints where Total Revenue equals Total Costs
              </p>
            </div>
          </div>
          <div className="h-80">
            <Line data={breakEvenChartData as any} options={breakEvenOptions} />
          </div>
        </div>
      </div>

      {/* Section 2: Cash Runway Tracker */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div className="space-y-4 rounded-xl border border-slate-200 bg-white p-5 lg:col-span-5 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
            <div>
              <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">
                Cash Runway Tracker
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Synced with Sandbox Cash ({formatCompactCurrency(cashOnHand)})
              </p>
            </div>
            <InfoTooltip termKey="cashRunway" align="right" />
          </div>

          <div>
            <div className="mb-1.5 flex items-center justify-between text-xs">
              <label htmlFor="burn-rate" className="font-medium text-slate-700 dark:text-slate-300">
                Monthly Net Burn Rate
              </label>
              <div className="flex items-center gap-2">
                <span
                  className={`font-mono font-semibold ${
                    monthlyBurn <= 0
                      ? 'text-emerald-600 dark:text-emerald-400'
                      : 'text-rose-600 dark:text-rose-400'
                  }`}
                >
                  {monthlyBurn <= 0
                    ? `+${formatCurrency(Math.abs(monthlyBurn))}/mo surplus`
                    : `-${formatCurrency(monthlyBurn)}/mo burn`}
                </span>
                {burnOverride !== null && (
                  <button
                    type="button"
                    onClick={() => setBurnOverride(null)}
                    className="text-[11px] font-medium text-sky-600 underline dark:text-sky-400"
                  >
                    Sync Live
                  </button>
                )}
              </div>
            </div>
            <input
              id="burn-rate"
              type="range"
              min={-300_000}
              max={800_000}
              step={20_000}
              value={monthlyBurn}
              onChange={(e) => setBurnOverride(Number(e.target.value))}
              className="fin-slider w-full"
            />
          </div>

          <div className="rounded-lg border border-slate-200 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-950/60">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              Estimated Runway
            </span>
            {isCashFlowPositive ? (
              <div className="mt-1 flex items-center gap-2 text-emerald-700 dark:text-emerald-400">
                <CheckCircle2 className="h-5 w-5 shrink-0" />
                <span className="font-mono text-2xl font-bold">Cash-Flow Positive</span>
              </div>
            ) : (
              <div className="mt-1 flex items-baseline gap-2">
                <span
                  className={`font-mono text-3xl font-bold ${
                    runwayMonths >= 12
                      ? 'text-emerald-600 dark:text-emerald-400'
                      : runwayMonths >= 6
                        ? 'text-amber-600 dark:text-amber-400'
                        : 'text-rose-600 dark:text-rose-400'
                  }`}
                >
                  {runwayMonths.toFixed(1)} months
                </span>
                <span className="text-xs text-slate-500 dark:text-slate-400">
                  before $0 cash
                </span>
              </div>
            )}
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5 lg:col-span-7 dark:border-slate-800 dark:bg-slate-900">
          <h3 className="mb-3 text-base font-semibold text-slate-900 dark:text-slate-100">
            12-Month Projected Cash Balance
          </h3>
          <div className="h-56">
            <Bar data={runwayChartData} options={runwayChartOptions} />
          </div>
        </div>
      </div>
    </div>
  );
};
