import React from 'react';
import { Bar } from 'react-chartjs-2';
import { CheckCircle2, ArrowRight } from 'lucide-react';
import { DerivedFinancials, formatCompactCurrency, formatCurrency } from '../../utils/financeEngine';
import { SandboxState } from '../../types/finance';
import { InfoTooltip, LearnBanner } from '../InfoTooltip';
import { buildBaseOptions } from '../ChartConfig';

interface Module1Props {
  sandbox: SandboxState;
  onUpdateSandbox: (next: SandboxState) => void;
  financials: DerivedFinancials;
  learnMode: boolean;
  isDark: boolean;
}

export const Module1Statements: React.FC<Module1Props> = ({
  sandbox,
  onUpdateSandbox,
  financials,
  learnMode,
  isDark,
}) => {
  const { incomeStatement: is, balanceSheet: bs, cashFlowStatement: cf } = financials;

  const waterfallData = {
    labels: ['Revenue', 'COGS', 'Gross Profit', 'OpEx', 'EBIT', 'Interest & Tax', 'Net Income'],
    datasets: [
      {
        label: 'Amount ($)',
        data: [
          is.revenue,
          -is.cogs,
          is.grossProfit,
          -is.opex,
          is.ebit,
          -(is.interestExpense + is.taxExpense),
          is.netIncome,
        ],
        backgroundColor: [
          '#0f172a',
          '#e11d48',
          '#0284c7',
          '#f43f5e',
          '#0ea5e9',
          '#fb7185',
          is.netIncome >= 0 ? '#059669' : '#dc2626',
        ],
        borderRadius: 6,
        barThickness: 28,
      },
    ],
  };

  const chartOptions = buildBaseOptions(isDark, {
    plugins: {
      legend: { display: false },
      tooltip: {
        callbacks: {
          label: (ctx: any) => formatCurrency(ctx.parsed.y),
        },
      },
    },
    scales: {
      y: {
        ticks: {
          callback: (val: any) => formatCompactCurrency(Number(val)),
        },
      },
    },
  });

  const StatementRow = ({
    label,
    value,
    bold = false,
    accent,
    termKey,
    indent = false,
  }: {
    label: string;
    value: number;
    bold?: boolean;
    accent?: 'emerald' | 'rose' | 'navy';
    termKey?: string;
    indent?: boolean;
  }) => {
    const colorClass =
      accent === 'emerald'
        ? 'text-emerald-700 dark:text-emerald-400'
        : accent === 'rose'
          ? 'text-rose-700 dark:text-rose-400'
          : bold
            ? 'text-slate-900 dark:text-slate-100'
            : 'text-slate-600 dark:text-slate-300';

    return (
      <div
        className={`flex items-center justify-between gap-4 py-2 ${
          bold
            ? 'border-t border-slate-200 font-semibold dark:border-slate-800'
            : 'border-b border-slate-100 last:border-b-0 dark:border-slate-800/60'
        }`}
      >
        <div className={`flex items-center gap-1.5 text-sm ${indent ? 'pl-3' : ''} ${colorClass}`}>
          <span>{label}</span>
          {termKey && <InfoTooltip termKey={termKey as any} />}
        </div>
        <span className={`font-mono text-sm tabular-nums ${colorClass}`}>
          {formatCurrency(value)}
        </span>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            01. Financial Statements
          </h2>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
            Watch how operational revenue and expense decisions flow from the Income Statement into Retained Earnings and keep the Balance Sheet balanced.
          </p>
        </div>
        <div className="flex items-center gap-2 text-xs font-medium text-emerald-700 dark:text-emerald-400">
          <CheckCircle2 className="h-4 w-4 shrink-0" />
          <span>
            Double-Entry Verified · Delta {formatCurrency(bs.balanceDelta)}
          </span>
          <InfoTooltip termKey="balanceSheetIdentity" align="right" />
        </div>
      </div>

      <LearnBanner
        learnMode={learnMode}
        title="How the Three Statements Connect"
        formula="Net Income − Dividends = Δ Retained Earnings  |  Assets = Liabilities + Equity"
        explanation="When you increase Revenue or reduce COGS in the sandbox, Net Income rises immediately. 85% of that Net Income flows into Retained Earnings (Equity) while simultaneously increasing Cash on the Balance Sheet via Operating Cash Flow."
      />

      {/* Live Accounting Equation & Flow Bridge */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <div className="grid grid-cols-1 items-center gap-4 lg:grid-cols-7">
          <div className="lg:col-span-2">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              Total Assets
            </span>
            <p className="mt-1 font-mono text-2xl font-bold text-slate-900 dark:text-slate-100">
              {formatCurrency(bs.totalAssets)}
            </p>
            <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
              Current {formatCompactCurrency(bs.totalCurrentAssets)} · PP&amp;E{' '}
              {formatCompactCurrency(bs.fixedAssets)}
            </p>
          </div>

          <div className="flex items-center justify-center text-lg font-bold text-slate-400">
            =
          </div>

          <div className="lg:col-span-2">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              Total Liabilities
            </span>
            <p className="mt-1 font-mono text-2xl font-bold text-rose-600 dark:text-rose-400">
              {formatCurrency(bs.totalLiabilities)}
            </p>
            <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
              Debt {formatCompactCurrency(sandbox.debt)} · Payables &amp; Accrued{' '}
              {formatCompactCurrency(bs.accountsPayable + bs.accruedLiabilities)}
            </p>
          </div>

          <div className="flex items-center justify-center text-lg font-bold text-slate-400">
            +
          </div>

          <div className="lg:col-span-1">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              Shareholders Equity
            </span>
            <p className="mt-1 font-mono text-2xl font-bold text-emerald-600 dark:text-emerald-400">
              {formatCurrency(bs.totalEquity)}
            </p>
            <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
              Includes{' '}
              <span className="font-mono">
                {formatCompactCurrency(bs.currentRetainedEarnings)}
              </span>{' '}
              Retained
            </p>
          </div>
        </div>

        {/* Direct Statement Quick-Sliders */}
        <div className="mt-5 grid grid-cols-1 gap-4 border-t border-slate-100 pt-4 sm:grid-cols-3 dark:border-slate-800">
          <div>
            <div className="mb-1 flex justify-between text-xs">
              <span className="font-medium text-slate-600 dark:text-slate-300">
                Adjust Revenue
              </span>
              <span className="font-mono font-semibold text-slate-900 dark:text-slate-100">
                {formatCompactCurrency(sandbox.revenue)}
              </span>
            </div>
            <input
              type="range"
              min={4_000_000}
              max={30_000_000}
              step={250_000}
              value={sandbox.revenue}
              onChange={(e) =>
                onUpdateSandbox({ ...sandbox, revenue: Number(e.target.value) })
              }
              className="fin-slider w-full"
            />
          </div>
          <div>
            <div className="mb-1 flex justify-between text-xs">
              <span className="font-medium text-slate-600 dark:text-slate-300">
                Adjust Operating Expenses
              </span>
              <span className="font-mono font-semibold text-slate-900 dark:text-slate-100">
                {formatCompactCurrency(sandbox.opex)}
              </span>
            </div>
            <input
              type="range"
              min={1_500_000}
              max={14_000_000}
              step={150_000}
              value={sandbox.opex}
              onChange={(e) =>
                onUpdateSandbox({ ...sandbox, opex: Number(e.target.value) })
              }
              className="fin-slider w-full"
            />
          </div>
          <div>
            <div className="mb-1 flex justify-between text-xs">
              <span className="font-medium text-slate-600 dark:text-slate-300">
                Adjust Fixed Assets (CapEx)
              </span>
              <span className="font-mono font-semibold text-slate-900 dark:text-slate-100">
                {formatCompactCurrency(sandbox.fixedAssets)}
              </span>
            </div>
            <input
              type="range"
              min={1_000_000}
              max={12_000_000}
              step={200_000}
              value={sandbox.fixedAssets}
              onChange={(e) =>
                onUpdateSandbox({ ...sandbox, fixedAssets: Number(e.target.value) })
              }
              className="fin-slider w-full"
            />
          </div>
        </div>
      </div>

      {/* Profit Waterfall Chart */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <div className="mb-4 flex items-center justify-between">
          <div>
            <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">
              Earnings Flow Breakdown
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Revenue conversion from top-line sales to bottom-line Net Income
            </p>
          </div>
          <div className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-300">
            <span>Gross Margin</span>
            <strong className="font-mono text-slate-900 dark:text-slate-100">
              {(is.grossMargin * 100).toFixed(1)}%
            </strong>
          </div>
        </div>
        <div className="h-64">
          <Bar data={waterfallData} options={chartOptions} />
        </div>
      </div>

      {/* Three Interactive Statements Grid */}
      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        {/* Income Statement */}
        <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <div className="mb-3 flex items-center justify-between border-b border-slate-200 pb-3 dark:border-slate-800">
            <div>
              <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">
                Income Statement
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Annualized Operating Performance
              </p>
            </div>
            <InfoTooltip termKey="netIncome" align="right" />
          </div>

          <div className="space-y-0.5">
            <StatementRow label="Revenue" value={is.revenue} termKey="revenue" />
            <StatementRow
              label="Cost of Goods Sold (COGS)"
              value={-is.cogs}
              termKey="cogs"
              indent
            />
            <StatementRow
              label="Gross Profit"
              value={is.grossProfit}
              bold
              termKey="grossProfit"
            />
            <StatementRow
              label="Operating Expenses (incl. $450K Dep.)"
              value={-is.opex}
              termKey="opex"
              indent
            />
            <StatementRow label="Operating Income (EBIT)" value={is.ebit} bold />
            <StatementRow
              label="Interest Expense (6.0% on Debt)"
              value={-is.interestExpense}
              indent
            />
            <StatementRow label="Pre-Tax Income (EBT)" value={is.ebt} />
            <StatementRow label="Corporate Income Tax (21%)" value={-is.taxExpense} indent />
            <StatementRow
              label="Net Income"
              value={is.netIncome}
              bold
              accent={is.netIncome >= 0 ? 'emerald' : 'rose'}
              termKey="netIncome"
            />
          </div>

          <div className="mt-4 flex items-center justify-between rounded-lg bg-slate-50 px-3 py-2.5 text-xs dark:bg-slate-800/60">
            <span className="flex items-center gap-1 text-slate-600 dark:text-slate-300">
              <span>Flow to Retained Earnings (85%)</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </span>
            <span className="font-mono font-semibold text-emerald-700 dark:text-emerald-400">
              {formatCurrency(is.additionToRetainedEarnings)}
            </span>
          </div>
        </div>

        {/* Balance Sheet */}
        <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <div className="mb-3 flex items-center justify-between border-b border-slate-200 pb-3 dark:border-slate-800">
            <div>
              <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">
                Balance Sheet
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Snapshot Position (Assets = L + E)
              </p>
            </div>
            <InfoTooltip termKey="retainedEarnings" align="right" />
          </div>

          <div className="space-y-0.5">
            <p className="pt-1 text-xs font-semibold text-slate-500 dark:text-slate-400">
              Assets
            </p>
            <StatementRow label="Cash & Equivalents" value={bs.cash} indent />
            <StatementRow label="Accounts Receivable" value={bs.accountsReceivable} indent />
            <StatementRow label="Inventory" value={bs.inventory} indent />
            <StatementRow label="Total Current Assets" value={bs.totalCurrentAssets} bold />
            <StatementRow label="Property, Plant & Equipment" value={bs.fixedAssets} indent />
            <StatementRow label="Total Assets" value={bs.totalAssets} bold accent="navy" />

            <p className="pt-3 text-xs font-semibold text-slate-500 dark:text-slate-400">
              Liabilities &amp; Equity
            </p>
            <StatementRow label="Accounts Payable" value={bs.accountsPayable} indent />
            <StatementRow label="Accrued Liabilities" value={bs.accruedLiabilities} indent />
            <StatementRow label="Short-Term Debt (20%)" value={bs.shortTermDebt} indent />
            {bs.creditLineOverdraft > 0 && (
              <StatementRow
                label="Revolving Credit Overdraft"
                value={bs.creditLineOverdraft}
                accent="rose"
                indent
              />
            )}
            <StatementRow label="Long-Term Debt (80%)" value={bs.longTermDebt} indent />
            <StatementRow label="Total Liabilities" value={bs.totalLiabilities} bold />
            <StatementRow label="Paid-In Capital" value={bs.paidInCapital} indent />
            <StatementRow
              label="Retained Earnings (Prior + Current)"
              value={bs.totalRetainedEarnings}
              termKey="retainedEarnings"
              indent
            />
            <StatementRow
              label="Total Liabilities & Equity"
              value={bs.totalLiabilitiesAndEquity}
              bold
              accent="emerald"
            />
          </div>
        </div>

        {/* Cash Flow Statement */}
        <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <div className="mb-3 flex items-center justify-between border-b border-slate-200 pb-3 dark:border-slate-800">
            <div>
              <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100">
                Cash Flow Statement
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Indirect Method Cash Reconciliation
              </p>
            </div>
            <InfoTooltip termKey="operatingCashFlow" align="right" />
          </div>

          <div className="space-y-0.5">
            <p className="pt-1 text-xs font-semibold text-slate-500 dark:text-slate-400">
              Operating Activities
            </p>
            <StatementRow label="Net Income" value={cf.netIncome} indent />
            <StatementRow label="Add: Depreciation (Non-Cash)" value={cf.depreciation} indent />
            <StatementRow
              label="Working Capital Adjustments"
              value={
                -cf.changeInReceivables -
                cf.changeInInventory +
                cf.changeInPayables +
                cf.changeInAccrued
              }
              indent
            />
            <StatementRow
              label="Operating Cash Flow"
              value={cf.operatingCashFlow}
              bold
              accent={cf.operatingCashFlow >= 0 ? 'emerald' : 'rose'}
              termKey="operatingCashFlow"
            />

            <p className="pt-3 text-xs font-semibold text-slate-500 dark:text-slate-400">
              Investing &amp; Financing Activities
            </p>
            <StatementRow label="Capital Expenditures (PP&E)" value={cf.investingCashFlow} indent />
            <StatementRow label="Net Debt Issuance / Repayment" value={cf.debtChange} indent />
            <StatementRow label="Dividends Paid (15%)" value={-cf.dividendsPaid} indent />
            {cf.overdraftDraw > 0 && (
              <StatementRow
                label="Emergency Credit Line Draw"
                value={cf.overdraftDraw}
                accent="rose"
                indent
              />
            )}
            <StatementRow label="Net Change in Cash" value={cf.netCashChange} bold />
            <StatementRow label="Beginning Cash Balance" value={cf.beginningCash} indent />
            <StatementRow
              label="Ending Cash (Matches Balance Sheet)"
              value={cf.endingCash}
              bold
              accent="emerald"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
