import { useState } from 'react';
import {
  Code2,
  Fingerprint,
  LayoutDashboard,
  Lock,
  Package,
  ReceiptText,
  RotateCcw,
  Users,
} from 'lucide-react';
import { AndroidSourceView } from './components/AndroidSourceView';
import { BiometricLockOverlay } from './components/BiometricLockOverlay';
import { ClientsView } from './components/ClientsView';
import { DashboardView } from './components/DashboardView';
import { InventoryView } from './components/InventoryView';
import { InvoicesView } from './components/InvoicesView';
import { useBizFlowStore } from './store/useBizFlowStore';
import { NavDestination } from './types/bizflow';

const NAV_ITEMS: {
  id: NavDestination;
  label: string;
  shortLabel: string;
  icon: typeof LayoutDashboard;
}[] = [
  {
    id: 'dashboard',
    label: 'Dashboard',
    shortLabel: 'Home',
    icon: LayoutDashboard,
  },
  {
    id: 'inventory',
    label: 'Inventory',
    shortLabel: 'Stock',
    icon: Package,
  },
  {
    id: 'clients',
    label: 'Clients',
    shortLabel: 'Clients',
    icon: Users,
  },
  {
    id: 'invoices',
    label: 'Invoices',
    shortLabel: 'Invoices',
    icon: ReceiptText,
  },
  {
    id: 'android-code',
    label: 'Android Source & APK',
    shortLabel: 'Kotlin',
    icon: Code2,
  },
];

export default function App() {
  const {
    products,
    clients,
    invoices,
    activities,
    settings,
    isLocked,
    setIsLocked,
    kpis,
    addProduct,
    updateProduct,
    adjustProductStock,
    deleteProduct,
    addClient,
    updateClient,
    deleteClient,
    createInvoice,
    toggleInvoiceStatus,
    deleteInvoice,
    updateSettings,
    resetDemoData,
  } = useBizFlowStore();

  const [activeTab, setActiveTab] = useState<NavDestination>('dashboard');
  const [openInvoiceComposer, setOpenInvoiceComposer] = useState(false);

  const handleQuickNewInvoice = () => {
    setOpenInvoiceComposer(true);
    setActiveTab('invoices');
  };

  const activeNav = NAV_ITEMS.find((item) => item.id === activeTab) ?? NAV_ITEMS[0];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      {isLocked && (
        <BiometricLockOverlay
          expectedPin={settings.fallbackPin}
          onUnlock={() => setIsLocked(false)}
        />
      )}

      <div className="flex min-h-screen">
        {/* Desktop Sidebar Navigation */}
        <aside className="hidden w-64 shrink-0 flex-col border-r border-slate-200 bg-white md:flex">
          <div className="flex h-16 items-center border-b border-slate-200 px-6">
            <span className="font-display text-lg font-bold tracking-tight text-slate-900">
              BizFlow
            </span>
          </div>

          <nav className="flex-1 space-y-1 p-4" aria-label="Primary">
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveTab(item.id)}
                  className={`flex w-full items-center gap-3 rounded-lg px-3.5 py-2.5 text-sm font-medium transition-colors whitespace-nowrap ${
                    isActive
                      ? 'bg-teal-700 text-white'
                      : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                  }`}
                >
                  <Icon
                    className={`h-4 w-4 shrink-0 ${
                      isActive ? 'text-teal-100' : 'text-slate-400'
                    }`}
                  />
                  <span className="truncate">{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Security & Offline Controls */}
          <div className="space-y-3 border-t border-slate-200 p-4">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-xs font-medium text-slate-700">
                <Fingerprint className="h-4 w-4 text-teal-700" />
                <span>Biometric Lock</span>
              </div>
              <button
                type="button"
                role="switch"
                aria-checked={settings.biometricLockEnabled}
                onClick={() =>
                  updateSettings({
                    biometricLockEnabled: !settings.biometricLockEnabled,
                  })
                }
                className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer items-center rounded-full transition-colors ${
                  settings.biometricLockEnabled ? 'bg-teal-700' : 'bg-slate-300'
                }`}
              >
                <span
                  className={`inline-block h-3.5 w-3.5 transform rounded-full bg-white transition-transform ${
                    settings.biometricLockEnabled
                      ? 'translate-x-4.5'
                      : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            {settings.biometricLockEnabled && (
              <button
                type="button"
                onClick={() => setIsLocked(true)}
                className="flex w-full items-center justify-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100"
              >
                <Lock className="h-3.5 w-3.5" />
                <span>Lock App Now</span>
              </button>
            )}

            <button
              type="button"
              onClick={resetDemoData}
              className="flex w-full items-center justify-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium text-slate-500 hover:bg-slate-100 hover:text-slate-800"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              <span>Reset Sample Data</span>
            </button>
          </div>
        </aside>

        {/* Main Workspace */}
        <div className="flex min-w-0 flex-1 flex-col pb-20 md:pb-0">
          {/* Compact Top Bar */}
          <header className="sticky top-0 z-30 flex h-14 items-center justify-between gap-4 border-b border-slate-200 bg-white/95 px-4 backdrop-blur-sm sm:px-8">
            <div className="flex items-center gap-3 min-w-0">
              <span className="font-display text-base font-bold text-slate-900 md:hidden">
                BizFlow
              </span>
              <span className="text-slate-300 md:hidden" aria-hidden="true">
                /
              </span>
              <span className="truncate text-sm font-medium text-slate-600">
                {activeNav.label}
              </span>
            </div>

            <div className="flex items-center gap-3 shrink-0">
              <span className="hidden text-xs text-slate-500 sm:inline">
                {settings.businessName}
              </span>
              <button
                type="button"
                onClick={() => {
                  if (!settings.biometricLockEnabled) {
                    updateSettings({ biometricLockEnabled: true });
                  }
                  setIsLocked(true);
                }}
                className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 md:hidden whitespace-nowrap"
              >
                <Lock className="h-3.5 w-3.5 text-teal-700" />
                <span>Lock</span>
              </button>
            </div>
          </header>

          <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-6 sm:px-8 sm:py-8">
            {activeTab === 'dashboard' && (
              <DashboardView
                kpis={kpis}
                activities={activities}
                onNavigate={setActiveTab}
                onQuickNewInvoice={handleQuickNewInvoice}
              />
            )}
            {activeTab === 'inventory' && (
              <InventoryView
                products={products}
                onAddProduct={addProduct}
                onUpdateProduct={updateProduct}
                onAdjustStock={adjustProductStock}
                onDeleteProduct={deleteProduct}
              />
            )}
            {activeTab === 'clients' && (
              <ClientsView
                clients={clients}
                invoices={invoices}
                onAddClient={addClient}
                onUpdateClient={updateClient}
                onDeleteClient={deleteClient}
              />
            )}
            {activeTab === 'invoices' && (
              <InvoicesView
                invoices={invoices}
                clients={clients}
                products={products}
                settings={settings}
                startWithComposer={openInvoiceComposer}
                onComposerOpened={() => setOpenInvoiceComposer(false)}
                onCreateInvoice={createInvoice}
                onToggleStatus={toggleInvoiceStatus}
                onDeleteInvoice={deleteInvoice}
              />
            )}
            {activeTab === 'android-code' && <AndroidSourceView />}
          </main>
        </div>
      </div>

      {/* Mobile Bottom Navigation Bar (Material 3 Thumb-Zone Ergonomics) */}
      <nav
        aria-label="Mobile navigation"
        className="fixed bottom-0 left-0 right-0 z-40 grid h-16 grid-cols-5 border-t border-slate-200 bg-white/95 backdrop-blur-md md:hidden"
      >
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setActiveTab(item.id)}
              className={`flex min-h-[44px] flex-col items-center justify-center gap-1 text-[11px] font-medium transition-colors ${
                isActive ? 'text-teal-700' : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <Icon className="h-5 w-5" />
              <span className="truncate">{item.shortLabel}</span>
            </button>
          );
        })}
      </nav>
    </div>
  );
}
