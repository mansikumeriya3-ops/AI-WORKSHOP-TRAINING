export type NavDestination =
  | 'dashboard'
  | 'inventory'
  | 'clients'
  | 'invoices'
  | 'android-code';

export interface Product {
  id: string;
  name: string;
  sku: string;
  category: string;
  unitPrice: number;
  stockQuantity: number;
  lowStockThreshold: number;
  updatedAt: string;
}

export interface Client {
  id: string;
  name: string;
  company: string;
  phone: string;
  email: string;
  notes: string;
  createdAt: string;
}

export interface InvoiceLineItem {
  productId: string;
  productName: string;
  sku: string;
  unitPrice: number;
  quantity: number;
}

export type InvoiceStatus = 'PAID' | 'UNPAID';

export interface Invoice {
  id: string;
  invoiceNumber: string;
  clientId: string;
  clientName: string;
  clientCompany: string;
  clientEmail: string;
  clientPhone: string;
  items: InvoiceLineItem[];
  subtotal: number;
  taxRatePercent: number;
  taxAmount: number;
  totalAmount: number;
  status: InvoiceStatus;
  issuedAt: string;
  dueDate: string;
  notes: string;
}

export type ActivityType =
  | 'INVOICE_CREATED'
  | 'INVOICE_PAID'
  | 'STOCK_UPDATED'
  | 'CLIENT_ADDED'
  | 'LOW_STOCK_ALERT';

export interface ActivityEntry {
  id: string;
  type: ActivityType;
  title: string;
  detail: string;
  timestamp: string;
}

export interface BusinessSettings {
  businessName: string;
  businessEmail: string;
  businessPhone: string;
  defaultTaxRate: number;
  biometricLockEnabled: boolean;
  fallbackPin: string;
}

export interface AndroidProjectFile {
  path: string;
  packageGroup:
    | 'Gradle & Manifest'
    | 'Data Layer (Room)'
    | 'Domain Layer'
    | 'DI (Hilt)'
    | 'Utilities (PDF & Biometric)'
    | 'UI Theme & Navigation'
    | 'UI Screens & Components';
  language: 'kotlin' | 'xml' | 'toml' | 'gradle';
  description: string;
  content: string;
}
