import { useState, useEffect, useCallback } from 'react';
import {
  ActivityEntry,
  BusinessSettings,
  Client,
  Invoice,
  InvoiceLineItem,
  InvoiceStatus,
  Product,
} from '../types/bizflow';

const STORAGE_KEY = 'bizflow_offline_db_v1';

interface PersistedState {
  products: Product[];
  clients: Client[];
  invoices: Invoice[];
  activities: ActivityEntry[];
  settings: BusinessSettings;
}

const nowIso = (offsetHours = 0) =>
  new Date(Date.now() - offsetHours * 3600 * 1000).toISOString();

const SEED_PRODUCTS: Product[] = [
  {
    id: 'prod-1',
    name: 'Heavy-Duty Thermal Receipt Printer',
    sku: 'HW-PRT-802',
    category: 'Point of Sale',
    unitPrice: 189.0,
    stockQuantity: 14,
    lowStockThreshold: 5,
    updatedAt: nowIso(3),
  },
  {
    id: 'prod-2',
    name: 'Wireless 2D Barcode Scanner',
    sku: 'HW-SCN-210',
    category: 'Point of Sale',
    unitPrice: 74.5,
    stockQuantity: 4,
    lowStockThreshold: 6,
    updatedAt: nowIso(5),
  },
  {
    id: 'prod-3',
    name: '80mm Thermal Paper Rolls (50 Pack)',
    sku: 'SUP-PPR-050',
    category: 'Consumables',
    unitPrice: 42.0,
    stockQuantity: 28,
    lowStockThreshold: 10,
    updatedAt: nowIso(12),
  },
  {
    id: 'prod-4',
    name: 'NFC Tap-to-Pay Counter Terminal',
    sku: 'HW-NFC-400',
    category: 'Payments',
    unitPrice: 129.0,
    stockQuantity: 2,
    lowStockThreshold: 5,
    updatedAt: nowIso(18),
  },
  {
    id: 'prod-5',
    name: 'Aluminum Tablet Counter Stand',
    sku: 'ACC-STD-115',
    category: 'Fixtures',
    unitPrice: 58.0,
    stockQuantity: 0,
    lowStockThreshold: 4,
    updatedAt: nowIso(26),
  },
  {
    id: 'prod-6',
    name: 'Shielded Cat6 Patch Cable 5m (10 Pack)',
    sku: 'NET-C6-005',
    category: 'Networking',
    unitPrice: 36.0,
    stockQuantity: 19,
    lowStockThreshold: 5,
    updatedAt: nowIso(40),
  },
];

const SEED_CLIENTS: Client[] = [
  {
    id: 'cli-1',
    name: 'Elena Rostova',
    company: 'Northside Roastery & Bakery',
    phone: '+1 (503) 555-0148',
    email: 'elena@northsideroastery.com',
    notes: 'Prefers net-14 invoicing; two retail locations.',
    createdAt: nowIso(120),
  },
  {
    id: 'cli-2',
    name: 'Marcus Vance',
    company: 'Vance Hardware Supply',
    phone: '+1 (503) 555-0192',
    email: 'mvance@vancehardware.co',
    notes: 'Bulk thermal paper orders every quarter.',
    createdAt: nowIso(96),
  },
  {
    id: 'cli-3',
    name: 'Priya Nair',
    company: 'Alder Street Pharmacy',
    phone: '+1 (503) 555-0174',
    email: 'ops@alderpharmacy.org',
    notes: 'Requires PDF invoices sent directly to accounts payable.',
    createdAt: nowIso(72),
  },
  {
    id: 'cli-4',
    name: 'Daniel Cho',
    company: 'Harbor Bicycle Workshop',
    phone: '+1 (503) 555-0131',
    email: 'daniel@harborbikes.io',
    notes: 'Upgrading two service desks next month.',
    createdAt: nowIso(48),
  },
];

const SEED_INVOICES: Invoice[] = [
  {
    id: 'inv-1001',
    invoiceNumber: 'INV-2026-101',
    clientId: 'cli-1',
    clientName: 'Elena Rostova',
    clientCompany: 'Northside Roastery & Bakery',
    clientEmail: 'elena@northsideroastery.com',
    clientPhone: '+1 (503) 555-0148',
    items: [
      {
        productId: 'prod-1',
        productName: 'Heavy-Duty Thermal Receipt Printer',
        sku: 'HW-PRT-802',
        unitPrice: 189.0,
        quantity: 2,
      },
      {
        productId: 'prod-3',
        productName: '80mm Thermal Paper Rolls (50 Pack)',
        sku: 'SUP-PPR-050',
        unitPrice: 42.0,
        quantity: 3,
      },
    ],
    subtotal: 504.0,
    taxRatePercent: 8.5,
    taxAmount: 42.84,
    totalAmount: 546.84,
    status: 'PAID',
    issuedAt: nowIso(72),
    dueDate: nowIso(48),
    notes: 'Installed at main counter and patio bar.',
  },
  {
    id: 'inv-1002',
    invoiceNumber: 'INV-2026-102',
    clientId: 'cli-2',
    clientName: 'Marcus Vance',
    clientCompany: 'Vance Hardware Supply',
    clientEmail: 'mvance@vancehardware.co',
    clientPhone: '+1 (503) 555-0192',
    items: [
      {
        productId: 'prod-2',
        productName: 'Wireless 2D Barcode Scanner',
        sku: 'HW-SCN-210',
        unitPrice: 74.5,
        quantity: 4,
      },
      {
        productId: 'prod-6',
        productName: 'Shielded Cat6 Patch Cable 5m (10 Pack)',
        sku: 'NET-C6-005',
        unitPrice: 36.0,
        quantity: 2,
      },
    ],
    subtotal: 370.0,
    taxRatePercent: 8.5,
    taxAmount: 31.45,
    totalAmount: 401.45,
    status: 'UNPAID',
    issuedAt: nowIso(24),
    dueDate: nowIso(-240),
    notes: 'Net-14 terms. Delivery confirmed.',
  },
  {
    id: 'inv-1003',
    invoiceNumber: 'INV-2026-103',
    clientId: 'cli-3',
    clientName: 'Priya Nair',
    clientCompany: 'Alder Street Pharmacy',
    clientEmail: 'ops@alderpharmacy.org',
    clientPhone: '+1 (503) 555-0174',
    items: [
      {
        productId: 'prod-4',
        productName: 'NFC Tap-to-Pay Counter Terminal',
        sku: 'HW-NFC-400',
        unitPrice: 129.0,
        quantity: 3,
      },
    ],
    subtotal: 387.0,
    taxRatePercent: 8.5,
    taxAmount: 32.9,
    totalAmount: 419.9,
    status: 'PAID',
    issuedAt: nowIso(14),
    dueDate: nowIso(2),
    notes: 'Paid via ACH transfer.',
  },
];

const SEED_ACTIVITIES: ActivityEntry[] = [
  {
    id: 'act-1',
    type: 'LOW_STOCK_ALERT',
    title: 'Low stock threshold reached',
    detail: 'NFC Tap-to-Pay Counter Terminal (HW-NFC-400) has 2 units remaining.',
    timestamp: nowIso(4),
  },
  {
    id: 'act-2',
    type: 'INVOICE_PAID',
    title: 'Invoice INV-2026-103 marked Paid',
    detail: 'Alder Street Pharmacy · $419.90 settled.',
    timestamp: nowIso(14),
  },
  {
    id: 'act-3',
    type: 'INVOICE_CREATED',
    title: 'Created Invoice INV-2026-102',
    detail: 'Vance Hardware Supply · $401.45 (Unpaid).',
    timestamp: nowIso(24),
  },
  {
    id: 'act-4',
    type: 'STOCK_UPDATED',
    title: 'Out of stock: Aluminum Tablet Counter Stand',
    detail: 'SKU ACC-STD-115 quantity reached 0.',
    timestamp: nowIso(26),
  },
];

const DEFAULT_SETTINGS: BusinessSettings = {
  businessName: 'Cascade Retail Systems LLC',
  businessEmail: 'billing@cascaderetail.local',
  businessPhone: '+1 (503) 555-0100',
  defaultTaxRate: 8.5,
  biometricLockEnabled: false,
  fallbackPin: '1234',
};

function loadInitialState(): PersistedState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as PersistedState;
      if (parsed && Array.isArray(parsed.products) && Array.isArray(parsed.clients)) {
        return parsed;
      }
    }
  } catch {
    // Fallback to seed data if storage is unavailable or corrupted
  }
  return {
    products: SEED_PRODUCTS,
    clients: SEED_CLIENTS,
    invoices: SEED_INVOICES,
    activities: SEED_ACTIVITIES,
    settings: DEFAULT_SETTINGS,
  };
}

export function useBizFlowStore() {
  const [state, setState] = useState<PersistedState>(loadInitialState);
  const [isLocked, setIsLocked] = useState<boolean>(() => {
    const initial = loadInitialState();
    return initial.settings.biometricLockEnabled;
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {
      // Ignore storage quota errors
    }
  }, [state]);

  const appendActivity = (
    prev: PersistedState,
    type: ActivityEntry['type'],
    title: string,
    detail: string
  ): ActivityEntry[] => {
    const entry: ActivityEntry = {
      id: `act-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      type,
      title,
      detail,
      timestamp: new Date().toISOString(),
    };
    return [entry, ...prev.activities].slice(0, 40);
  };

  // Inventory CRUD
  const addProduct = useCallback(
    (input: Omit<Product, 'id' | 'updatedAt'>) => {
      setState((prev) => {
        const product: Product = {
          ...input,
          id: `prod-${Date.now()}`,
          updatedAt: new Date().toISOString(),
        };
        const activities = appendActivity(
          prev,
          'STOCK_UPDATED',
          `Added product ${product.name}`,
          `SKU ${product.sku} · ${product.stockQuantity} in stock at $${product.unitPrice.toFixed(2)}`
        );
        return {
          ...prev,
          products: [product, ...prev.products],
          activities,
        };
      });
    },
    []
  );

  const updateProduct = useCallback((updated: Product) => {
    setState((prev) => {
      const nextProducts = prev.products.map((p) =>
        p.id === updated.id ? { ...updated, updatedAt: new Date().toISOString() } : p
      );
      const isLow = updated.stockQuantity <= updated.lowStockThreshold;
      const activities = appendActivity(
        prev,
        isLow ? 'LOW_STOCK_ALERT' : 'STOCK_UPDATED',
        isLow ? `Low stock: ${updated.name}` : `Updated ${updated.name}`,
        `SKU ${updated.sku} · ${updated.stockQuantity} units remaining`
      );
      return {
        ...prev,
        products: nextProducts,
        activities,
      };
    });
  }, []);

  const adjustProductStock = useCallback((productId: string, delta: number) => {
    setState((prev) => {
      let targetName = '';
      let nextQty = 0;
      let isLow = false;
      const nextProducts = prev.products.map((p) => {
        if (p.id !== productId) return p;
        nextQty = Math.max(0, p.stockQuantity + delta);
        targetName = p.name;
        isLow = nextQty <= p.lowStockThreshold;
        return {
          ...p,
          stockQuantity: nextQty,
          updatedAt: new Date().toISOString(),
        };
      });
      if (!targetName) return prev;
      return {
        ...prev,
        products: nextProducts,
        activities: appendActivity(
          prev,
          isLow ? 'LOW_STOCK_ALERT' : 'STOCK_UPDATED',
          `${targetName} stock adjusted`,
          `Current quantity: ${nextQty} units`
        ),
      };
    });
  }, []);

  const deleteProduct = useCallback((productId: string) => {
    setState((prev) => ({
      ...prev,
      products: prev.products.filter((p) => p.id !== productId),
    }));
  }, []);

  // Client CRUD
  const addClient = useCallback((input: Omit<Client, 'id' | 'createdAt'>) => {
    setState((prev) => {
      const client: Client = {
        ...input,
        id: `cli-${Date.now()}`,
        createdAt: new Date().toISOString(),
      };
      return {
        ...prev,
        clients: [client, ...prev.clients],
        activities: appendActivity(
          prev,
          'CLIENT_ADDED',
          `New client: ${client.name}`,
          `${client.company || 'Independent'} · ${client.email}`
        ),
      };
    });
  }, []);

  const updateClient = useCallback((updated: Client) => {
    setState((prev) => ({
      ...prev,
      clients: prev.clients.map((c) => (c.id === updated.id ? updated : c)),
    }));
  }, []);

  const deleteClient = useCallback((clientId: string) => {
    setState((prev) => ({
      ...prev,
      clients: prev.clients.filter((c) => c.id !== clientId),
    }));
  }, []);

  // Invoice Operations
  const createInvoice = useCallback(
    (payload: {
      client: Client;
      items: InvoiceLineItem[];
      taxRatePercent: number;
      status: InvoiceStatus;
      dueDate: string;
      notes: string;
    }): Invoice => {
      const subtotal = payload.items.reduce(
        (sum, item) => sum + item.unitPrice * item.quantity,
        0
      );
      const taxAmount = Number(((subtotal * payload.taxRatePercent) / 100).toFixed(2));
      const totalAmount = Number((subtotal + taxAmount).toFixed(2));
      const nextNum = 104 + Math.floor(Math.random() * 890);
      const invoice: Invoice = {
        id: `inv-${Date.now()}`,
        invoiceNumber: `INV-2026-${nextNum}`,
        clientId: payload.client.id,
        clientName: payload.client.name,
        clientCompany: payload.client.company,
        clientEmail: payload.client.email,
        clientPhone: payload.client.phone,
        items: payload.items,
        subtotal: Number(subtotal.toFixed(2)),
        taxRatePercent: payload.taxRatePercent,
        taxAmount,
        totalAmount,
        status: payload.status,
        issuedAt: new Date().toISOString(),
        dueDate: payload.dueDate,
        notes: payload.notes,
      };

      setState((prev) => {
        // Deduct ordered quantities from local inventory
        const qtyById = new Map<string, number>();
        payload.items.forEach((item) => {
          qtyById.set(item.productId, (qtyById.get(item.productId) ?? 0) + item.quantity);
        });
        const nextProducts = prev.products.map((p) => {
          const ordered = qtyById.get(p.id);
          if (!ordered) return p;
          return {
            ...p,
            stockQuantity: Math.max(0, p.stockQuantity - ordered),
            updatedAt: new Date().toISOString(),
          };
        });

        const activities = appendActivity(
          prev,
          payload.status === 'PAID' ? 'INVOICE_PAID' : 'INVOICE_CREATED',
          `Invoice ${invoice.invoiceNumber} (${payload.status === 'PAID' ? 'Paid' : 'Unpaid'})`,
          `${invoice.clientCompany || invoice.clientName} · $${invoice.totalAmount.toFixed(2)}`
        );

        return {
          ...prev,
          products: nextProducts,
          invoices: [invoice, ...prev.invoices],
          activities,
        };
      });

      return invoice;
    },
    []
  );

  const toggleInvoiceStatus = useCallback((invoiceId: string) => {
    setState((prev) => {
      let target: Invoice | undefined;
      const nextInvoices = prev.invoices.map((inv) => {
        if (inv.id !== invoiceId) return inv;
        const nextStatus: InvoiceStatus = inv.status === 'PAID' ? 'UNPAID' : 'PAID';
        target = { ...inv, status: nextStatus };
        return target;
      });
      if (!target) return prev;
      return {
        ...prev,
        invoices: nextInvoices,
        activities: appendActivity(
          prev,
          target.status === 'PAID' ? 'INVOICE_PAID' : 'INVOICE_CREATED',
          `${target.invoiceNumber} marked ${target.status === 'PAID' ? 'Paid' : 'Unpaid'}`,
          `${target.clientCompany || target.clientName} · $${target.totalAmount.toFixed(2)}`
        ),
      };
    });
  }, []);

  const deleteInvoice = useCallback((invoiceId: string) => {
    setState((prev) => ({
      ...prev,
      invoices: prev.invoices.filter((inv) => inv.id !== invoiceId),
    }));
  }, []);

  const updateSettings = useCallback((patch: Partial<BusinessSettings>) => {
    setState((prev) => ({
      ...prev,
      settings: { ...prev.settings, ...patch },
    }));
  }, []);

  const resetDemoData = useCallback(() => {
    const fresh: PersistedState = {
      products: SEED_PRODUCTS,
      clients: SEED_CLIENTS,
      invoices: SEED_INVOICES,
      activities: SEED_ACTIVITIES,
      settings: DEFAULT_SETTINGS,
    };
    setState(fresh);
    setIsLocked(false);
  }, []);

  // Computed KPIs
  const totalRevenue = state.invoices
    .filter((i) => i.status === 'PAID')
    .reduce((sum, i) => sum + i.totalAmount, 0);

  const pendingInvoices = state.invoices.filter((i) => i.status === 'UNPAID');
  const pendingAmount = pendingInvoices.reduce((sum, i) => sum + i.totalAmount, 0);

  const lowStockProducts = state.products.filter(
    (p) => p.stockQuantity <= p.lowStockThreshold
  );

  return {
    products: state.products,
    clients: state.clients,
    invoices: state.invoices,
    activities: state.activities,
    settings: state.settings,
    isLocked,
    setIsLocked,
    kpis: {
      totalRevenue,
      pendingCount: pendingInvoices.length,
      pendingAmount,
      lowStockCount: lowStockProducts.length,
      lowStockProducts,
      clientCount: state.clients.length,
    },
    addProduct,
    updateProduct,
    adjustProductStock,
    deleteProduct,
    addClient,
    updateClient,
    deleteClient,
    createInvoice,
    toggleInvoiceStatus,
    deleteInvoice,
    updateSettings,
    resetDemoData,
  };
}
