import { AndroidProjectFile } from '../types/bizflow';
import { GRADLE_AND_MANIFEST_FILES } from './android/gradleAndManifest';
import { DATA_LAYER_FILES } from './android/dataLayer';
import { DOMAIN_AND_DI_FILES } from './android/domainAndDi';
import { UI_LAYER_FILES } from './android/uiLayer';

export const ANDROID_PROJECT_FILES: AndroidProjectFile[] = [
  ...GRADLE_AND_MANIFEST_FILES,
  ...DATA_LAYER_FILES,
  ...DOMAIN_AND_DI_FILES,
  ...UI_LAYER_FILES,
];
