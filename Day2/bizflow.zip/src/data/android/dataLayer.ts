import { AndroidProjectFile } from '../../types/bizflow';

export const DATA_LAYER_FILES: AndroidProjectFile[] = [
  {
    path: 'app/src/main/java/com/bizflow/app/data/local/entity/ProductEntity.kt',
    packageGroup: 'Data Layer (Room)',
    language: 'kotlin',
    description: 'Room entity representing an inventory SKU with stock quantity and low-stock threshold.',
    content: `package com.bizflow.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.bizflow.app.domain.model.Product

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val sku: String,
    val category: String,
    val unitPrice: Double,
    val stockQuantity: Int,
    val lowStockThreshold: Int,
    val updatedAtMillis: Long = System.currentTimeMillis()
)

fun ProductEntity.toDomain() = Product(
    id = id,
    name = name,
    sku = sku,
    category = category,
    unitPrice = unitPrice,
    stockQuantity = stockQuantity,
    lowStockThreshold = lowStockThreshold,
    updatedAtMillis = updatedAtMillis
)

fun Product.toEntity() = ProductEntity(
    id = id,
    name = name,
    sku = sku,
    category = category,
    unitPrice = unitPrice,
    stockQuantity = stockQuantity,
    lowStockThreshold = lowStockThreshold,
    updatedAtMillis = updatedAtMillis
)
`,
  },
  {
    path: 'app/src/main/java/com/bizflow/app/data/local/entity/ClientEntity.kt',
    packageGroup: 'Data Layer (Room)',
    language: 'kotlin',
    description: 'Room entity for CRM client records.',
    content: `package com.bizflow.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.bizflow.app.domain.model.Client

@Entity(tableName = "clients")
data class ClientEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val company: String,
    val phone: String,
    val email: String,
    val notes: String,
    val createdAtMillis: Long = System.currentTimeMillis()
)

fun ClientEntity.toDomain() = Client(
    id = id,
    name = name,
    company = company,
    phone = phone,
    email = email,
    notes = notes,
    createdAtMillis = createdAtMillis
)

fun Client.toEntity() = ClientEntity(
    id = id,
    name = name,
    company = company,
    phone = phone,
    email = email,
    notes = notes,
    createdAtMillis = createdAtMillis
)
`,
  },
  {
    path: 'app/src/main/java/com/bizflow/app/data/local/entity/InvoiceEntity.kt',
    packageGroup: 'Data Layer (Room)',
    language: 'kotlin',
    description: 'Room entities for Invoices, Line Items, and relational InvoiceWithItems.',
    content: `package com.bizflow.app.data.local.entity

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Relation
import com.bizflow.app.domain.model.Invoice
import com.bizflow.app.domain.model.InvoiceLineItem
import com.bizflow.app.domain.model.InvoiceStatus

@Entity(tableName = "invoices")
data class InvoiceEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val invoiceNumber: String,
    val clientId: Long,
    val clientName: String,
    val clientCompany: String,
    val clientEmail: String,
    val clientPhone: String,
    val subtotal: Double,
    val taxRatePercent: Double,
    val taxAmount: Double,
    val totalAmount: Double,
    val status: String,
    val issuedAtMillis: Long,
    val dueDateMillis: Long,
    val notes: String
)

@Entity(
    tableName = "invoice_line_items",
    foreignKeys = [
        ForeignKey(
            entity = InvoiceEntity::class,
            parentColumns = ["id"],
            childColumns = ["invoiceId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("invoiceId")]
)
data class InvoiceLineItemEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val invoiceId: Long,
    val productId: Long,
    val productName: String,
    val sku: String,
    val unitPrice: Double,
    val quantity: Int
)

data class InvoiceWithItems(
    @Embedded val invoice: InvoiceEntity,
    @Relation(
        parentColumn = "id",
        entityColumn = "invoiceId"
    )
    val items: List<InvoiceLineItemEntity>
)

fun InvoiceWithItems.toDomain() = Invoice(
    id = invoice.id,
    invoiceNumber = invoice.invoiceNumber,
    clientId = invoice.clientId,
    clientName = invoice.clientName,
    clientCompany = invoice.clientCompany,
    clientEmail = invoice.clientEmail,
    clientPhone = invoice.clientPhone,
    items = items.map {
        InvoiceLineItem(
            productId = it.productId,
            productName = it.productName,
            sku = it.sku,
            unitPrice = it.unitPrice,
            quantity = it.quantity
        )
    },
    subtotal = invoice.subtotal,
    taxRatePercent = invoice.taxRatePercent,
    taxAmount = invoice.taxAmount,
    totalAmount = invoice.totalAmount,
    status = InvoiceStatus.valueOf(invoice.status),
    issuedAtMillis = invoice.issuedAtMillis,
    dueDateMillis = invoice.dueDateMillis,
    notes = invoice.notes
)
`,
  },
  {
    path: 'app/src/main/java/com/bizflow/app/data/local/entity/ActivityLogEntity.kt',
    packageGroup: 'Data Layer (Room)',
    language: 'kotlin',
    description: 'Room entity for recent business activity feed items.',
    content: `package com.bizflow.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.bizflow.app.domain.model.ActivityEntry

@Entity(tableName = "activity_logs")
data class ActivityLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val detail: String,
    val timestampMillis: Long = System.currentTimeMillis()
)

fun ActivityLogEntity.toDomain() = ActivityEntry(
    id = id,
    title = title,
    detail = detail,
    timestampMillis = timestampMillis
)
`,
  },
  {
    path: 'app/src/main/java/com/bizflow/app/data/local/dao/ProductDao.kt',
    packageGroup: 'Data Layer (Room)',
    language: 'kotlin',
    description: 'Room DAO for reactive inventory queries, CRUD, and atomic stock deduction.',
    content: `package com.bizflow.app.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.bizflow.app.data.local.entity.ProductEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductDao {
    @Query("SELECT * FROM products ORDER BY name ASC")
    fun observeAllProducts(): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE stockQuantity <= lowStockThreshold ORDER BY stockQuantity ASC")
    fun observeLowStockProducts(): Flow<List<ProductEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(product: ProductEntity): Long

    @Update
    suspend fun updateProduct(product: ProductEntity)

    @Delete
    suspend fun deleteProduct(product: ProductEntity)

    @Query("UPDATE products SET stockQuantity = MAX(0, stockQuantity - :quantity), updatedAtMillis = :now WHERE id = :productId")
    suspend fun decrementStock(productId: Long, quantity: Int, now: Long = System.currentTimeMillis())
}
`,
  },
  {
    path: 'app/src/main/java/com/bizflow/app/data/local/dao/ClientDao.kt',
    packageGroup: 'Data Layer (Room)',
    language: 'kotlin',
    description: 'Room DAO for client search and CRUD.',
    content: `package com.bizflow.app.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.bizflow.app.data.local.entity.ClientEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ClientDao {
    @Query("SELECT * FROM clients ORDER BY name ASC")
    fun observeAllClients(): Flow<List<ClientEntity>>

    @Query("""
        SELECT * FROM clients 
        WHERE name LIKE '%' || :query || '%' 
           OR company LIKE '%' || :query || '%' 
           OR email LIKE '%' || :query || '%'
        ORDER BY name ASC
    """)
    fun searchClients(query: String): Flow<List<ClientEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClient(client: ClientEntity): Long

    @Update
    suspend fun updateClient(client: ClientEntity)

    @Delete
    suspend fun deleteClient(client: ClientEntity)
}
`,
  },
  {
    path: 'app/src/main/java/com/bizflow/app/data/local/dao/InvoiceDao.kt',
    packageGroup: 'Data Layer (Room)',
    language: 'kotlin',
    description: 'Room DAO for transactional invoice creation, status toggles, and revenue queries.',
    content: `package com.bizflow.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.bizflow.app.data.local.entity.InvoiceEntity
import com.bizflow.app.data.local.entity.InvoiceLineItemEntity
import com.bizflow.app.data.local.entity.InvoiceWithItems
import kotlinx.coroutines.flow.Flow

@Dao
interface InvoiceDao {
    @Transaction
    @Query("SELECT * FROM invoices ORDER BY issuedAtMillis DESC")
    fun observeAllInvoices(): Flow<List<InvoiceWithItems>>

    @Query("SELECT COALESCE(SUM(totalAmount), 0.0) FROM invoices WHERE status = 'PAID'")
    fun observeTotalPaidRevenue(): Flow<Double>

    @Query("SELECT COUNT(*) FROM invoices WHERE status = 'UNPAID'")
    fun observePendingInvoiceCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInvoice(invoice: InvoiceEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLineItems(items: List<InvoiceLineItemEntity>)

    @Transaction
    suspend fun insertInvoiceWithItems(
        invoice: InvoiceEntity,
        items: List<InvoiceLineItemEntity>
    ): Long {
        val invoiceId = insertInvoice(invoice)
        val boundItems = items.map { it.copy(invoiceId = invoiceId) }
        insertLineItems(boundItems)
        return invoiceId
    }

    @Query("UPDATE invoices SET status = :status WHERE id = :invoiceId")
    suspend fun updateStatus(invoiceId: Long, status: String)

    @Query("DELETE FROM invoices WHERE id = :invoiceId")
    suspend fun deleteInvoiceById(invoiceId: Long)
}
`,
  },
  {
    path: 'app/src/main/java/com/bizflow/app/data/local/dao/ActivityLogDao.kt',
    packageGroup: 'Data Layer (Room)',
    language: 'kotlin',
    description: 'Room DAO for recent activity feed.',
    content: `package com.bizflow.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.bizflow.app.data.local.entity.ActivityLogEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ActivityLogDao {
    @Query("SELECT * FROM activity_logs ORDER BY timestampMillis DESC LIMIT 25")
    fun observeRecentActivity(): Flow<List<ActivityLogEntity>>

    @Insert
    suspend fun insertLog(entry: ActivityLogEntity)
}
`,
  },
  {
    path: 'app/src/main/java/com/bizflow/app/data/local/BizFlowDatabase.kt',
    packageGroup: 'Data Layer (Room)',
    language: 'kotlin',
    description: 'Offline-first Room database definition uniting Products, Clients, Invoices, and Activity logs.',
    content: `package com.bizflow.app.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.bizflow.app.data.local.dao.ActivityLogDao
import com.bizflow.app.data.local.dao.ClientDao
import com.bizflow.app.data.local.dao.InvoiceDao
import com.bizflow.app.data.local.dao.ProductDao
import com.bizflow.app.data.local.entity.ActivityLogEntity
import com.bizflow.app.data.local.entity.ClientEntity
import com.bizflow.app.data.local.entity.InvoiceEntity
import com.bizflow.app.data.local.entity.InvoiceLineItemEntity
import com.bizflow.app.data.local.entity.ProductEntity

@Database(
    entities = [
        ProductEntity::class,
        ClientEntity::class,
        InvoiceEntity::class,
        InvoiceLineItemEntity::class,
        ActivityLogEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class BizFlowDatabase : RoomDatabase() {
    abstract fun productDao(): ProductDao
    abstract fun clientDao(): ClientDao
    abstract fun invoiceDao(): InvoiceDao
    abstract fun activityLogDao(): ActivityLogDao
}
`,
  },
  {
    path: 'app/src/main/java/com/bizflow/app/data/repository/ProductRepositoryImpl.kt',
    packageGroup: 'Data Layer (Room)',
    language: 'kotlin',
    description: 'Repository implementation bridging ProductDao and Domain layer.',
    content: `package com.bizflow.app.data.repository

import com.bizflow.app.data.local.dao.ActivityLogDao
import com.bizflow.app.data.local.dao.ProductDao
import com.bizflow.app.data.local.entity.ActivityLogEntity
import com.bizflow.app.data.local.entity.toDomain
import com.bizflow.app.data.local.entity.toEntity
import com.bizflow.app.domain.model.Product
import com.bizflow.app.domain.repository.ProductRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject

class ProductRepositoryImpl @Inject constructor(
    private val productDao: ProductDao,
    private val activityLogDao: ActivityLogDao
) : ProductRepository {

    override fun observeProducts(): Flow<List<Product>> =
        productDao.observeAllProducts().map { list -> list.map { it.toDomain() } }

    override fun observeLowStockProducts(): Flow<List<Product>> =
        productDao.observeLowStockProducts().map { list -> list.map { it.toDomain() } }

    override suspend fun saveProduct(product: Product) {
        if (product.id == 0L) {
            productDao.insertProduct(product.toEntity())
            activityLogDao.insertLog(
                ActivityLogEntity(
                    title = "Added product \${product.name}",
                    detail = "SKU \${product.sku} · \${product.stockQuantity} units"
                )
            )
        } else {
            productDao.updateProduct(product.toEntity())
            activityLogDao.insertLog(
                ActivityLogEntity(
                    title = "Updated \${product.name}",
                    detail = "Stock: \${product.stockQuantity} · $\${"%.2f".format(product.unitPrice)}"
                )
            )
        }
    }

    override suspend fun deleteProduct(product: Product) {
        productDao.deleteProduct(product.toEntity())
    }
}
`,
  },
  {
    path: 'app/src/main/java/com/bizflow/app/data/repository/ClientRepositoryImpl.kt',
    packageGroup: 'Data Layer (Room)',
    language: 'kotlin',
    description: 'Repository implementation for Client CRM operations.',
    content: `package com.bizflow.app.data.repository

import com.bizflow.app.data.local.dao.ActivityLogDao
import com.bizflow.app.data.local.dao.ClientDao
import com.bizflow.app.data.local.entity.ActivityLogEntity
import com.bizflow.app.data.local.entity.toDomain
import com.bizflow.app.data.local.entity.toEntity
import com.bizflow.app.domain.model.Client
import com.bizflow.app.domain.repository.ClientRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject

class ClientRepositoryImpl @Inject constructor(
    private val clientDao: ClientDao,
    private val activityLogDao: ActivityLogDao
) : ClientRepository {

    override fun observeClients(query: String): Flow<List<Client>> {
        val source = if (query.isBlank()) {
            clientDao.observeAllClients()
        } else {
            clientDao.searchClients(query.trim())
        }
        return source.map { list -> list.map { it.toDomain() } }
    }

    override suspend fun saveClient(client: Client) {
        if (client.id == 0L) {
            clientDao.insertClient(client.toEntity())
            activityLogDao.insertLog(
                ActivityLogEntity(
                    title = "New client: \${client.name}",
                    detail = "\${client.company.ifBlank { "Independent" }} · \${client.email}"
                )
            )
        } else {
            clientDao.updateClient(client.toEntity())
        }
    }

    override suspend fun deleteClient(client: Client) {
        clientDao.deleteClient(client.toEntity())
    }
}
`,
  },
  {
    path: 'app/src/main/java/com/bizflow/app/data/repository/InvoiceRepositoryImpl.kt',
    packageGroup: 'Data Layer (Room)',
    language: 'kotlin',
    description: 'Repository implementation handling transactional invoice saving, stock decrement, and dashboard activity.',
    content: `package com.bizflow.app.data.repository

import androidx.room.withTransaction
import com.bizflow.app.data.local.BizFlowDatabase
import com.bizflow.app.data.local.dao.ActivityLogDao
import com.bizflow.app.data.local.dao.InvoiceDao
import com.bizflow.app.data.local.dao.ProductDao
import com.bizflow.app.data.local.entity.ActivityLogEntity
import com.bizflow.app.data.local.entity.InvoiceEntity
import com.bizflow.app.data.local.entity.InvoiceLineItemEntity
import com.bizflow.app.data.local.entity.toDomain
import com.bizflow.app.domain.model.ActivityEntry
import com.bizflow.app.domain.model.Invoice
import com.bizflow.app.domain.model.InvoiceStatus
import com.bizflow.app.domain.repository.InvoiceRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject

class InvoiceRepositoryImpl @Inject constructor(
    private val database: BizFlowDatabase,
    private val invoiceDao: InvoiceDao,
    private val productDao: ProductDao,
    private val activityLogDao: ActivityLogDao
) : InvoiceRepository {

    override fun observeInvoices(): Flow<List<Invoice>> =
        invoiceDao.observeAllInvoices().map { list -> list.map { it.toDomain() } }

    override fun observeTotalPaidRevenue(): Flow<Double> =
        invoiceDao.observeTotalPaidRevenue()

    override fun observePendingInvoiceCount(): Flow<Int> =
        invoiceDao.observePendingInvoiceCount()

    override fun observeRecentActivity(): Flow<List<ActivityEntry>> =
        activityLogDao.observeRecentActivity().map { list -> list.map { it.toDomain() } }

    override suspend fun createInvoice(invoice: Invoice): Long =
        database.withTransaction {
            val invoiceId = invoiceDao.insertInvoiceWithItems(
                invoice = InvoiceEntity(
                    invoiceNumber = invoice.invoiceNumber,
                    clientId = invoice.clientId,
                    clientName = invoice.clientName,
                    clientCompany = invoice.clientCompany,
                    clientEmail = invoice.clientEmail,
                    clientPhone = invoice.clientPhone,
                    subtotal = invoice.subtotal,
                    taxRatePercent = invoice.taxRatePercent,
                    taxAmount = invoice.taxAmount,
                    totalAmount = invoice.totalAmount,
                    status = invoice.status.name,
                    issuedAtMillis = invoice.issuedAtMillis,
                    dueDateMillis = invoice.dueDateMillis,
                    notes = invoice.notes
                ),
                items = invoice.items.map {
                    InvoiceLineItemEntity(
                        invoiceId = 0L,
                        productId = it.productId,
                        productName = it.productName,
                        sku = it.sku,
                        unitPrice = it.unitPrice,
                        quantity = it.quantity
                    )
                }
            )

            invoice.items.forEach { item ->
                productDao.decrementStock(item.productId, item.quantity)
            }

            activityLogDao.insertLog(
                ActivityLogEntity(
                    title = "Invoice \${invoice.invoiceNumber} (\${invoice.status.label})",
                    detail = "\${invoice.clientCompany.ifBlank { invoice.clientName }} · $\${"%.2f".format(invoice.totalAmount)}"
                )
            )
            invoiceId
        }

    override suspend fun toggleInvoiceStatus(invoiceId: Long, newStatus: InvoiceStatus) {
        invoiceDao.updateStatus(invoiceId, newStatus.name)
        activityLogDao.insertLog(
            ActivityLogEntity(
                title = "Invoice status updated",
                detail = "Invoice #$invoiceId marked \${newStatus.label}"
            )
        )
    }

    override suspend fun deleteInvoice(invoiceId: Long) {
        invoiceDao.deleteInvoiceById(invoiceId)
    }
}
`,
  },
];
