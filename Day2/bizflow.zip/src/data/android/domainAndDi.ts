import { AndroidProjectFile } from '../../types/bizflow';

export const DOMAIN_AND_DI_FILES: AndroidProjectFile[] = [
  {
    path: 'app/src/main/java/com/bizflow/app/domain/model/Product.kt',
    packageGroup: 'Domain Layer',
    language: 'kotlin',
    description: 'Clean domain model for inventory products with computed low-stock helper.',
    content: `package com.bizflow.app.domain.model

data class Product(
    val id: Long = 0,
    val name: String,
    val sku: String,
    val category: String,
    val unitPrice: Double,
    val stockQuantity: Int,
    val lowStockThreshold: Int,
    val updatedAtMillis: Long = System.currentTimeMillis()
) {
    val isLowStock: Boolean
        get() = stockQuantity <= lowStockThreshold

    val isOutOfStock: Boolean
        get() = stockQuantity <= 0
}
`,
  },
  {
    path: 'app/src/main/java/com/bizflow/app/domain/model/Client.kt',
    packageGroup: 'Domain Layer',
    language: 'kotlin',
    description: 'Clean domain model for CRM clients.',
    content: `package com.bizflow.app.domain.model

data class Client(
    val id: Long = 0,
    val name: String,
    val company: String,
    val phone: String,
    val email: String,
    val notes: String = "",
    val createdAtMillis: Long = System.currentTimeMillis()
)
`,
  },
  {
    path: 'app/src/main/java/com/bizflow/app/domain/model/Invoice.kt',
    packageGroup: 'Domain Layer',
    language: 'kotlin',
    description: 'Clean domain models for Invoice, InvoiceLineItem, InvoiceStatus, and ActivityEntry.',
    content: `package com.bizflow.app.domain.model

enum class InvoiceStatus(val label: String) {
    PAID("Paid"),
    UNPAID("Unpaid")
}

data class InvoiceLineItem(
    val productId: Long,
    val productName: String,
    val sku: String,
    val unitPrice: Double,
    val quantity: Int
) {
    val lineTotal: Double
        get() = unitPrice * quantity
}

data class Invoice(
    val id: Long = 0,
    val invoiceNumber: String,
    val clientId: Long,
    val clientName: String,
    val clientCompany: String,
    val clientEmail: String,
    val clientPhone: String,
    val items: List<InvoiceLineItem>,
    val subtotal: Double,
    val taxRatePercent: Double,
    val taxAmount: Double,
    val totalAmount: Double,
    val status: InvoiceStatus,
    val issuedAtMillis: Long = System.currentTimeMillis(),
    val dueDateMillis: Long = System.currentTimeMillis() + 14L * 86_400_000L,
    val notes: String = ""
)

data class ActivityEntry(
    val id: Long,
    val title: String,
    val detail: String,
    val timestampMillis: Long
)
`,
  },
  {
    path: 'app/src/main/java/com/bizflow/app/domain/model/DashboardKpis.kt',
    packageGroup: 'Domain Layer',
    language: 'kotlin',
    description: 'Aggregated KPI snapshot powering the Dashboard screen.',
    content: `package com.bizflow.app.domain.model

data class DashboardKpis(
    val totalRevenue: Double = 0.0,
    val pendingInvoicesCount: Int = 0,
    val lowStockAlertCount: Int = 0,
    val lowStockProducts: List<Product> = emptyList(),
    val recentActivities: List<ActivityEntry> = emptyList()
)
`,
  },
  {
    path: 'app/src/main/java/com/bizflow/app/domain/repository/Repositories.kt',
    packageGroup: 'Domain Layer',
    language: 'kotlin',
    description: 'Domain repository contracts decoupled from Room implementation details.',
    content: `package com.bizflow.app.domain.repository

import com.bizflow.app.domain.model.ActivityEntry
import com.bizflow.app.domain.model.Client
import com.bizflow.app.domain.model.Invoice
import com.bizflow.app.domain.model.InvoiceStatus
import com.bizflow.app.domain.model.Product
import kotlinx.coroutines.flow.Flow

interface ProductRepository {
    fun observeProducts(): Flow<List<Product>>
    fun observeLowStockProducts(): Flow<List<Product>>
    suspend fun saveProduct(product: Product)
    suspend fun deleteProduct(product: Product)
}

interface ClientRepository {
    fun observeClients(query: String = ""): Flow<List<Client>>
    suspend fun saveClient(client: Client)
    suspend fun deleteClient(client: Client)
}

interface InvoiceRepository {
    fun observeInvoices(): Flow<List<Invoice>>
    fun observeTotalPaidRevenue(): Flow<Double>
    fun observePendingInvoiceCount(): Flow<Int>
    fun observeRecentActivity(): Flow<List<ActivityEntry>>
    suspend fun createInvoice(invoice: Invoice): Long
    suspend fun toggleInvoiceStatus(invoiceId: Long, newStatus: InvoiceStatus)
    suspend fun deleteInvoice(invoiceId: Long)
}
`,
  },
  {
    path: 'app/src/main/java/com/bizflow/app/domain/usecase/GetDashboardKpisUseCase.kt',
    packageGroup: 'Domain Layer',
    language: 'kotlin',
    description: 'Combines reactive Room streams into real-time Dashboard KPIs.',
    content: `package com.bizflow.app.domain.usecase

import com.bizflow.app.domain.model.DashboardKpis
import com.bizflow.app.domain.repository.InvoiceRepository
import com.bizflow.app.domain.repository.ProductRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import javax.inject.Inject

class GetDashboardKpisUseCase @Inject constructor(
    private val invoiceRepository: InvoiceRepository,
    private val productRepository: ProductRepository
) {
    operator fun invoke(): Flow<DashboardKpis> = combine(
        invoiceRepository.observeTotalPaidRevenue(),
        invoiceRepository.observePendingInvoiceCount(),
        productRepository.observeLowStockProducts(),
        invoiceRepository.observeRecentActivity()
    ) { revenue, pendingCount, lowStock, activities ->
        DashboardKpis(
            totalRevenue = revenue,
            pendingInvoicesCount = pendingCount,
            lowStockAlertCount = lowStock.size,
            lowStockProducts = lowStock,
            recentActivities = activities
        )
    }
}
`,
  },
  {
    path: 'app/src/main/java/com/bizflow/app/domain/usecase/CreateInvoiceUseCase.kt',
    packageGroup: 'Domain Layer',
    language: 'kotlin',
    description: 'Calculates subtotal, tax, and grand total before persisting an invoice atomically.',
    content: `package com.bizflow.app.domain.usecase

import com.bizflow.app.domain.model.Client
import com.bizflow.app.domain.model.Invoice
import com.bizflow.app.domain.model.InvoiceLineItem
import com.bizflow.app.domain.model.InvoiceStatus
import com.bizflow.app.domain.repository.InvoiceRepository
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.inject.Inject
import kotlin.math.roundToInt

class CreateInvoiceUseCase @Inject constructor(
    private val invoiceRepository: InvoiceRepository
) {
    suspend operator fun invoke(
        client: Client,
        items: List<InvoiceLineItem>,
        taxRatePercent: Double,
        status: InvoiceStatus,
        notes: String
    ): Invoice {
        require(items.isNotEmpty()) { "At least one line item is required." }

        val subtotal = items.sumOf { it.unitPrice * it.quantity }
        val taxAmount = ((subtotal * (taxRatePercent / 100.0)) * 100.0).roundToInt() / 100.0
        val total = ((subtotal + taxAmount) * 100.0).roundToInt() / 100.0

        val stamp = SimpleDateFormat("yyMMdd-HHmm", Locale.US).format(Date())
        val invoice = Invoice(
            invoiceNumber = "INV-$stamp",
            clientId = client.id,
            clientName = client.name,
            clientCompany = client.company,
            clientEmail = client.email,
            clientPhone = client.phone,
            items = items,
            subtotal = subtotal,
            taxRatePercent = taxRatePercent,
            taxAmount = taxAmount,
            totalAmount = total,
            status = status,
            notes = notes
        )

        val generatedId = invoiceRepository.createInvoice(invoice)
        return invoice.copy(id = generatedId)
    }
}
`,
  },
  {
    path: 'app/src/main/java/com/bizflow/app/di/DatabaseModule.kt',
    packageGroup: 'DI (Hilt)',
    language: 'kotlin',
    description: 'Hilt SingletonComponent module providing BizFlowDatabase and all DAOs.',
    content: `package com.bizflow.app.di

import android.content.Context
import androidx.room.Room
import com.bizflow.app.data.local.BizFlowDatabase
import com.bizflow.app.data.local.dao.ActivityLogDao
import com.bizflow.app.data.local.dao.ClientDao
import com.bizflow.app.data.local.dao.InvoiceDao
import com.bizflow.app.data.local.dao.ProductDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideBizFlowDatabase(
        @ApplicationContext context: Context
    ): BizFlowDatabase = Room.databaseBuilder(
        context,
        BizFlowDatabase::class.java,
        "bizflow_offline.db"
    )
        .fallbackToDestructiveMigration()
        .build()

    @Provides
    fun provideProductDao(db: BizFlowDatabase): ProductDao = db.productDao()

    @Provides
    fun provideClientDao(db: BizFlowDatabase): ClientDao = db.clientDao()

    @Provides
    fun provideInvoiceDao(db: BizFlowDatabase): InvoiceDao = db.invoiceDao()

    @Provides
    fun provideActivityLogDao(db: BizFlowDatabase): ActivityLogDao = db.activityLogDao()
}
`,
  },
  {
    path: 'app/src/main/java/com/bizflow/app/di/RepositoryModule.kt',
    packageGroup: 'DI (Hilt)',
    language: 'kotlin',
    description: 'Hilt module binding Repository implementations to Domain interfaces.',
    content: `package com.bizflow.app.di

import com.bizflow.app.data.repository.ClientRepositoryImpl
import com.bizflow.app.data.repository.InvoiceRepositoryImpl
import com.bizflow.app.data.repository.ProductRepositoryImpl
import com.bizflow.app.domain.repository.ClientRepository
import com.bizflow.app.domain.repository.InvoiceRepository
import com.bizflow.app.domain.repository.ProductRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    @Singleton
    abstract fun bindProductRepository(impl: ProductRepositoryImpl): ProductRepository

    @Binds
    @Singleton
    abstract fun bindClientRepository(impl: ClientRepositoryImpl): ClientRepository

    @Binds
    @Singleton
    abstract fun bindInvoiceRepository(impl: InvoiceRepositoryImpl): InvoiceRepository
}
`,
  },
  {
    path: 'app/src/main/java/com/bizflow/app/util/InvoicePdfGenerator.kt',
    packageGroup: 'Utilities (PDF & Biometric)',
    language: 'kotlin',
    description: 'Generates an A4 PDF invoice via android.graphics.pdf.PdfDocument and shares it using FileProvider.',
    content: `package com.bizflow.app.util

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.bizflow.app.domain.model.Invoice
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class InvoicePdfGenerator @Inject constructor(
    @ApplicationContext private val context: Context
) {
    fun generateAndSharePdf(invoice: Invoice, businessName: String = "BizFlow Business") {
        val pdfFile = createPdfFile(invoice, businessName)
        val uri = FileProvider.getUriForFile(
            context,
            "\${context.packageName}.fileprovider",
            pdfFile
        )

        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "Invoice \${invoice.invoiceNumber}")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        val chooser = Intent.createChooser(shareIntent, "Share Invoice PDF").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    }

    fun createPdfFile(invoice: Invoice, businessName: String): File {
        val document = PdfDocument()
        // Standard A4 @ 72 DPI: 595 x 842
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas

        val margin = 44f
        val rightEdge = 595f - margin
        var y = 56f

        val titlePaint = Paint().apply {
            color = Color.parseColor("#0F172A")
            textSize = 20f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        val accentPaint = Paint().apply {
            color = Color.parseColor("#0F766E")
            textSize = 22f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        val bodyPaint = Paint().apply {
            color = Color.parseColor("#334155")
            textSize = 11f
            isAntiAlias = true
        }
        val boldBodyPaint = Paint(bodyPaint).apply {
            color = Color.parseColor("#0F172A")
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val mutedPaint = Paint().apply {
            color = Color.parseColor("#64748B")
            textSize = 9.5f
            isAntiAlias = true
        }
        val dividerPaint = Paint().apply {
            color = Color.parseColor("#CBD5E1")
            strokeWidth = 1f
        }

        // Header
        canvas.drawText(businessName, margin, y, titlePaint)
        canvas.drawText("INVOICE", rightEdge, y, accentPaint)

        y += 20f
        val statusPaint = Paint(boldBodyPaint).apply {
            textAlign = Paint.Align.RIGHT
            color = if (invoice.status.name == "PAID") {
                Color.parseColor("#16A34A")
            } else {
                Color.parseColor("#D97706")
            }
        }
        canvas.drawText("Invoice #: \${invoice.invoiceNumber}", margin, y, mutedPaint)
        canvas.drawText("STATUS: \${invoice.status.label.uppercase()}", rightEdge, y, statusPaint)

        y += 18f
        canvas.drawLine(margin, y, rightEdge, y, dividerPaint)

        // Client & Dates
        y += 24f
        val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.US)
        canvas.drawText("BILL TO", margin, y, mutedPaint)
        canvas.drawText("Issued: \${dateFormat.format(Date(invoice.issuedAtMillis))}", rightEdge - 140f, y, mutedPaint)

        y += 16f
        canvas.drawText(invoice.clientName, margin, y, boldBodyPaint)
        canvas.drawText("Due: \${dateFormat.format(Date(invoice.dueDateMillis))}", rightEdge - 140f, y, mutedPaint)

        if (invoice.clientCompany.isNotBlank()) {
            y += 15f
            canvas.drawText(invoice.clientCompany, margin, y, bodyPaint)
        }
        y += 15f
        canvas.drawText("\${invoice.clientEmail} · \${invoice.clientPhone}", margin, y, bodyPaint)

        // Line items header
        y += 32f
        val headerBgPaint = Paint().apply { color = Color.parseColor("#F1F5F9") }
        canvas.drawRect(margin, y - 14f, rightEdge, y + 10f, headerBgPaint)

        canvas.drawText("ITEM / SKU", margin + 6f, y, boldBodyPaint)
        canvas.drawText("QTY", rightEdge - 145f, y, boldBodyPaint)
        canvas.drawText("PRICE", rightEdge - 90f, y, boldBodyPaint)
        canvas.drawText("TOTAL", rightEdge - 40f, y, boldBodyPaint)

        y += 24f
        invoice.items.forEach { item ->
            canvas.drawText(item.productName.take(36), margin + 6f, y, boldBodyPaint)
            canvas.drawText(item.quantity.toString(), rightEdge - 145f, y, bodyPaint)
            canvas.drawText("$\${"%.2f".format(item.unitPrice)}", rightEdge - 90f, y, bodyPaint)
            canvas.drawText("$\${"%.2f".format(item.lineTotal)}", rightEdge - 40f, y, boldBodyPaint)

            y += 13f
            canvas.drawText("SKU: \${item.sku}", margin + 6f, y, mutedPaint)
            y += 12f
            canvas.drawLine(margin, y, rightEdge, y, dividerPaint)
            y += 16f
        }

        // Totals
        y += 12f
        val labelX = rightEdge - 165f
        val rightValPaint = Paint(bodyPaint).apply { textAlign = Paint.Align.RIGHT }
        val rightBoldPaint = Paint(boldBodyPaint).apply {
            textAlign = Paint.Align.RIGHT
            textSize = 13f
            color = Color.parseColor("#0F766E")
        }

        canvas.drawText("Subtotal", labelX, y, bodyPaint)
        canvas.drawText("$\${"%.2f".format(invoice.subtotal)}", rightEdge, y, rightValPaint)

        y += 18f
        canvas.drawText("Tax (\${"%.1f".format(invoice.taxRatePercent)}%)", labelX, y, bodyPaint)
        canvas.drawText("$\${"%.2f".format(invoice.taxAmount)}", rightEdge, y, rightValPaint)

        y += 12f
        canvas.drawLine(labelX, y, rightEdge, y, dividerPaint)

        y += 22f
        canvas.drawText("Grand Total", labelX, y, boldBodyPaint)
        canvas.drawText("$\${"%.2f".format(invoice.totalAmount)}", rightEdge, y, rightBoldPaint)

        if (invoice.notes.isNotBlank()) {
            y += 40f
            canvas.drawText("NOTES", margin, y, mutedPaint)
            y += 15f
            canvas.drawText(invoice.notes, margin, y, bodyPaint)
        }

        document.finishPage(page)

        val invoiceDir = File(context.cacheDir, "invoices").apply { mkdirs() }
        val outFile = File(invoiceDir, "\${invoice.invoiceNumber}.pdf")
        FileOutputStream(outFile).use { stream ->
            document.writeTo(stream)
        }
        document.close()
        return outFile
    }
}
`,
  },
  {
    path: 'app/src/main/java/com/bizflow/app/util/BiometricAuthHelper.kt',
    packageGroup: 'Utilities (PDF & Biometric)',
    language: 'kotlin',
    description: 'Wraps androidx.biometric.BiometricPrompt with hardware fingerprint/face + device credential fallback.',
    content: `package com.bizflow.app.util

import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

object BiometricAuthHelper {

    fun canAuthenticate(activity: FragmentActivity): Boolean {
        val manager = BiometricManager.from(activity)
        val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG or
            BiometricManager.Authenticators.DEVICE_CREDENTIAL
        return manager.canAuthenticate(authenticators) == BiometricManager.BIOMETRIC_SUCCESS
    }

    fun authenticate(
        activity: FragmentActivity,
        title: String = "Unlock BizFlow",
        subtitle: String = "Verify your identity to access business records",
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        val executor = ContextCompat.getMainExecutor(activity)
        val callback = object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                super.onAuthenticationSucceeded(result)
                onSuccess()
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                super.onAuthenticationError(errorCode, errString)
                onError(errString.toString())
            }

            override fun onAuthenticationFailed() {
                super.onAuthenticationFailed()
                onError("Biometric recognition failed. Try again.")
            }
        }

        val prompt = BiometricPrompt(activity, executor, callback)
        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setSubtitle(subtitle)
            .setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_STRONG or
                    BiometricManager.Authenticators.DEVICE_CREDENTIAL
            )
            .build()

        prompt.authenticate(promptInfo)
    }
}
`,
  },
];
