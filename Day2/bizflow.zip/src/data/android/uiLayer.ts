import { AndroidProjectFile } from '../../types/bizflow';

export const UI_LAYER_FILES: AndroidProjectFile[] = [
  {
    path: 'app/src/main/java/com/bizflow/app/BizFlowApplication.kt',
    packageGroup: 'UI Theme & Navigation',
    language: 'kotlin',
    description: 'Hilt Application entry point.',
    content: `package com.bizflow.app

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class BizFlowApplication : Application()
`,
  },
  {
    path: 'app/src/main/java/com/bizflow/app/MainActivity.kt',
    packageGroup: 'UI Theme & Navigation',
    language: 'kotlin',
    description: 'FragmentActivity host enabling BiometricPrompt and edge-to-edge Jetpack Compose navigation.',
    content: `package com.bizflow.app

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.fragment.app.FragmentActivity
import com.bizflow.app.ui.components.BiometricLockScreen
import com.bizflow.app.ui.navigation.BizFlowNavGraph
import com.bizflow.app.ui.theme.BizFlowTheme
import com.bizflow.app.util.BiometricAuthHelper
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            BizFlowTheme {
                var biometricLockEnabled by rememberSaveable { mutableStateOf(false) }
                var isUnlocked by rememberSaveable { mutableStateOf(true) }
                var authError by rememberSaveable { mutableStateOf<String?>(null) }

                if (biometricLockEnabled && !isUnlocked) {
                    BiometricLockScreen(
                        errorMessage = authError,
                        onUnlockClick = {
                            if (BiometricAuthHelper.canAuthenticate(this)) {
                                BiometricAuthHelper.authenticate(
                                    activity = this,
                                    onSuccess = {
                                        authError = null
                                        isUnlocked = true
                                    },
                                    onError = { message -> authError = message }
                                )
                            } else {
                                authError = "No biometric or device PIN configured on this phone."
                            }
                        }
                    )
                } else {
                    BizFlowNavGraph(
                        biometricLockEnabled = biometricLockEnabled,
                        onToggleBiometricLock = { enabled ->
                            biometricLockEnabled = enabled
                            if (enabled) isUnlocked = false
                        },
                        onLockNow = {
                            if (biometricLockEnabled) isUnlocked = false
                        }
                    )
                }
            }
        }
    }
}
`,
  },
  {
    path: 'app/src/main/java/com/bizflow/app/ui/theme/Theme.kt',
    packageGroup: 'UI Theme & Navigation',
    language: 'kotlin',
    description: 'Material Design 3 color scheme and typography for BizFlow.',
    content: `package com.bizflow.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val TealPrimary = Color(0xFF0F766E)
val TealContainer = Color(0xFFCCFBF1)
val SlateSurface = Color(0xFFF8FAFC)
val SlateOutline = Color(0xFFE2E8F0)
val AmberWarning = Color(0xFFD97706)
val AmberContainer = Color(0xFFFEF3C7)
val EmeraldSuccess = Color(0xFF16A34A)
val CrimsonAlert = Color(0xFFDC2626)

private val LightColors = lightColorScheme(
    primary = TealPrimary,
    onPrimary = Color.White,
    primaryContainer = TealContainer,
    onPrimaryContainer = Color(0xFF134E4A),
    background = SlateSurface,
    onBackground = Color(0xFF0F172A),
    surface = Color.White,
    onSurface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFFF1F5F9),
    onSurfaceVariant = Color(0xFF475569),
    outline = SlateOutline
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF2DD4BF),
    onPrimary = Color(0xFF042F2E),
    background = Color(0xFF0F172A),
    onBackground = Color(0xFFF8FAFC),
    surface = Color(0xFF1E293B),
    onSurface = Color(0xFFF8FAFC),
    outline = Color(0xFF334155)
)

@Composable
fun BizFlowTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content
    )
}
`,
  },
  {
    path: 'app/src/main/java/com/bizflow/app/ui/components/SharedComponents.kt',
    packageGroup: 'UI Screens & Components',
    language: 'kotlin',
    description: 'Reusable Material 3 KPI cards, low-stock warning badges, and BiometricLockScreen.',
    content: `package com.bizflow.app.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Fingerprint
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.bizflow.app.ui.theme.AmberContainer
import com.bizflow.app.ui.theme.AmberWarning
import com.bizflow.app.ui.theme.CrimsonAlert

@Composable
fun KpiCard(
    label: String,
    value: String,
    supportingText: String,
    modifier: Modifier = Modifier,
    accentColor: Color = MaterialTheme.colorScheme.onSurface
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = accentColor
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = supportingText,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun LowStockBadge(stockQuantity: Int, threshold: Int) {
    if (stockQuantity > threshold) return
    val isOut = stockQuantity <= 0
    val container = if (isOut) Color(0xFFFEE2E2) else AmberContainer
    val content = if (isOut) CrimsonAlert else AmberWarning
    val text = if (isOut) "Out of Stock" else "Low Stock ($stockQuantity)"

    Surface(
        color = container,
        shape = MaterialTheme.shapes.small
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Outlined.WarningAmber,
                contentDescription = null,
                tint = content,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.SemiBold,
                color = content
            )
        }
    }
}

@Composable
fun BiometricLockScreen(
    errorMessage: String?,
    onUnlockClick: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Outlined.Fingerprint,
                contentDescription = "Biometric Lock",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(64.dp)
            )
            Spacer(modifier = Modifier.height(20.dp))
            Text(
                text = "BizFlow Locked",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Authenticate with fingerprint, face, or device PIN to access customer and invoice records.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (errorMessage != null) {
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = errorMessage,
                    style = MaterialTheme.typography.bodySmall,
                    color = CrimsonAlert
                )
            }
            Spacer(modifier = Modifier.height(24.dp))
            Button(
                onClick = onUnlockClick,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Unlock BizFlow")
            }
        }
    }
}
`,
  },
  {
    path: 'app/src/main/java/com/bizflow/app/ui/navigation/BizFlowNavGraph.kt',
    packageGroup: 'UI Theme & Navigation',
    language: 'kotlin',
    description: 'Material 3 Scaffold with Bottom NavigationBar connecting Dashboard, Inventory, Clients, and Invoices.',
    content: `package com.bizflow.app.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.People
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.bizflow.app.ui.screens.clients.ClientsScreen
import com.bizflow.app.ui.screens.dashboard.DashboardScreen
import com.bizflow.app.ui.screens.inventory.InventoryScreen
import com.bizflow.app.ui.screens.invoices.InvoicesScreen

sealed class BizFlowDestination(
    val route: String,
    val label: String,
    val icon: ImageVector
) {
    data object Dashboard : BizFlowDestination("dashboard", "Dashboard", Icons.Outlined.Dashboard)
    data object Inventory : BizFlowDestination("inventory", "Inventory", Icons.Outlined.Inventory2)
    data object Clients : BizFlowDestination("clients", "Clients", Icons.Outlined.People)
    data object Invoices : BizFlowDestination("invoices", "Invoices", Icons.Outlined.ReceiptLong)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BizFlowNavGraph(
    biometricLockEnabled: Boolean,
    onToggleBiometricLock: (Boolean) -> Unit,
    onLockNow: () -> Unit
) {
    val navController = rememberNavController()
    val destinations = listOf(
        BizFlowDestination.Dashboard,
        BizFlowDestination.Inventory,
        BizFlowDestination.Clients,
        BizFlowDestination.Invoices
    )
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("BizFlow") },
                actions = {
                    if (biometricLockEnabled) {
                        IconButton(onClick = onLockNow) {
                            Icon(Icons.Outlined.Lock, contentDescription = "Lock App")
                        }
                    }
                    Switch(
                        checked = biometricLockEnabled,
                        onCheckedChange = onToggleBiometricLock
                    )
                }
            )
        },
        bottomBar = {
            NavigationBar {
                destinations.forEach { destination ->
                    NavigationBarItem(
                        selected = currentRoute == destination.route,
                        onClick = {
                            navController.navigate(destination.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(destination.icon, contentDescription = destination.label) },
                        label = { Text(destination.label) }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = BizFlowDestination.Dashboard.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(BizFlowDestination.Dashboard.route) { DashboardScreen() }
            composable(BizFlowDestination.Inventory.route) { InventoryScreen() }
            composable(BizFlowDestination.Clients.route) { ClientsScreen() }
            composable(BizFlowDestination.Invoices.route) { InvoicesScreen() }
        }
    }
}
`,
  },
  {
    path: 'app/src/main/java/com/bizflow/app/ui/screens/dashboard/DashboardScreen.kt',
    packageGroup: 'UI Screens & Components',
    language: 'kotlin',
    description: 'Dashboard ViewModel and Jetpack Compose screen displaying live KPIs, low-stock alerts, and recent activity feed.',
    content: `package com.bizflow.app.ui.screens.dashboard

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.bizflow.app.domain.model.DashboardKpis
import com.bizflow.app.domain.usecase.GetDashboardKpisUseCase
import com.bizflow.app.ui.components.KpiCard
import com.bizflow.app.ui.components.LowStockBadge
import com.bizflow.app.ui.theme.AmberWarning
import com.bizflow.app.ui.theme.TealPrimary
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

@HiltViewModel
class DashboardViewModel @Inject constructor(
    getDashboardKpisUseCase: GetDashboardKpisUseCase
) : ViewModel() {
    val kpis: StateFlow<DashboardKpis> = getDashboardKpisUseCase()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = DashboardKpis()
        )
}

@Composable
fun DashboardScreen(
    viewModel: DashboardViewModel = hiltViewModel()
) {
    val kpis by viewModel.kpis.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Business Overview",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                KpiCard(
                    label = "Total Revenue",
                    value = "$\${"%.2f".format(kpis.totalRevenue)}",
                    supportingText = "Paid invoices",
                    accentColor = TealPrimary,
                    modifier = Modifier.weight(1f)
                )
                KpiCard(
                    label = "Pending Invoices",
                    value = kpis.pendingInvoicesCount.toString(),
                    supportingText = "Awaiting payment",
                    accentColor = AmberWarning,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            KpiCard(
                label = "Low Stock Alerts",
                value = kpis.lowStockAlertCount.toString(),
                supportingText = "Items at or below reorder threshold",
                modifier = Modifier.fillMaxWidth()
            )
        }

        if (kpis.lowStockProducts.isNotEmpty()) {
            item {
                Text(
                    text = "Restock Priority",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }
            items(kpis.lowStockProducts, key = { it.id }) { product ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(product.name, fontWeight = FontWeight.Medium)
                        Text(
                            "SKU: \${product.sku}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    LowStockBadge(product.stockQuantity, product.lowStockThreshold)
                }
                HorizontalDivider()
            }
        }

        item {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Recent Activity",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
        }

        if (kpis.recentActivities.isEmpty()) {
            item {
                Text(
                    text = "No offline activity logged yet. Add inventory or issue an invoice to begin.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            items(kpis.recentActivities, key = { it.id }) { entry ->
                Column(modifier = Modifier.padding(vertical = 6.dp)) {
                    Text(entry.title, fontWeight = FontWeight.Medium)
                    Text(
                        entry.detail,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                HorizontalDivider()
            }
        }
    }
}
`,
  },
  {
    path: 'app/src/main/java/com/bizflow/app/ui/screens/inventory/InventoryScreen.kt',
    packageGroup: 'UI Screens & Components',
    language: 'kotlin',
    description: 'Inventory ViewModel and Compose screen supporting full CRUD, SKU tracking, and automatic low-stock badges.',
    content: `package com.bizflow.app.ui.screens.inventory

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.bizflow.app.domain.model.Product
import com.bizflow.app.domain.repository.ProductRepository
import com.bizflow.app.ui.components.LowStockBadge
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class InventoryViewModel @Inject constructor(
    private val productRepository: ProductRepository
) : ViewModel() {
    val products: StateFlow<List<Product>> = productRepository.observeProducts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun saveProduct(product: Product) {
        viewModelScope.launch { productRepository.saveProduct(product) }
    }

    fun deleteProduct(product: Product) {
        viewModelScope.launch { productRepository.deleteProduct(product) }
    }
}

@Composable
fun InventoryScreen(viewModel: InventoryViewModel = hiltViewModel()) {
    val products by viewModel.products.collectAsStateWithLifecycle()
    var editingProduct by remember { mutableStateOf<Product?>(null) }
    var showDialog by remember { mutableStateOf(false) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    editingProduct = null
                    showDialog = true
                }
            ) {
                Icon(Icons.Outlined.Add, contentDescription = "Add Product")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                Text(
                    text = "Inventory (\${products.size} SKUs)",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            }
            items(products, key = { it.id }) { product ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(product.name, fontWeight = FontWeight.SemiBold)
                        Text(
                            "SKU: \${product.sku} · $\${"%.2f".format(product.unitPrice)} · Stock: \${product.stockQuantity}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        LowStockBadge(product.stockQuantity, product.lowStockThreshold)
                    }
                    IconButton(onClick = {
                        editingProduct = product
                        showDialog = true
                    }) {
                        Icon(Icons.Outlined.Edit, contentDescription = "Edit")
                    }
                    IconButton(onClick = { viewModel.deleteProduct(product) }) {
                        Icon(Icons.Outlined.Delete, contentDescription = "Delete")
                    }
                }
                HorizontalDivider()
            }
        }
    }

    if (showDialog) {
        ProductEditorDialog(
            initial = editingProduct,
            onDismiss = { showDialog = false },
            onSave = { product ->
                viewModel.saveProduct(product)
                showDialog = false
            }
        )
    }
}

@Composable
private fun ProductEditorDialog(
    initial: Product?,
    onDismiss: () -> Unit,
    onSave: (Product) -> Unit
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var sku by remember { mutableStateOf(initial?.sku ?: "") }
    var category by remember { mutableStateOf(initial?.category ?: "General") }
    var price by remember { mutableStateOf(initial?.unitPrice?.toString() ?: "") }
    var stock by remember { mutableStateOf(initial?.stockQuantity?.toString() ?: "0") }
    var threshold by remember { mutableStateOf(initial?.lowStockThreshold?.toString() ?: "5") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Add Inventory Item" else "Edit Product") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Product Name") })
                OutlinedTextField(value = sku, onValueChange = { sku = it }, label = { Text("SKU") })
                OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Category") })
                OutlinedTextField(value = price, onValueChange = { price = it }, label = { Text("Unit Price ($)") })
                OutlinedTextField(value = stock, onValueChange = { stock = it }, label = { Text("Stock Quantity") })
                OutlinedTextField(value = threshold, onValueChange = { threshold = it }, label = { Text("Low Stock Alert At") })
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    if (name.isNotBlank() && sku.isNotBlank()) {
                        onSave(
                            Product(
                                id = initial?.id ?: 0L,
                                name = name.trim(),
                                sku = sku.trim(),
                                category = category.trim(),
                                unitPrice = price.toDoubleOrNull() ?: 0.0,
                                stockQuantity = stock.toIntOrNull() ?: 0,
                                lowStockThreshold = threshold.toIntOrNull() ?: 5
                            )
                        )
                    }
                }
            ) { Text("Save") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
`,
  },
  {
    path: 'app/src/main/java/com/bizflow/app/ui/screens/clients/ClientsScreen.kt',
    packageGroup: 'UI Screens & Components',
    language: 'kotlin',
    description: 'Client CRM ViewModel and Compose screen with live search and one-tap ACTION_DIAL / ACTION_SENDTO intents.',
    content: `package com.bizflow.app.ui.screens.clients

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Call
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.bizflow.app.domain.model.Client
import com.bizflow.app.domain.repository.ClientRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ClientsViewModel @Inject constructor(
    private val clientRepository: ClientRepository
) : ViewModel() {
    val searchQuery = MutableStateFlow("")

    @OptIn(ExperimentalCoroutinesApi::class)
    val clients: StateFlow<List<Client>> = searchQuery
        .flatMapLatest { query -> clientRepository.observeClients(query) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun saveClient(client: Client) {
        viewModelScope.launch { clientRepository.saveClient(client) }
    }
}

@Composable
fun ClientsScreen(viewModel: ClientsViewModel = hiltViewModel()) {
    val clients by viewModel.clients.collectAsStateWithLifecycle()
    val query by viewModel.searchQuery.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var showAddDialog by remember { mutableStateOf(false) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddDialog = true }) {
                Icon(Icons.Outlined.Add, contentDescription = "Add Client")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = { viewModel.searchQuery.value = it },
                modifier = Modifier.fillMaxWidth(),
                leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
                placeholder = { Text("Search clients by name, company, or email") },
                singleLine = true
            )

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(top = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(clients, key = { it.id }) { client ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(client.name, fontWeight = FontWeight.SemiBold)
                            Text(
                                "\${client.company} · \${client.phone}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(
                            onClick = {
                                val dialIntent = Intent(
                                    Intent.ACTION_DIAL,
                                    Uri.parse("tel:\${client.phone}")
                                )
                                context.startActivity(dialIntent)
                            }
                        ) {
                            Icon(Icons.Outlined.Call, contentDescription = "Call Client")
                        }
                        IconButton(
                            onClick = {
                                val emailIntent = Intent(
                                    Intent.ACTION_SENDTO,
                                    Uri.parse("mailto:\${client.email}")
                                )
                                context.startActivity(emailIntent)
                            }
                        ) {
                            Icon(Icons.Outlined.Email, contentDescription = "Email Client")
                        }
                    }
                    HorizontalDivider()
                }
            }
        }
    }

    if (showAddDialog) {
        AddClientDialog(
            onDismiss = { showAddDialog = false },
            onSave = { client ->
                viewModel.saveClient(client)
                showAddDialog = false
            }
        )
    }
}

@Composable
private fun AddClientDialog(
    onDismiss: () -> Unit,
    onSave: (Client) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var company by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Client") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Full Name") })
                OutlinedTextField(value = company, onValueChange = { company = it }, label = { Text("Company") })
                OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Phone") })
                OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email") })
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    if (name.isNotBlank()) {
                        onSave(
                            Client(
                                name = name.trim(),
                                company = company.trim(),
                                phone = phone.trim(),
                                email = email.trim()
                            )
                        )
                    }
                }
            ) { Text("Save") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
`,
  },
  {
    path: 'app/src/main/java/com/bizflow/app/ui/screens/invoices/InvoicesScreen.kt',
    packageGroup: 'UI Screens & Components',
    language: 'kotlin',
    description: 'Invoice Generator ViewModel & Screen with multi-item selection, auto tax calculation, Paid/Unpaid toggle, and PDF export.',
    content: `package com.bizflow.app.ui.screens.invoices

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.PictureAsPdf
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.bizflow.app.domain.model.Client
import com.bizflow.app.domain.model.Invoice
import com.bizflow.app.domain.model.InvoiceLineItem
import com.bizflow.app.domain.model.InvoiceStatus
import com.bizflow.app.domain.model.Product
import com.bizflow.app.domain.repository.ClientRepository
import com.bizflow.app.domain.repository.InvoiceRepository
import com.bizflow.app.domain.repository.ProductRepository
import com.bizflow.app.domain.usecase.CreateInvoiceUseCase
import com.bizflow.app.util.InvoicePdfGenerator
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class InvoicesViewModel @Inject constructor(
    private val invoiceRepository: InvoiceRepository,
    clientRepository: ClientRepository,
    productRepository: ProductRepository,
    private val createInvoiceUseCase: CreateInvoiceUseCase,
    private val pdfGenerator: InvoicePdfGenerator
) : ViewModel() {

    val invoices: StateFlow<List<Invoice>> = invoiceRepository.observeInvoices()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val clients: StateFlow<List<Client>> = clientRepository.observeClients()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val products: StateFlow<List<Product>> = productRepository.observeProducts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun createInvoice(
        client: Client,
        items: List<InvoiceLineItem>,
        taxRate: Double,
        status: InvoiceStatus,
        notes: String
    ) {
        viewModelScope.launch {
            createInvoiceUseCase(client, items, taxRate, status, notes)
        }
    }

    fun toggleStatus(invoice: Invoice) {
        viewModelScope.launch {
            val next = if (invoice.status == InvoiceStatus.PAID) InvoiceStatus.UNPAID else InvoiceStatus.PAID
            invoiceRepository.toggleInvoiceStatus(invoice.id, next)
        }
    }

    fun exportPdf(invoice: Invoice) {
        pdfGenerator.generateAndSharePdf(invoice)
    }
}

@Composable
fun InvoicesScreen(viewModel: InvoicesViewModel = hiltViewModel()) {
    val invoices by viewModel.invoices.collectAsStateWithLifecycle()
    val clients by viewModel.clients.collectAsStateWithLifecycle()
    val products by viewModel.products.collectAsStateWithLifecycle()
    var showCreateDialog by remember { mutableStateOf(false) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { showCreateDialog = true }) {
                Icon(Icons.Outlined.Add, contentDescription = "Create Invoice")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                Text(
                    text = "Invoices (\${invoices.size})",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            }
            items(invoices, key = { it.id }) { invoice ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "\${invoice.invoiceNumber} · \${invoice.clientName}",
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            "$\${"%.2f".format(invoice.totalAmount)} · \${invoice.items.size} items · \${invoice.status.label}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    OutlinedButton(onClick = { viewModel.toggleStatus(invoice) }) {
                        Text(if (invoice.status == InvoiceStatus.PAID) "Mark Unpaid" else "Mark Paid")
                    }
                    IconButton(onClick = { viewModel.exportPdf(invoice) }) {
                        Icon(Icons.Outlined.PictureAsPdf, contentDescription = "Export PDF")
                    }
                }
                HorizontalDivider()
            }
        }
    }

    if (showCreateDialog && clients.isNotEmpty() && products.isNotEmpty()) {
        InvoiceBuilderDialog(
            clients = clients,
            products = products,
            onDismiss = { showCreateDialog = false },
            onCreate = { client, lineItems, status ->
                viewModel.createInvoice(client, lineItems, 8.5, status, "")
                showCreateDialog = false
            }
        )
    }
}

@Composable
private fun InvoiceBuilderDialog(
    clients: List<Client>,
    products: List<Product>,
    onDismiss: () -> Unit,
    onCreate: (Client, List<InvoiceLineItem>, InvoiceStatus) -> Unit
) {
    var selectedClient by remember { mutableStateOf(clients.first()) }
    var status by remember { mutableStateOf(InvoiceStatus.UNPAID) }
    val selectedQty = remember { mutableStateMapOf<Long, Int>() }

    val lineItems = products.mapNotNull { product ->
        val qty = selectedQty[product.id] ?: 0
        if (qty > 0) {
            InvoiceLineItem(
                productId = product.id,
                productName = product.name,
                sku = product.sku,
                unitPrice = product.unitPrice,
                quantity = qty
            )
        } else null
    }
    val subtotal = lineItems.sumOf { it.lineTotal }
    val totalWithTax = subtotal * 1.085

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New Invoice") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Client: \${selectedClient.name}", fontWeight = FontWeight.Medium)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    clients.take(3).forEach { client ->
                        FilterChip(
                            selected = selectedClient.id == client.id,
                            onClick = { selectedClient = client },
                            label = { Text(client.name.substringBefore(" ")) }
                        )
                    }
                }
                HorizontalDivider()
                products.take(4).forEach { product ->
                    val qty = selectedQty[product.id] ?: 0
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("\${product.name.take(20)} ($\${product.unitPrice})", modifier = Modifier.weight(1f))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TextButton(onClick = { if (qty > 0) selectedQty[product.id] = qty - 1 }) { Text("-") }
                            Text(qty.toString())
                            TextButton(onClick = { selectedQty[product.id] = qty + 1 }) { Text("+") }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = status == InvoiceStatus.UNPAID,
                        onClick = { status = InvoiceStatus.UNPAID },
                        label = { Text("Unpaid") }
                    )
                    FilterChip(
                        selected = status == InvoiceStatus.PAID,
                        onClick = { status = InvoiceStatus.PAID },
                        label = { Text("Paid") }
                    )
                }
                Text(
                    "Total (incl. 8.5% tax): $\${"%.2f".format(totalWithTax)}",
                    fontWeight = FontWeight.Bold
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = lineItems.isNotEmpty(),
                onClick = { onCreate(selectedClient, lineItems, status) }
            ) { Text("Create Invoice") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
`,
  },
];
