import { jsPDF } from 'jspdf';
import { BusinessSettings, Invoice } from '../types/bizflow';

export function exportInvoicePdf(invoice: Invoice, settings: BusinessSettings) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'pt',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const margin = 48;
  let y = 56;

  // Header band
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(20);
  doc.setTextColor(15, 23, 42);
  doc.text(settings.businessName || 'BizFlow Business', margin, y);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9.5);
  doc.setTextColor(100, 116, 139);
  doc.text(`${settings.businessEmail}  ·  ${settings.businessPhone}`, margin, y + 18);

  // Invoice title & status on right
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(22);
  doc.setTextColor(15, 118, 110);
  doc.text('INVOICE', pageWidth - margin, y, { align: 'right' });

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10.5);
  if (invoice.status === 'PAID') {
    doc.setTextColor(22, 163, 74);
  } else {
    doc.setTextColor(217, 119, 6);
  }
  doc.text(`STATUS: ${invoice.status}`, pageWidth - margin, y + 18, { align: 'right' });

  y += 42;
  doc.setDrawColor(226, 232, 240);
  doc.setLineWidth(1);
  doc.line(margin, y, pageWidth - margin, y);

  y += 28;

  // Bill To & Invoice Metadata
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(100, 116, 139);
  doc.text('BILL TO', margin, y);
  doc.text('INVOICE DETAILS', pageWidth - margin - 180, y);

  y += 16;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11.5);
  doc.setTextColor(15, 23, 42);
  doc.text(invoice.clientName, margin, y);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(51, 65, 85);
  if (invoice.clientCompany) {
    doc.text(invoice.clientCompany, margin, y + 15);
  }
  doc.text(invoice.clientEmail, margin, y + (invoice.clientCompany ? 30 : 15));
  doc.text(invoice.clientPhone, margin, y + (invoice.clientCompany ? 45 : 30));

  const metaXLabel = pageWidth - margin - 180;
  const metaXVal = pageWidth - margin;
  const issuedStr = new Date(invoice.issuedAt).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
  const dueStr = new Date(invoice.dueDate).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });

  doc.setFont('helvetica', 'bold');
  doc.text('Invoice #:', metaXLabel, y);
  doc.setFont('helvetica', 'normal');
  doc.text(invoice.invoiceNumber, metaXVal, y, { align: 'right' });

  doc.setFont('helvetica', 'bold');
  doc.text('Issued:', metaXLabel, y + 16);
  doc.setFont('helvetica', 'normal');
  doc.text(issuedStr, metaXVal, y + 16, { align: 'right' });

  doc.setFont('helvetica', 'bold');
  doc.text('Due Date:', metaXLabel, y + 32);
  doc.setFont('helvetica', 'normal');
  doc.text(dueStr, metaXVal, y + 32, { align: 'right' });

  y += 76;

  // Table header
  doc.setFillColor(248, 250, 252);
  doc.rect(margin, y, pageWidth - margin * 2, 26, 'F');
  doc.setDrawColor(226, 232, 240);
  doc.line(margin, y, pageWidth - margin, y);
  doc.line(margin, y + 26, pageWidth - margin, y + 26);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(71, 85, 105);
  doc.text('ITEM / SKU', margin + 8, y + 17);
  doc.text('QTY', pageWidth - margin - 170, y + 17, { align: 'right' });
  doc.text('UNIT PRICE', pageWidth - margin - 90, y + 17, { align: 'right' });
  doc.text('AMOUNT', pageWidth - margin - 8, y + 17, { align: 'right' });

  y += 26;

  // Line items
  invoice.items.forEach((item) => {
    y += 26;
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(15, 23, 42);
    doc.text(item.productName, margin + 8, y - 4);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.setTextColor(100, 116, 139);
    doc.text(`SKU: ${item.sku}`, margin + 8, y + 8);

    doc.setFontSize(10);
    doc.setTextColor(51, 65, 85);
    doc.text(String(item.quantity), pageWidth - margin - 170, y, { align: 'right' });
    doc.text(`$${item.unitPrice.toFixed(2)}`, pageWidth - margin - 90, y, {
      align: 'right',
    });

    doc.setFont('helvetica', 'bold');
    doc.setTextColor(15, 23, 42);
    doc.text(
      `$${(item.unitPrice * item.quantity).toFixed(2)}`,
      pageWidth - margin - 8,
      y,
      { align: 'right' }
    );

    y += 14;
    doc.setDrawColor(241, 245, 249);
    doc.line(margin, y, pageWidth - margin, y);
  });

  // Totals block
  y += 28;
  const totalsLabelX = pageWidth - margin - 160;
  const totalsValX = pageWidth - margin - 8;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(71, 85, 105);
  doc.text('Subtotal', totalsLabelX, y);
  doc.text(`$${invoice.subtotal.toFixed(2)}`, totalsValX, y, { align: 'right' });

  y += 18;
  doc.text(`Tax (${invoice.taxRatePercent.toFixed(1)}%)`, totalsLabelX, y);
  doc.text(`$${invoice.taxAmount.toFixed(2)}`, totalsValX, y, { align: 'right' });

  y += 12;
  doc.setDrawColor(203, 213, 225);
  doc.line(totalsLabelX, y, pageWidth - margin, y);

  y += 22;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(13);
  doc.setTextColor(15, 23, 42);
  doc.text('Total', totalsLabelX, y);
  doc.setTextColor(15, 118, 110);
  doc.text(`$${invoice.totalAmount.toFixed(2)}`, totalsValX, y, { align: 'right' });

  if (invoice.notes) {
    y += 46;
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(100, 116, 139);
    doc.text('NOTES', margin, y);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9.5);
    doc.setTextColor(71, 85, 105);
    doc.text(invoice.notes, margin, y + 15, { maxWidth: pageWidth - margin * 2 });
  }

  // Footer
  const pageHeight = doc.internal.pageSize.getHeight();
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(148, 163, 184);
  doc.text(
    `Generated offline by BizFlow · ${settings.businessName}`,
    pageWidth / 2,
    pageHeight - 32,
    { align: 'center' }
  );

  doc.save(`${invoice.invoiceNumber}.pdf`);
}
