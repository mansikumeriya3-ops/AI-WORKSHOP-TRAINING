import JSZip from 'jszip';
import { ANDROID_PROJECT_FILES } from '../data/androidProjectFiles';

export async function downloadAndroidProjectZip() {
  const zip = new JSZip();
  const root = zip.folder('BizFlow-Android');
  if (!root) return;

  ANDROID_PROJECT_FILES.forEach((file) => {
    root.file(file.path, file.content);
  });

  // Include concise README with build instructions inside the zip
  root.file(
    'README.md',
    `# BizFlow — Offline-First Android Business Application

## Tech Stack
- Kotlin + Jetpack Compose (Material Design 3)
- Android SDK 35 (minSdk 26, targetSdk 35)
- MVVM + Clean Architecture (data / domain / ui / di)
- Room Database (offline-first SQLite persistence)
- Dagger Hilt Dependency Injection
- Android PdfDocument + FileProvider for PDF invoicing
- AndroidX BiometricPrompt lock screen

## How to Open & Build APK in Android Studio
1. Unzip \`BizFlow-Android\` and open the folder in Android Studio (Ladybug or newer).
2. Wait for Gradle Sync to download dependencies and configure SDK 35.
3. Connect your Android phone via USB (with USB Debugging enabled) or open Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Locate \`app/build/outputs/apk/debug/app-debug.apk\` and install on your Android device.
`
  );

  const blob = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = 'BizFlow-Android-Studio-Project.zip';
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  URL.revokeObjectURL(url);
}
