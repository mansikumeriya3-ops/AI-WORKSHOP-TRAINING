import React from 'react';
import {
  AlertTriangle,
  ArrowUpRight,
  FileText,
  Package,
  Plus,
  Users,
} from 'lucide-react';
import { ActivityEntry, NavDestination, Product } from '../types/bizflow';

interface DashboardViewProps {
  kpis: {
    totalRevenue: number;
    pendingCount: number;
    pendingAmount: number;
    lowStockCount: number;
    lowStockProducts: Product[];
    clientCount: number;
  };
  activities: ActivityEntry[];
  onNavigate: (dest: NavDestination) => void;
  onQuickNewInvoice: () => void;
}

function formatCurrency(val: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(val);
}

function formatRelativeTime(iso: string): string {
  const diffMs = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return 'Just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  return `${days}d ago`;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  kpis,
  activities,
  onNavigate,
  onQuickNewInvoice,
}) => {
  return (
    <div className="space-y-8">
      {/* Header & Primary Action */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl">
            Business Overview
          </h1>
          <p className="mt-1 text-sm text-slate-500">
            Real-time offline ledger · Stored locally on device
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => onNavigate('android-code')}
            className="inline-flex min-h-[40px] items-center gap-2 rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-700 transition-colors hover:bg-slate-50 whitespace-nowrap shrink-0"
          >
            <span>Android APK Code</span>
            <ArrowUpRight className="h-4 w-4 text-slate-400" />
          </button>
          <button
            type="button"
            onClick={onQuickNewInvoice}
            className="inline-flex min-h-[40px] items-center gap-2 rounded-lg bg-teal-700 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-teal-800 whitespace-nowrap shrink-0"
          >
            <Plus className="h-4 w-4" />
            <span>New Invoice</span>
          </button>
        </div>
      </div>

      {/* 4-Column KPI Strip */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <div className="text-xs font-medium text-slate-500">Total Revenue</div>
          <div className="mt-2 font-mono text-2xl font-semibold tracking-tight text-slate-900 tabular-nums">
            {formatCurrency(kpis.totalRevenue)}
          </div>
          <div className="mt-1.5 text-xs text-emerald-700">
            Settled from paid invoices
          </div>
        </div>

        <button
          type="button"
          onClick={() => onNavigate('invoices')}
          className="rounded-xl border border-slate-200 bg-white p-5 text-left transition-colors hover:border-slate-300"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Pending Invoices</span>
            <FileText className="h-4 w-4 text-slate-400" />
          </div>
          <div className="mt-2 font-mono text-2xl font-semibold tracking-tight text-slate-900 tabular-nums">
            {kpis.pendingCount}
          </div>
          <div className="mt-1.5 font-mono text-xs text-amber-700 tabular-nums">
            {formatCurrency(kpis.pendingAmount)} awaiting payment
          </div>
        </button>

        <button
          type="button"
          onClick={() => onNavigate('inventory')}
          className="rounded-xl border border-slate-200 bg-white p-5 text-left transition-colors hover:border-slate-300"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Low Stock Alerts</span>
            <Package className="h-4 w-4 text-slate-400" />
          </div>
          <div className="mt-2 font-mono text-2xl font-semibold tracking-tight text-slate-900 tabular-nums">
            {kpis.lowStockCount}
          </div>
          <div className="mt-1.5 text-xs text-slate-500">
            {kpis.lowStockCount > 0
              ? 'SKUs at or below threshold'
              : 'All stock levels healthy'}
          </div>
        </button>

        <button
          type="button"
          onClick={() => onNavigate('clients')}
          className="rounded-xl border border-slate-200 bg-white p-5 text-left transition-colors hover:border-slate-300"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Active Clients</span>
            <Users className="h-4 w-4 text-slate-400" />
          </div>
          <div className="mt-2 font-mono text-2xl font-semibold tracking-tight text-slate-900 tabular-nums">
            {kpis.clientCount}
          </div>
          <div className="mt-1.5 text-xs text-slate-500">
            Saved in offline CRM directory
          </div>
        </button>
      </div>

      {/* Main Two-Column Split: Low Stock Priority + Recent Activity Feed */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Low Stock Priority */}
        <section className="rounded-xl border border-slate-200 bg-white lg:col-span-5">
          <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4">
            <div>
              <h2 className="text-base font-semibold text-slate-900">
                Restock Priority
              </h2>
              <p className="text-xs text-slate-500">
                Inventory items requiring replenishment
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('inventory')}
              className="text-xs font-medium text-teal-700 hover:text-teal-800 whitespace-nowrap"
            >
              Manage Inventory
            </button>
          </div>

          {kpis.lowStockProducts.length === 0 ? (
            <div className="px-5 py-10 text-center">
              <p className="text-sm font-medium text-slate-700">
                No low-stock items
              </p>
              <p className="mt-1 text-xs text-slate-500">
                Every SKU is currently above its reorder threshold.
              </p>
            </div>
          ) : (
            <ul className="divide-y divide-slate-100">
              {kpis.lowStockProducts.map((product) => {
                const isOut = product.stockQuantity === 0;
                return (
                  <li
                    key={product.id}
                    className="flex items-center justify-between gap-4 px-5 py-3.5"
                  >
                    <div className="min-w-0">
                      <p className="truncate text-sm font-medium text-slate-900">
                        {product.name}
                      </p>
                      <p className="mt-0.5 font-mono text-xs text-slate-500 tabular-nums">
                        {product.sku} · Threshold {product.lowStockThreshold}
                      </p>
                    </div>
                    <div
                      className={`inline-flex items-center gap-1.5 text-xs font-semibold whitespace-nowrap shrink-0 tabular-nums ${
                        isOut ? 'text-red-700' : 'text-amber-700'
                      }`}
                    >
                      <AlertTriangle className="h-3.5 w-3.5" />
                      <span>
                        {isOut ? 'Out of stock' : `${product.stockQuantity} left`}
                      </span>
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </section>

        {/* Recent Activity Feed */}
        <section className="rounded-xl border border-slate-200 bg-white lg:col-span-7">
          <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4">
            <div>
              <h2 className="text-base font-semibold text-slate-900">
                Recent Activity
              </h2>
              <p className="text-xs text-slate-500">
                Chronological ledger of invoices, stock edits, and client entries
              </p>
            </div>
            <span className="font-mono text-xs text-slate-400 tabular-nums">
              {activities.length} entries
            </span>
          </div>

          {activities.length === 0 ? (
            <div className="px-5 py-10 text-center">
              <p className="text-sm font-medium text-slate-700">No activity yet</p>
              <p className="mt-1 text-xs text-slate-500">
                Actions you perform offline will appear here immediately.
              </p>
            </div>
          ) : (
            <ul className="divide-y divide-slate-100">
              {activities.slice(0, 8).map((entry) => (
                <li
                  key={entry.id}
                  className="flex items-start justify-between gap-4 px-5 py-3.5"
                >
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-slate-900">
                      {entry.title}
                    </p>
                    <p className="mt-0.5 text-xs text-slate-500">{entry.detail}</p>
                  </div>
                  <span className="font-mono text-xs text-slate-400 whitespace-nowrap shrink-0 tabular-nums">
                    {formatRelativeTime(entry.timestamp)}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </div>
  );
};
