import React, { useState } from 'react';
import { Fingerprint, Lock, ShieldCheck } from 'lucide-react';

interface BiometricLockOverlayProps {
  expectedPin: string;
  onUnlock: () => void;
}

export const BiometricLockOverlay: React.FC<BiometricLockOverlayProps> = ({
  expectedPin,
  onUnlock,
}) => {
  const [pin, setPin] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [scanning, setScanning] = useState(false);

  const handleBiometricScan = () => {
    setError(null);
    setScanning(true);
    setTimeout(() => {
      setScanning(false);
      onUnlock();
    }, 550);
  };

  const handlePinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (pin === expectedPin) {
      setError(null);
      setPin('');
      onUnlock();
    } else {
      setError(`Incorrect PIN (default is ${expectedPin})`);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/95 p-6 backdrop-blur-sm">
      <div className="w-full max-w-sm rounded-2xl border border-slate-800 bg-slate-900 p-7 text-center text-slate-100 shadow-2xl">
        <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-teal-900/50 text-teal-400">
          {scanning ? (
            <ShieldCheck className="h-7 w-7" />
          ) : (
            <Lock className="h-7 w-7" />
          )}
        </div>
        <h2 className="mt-4 text-xl font-bold tracking-tight text-white">
          BizFlow Locked
        </h2>
        <p className="mt-1.5 text-xs leading-relaxed text-slate-400">
          Offline business records are protected. Verify with BiometricPrompt or
          enter your fallback PIN.
        </p>

        <button
          type="button"
          onClick={handleBiometricScan}
          disabled={scanning}
          className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl bg-teal-600 px-4 py-3 text-sm font-medium text-white transition-colors hover:bg-teal-500 disabled:opacity-70"
        >
          <Fingerprint className="h-5 w-5" />
          <span>{scanning ? 'Verifying Biometrics...' : 'Unlock with Biometrics'}</span>
        </button>

        <form onSubmit={handlePinSubmit} className="mt-6 border-t border-slate-800 pt-5">
          <label className="block text-xs font-medium text-slate-400">
            Or enter fallback PIN (default {expectedPin})
          </label>
          <div className="mt-2 flex gap-2">
            <input
              type="password"
              inputMode="numeric"
              maxLength={6}
              value={pin}
              onChange={(e) => setPin(e.target.value)}
              placeholder="••••"
              className="flex-1 rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-center font-mono text-sm tracking-widest text-white focus:border-teal-500 focus:outline-none"
            />
            <button
              type="submit"
              className="rounded-lg border border-slate-700 bg-slate-800 px-4 py-2 text-xs font-medium text-slate-200 hover:bg-slate-700"
            >
              Unlock
            </button>
          </div>
          {error && <p className="mt-2 text-xs text-red-400">{error}</p>}
        </form>
      </div>
    </div>
  );
};
