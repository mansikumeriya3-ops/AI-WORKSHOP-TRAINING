import React, { useMemo, useState } from 'react';
import {
  Check,
  Copy,
  Download,
  FileCode2,
  FolderOpen,
  Smartphone,
} from 'lucide-react';
import { ANDROID_PROJECT_FILES } from '../data/androidProjectFiles';
import { AndroidProjectFile } from '../types/bizflow';
import { downloadAndroidProjectZip } from '../utils/zipAndroidProject';

const PACKAGE_GROUPS: AndroidProjectFile['packageGroup'][] = [
  'Gradle & Manifest',
  'Data Layer (Room)',
  'Domain Layer',
  'DI (Hilt)',
  'Utilities (PDF & Biometric)',
  'UI Theme & Navigation',
  'UI Screens & Components',
];

export const AndroidSourceView: React.FC = () => {
  const [selectedPath, setSelectedPath] = useState<string>(
    ANDROID_PROJECT_FILES[3].path // app/build.gradle.kts by default
  );
  const [copied, setCopied] = useState(false);
  const [zipping, setZipping] = useState(false);

  const selectedFile = useMemo(
    () =>
      ANDROID_PROJECT_FILES.find((f) => f.path === selectedPath) ??
      ANDROID_PROJECT_FILES[0],
    [selectedPath]
  );

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(selectedFile.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      // Ignore clipboard failures in restricted frames
    }
  };

  const handleDownloadZip = async () => {
    setZipping(true);
    try {
      await downloadAndroidProjectZip();
    } finally {
      setZipping(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Header & ZIP Export Action */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Android Studio Project & APK Guide
          </h1>
          <p className="mt-1 text-sm text-slate-500">
            {ANDROID_PROJECT_FILES.length} Kotlin, Gradle, and XML source files ·
            Android SDK 35 · Jetpack Compose + Room + Hilt
          </p>
        </div>
        <button
          type="button"
          onClick={handleDownloadZip}
          disabled={zipping}
          className="inline-flex min-h-[40px] items-center gap-2 rounded-lg bg-teal-700 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-teal-800 disabled:opacity-60 whitespace-nowrap shrink-0"
        >
          <Download className="h-4 w-4" />
          <span>
            {zipping
              ? 'Bundling ZIP...'
              : 'Download Android Studio Project (.zip)'}
          </span>
        </button>
      </div>

      {/* Step-by-step Android Studio & APK Build Guide */}
      <section className="rounded-xl border border-slate-200 bg-white p-5">
        <div className="flex items-center gap-2 text-sm font-semibold text-slate-900">
          <Smartphone className="h-4 w-4 text-teal-700" />
          <span>Build & Install Debug .APK on Your Physical Android Phone</span>
        </div>
        <ol className="mt-4 grid grid-cols-1 gap-4 text-sm text-slate-600 md:grid-cols-5">
          <li className="space-y-1">
            <div className="font-mono text-xs font-semibold text-teal-700">
              01. Download & Unzip
            </div>
            <p className="text-xs leading-relaxed">
              Click <strong>Download Android Studio Project (.zip)</strong> above
              and extract the <code className="font-mono">BizFlow-Android</code>{' '}
              folder.
            </p>
          </li>
          <li className="space-y-1">
            <div className="font-mono text-xs font-semibold text-teal-700">
              02. Open in Android Studio
            </div>
            <p className="text-xs leading-relaxed">
              Launch Android Studio (Ladybug or newer), select{' '}
              <strong>Open</strong>, and choose the extracted{' '}
              <code className="font-mono">BizFlow-Android</code> directory.
            </p>
          </li>
          <li className="space-y-1">
            <div className="font-mono text-xs font-semibold text-teal-700">
              03. Sync Gradle (SDK 35)
            </div>
            <p className="text-xs leading-relaxed">
              Allow Gradle to sync automatically or click{' '}
              <strong>File &gt; Sync Project with Gradle Files</strong>.
            </p>
          </li>
          <li className="space-y-1">
            <div className="font-mono text-xs font-semibold text-teal-700">
              04. Build Debug APK
            </div>
            <p className="text-xs leading-relaxed">
              In the top menu, go to{' '}
              <strong>Build &gt; Build Bundle(s) / APK(s) &gt; Build APK(s)</strong>
              .
            </p>
          </li>
          <li className="space-y-1">
            <div className="font-mono text-xs font-semibold text-teal-700">
              05. Install on Phone
            </div>
            <p className="text-xs leading-relaxed">
              Copy <code className="font-mono">app/build/outputs/apk/debug/app-debug.apk</code>{' '}
              to your phone, tap it, and allow{' '}
              <strong>Install unknown apps</strong>.
            </p>
          </li>
        </ol>
      </section>

      {/* Interactive Package Tree & Code Viewer */}
      <div className="grid grid-cols-1 overflow-hidden rounded-xl border border-slate-200 bg-white lg:grid-cols-12">
        {/* Package Sidebar */}
        <aside className="max-h-[640px] overflow-y-auto border-b border-slate-200 bg-slate-50/70 p-4 lg:col-span-4 lg:border-b-0 lg:border-r">
          <div className="space-y-5">
            {PACKAGE_GROUPS.map((group) => {
              const groupFiles = ANDROID_PROJECT_FILES.filter(
                (f) => f.packageGroup === group
              );
              return (
                <div key={group}>
                  <div className="flex items-center gap-1.5 px-2 text-xs font-semibold text-slate-500">
                    <FolderOpen className="h-3.5 w-3.5 text-slate-400" />
                    <span>{group}</span>
                  </div>
                  <ul className="mt-1.5 space-y-0.5">
                    {groupFiles.map((file) => {
                      const fileName = file.path.split('/').pop() ?? file.path;
                      const isActive = file.path === selectedFile.path;
                      return (
                        <li key={file.path}>
                          <button
                            type="button"
                            onClick={() => setSelectedPath(file.path)}
                            className={`flex w-full items-center gap-2 rounded-md px-2.5 py-1.5 text-left text-xs transition-colors ${
                              isActive
                                ? 'bg-teal-700 font-medium text-white'
                                : 'text-slate-700 hover:bg-slate-200/70'
                            }`}
                          >
                            <FileCode2
                              className={`h-3.5 w-3.5 shrink-0 ${
                                isActive ? 'text-teal-100' : 'text-slate-400'
                              }`}
                            />
                            <span className="truncate font-mono">{fileName}</span>
                          </button>
                        </li>
                      );
                    })}
                  </ul>
                </div>
              );
            })}
          </div>
        </aside>

        {/* Source Code Pane */}
        <div className="flex max-h-[640px] flex-col lg:col-span-8">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 px-5 py-3.5">
            <div className="min-w-0">
              <div className="truncate font-mono text-xs font-semibold text-slate-900">
                {selectedFile.path}
              </div>
              <div className="mt-0.5 text-xs text-slate-500">
                {selectedFile.description}
              </div>
            </div>
            <button
              type="button"
              onClick={handleCopy}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap shrink-0"
            >
              {copied ? (
                <>
                  <Check className="h-3.5 w-3.5 text-emerald-600" />
                  <span>Copied</span>
                </>
              ) : (
                <>
                  <Copy className="h-3.5 w-3.5" />
                  <span>Copy File</span>
                </>
              )}
            </button>
          </div>
          <pre className="flex-1 overflow-auto bg-slate-950 p-5 font-mono text-xs leading-relaxed text-slate-100">
            <code>{selectedFile.content}</code>
          </pre>
        </div>
      </div>
    </div>
  );
};
