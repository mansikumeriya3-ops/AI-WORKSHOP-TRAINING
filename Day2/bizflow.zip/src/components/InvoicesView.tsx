import React, { useMemo, useState } from 'react';
import {
  CheckCircle2,
  Clock,
  Download,
  Eye,
  Minus,
  Plus,
  Trash2,
  X,
} from 'lucide-react';
import {
  BusinessSettings,
  Client,
  Invoice,
  InvoiceLineItem,
  InvoiceStatus,
  Product,
} from '../types/bizflow';
import { exportInvoicePdf } from '../utils/pdfExport';

interface InvoicesViewProps {
  invoices: Invoice[];
  clients: Client[];
  products: Product[];
  settings: BusinessSettings;
  startWithComposer?: boolean;
  onComposerOpened?: () => void;
  onCreateInvoice: (payload: {
    client: Client;
    items: InvoiceLineItem[];
    taxRatePercent: number;
    status: InvoiceStatus;
    dueDate: string;
    notes: string;
  }) => Invoice;
  onToggleStatus: (invoiceId: string) => void;
  onDeleteInvoice: (invoiceId: string) => void;
}

type StatusFilter = 'ALL' | 'PAID' | 'UNPAID';

export const InvoicesView: React.FC<InvoicesViewProps> = ({
  invoices,
  clients,
  products,
  settings,
  startWithComposer = false,
  onComposerOpened,
  onCreateInvoice,
  onToggleStatus,
  onDeleteInvoice,
}) => {
  const [filter, setFilter] = useState<StatusFilter>('ALL');
  const [composerOpen, setComposerOpen] = useState(startWithComposer);
  const [previewInvoice, setPreviewInvoice] = useState<Invoice | null>(null);

  // Composer state
  const [selectedClientId, setSelectedClientId] = useState<string>(
    clients[0]?.id ?? ''
  );
  const [quantities, setQuantities] = useState<Record<string, number>>({});
  const [taxRate, setTaxRate] = useState<string>(String(settings.defaultTaxRate));
  const [status, setStatus] = useState<InvoiceStatus>('UNPAID');
  const [dueDate, setDueDate] = useState<string>(() => {
    const d = new Date(Date.now() + 14 * 86400000);
    return d.toISOString().split('T')[0];
  });
  const [notes, setNotes] = useState('');

  React.useEffect(() => {
    if (startWithComposer) {
      setComposerOpen(true);
      onComposerOpened?.();
    }
  }, [startWithComposer, onComposerOpened]);

  const filteredInvoices = useMemo(() => {
    if (filter === 'ALL') return invoices;
    return invoices.filter((inv) => inv.status === filter);
  }, [invoices, filter]);

  const selectedItems: InvoiceLineItem[] = useMemo(() => {
    return products
      .filter((p) => (quantities[p.id] ?? 0) > 0)
      .map((p) => ({
        productId: p.id,
        productName: p.name,
        sku: p.sku,
        unitPrice: p.unitPrice,
        quantity: quantities[p.id],
      }));
  }, [products, quantities]);

  const subtotal = useMemo(
    () =>
      selectedItems.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0),
    [selectedItems]
  );
  const numericTax = Math.max(0, parseFloat(taxRate) || 0);
  const taxAmount = Number(((subtotal * numericTax) / 100).toFixed(2));
  const grandTotal = Number((subtotal + taxAmount).toFixed(2));

  const openComposer = () => {
    setSelectedClientId(clients[0]?.id ?? '');
    setQuantities({});
    setTaxRate(String(settings.defaultTaxRate));
    setStatus('UNPAID');
    setNotes('');
    setComposerOpen(true);
  };

  const adjustItemQty = (product: Product, delta: number) => {
    setQuantities((prev) => {
      const next = Math.max(0, (prev[product.id] ?? 0) + delta);
      if (next === 0) {
        const copy = { ...prev };
        delete copy[product.id];
        return copy;
      }
      return { ...prev, [product.id]: next };
    });
  };

  const handleSaveInvoice = (e: React.FormEvent) => {
    e.preventDefault();
    const client = clients.find((c) => c.id === selectedClientId);
    if (!client || selectedItems.length === 0) return;

    const created = onCreateInvoice({
      client,
      items: selectedItems,
      taxRatePercent: numericTax,
      status,
      dueDate: new Date(dueDate).toISOString(),
      notes: notes.trim(),
    });
    setComposerOpen(false);
    setPreviewInvoice(created);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Invoices & PDF Export
          </h1>
          <p className="mt-1 text-sm text-slate-500">
            {invoices.length} invoices · Auto-calculates tax and exports printable PDFs
          </p>
        </div>
        <button
          type="button"
          onClick={openComposer}
          disabled={clients.length === 0 || products.length === 0}
          className="inline-flex min-h-[40px] items-center gap-2 rounded-lg bg-teal-700 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-teal-800 disabled:cursor-not-allowed disabled:opacity-50 whitespace-nowrap shrink-0"
        >
          <Plus className="h-4 w-4" />
          <span>Create Invoice</span>
        </button>
      </div>

      {/* Status Filter */}
      <div className="inline-flex items-center gap-1 rounded-lg bg-slate-200/70 p-1">
        {(
          [
            { id: 'ALL', label: 'All Invoices' },
            { id: 'PAID', label: 'Paid' },
            { id: 'UNPAID', label: 'Unpaid' },
          ] as const
        ).map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setFilter(tab.id)}
            className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
              filter === tab.id
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Invoices Table */}
      <div className="overflow-hidden rounded-xl border border-slate-200 bg-white">
        {filteredInvoices.length === 0 ? (
          <div className="px-6 py-14 text-center">
            <p className="text-sm font-semibold text-slate-900">
              No invoices in this view
            </p>
            <p className="mt-1 text-xs text-slate-500">
              Create a new invoice to generate an itemized PDF and update revenue.
            </p>
            <button
              type="button"
              onClick={openComposer}
              className="mt-4 inline-flex items-center gap-2 rounded-lg bg-teal-700 px-4 py-2 text-xs font-medium text-white hover:bg-teal-800"
            >
              <Plus className="h-3.5 w-3.5" />
              <span>Create First Invoice</span>
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-left text-sm">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/70 text-xs font-medium text-slate-500">
                  <th className="px-5 py-3">Invoice #</th>
                  <th className="px-4 py-3">Client</th>
                  <th className="px-4 py-3">Issued</th>
                  <th className="px-4 py-3 text-right">Total</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-5 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredInvoices.map((inv) => {
                  const isPaid = inv.status === 'PAID';
                  return (
                    <tr
                      key={inv.id}
                      className="transition-colors hover:bg-slate-50/60"
                    >
                      <td className="px-5 py-3.5 font-mono text-xs font-semibold text-slate-900">
                        {inv.invoiceNumber}
                      </td>
                      <td className="px-4 py-3.5">
                        <div className="font-medium text-slate-900">
                          {inv.clientName}
                        </div>
                        <div className="text-xs text-slate-500">
                          {inv.clientCompany || inv.clientEmail} · {inv.items.length} line{' '}
                          {inv.items.length === 1 ? 'item' : 'items'}
                        </div>
                      </td>
                      <td className="px-4 py-3.5 font-mono text-xs text-slate-500 tabular-nums">
                        {new Date(inv.issuedAt).toLocaleDateString()}
                      </td>
                      <td className="px-4 py-3.5 text-right font-mono font-semibold text-slate-900 tabular-nums">
                        ${inv.totalAmount.toFixed(2)}
                      </td>
                      <td className="px-4 py-3.5">
                        <button
                          type="button"
                          onClick={() => onToggleStatus(inv.id)}
                          title="Click to toggle Paid / Unpaid"
                          className={`inline-flex items-center gap-1.5 text-xs font-semibold whitespace-nowrap ${
                            isPaid
                              ? 'text-emerald-700 hover:text-emerald-800'
                              : 'text-amber-700 hover:text-amber-800'
                          }`}
                        >
                          {isPaid ? (
                            <CheckCircle2 className="h-3.5 w-3.5" />
                          ) : (
                            <Clock className="h-3.5 w-3.5" />
                          )}
                          <span>{isPaid ? 'Paid' : 'Unpaid'}</span>
                        </button>
                      </td>
                      <td className="px-5 py-3.5 text-right">
                        <div className="inline-flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => setPreviewInvoice(inv)}
                            className="inline-flex items-center gap-1 rounded-md px-2.5 py-1.5 text-xs font-medium text-slate-600 hover:bg-slate-100 hover:text-slate-900"
                          >
                            <Eye className="h-3.5 w-3.5" />
                            <span>View</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => exportInvoicePdf(inv, settings)}
                            className="inline-flex items-center gap-1 rounded-md px-2.5 py-1.5 text-xs font-medium text-teal-700 hover:bg-teal-50"
                          >
                            <Download className="h-3.5 w-3.5" />
                            <span>PDF</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => onDeleteInvoice(inv.id)}
                            aria-label={`Delete ${inv.invoiceNumber}`}
                            className="rounded-md p-1.5 text-slate-400 hover:bg-red-50 hover:text-red-700"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Invoice Builder Modal */}
      {composerOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 p-4 backdrop-blur-xs">
          <div className="flex max-h-[90vh] w-full max-w-2xl flex-col overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4">
              <h2 className="text-base font-semibold text-slate-900">
                Create New Invoice
              </h2>
              <button
                type="button"
                onClick={() => setComposerOpen(false)}
                className="rounded-md p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <form
              onSubmit={handleSaveInvoice}
              className="flex-1 space-y-5 overflow-y-auto p-5"
            >
              {/* Client & Status Row */}
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <label className="block text-xs font-medium text-slate-700">
                    Select Client
                  </label>
                  <select
                    value={selectedClientId}
                    onChange={(e) => setSelectedClientId(e.target.value)}
                    className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm focus:border-teal-700 focus:outline-none"
                  >
                    {clients.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} {c.company ? `(${c.company})` : ''}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700">
                    Payment Status
                  </label>
                  <div className="mt-1 grid grid-cols-2 gap-1 rounded-lg bg-slate-100 p-1">
                    {(['UNPAID', 'PAID'] as const).map((s) => (
                      <button
                        key={s}
                        type="button"
                        onClick={() => setStatus(s)}
                        className={`rounded-md py-1.5 text-xs font-medium transition-colors ${
                          status === s
                            ? 'bg-white text-slate-900 shadow-xs'
                            : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        {s === 'PAID' ? 'Paid' : 'Unpaid'}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Inventory Items Picker */}
              <div>
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-medium text-slate-700">
                    Select Inventory Items
                  </label>
                  <span className="text-xs text-slate-500">
                    Quantities deduct from stock on save
                  </span>
                </div>
                <div className="mt-2 max-h-56 divide-y divide-slate-100 overflow-y-auto rounded-lg border border-slate-200">
                  {products.map((product) => {
                    const qty = quantities[product.id] ?? 0;
                    return (
                      <div
                        key={product.id}
                        className="flex items-center justify-between gap-3 px-3.5 py-2.5"
                      >
                        <div className="min-w-0">
                          <div className="truncate text-sm font-medium text-slate-900">
                            {product.name}
                          </div>
                          <div className="font-mono text-xs text-slate-500 tabular-nums">
                            {product.sku} · ${product.unitPrice.toFixed(2)} ·{' '}
                            {product.stockQuantity} in stock
                          </div>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          <button
                            type="button"
                            onClick={() => adjustItemQty(product, -1)}
                            disabled={qty === 0}
                            className="flex h-7 w-7 items-center justify-center rounded border border-slate-200 text-slate-600 hover:bg-slate-100 disabled:opacity-40"
                          >
                            <Minus className="h-3.5 w-3.5" />
                          </button>
                          <span className="w-6 text-center font-mono text-sm font-semibold tabular-nums">
                            {qty}
                          </span>
                          <button
                            type="button"
                            onClick={() => adjustItemQty(product, 1)}
                            className="flex h-7 w-7 items-center justify-center rounded border border-slate-200 text-slate-600 hover:bg-slate-100"
                          >
                            <Plus className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Tax, Due Date & Notes */}
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700">
                    Tax Rate (%)
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    min="0"
                    value={taxRate}
                    onChange={(e) => setTaxRate(e.target.value)}
                    className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 font-mono text-sm tabular-nums focus:border-teal-700 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700">
                    Due Date
                  </label>
                  <input
                    type="date"
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 font-mono text-sm focus:border-teal-700 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700">
                    Notes
                  </label>
                  <input
                    type="text"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Net-14 terms..."
                    className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-teal-700 focus:outline-none"
                  />
                </div>
              </div>

              {/* Live Totals Summary */}
              <div className="space-y-1.5 border-t border-slate-200 pt-4 text-sm">
                <div className="flex justify-between text-slate-600">
                  <span>Subtotal ({selectedItems.length} items)</span>
                  <span className="font-mono tabular-nums">
                    ${subtotal.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Tax ({numericTax.toFixed(1)}%)</span>
                  <span className="font-mono tabular-nums">
                    ${taxAmount.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between pt-1 text-base font-bold text-slate-900">
                  <span>Total</span>
                  <span className="font-mono text-teal-700 tabular-nums">
                    ${grandTotal.toFixed(2)}
                  </span>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setComposerOpen(false)}
                  className="rounded-lg border border-slate-200 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={selectedItems.length === 0}
                  className="rounded-lg bg-teal-700 px-4 py-2 text-sm font-medium text-white hover:bg-teal-800 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  Save Invoice
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Invoice Detail & PDF Export Modal */}
      {previewInvoice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 p-4 backdrop-blur-xs">
          <div className="w-full max-w-xl rounded-xl border border-slate-200 bg-white shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4">
              <div>
                <h2 className="font-mono text-base font-bold text-slate-900">
                  {previewInvoice.invoiceNumber}
                </h2>
                <p className="text-xs text-slate-500">
                  Issued {new Date(previewInvoice.issuedAt).toLocaleDateString()} ·{' '}
                  {previewInvoice.status === 'PAID' ? 'Paid' : 'Unpaid'}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setPreviewInvoice(null)}
                className="rounded-md p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="space-y-5 p-6">
              <div className="flex flex-col justify-between gap-4 sm:flex-row">
                <div>
                  <div className="text-xs font-medium text-slate-400">From</div>
                  <div className="mt-1 text-sm font-semibold text-slate-900">
                    {settings.businessName}
                  </div>
                  <div className="text-xs text-slate-500">
                    {settings.businessEmail}
                  </div>
                </div>
                <div className="sm:text-right">
                  <div className="text-xs font-medium text-slate-400">Bill To</div>
                  <div className="mt-1 text-sm font-semibold text-slate-900">
                    {previewInvoice.clientName}
                  </div>
                  <div className="text-xs text-slate-500">
                    {previewInvoice.clientCompany}
                  </div>
                  <div className="text-xs text-slate-500">
                    {previewInvoice.clientEmail}
                  </div>
                </div>
              </div>

              <div className="divide-y divide-slate-100 border-y border-slate-200">
                {previewInvoice.items.map((item) => (
                  <div
                    key={item.productId}
                    className="flex items-center justify-between py-2.5 text-sm"
                  >
                    <div>
                      <div className="font-medium text-slate-900">
                        {item.productName}
                      </div>
                      <div className="font-mono text-xs text-slate-500 tabular-nums">
                        {item.sku} · {item.quantity} × ${item.unitPrice.toFixed(2)}
                      </div>
                    </div>
                    <div className="font-mono font-semibold text-slate-900 tabular-nums">
                      ${(item.quantity * item.unitPrice).toFixed(2)}
                    </div>
                  </div>
                ))}
              </div>

              <div className="space-y-1 text-sm">
                <div className="flex justify-between text-slate-600">
                  <span>Subtotal</span>
                  <span className="font-mono tabular-nums">
                    ${previewInvoice.subtotal.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Tax ({previewInvoice.taxRatePercent.toFixed(1)}%)</span>
                  <span className="font-mono tabular-nums">
                    ${previewInvoice.taxAmount.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between pt-2 text-base font-bold text-slate-900">
                  <span>Total</span>
                  <span className="font-mono text-teal-700 tabular-nums">
                    ${previewInvoice.totalAmount.toFixed(2)}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between border-t border-slate-200 bg-slate-50 px-6 py-4">
              <button
                type="button"
                onClick={() => {
                  onToggleStatus(previewInvoice.id);
                  setPreviewInvoice((prev) =>
                    prev
                      ? {
                          ...prev,
                          status: prev.status === 'PAID' ? 'UNPAID' : 'PAID',
                        }
                      : null
                  );
                }}
                className="rounded-lg border border-slate-200 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100"
              >
                Mark as {previewInvoice.status === 'PAID' ? 'Unpaid' : 'Paid'}
              </button>
              <button
                type="button"
                onClick={() => exportInvoicePdf(previewInvoice, settings)}
                className="inline-flex items-center gap-2 rounded-lg bg-teal-700 px-4 py-2 text-xs font-medium text-white hover:bg-teal-800"
              >
                <Download className="h-3.5 w-3.5" />
                <span>Download PDF Invoice</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
