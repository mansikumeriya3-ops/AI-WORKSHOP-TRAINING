import express, { NextFunction, Request, Response } from 'express';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { db, hashPassword, initializeDatabase, verifyPassword } from './server/db.ts';

dotenv.config();

initializeDatabase();

const app = express();
const PORT = 3000;
const SESSION_SECRET = process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex');
const UPLOADS_DIR = path.resolve(process.cwd(), 'data', 'uploads');

if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

app.use(express.json({ limit: '25mb' }));
app.use('/uploads', express.static(UPLOADS_DIR));

interface TokenPayload {
  userId: number;
  role: 'customer' | 'agent' | 'admin';
  email: string;
  exp: number;
}

interface AuthenticatedRequest extends Request {
  user?: {
    id: number;
    name: string;
    email: string;
    role: 'customer' | 'agent' | 'admin';
    is_verified: number;
    is_active: number;
  };
}

function signToken(payload: TokenPayload): string {
  const encoded = Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
  const sig = crypto.createHmac('sha256', SESSION_SECRET).update(encoded).digest('base64url');
  return `${encoded}.${sig}`;
}

function verifyToken(token: string): TokenPayload | null {
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [encoded, sig] = parts;
  const expectedSig = crypto.createHmac('sha256', SESSION_SECRET).update(encoded).digest('base64url');
  const sigBuf = Buffer.from(sig);
  const expBuf = Buffer.from(expectedSig);
  if (sigBuf.length !== expBuf.length || !crypto.timingSafeEqual(sigBuf, expBuf)) {
    return null;
  }
  try {
    const parsed = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8')) as TokenPayload;
    if (!parsed.exp || Date.now() > parsed.exp) return null;
    return parsed;
  } catch {
    return null;
  }
}

function attachUserOptional(req: AuthenticatedRequest, _res: Response, next: NextFunction) {
  const auth = req.headers.authorization;
  if (auth && auth.startsWith('Bearer ')) {
    const payload = verifyToken(auth.slice(7));
    if (payload) {
      const user = db
        .prepare('SELECT id, name, email, role, is_verified, is_active FROM users WHERE id = ?')
        .get(payload.userId) as AuthenticatedRequest['user'] | undefined;
      if (user && user.is_active === 1) {
        req.user = user;
      }
    }
  }
  next();
}

function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  attachUserOptional(req, res, () => {
    if (!req.user) {
      res.status(401).json({ error: 'Authentication required. Please sign in.' });
      return;
    }
    next();
  });
}

function requireRole(...roles: Array<'customer' | 'agent' | 'admin'>) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    requireAuth(req, res, () => {
      if (!req.user || !roles.includes(req.user.role)) {
        res.status(403).json({ error: 'Insufficient permissions for this action.' });
        return;
      }
      next();
    });
  };
}

function isValidEmail(email: unknown): email is string {
  return typeof email === 'string' && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
}

function sanitizeImageUrl(url: string): string | null {
  const trimmed = url.trim();
  if (!trimmed) return null;
  if (trimmed.startsWith('/src/assets/images/') || trimmed.startsWith('/uploads/')) {
    return trimmed;
  }
  try {
    const parsed = new URL(trimmed);
    if (parsed.protocol === 'https:' || parsed.protocol === 'http:') {
      return parsed.toString();
    }
  } catch {
    return null;
  }
  return null;
}

function formatPropertyRow(row: Record<string, unknown>) {
  let amenities: string[] = [];
  let images: string[] = [];
  try {
    amenities = JSON.parse(String(row.amenities || '[]'));
  } catch {
    amenities = [];
  }
  try {
    images = JSON.parse(String(row.images || '[]'));
  } catch {
    images = [];
  }
  return {
    ...row,
    featured: Boolean(row.featured),
    amenities,
    images,
  };
}

// Health check
app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok' });
});

// Dashboard KPIs
app.get('/api/stats', (_req, res) => {
  const totalProperties = (
    db.prepare("SELECT COUNT(*) as c FROM properties WHERE approval_status = 'Approved'").get() as { c: number }
  ).c;
  const forSaleCount = (
    db
      .prepare("SELECT COUNT(*) as c FROM properties WHERE approval_status = 'Approved' AND listing_type = 'buy' AND status = 'Available'")
      .get() as { c: number }
  ).c;
  const forRentCount = (
    db
      .prepare("SELECT COUNT(*) as c FROM properties WHERE approval_status = 'Approved' AND listing_type = 'rent' AND status = 'Available'")
      .get() as { c: number }
  ).c;
  const totalUsers = (db.prepare('SELECT COUNT(*) as c FROM users WHERE is_active = 1').get() as { c: number }).c;
  const pendingApprovalCount = (
    db.prepare("SELECT COUNT(*) as c FROM properties WHERE approval_status = 'Pending'").get() as { c: number }
  ).c;
  const totalEnquiries = (db.prepare('SELECT COUNT(*) as c FROM enquiries').get() as { c: number }).c;
  const totalVisits = (db.prepare('SELECT COUNT(*) as c FROM site_visits').get() as { c: number }).c;

  res.json({
    totalProperties,
    forSaleCount,
    forRentCount,
    totalUsers,
    pendingApprovalCount,
    totalEnquiries,
    totalVisits,
  });
});

// Admin setup status
app.get('/api/auth/admin-status', (_req, res) => {
  const envPasscode = (process.env.ADMIN_PASSCODE || '').trim();
  const claimRow = db.prepare('SELECT id, email FROM admin_claim WHERE id = 1').get() as { id: number; email: string } | undefined;
  const adminUser = db.prepare("SELECT id, email FROM users WHERE role = 'admin' LIMIT 1").get() as { id: number; email: string } | undefined;

  res.json({
    claimed: Boolean(claimRow || adminUser),
    envConfigured: Boolean(envPasscode),
  });
});

// First-run one-time admin claim route
app.post('/api/auth/claim-admin', (req, res) => {
  const envPasscode = (process.env.ADMIN_PASSCODE || '').trim();
  if (envPasscode) {
    res.status(403).json({ error: 'Admin access is managed by server environment configuration.' });
    return;
  }

  const existingClaim = db.prepare('SELECT id FROM admin_claim WHERE id = 1').get();
  const existingAdmin = db.prepare("SELECT id FROM users WHERE role = 'admin' LIMIT 1").get();
  if (existingClaim || existingAdmin) {
    res.status(409).json({ error: 'Admin account has already been claimed. Please sign in.' });
    return;
  }

  const { name, email, password } = req.body as { name?: string; email?: string; password?: string };
  if (!name || typeof name !== 'string' || name.trim().length < 2) {
    res.status(400).json({ error: 'Please provide an admin full name.' });
    return;
  }
  if (!isValidEmail(email)) {
    res.status(400).json({ error: 'Please enter a valid admin email address.' });
    return;
  }
  if (!password || typeof password !== 'string' || password.length < 8) {
    res.status(400).json({ error: 'Admin password must be at least 8 characters.' });
    return;
  }

  const normalizedEmail = email.trim().toLowerCase();
  const existingEmailUser = db.prepare('SELECT id FROM users WHERE email = ?').get(normalizedEmail);
  if (existingEmailUser) {
    res.status(409).json({ error: 'An account with this email already exists.' });
    return;
  }

  const pwHash = hashPassword(password);
  const tx = db.transaction(() => {
    db.prepare('INSERT INTO admin_claim (id, email, password_hash) VALUES (1, ?, ?)').run(normalizedEmail, pwHash);
    const result = db
      .prepare(
        `INSERT INTO users (name, email, password_hash, phone, city, bio, role, is_verified, is_active, agency_name)
         VALUES (?, ?, ?, '', 'Headquarters', 'Platform Administrator', 'admin', 1, 1, 'Dream Homes Realty HQ')`
      )
      .run(name.trim(), normalizedEmail, pwHash);
    return Number(result.lastInsertRowid);
  });

  const adminId = tx();
  const user = db
    .prepare('SELECT id, name, email, phone, city, bio, avatar_url, role, is_verified, is_active, agency_name, created_at FROM users WHERE id = ?')
    .get(adminId) as Record<string, unknown>;

  const token = signToken({
    userId: adminId,
    role: 'admin',
    email: normalizedEmail,
    exp: Date.now() + 1000 * 60 * 60 * 24 * 7,
  });

  res.status(201).json({ token, user });
});

// Register Customer or Property Agent
app.post('/api/auth/register', (req, res) => {
  const { name, email, password, phone, city, role, agency_name } = req.body as {
    name?: string;
    email?: string;
    password?: string;
    phone?: string;
    city?: string;
    role?: string;
    agency_name?: string;
  };

  if (!name || typeof name !== 'string' || name.trim().length < 2) {
    res.status(400).json({ error: 'Full name must be at least 2 characters.' });
    return;
  }
  if (!isValidEmail(email)) {
    res.status(400).json({ error: 'Please enter a valid email address.' });
    return;
  }
  if (!password || typeof password !== 'string' || password.length < 6) {
    res.status(400).json({ error: 'Password must be at least 6 characters.' });
    return;
  }

  const assignedRole = role === 'agent' ? 'agent' : 'customer';
  const normalizedEmail = email.trim().toLowerCase();

  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(normalizedEmail);
  if (existing) {
    res.status(409).json({ error: 'An account with this email is already registered.' });
    return;
  }

  const pwHash = hashPassword(password);
  const result = db
    .prepare(
      `INSERT INTO users (name, email, password_hash, phone, city, role, is_verified, is_active, agency_name)
       VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?)`
    )
    .run(
      name.trim(),
      normalizedEmail,
      pwHash,
      typeof phone === 'string' ? phone.trim() : '',
      typeof city === 'string' ? city.trim() : '',
      assignedRole,
      assignedRole === 'customer' ? 1 : 0,
      assignedRole === 'agent' && typeof agency_name === 'string' ? agency_name.trim() : ''
    );

  const userId = Number(result.lastInsertRowid);
  const user = db
    .prepare('SELECT id, name, email, phone, city, bio, avatar_url, role, is_verified, is_active, agency_name, created_at FROM users WHERE id = ?')
    .get(userId) as Record<string, unknown>;

  const token = signToken({
    userId,
    role: assignedRole,
    email: normalizedEmail,
    exp: Date.now() + 1000 * 60 * 60 * 24 * 7,
  });

  res.status(201).json({ token, user });
});

// Login (Supports regular email/password + optional ADMIN_PASSCODE override)
app.post('/api/auth/login', (req, res) => {
  const { email, password, adminPasscode } = req.body as {
    email?: string;
    password?: string;
    adminPasscode?: string;
  };

  const envPasscode = (process.env.ADMIN_PASSCODE || '').trim();
  if (adminPasscode && envPasscode) {
    const inputBuf = Buffer.from(String(adminPasscode));
    const envBuf = Buffer.from(envPasscode);
    if (inputBuf.length === envBuf.length && crypto.timingSafeEqual(inputBuf, envBuf)) {
      let adminUser = db.prepare("SELECT * FROM users WHERE role = 'admin' LIMIT 1").get() as Record<string, unknown> | undefined;
      if (!adminUser) {
        const resAdmin = db
          .prepare(
            `INSERT INTO users (name, email, password_hash, phone, city, bio, role, is_verified, is_active, agency_name)
             VALUES ('Platform Administrator', 'admin@dreamhomes.realty', ?, '', 'Headquarters', 'Platform Administrator', 'admin', 1, 1, 'Dream Homes Realty HQ')`
          )
          .run(hashPassword(envPasscode));
        adminUser = db.prepare('SELECT * FROM users WHERE id = ?').get(resAdmin.lastInsertRowid) as Record<string, unknown>;
      }
      const safeUser = { ...adminUser };
      delete safeUser.password_hash;
      const token = signToken({
        userId: Number(adminUser.id),
        role: 'admin',
        email: String(adminUser.email),
        exp: Date.now() + 1000 * 60 * 60 * 24 * 7,
      });
      res.json({ token, user: safeUser });
      return;
    }
    res.status(401).json({ error: 'Invalid admin passcode.' });
    return;
  }

  if (!isValidEmail(email) || !password || typeof password !== 'string') {
    res.status(400).json({ error: 'Please provide both email and password.' });
    return;
  }

  const normalizedEmail = email.trim().toLowerCase();
  const userRow = db.prepare('SELECT * FROM users WHERE email = ?').get(normalizedEmail) as
    | (Record<string, unknown> & { password_hash: string; is_active: number; role: 'customer' | 'agent' | 'admin'; id: number; email: string })
    | undefined;

  if (!userRow || !verifyPassword(password, userRow.password_hash)) {
    res.status(401).json({ error: 'Invalid email or password.' });
    return;
  }

  if (userRow.is_active !== 1) {
    res.status(403).json({ error: 'This account has been suspended. Please contact support.' });
    return;
  }

  const safeUser = { ...userRow } as Record<string, unknown>;
  delete safeUser.password_hash;

  const token = signToken({
    userId: userRow.id,
    role: userRow.role,
    email: userRow.email,
    exp: Date.now() + 1000 * 60 * 60 * 24 * 7,
  });

  res.json({ token, user: safeUser });
});

app.get('/api/auth/me', requireAuth, (req: AuthenticatedRequest, res) => {
  const user = db
    .prepare('SELECT id, name, email, phone, city, bio, avatar_url, role, is_verified, is_active, agency_name, created_at FROM users WHERE id = ?')
    .get(req.user!.id);
  res.json({ user });
});

app.put('/api/auth/profile', requireAuth, (req: AuthenticatedRequest, res) => {
  const { name, phone, city, bio, agency_name } = req.body as {
    name?: string;
    phone?: string;
    city?: string;
    bio?: string;
    agency_name?: string;
  };
  if (!name || typeof name !== 'string' || name.trim().length < 2) {
    res.status(400).json({ error: 'Name must be at least 2 characters.' });
    return;
  }

  db.prepare('UPDATE users SET name = ?, phone = ?, city = ?, bio = ?, agency_name = ? WHERE id = ?').run(
    name.trim(),
    typeof phone === 'string' ? phone.trim() : '',
    typeof city === 'string' ? city.trim() : '',
    typeof bio === 'string' ? bio.trim() : '',
    typeof agency_name === 'string' ? agency_name.trim() : '',
    req.user!.id
  );

  const updated = db
    .prepare('SELECT id, name, email, phone, city, bio, avatar_url, role, is_verified, is_active, agency_name, created_at FROM users WHERE id = ?')
    .get(req.user!.id);
  res.json({ user: updated });
});

// Search suggestions
app.get('/api/properties/suggestions', (req, res) => {
  const q = typeof req.query.q === 'string' ? req.query.q.trim() : '';
  const pattern = `%${q}%`;
  const rows = db
    .prepare(
      `SELECT DISTINCT city, neighborhood, title
       FROM properties
       WHERE approval_status = 'Approved' AND (city LIKE ? OR neighborhood LIKE ? OR title LIKE ? OR address LIKE ?)
       LIMIT 8`
    )
    .all(pattern, pattern, pattern, pattern) as Array<{ city: string; neighborhood: string; title: string }>;

  const suggestions = new Set<string>();
  for (const r of rows) {
    if (r.city.toLowerCase().includes(q.toLowerCase())) suggestions.add(r.city);
    if (r.neighborhood.toLowerCase().includes(q.toLowerCase())) suggestions.add(`${r.neighborhood}, ${r.city}`);
    if (r.title.toLowerCase().includes(q.toLowerCase())) suggestions.add(r.title);
  }
  if (suggestions.size === 0 && !q) {
    rows.forEach((r) => suggestions.add(r.city));
  }
  res.json({ suggestions: Array.from(suggestions).slice(0, 6) });
});

// List & Advanced Filter Properties
app.get('/api/properties', attachUserOptional, (req: AuthenticatedRequest, res) => {
  const {
    q,
    location,
    minPrice,
    maxPrice,
    propertyType,
    listingType,
    bedrooms,
    bathrooms,
    minArea,
    maxArea,
    furnishing,
    status,
    featured,
    agentOnly,
    includeAll,
    sort,
  } = req.query;

  const clauses: string[] = [];
  const params: Array<string | number> = [];

  const isPrivilegedAll = includeAll === '1' && req.user?.role === 'admin';
  const isAgentOwn = agentOnly === '1' && req.user && (req.user.role === 'agent' || req.user.role === 'admin');

  if (isAgentOwn && req.user?.role === 'agent') {
    clauses.push('p.agent_id = ?');
    params.push(req.user.id);
  } else if (!isPrivilegedAll) {
    clauses.push("p.approval_status = 'Approved'");
  }

  if (typeof q === 'string' && q.trim()) {
    const like = `%${q.trim()}%`;
    clauses.push('(p.title LIKE ? OR p.description LIKE ? OR p.address LIKE ? OR p.city LIKE ? OR p.neighborhood LIKE ?)');
    params.push(like, like, like, like, like);
  }

  if (typeof location === 'string' && location.trim()) {
    const loc = `%${location.trim()}%`;
    clauses.push('(p.city LIKE ? OR p.neighborhood LIKE ? OR p.address LIKE ?)');
    params.push(loc, loc, loc);
  }

  if (typeof listingType === 'string' && (listingType === 'buy' || listingType === 'rent')) {
    clauses.push('p.listing_type = ?');
    params.push(listingType);
  }

  if (typeof propertyType === 'string' && propertyType !== 'All' && propertyType.trim()) {
    clauses.push('p.property_type = ?');
    params.push(propertyType.trim());
  }

  if (typeof furnishing === 'string' && furnishing !== 'All' && furnishing.trim()) {
    clauses.push('p.furnishing = ?');
    params.push(furnishing.trim());
  }

  if (typeof status === 'string' && status !== 'All' && status.trim()) {
    clauses.push('p.status = ?');
    params.push(status.trim());
  }

  if (featured === '1') {
    clauses.push('p.featured = 1');
  }

  const minP = Number(minPrice);
  if (!Number.isNaN(minP) && minPrice !== '' && minPrice !== undefined) {
    clauses.push('p.price >= ?');
    params.push(minP);
  }
  const maxP = Number(maxPrice);
  if (!Number.isNaN(maxP) && maxPrice !== '' && maxPrice !== undefined && maxP > 0) {
    clauses.push('p.price <= ?');
    params.push(maxP);
  }

  const minBeds = Number(bedrooms);
  if (!Number.isNaN(minBeds) && minBeds > 0) {
    clauses.push('p.bedrooms >= ?');
    params.push(minBeds);
  }

  const minBaths = Number(bathrooms);
  if (!Number.isNaN(minBaths) && minBaths > 0) {
    clauses.push('p.bathrooms >= ?');
    params.push(minBaths);
  }

  const minA = Number(minArea);
  if (!Number.isNaN(minA) && minA > 0) {
    clauses.push('p.area_sqft >= ?');
    params.push(minA);
  }
  const maxA = Number(maxArea);
  if (!Number.isNaN(maxA) && maxA > 0) {
    clauses.push('p.area_sqft <= ?');
    params.push(maxA);
  }

  const whereSql = clauses.length > 0 ? `WHERE ${clauses.join(' AND ')}` : '';

  let orderSql = 'ORDER BY p.featured DESC, p.created_at DESC';
  if (sort === 'price_asc') orderSql = 'ORDER BY p.price ASC';
  else if (sort === 'price_desc') orderSql = 'ORDER BY p.price DESC';
  else if (sort === 'area_desc') orderSql = 'ORDER BY p.area_sqft DESC';
  else if (sort === 'newest') orderSql = 'ORDER BY p.created_at DESC';

  const rows = db
    .prepare(
      `SELECT p.*,
        u.name as agent_name,
        u.email as agent_email,
        u.phone as agent_phone,
        u.avatar_url as agent_avatar,
        u.agency_name as agent_agency,
        u.is_verified as agent_verified,
        COALESCE((SELECT AVG(r.rating) FROM reviews r WHERE r.property_id = p.id), 0) as avg_rating,
        (SELECT COUNT(*) FROM reviews r WHERE r.property_id = p.id) as review_count
       FROM properties p
       JOIN users u ON u.id = p.agent_id
       ${whereSql}
       ${orderSql}`
    )
    .all(...params) as Array<Record<string, unknown>>;

  res.json({ properties: rows.map(formatPropertyRow) });
});

// Single Property Detail + Reviews + Recommended Properties
app.get('/api/properties/:id', attachUserOptional, (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) {
    res.status(400).json({ error: 'Invalid property ID.' });
    return;
  }

  const row = db
    .prepare(
      `SELECT p.*,
        u.name as agent_name,
        u.email as agent_email,
        u.phone as agent_phone,
        u.avatar_url as agent_avatar,
        u.agency_name as agent_agency,
        u.is_verified as agent_verified,
        COALESCE((SELECT AVG(r.rating) FROM reviews r WHERE r.property_id = p.id), 0) as avg_rating,
        (SELECT COUNT(*) FROM reviews r WHERE r.property_id = p.id) as review_count
       FROM properties p
       JOIN users u ON u.id = p.agent_id
       WHERE p.id = ?`
    )
    .get(id) as Record<string, unknown> | undefined;

  if (!row) {
    res.status(404).json({ error: 'Property not found.' });
    return;
  }

  if (
    row.approval_status !== 'Approved' &&
    req.user?.role !== 'admin' &&
    req.user?.id !== Number(row.agent_id)
  ) {
    res.status(404).json({ error: 'Property not found.' });
    return;
  }

  db.prepare('UPDATE properties SET views_count = views_count + 1 WHERE id = ?').run(id);

  const reviews = db
    .prepare('SELECT * FROM reviews WHERE property_id = ? ORDER BY created_at DESC')
    .all(id);

  const recommendedRows = db
    .prepare(
      `SELECT p.*,
        u.name as agent_name,
        u.phone as agent_phone,
        u.avatar_url as agent_avatar,
        u.is_verified as agent_verified,
        COALESCE((SELECT AVG(r.rating) FROM reviews r WHERE r.property_id = p.id), 0) as avg_rating,
        (SELECT COUNT(*) FROM reviews r WHERE r.property_id = p.id) as review_count
       FROM properties p
       JOIN users u ON u.id = p.agent_id
       WHERE p.id != ? AND p.approval_status = 'Approved'
       ORDER BY (CASE WHEN p.listing_type = ? THEN 2 ELSE 0 END) + (CASE WHEN p.property_type = ? THEN 2 ELSE 0 END) + (CASE WHEN p.city = ? THEN 1 ELSE 0 END) DESC, p.featured DESC
       LIMIT 3`
    )
    .all(id, row.listing_type, row.property_type, row.city) as Array<Record<string, unknown>>;

  res.json({
    property: formatPropertyRow(row),
    reviews,
    recommended: recommendedRows.map(formatPropertyRow),
  });
});

// Upload multiple property images (Base64 -> disk in data/uploads)
app.post('/api/upload', requireRole('agent', 'admin'), (req, res) => {
  const { files } = req.body as { files?: Array<{ name?: string; dataUrl?: string }> };
  if (!Array.isArray(files) || files.length === 0 || files.length > 8) {
    res.status(400).json({ error: 'Please select between 1 and 8 image files.' });
    return;
  }

  const mimeToExt: Record<string, string> = {
    'image/jpeg': 'jpg',
    'image/jpg': 'jpg',
    'image/png': 'png',
    'image/webp': 'webp',
  };

  const urls: string[] = [];
  for (const file of files) {
    if (!file.dataUrl || typeof file.dataUrl !== 'string') {
      res.status(400).json({ error: 'Invalid file payload.' });
      return;
    }
    const match = /^data:(image\/(?:jpeg|jpg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(file.dataUrl);
    if (!match) {
      res.status(400).json({ error: 'Only PNG, JPG, and WebP images are supported.' });
      return;
    }
    const ext = mimeToExt[match[1]];
    const buffer = Buffer.from(match[2], 'base64');
    if (buffer.length > 5 * 1024 * 1024) {
      res.status(400).json({ error: 'Each image must be under 5 MB.' });
      return;
    }
    const filename = `${crypto.randomUUID()}.${ext}`;
    const targetPath = path.resolve(UPLOADS_DIR, filename);
    if (!targetPath.startsWith(UPLOADS_DIR + path.sep)) {
      res.status(400).json({ error: 'Invalid upload path.' });
      return;
    }
    fs.writeFileSync(targetPath, buffer);
    urls.push(`/uploads/${filename}`);
  }

  res.status(201).json({ urls });
});

// Create Property (Agent or Admin)
app.post('/api/properties', requireRole('agent', 'admin'), (req: AuthenticatedRequest, res) => {
  const body = req.body as Record<string, unknown>;
  const title = typeof body.title === 'string' ? body.title.trim() : '';
  const description = typeof body.description === 'string' ? body.description.trim() : '';
  const price = Number(body.price);
  const listingType = body.listing_type === 'rent' ? 'rent' : 'buy';
  const allowedTypes = ['Apartment', 'Villa', 'House', 'Penthouse', 'Commercial', 'Plot'];
  const propertyType = allowedTypes.includes(String(body.property_type)) ? String(body.property_type) : 'House';
  const allowedStatuses = ['Available', 'Under Offer', 'Sold', 'Rented'];
  const status = allowedStatuses.includes(String(body.status)) ? String(body.status) : 'Available';
  const allowedFurnishing = ['Furnished', 'Semi-Furnished', 'Unfurnished'];
  const furnishing = allowedFurnishing.includes(String(body.furnishing)) ? String(body.furnishing) : 'Furnished';

  const address = typeof body.address === 'string' ? body.address.trim() : '';
  const city = typeof body.city === 'string' ? body.city.trim() : '';
  const neighborhood = typeof body.neighborhood === 'string' ? body.neighborhood.trim() : '';
  const areaSqft = Number(body.area_sqft);
  const bedrooms = Math.max(0, Math.min(30, Number(body.bedrooms) || 0));
  const bathrooms = Math.max(0, Math.min(30, Number(body.bathrooms) || 0));
  const yearBuilt = Math.max(1900, Math.min(2030, Number(body.year_built) || 2024));
  const parkingSpots = Math.max(0, Math.min(200, Number(body.parking_spots) || 1));
  const latitude = Number.isFinite(Number(body.latitude)) ? Number(body.latitude) : 34.0522;
  const longitude = Number.isFinite(Number(body.longitude)) ? Number(body.longitude) : -118.2437;

  if (title.length < 4 || description.length < 15 || !address || !city || !Number.isFinite(price) || price <= 0 || !Number.isFinite(areaSqft) || areaSqft <= 0) {
    res.status(400).json({ error: 'Please complete all required property fields with valid numbers.' });
    return;
  }

  const amenities = Array.isArray(body.amenities)
    ? body.amenities.filter((a): a is string => typeof a === 'string' && a.trim().length > 0).slice(0, 20)
    : [];

  const rawImages = Array.isArray(body.images) ? body.images : [];
  const images = rawImages
    .filter((img): img is string => typeof img === 'string')
    .map(sanitizeImageUrl)
    .filter((img): img is string => img !== null)
    .slice(0, 10);

  if (images.length === 0) {
    images.push('/src/assets/images/prop_modern_penthouse_1795250753657.jpg');
  }

  const approvalStatus = req.user!.role === 'admin' ? 'Approved' : 'Pending';
  const featured = req.user!.role === 'admin' && body.featured ? 1 : 0;

  const result = db
    .prepare(
      `INSERT INTO properties (
        title, description, price, listing_type, property_type, status, approval_status, featured,
        address, city, neighborhood, latitude, longitude, bedrooms, bathrooms, area_sqft,
        furnishing, year_built, parking_spots, amenities, images, agent_id
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(
      title,
      description,
      Math.round(price),
      listingType,
      propertyType,
      status,
      approvalStatus,
      featured,
      address,
      city,
      neighborhood || city,
      latitude,
      longitude,
      bedrooms,
      bathrooms,
      Math.round(areaSqft),
      furnishing,
      yearBuilt,
      parkingSpots,
      JSON.stringify(amenities),
      JSON.stringify(images),
      req.user!.id
    );

  const created = db
    .prepare(
      `SELECT p.*, u.name as agent_name, u.phone as agent_phone, u.email as agent_email, u.avatar_url as agent_avatar, u.is_verified as agent_verified
       FROM properties p JOIN users u ON u.id = p.agent_id WHERE p.id = ?`
    )
    .get(result.lastInsertRowid) as Record<string, unknown>;

  res.status(201).json({ property: formatPropertyRow(created) });
});

// Update Property (Owner Agent or Admin)
app.put('/api/properties/:id', requireRole('agent', 'admin'), (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  const existing = db.prepare('SELECT * FROM properties WHERE id = ?').get(id) as Record<string, unknown> | undefined;
  if (!existing) {
    res.status(404).json({ error: 'Property not found.' });
    return;
  }
  if (req.user!.role !== 'admin' && Number(existing.agent_id) !== req.user!.id) {
    res.status(403).json({ error: 'You can only edit your own listings.' });
    return;
  }

  const body = req.body as Record<string, unknown>;
  const title = typeof body.title === 'string' && body.title.trim() ? body.title.trim() : String(existing.title);
  const description = typeof body.description === 'string' && body.description.trim() ? body.description.trim() : String(existing.description);
  const price = Number.isFinite(Number(body.price)) && Number(body.price) > 0 ? Math.round(Number(body.price)) : Number(existing.price);
  const listingType = body.listing_type === 'rent' || body.listing_type === 'buy' ? body.listing_type : String(existing.listing_type);
  const allowedTypes = ['Apartment', 'Villa', 'House', 'Penthouse', 'Commercial', 'Plot'];
  const propertyType = allowedTypes.includes(String(body.property_type)) ? String(body.property_type) : String(existing.property_type);
  const allowedStatuses = ['Available', 'Under Offer', 'Sold', 'Rented'];
  const status = allowedStatuses.includes(String(body.status)) ? String(body.status) : String(existing.status);
  const allowedFurnishing = ['Furnished', 'Semi-Furnished', 'Unfurnished'];
  const furnishing = allowedFurnishing.includes(String(body.furnishing)) ? String(body.furnishing) : String(existing.furnishing);

  const address = typeof body.address === 'string' && body.address.trim() ? body.address.trim() : String(existing.address);
  const city = typeof body.city === 'string' && body.city.trim() ? body.city.trim() : String(existing.city);
  const neighborhood = typeof body.neighborhood === 'string' && body.neighborhood.trim() ? body.neighborhood.trim() : String(existing.neighborhood);
  const bedrooms = body.bedrooms !== undefined ? Math.max(0, Number(body.bedrooms) || 0) : Number(existing.bedrooms);
  const bathrooms = body.bathrooms !== undefined ? Math.max(0, Number(body.bathrooms) || 0) : Number(existing.bathrooms);
  const areaSqft = body.area_sqft !== undefined && Number(body.area_sqft) > 0 ? Math.round(Number(body.area_sqft)) : Number(existing.area_sqft);
  const parkingSpots = body.parking_spots !== undefined ? Math.max(0, Number(body.parking_spots) || 0) : Number(existing.parking_spots);

  const amenitiesJson = Array.isArray(body.amenities)
    ? JSON.stringify(body.amenities.filter((a): a is string => typeof a === 'string'))
    : String(existing.amenities);

  let imagesJson = String(existing.images);
  if (Array.isArray(body.images)) {
    const cleanImgs = body.images
      .filter((img): img is string => typeof img === 'string')
      .map(sanitizeImageUrl)
      .filter((img): img is string => img !== null);
    if (cleanImgs.length > 0) {
      imagesJson = JSON.stringify(cleanImgs);
    }
  }

  const featured = req.user!.role === 'admin' && body.featured !== undefined ? (body.featured ? 1 : 0) : Number(existing.featured);

  db.prepare(
    `UPDATE properties SET
      title = ?, description = ?, price = ?, listing_type = ?, property_type = ?, status = ?,
      furnishing = ?, address = ?, city = ?, neighborhood = ?, bedrooms = ?, bathrooms = ?,
      area_sqft = ?, parking_spots = ?, amenities = ?, images = ?, featured = ?, updated_at = datetime('now')
     WHERE id = ?`
  ).run(
    title,
    description,
    price,
    listingType,
    propertyType,
    status,
    furnishing,
    address,
    city,
    neighborhood,
    bedrooms,
    bathrooms,
    areaSqft,
    parkingSpots,
    amenitiesJson,
    imagesJson,
    featured,
    id
  );

  const updated = db
    .prepare(
      `SELECT p.*, u.name as agent_name, u.phone as agent_phone, u.email as agent_email, u.avatar_url as agent_avatar, u.is_verified as agent_verified
       FROM properties p JOIN users u ON u.id = p.agent_id WHERE p.id = ?`
    )
    .get(id) as Record<string, unknown>;

  res.json({ property: formatPropertyRow(updated) });
});

// Delete Property
app.delete('/api/properties/:id', requireRole('agent', 'admin'), (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  const existing = db.prepare('SELECT agent_id FROM properties WHERE id = ?').get(id) as { agent_id: number } | undefined;
  if (!existing) {
    res.status(404).json({ error: 'Property not found.' });
    return;
  }
  if (req.user!.role !== 'admin' && existing.agent_id !== req.user!.id) {
    res.status(403).json({ error: 'You can only delete your own listings.' });
    return;
  }
  db.prepare('DELETE FROM properties WHERE id = ?').run(id);
  res.json({ deleted: true });
});

// Favorites
app.get('/api/favorites', requireAuth, (req: AuthenticatedRequest, res) => {
  const rows = db
    .prepare(
      `SELECT p.*, u.name as agent_name, u.phone as agent_phone, u.avatar_url as agent_avatar, u.is_verified as agent_verified,
        COALESCE((SELECT AVG(r.rating) FROM reviews r WHERE r.property_id = p.id), 0) as avg_rating,
        (SELECT COUNT(*) FROM reviews r WHERE r.property_id = p.id) as review_count
       FROM favorites f
       JOIN properties p ON p.id = f.property_id
       JOIN users u ON u.id = p.agent_id
       WHERE f.user_id = ?
       ORDER BY f.created_at DESC`
    )
    .all(req.user!.id) as Array<Record<string, unknown>>;

  res.json({
    favorites: rows.map(formatPropertyRow),
    favoriteIds: rows.map((r) => Number(r.id)),
  });
});

app.post('/api/favorites/:propertyId', requireAuth, (req: AuthenticatedRequest, res) => {
  const propertyId = Number(req.params.propertyId);
  const exists = db.prepare('SELECT id FROM properties WHERE id = ?').get(propertyId);
  if (!exists) {
    res.status(404).json({ error: 'Property not found.' });
    return;
  }
  db.prepare('INSERT OR IGNORE INTO favorites (user_id, property_id) VALUES (?, ?)').run(req.user!.id, propertyId);
  res.json({ saved: true });
});

app.delete('/api/favorites/:propertyId', requireAuth, (req: AuthenticatedRequest, res) => {
  const propertyId = Number(req.params.propertyId);
  db.prepare('DELETE FROM favorites WHERE user_id = ? AND property_id = ?').run(req.user!.id, propertyId);
  res.json({ saved: false });
});

// Enquiries
app.get('/api/enquiries', requireAuth, (req: AuthenticatedRequest, res) => {
  let rows: unknown[] = [];
  if (req.user!.role === 'admin') {
    rows = db
      .prepare(
        `SELECT e.*, p.title as property_title, p.city as property_city, p.price as property_price, u.name as agent_name
         FROM enquiries e
         JOIN properties p ON p.id = e.property_id
         JOIN users u ON u.id = p.agent_id
         ORDER BY e.created_at DESC`
      )
      .all();
  } else if (req.user!.role === 'agent') {
    rows = db
      .prepare(
        `SELECT e.*, p.title as property_title, p.city as property_city, p.price as property_price
         FROM enquiries e
         JOIN properties p ON p.id = e.property_id
         WHERE p.agent_id = ? OR e.user_id = ?
         ORDER BY e.created_at DESC`
      )
      .all(req.user!.id, req.user!.id);
  } else {
    rows = db
      .prepare(
        `SELECT e.*, p.title as property_title, p.city as property_city, p.price as property_price, u.name as agent_name
         FROM enquiries e
         JOIN properties p ON p.id = e.property_id
         JOIN users u ON u.id = p.agent_id
         WHERE e.user_id = ?
         ORDER BY e.created_at DESC`
      )
      .all(req.user!.id);
  }
  res.json({ enquiries: rows });
});

app.post('/api/enquiries', attachUserOptional, (req: AuthenticatedRequest, res) => {
  const { property_id, name, email, phone, message } = req.body as {
    property_id?: number;
    name?: string;
    email?: string;
    phone?: string;
    message?: string;
  };
  const propId = Number(property_id);
  if (!Number.isInteger(propId) || !name?.trim() || !isValidEmail(email) || !phone?.trim() || !message?.trim()) {
    res.status(400).json({ error: 'Please fill in your name, valid email, phone, and enquiry message.' });
    return;
  }
  const prop = db.prepare('SELECT id FROM properties WHERE id = ?').get(propId);
  if (!prop) {
    res.status(404).json({ error: 'Property not found.' });
    return;
  }

  const result = db
    .prepare('INSERT INTO enquiries (property_id, user_id, name, email, phone, message) VALUES (?, ?, ?, ?, ?, ?)')
    .run(propId, req.user?.id || null, name.trim(), email.trim().toLowerCase(), phone.trim(), message.trim());

  const enquiry = db.prepare('SELECT * FROM enquiries WHERE id = ?').get(result.lastInsertRowid);
  res.status(201).json({ enquiry });
});

app.patch('/api/enquiries/:id', requireRole('agent', 'admin'), (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  const existing = db
    .prepare('SELECT e.*, p.agent_id FROM enquiries e JOIN properties p ON p.id = e.property_id WHERE e.id = ?')
    .get(id) as { id: number; agent_id: number; status: string; admin_notes: string } | undefined;

  if (!existing) {
    res.status(404).json({ error: 'Enquiry not found.' });
    return;
  }
  if (req.user!.role === 'agent' && existing.agent_id !== req.user!.id) {
    res.status(403).json({ error: 'Not authorized for this enquiry.' });
    return;
  }

  const { status, admin_notes } = req.body as { status?: string; admin_notes?: string };
  const allowed = ['New', 'In Progress', 'Resolved'];
  const nextStatus = allowed.includes(String(status)) ? String(status) : existing.status;
  const nextNotes = typeof admin_notes === 'string' ? admin_notes.trim() : existing.admin_notes;

  db.prepare('UPDATE enquiries SET status = ?, admin_notes = ? WHERE id = ?').run(nextStatus, nextNotes, id);
  const updated = db.prepare('SELECT * FROM enquiries WHERE id = ?').get(id);
  res.json({ enquiry: updated });
});

// Site Visits
app.get('/api/visits', requireAuth, (req: AuthenticatedRequest, res) => {
  let rows: unknown[] = [];
  if (req.user!.role === 'admin') {
    rows = db
      .prepare(
        `SELECT v.*, p.title as property_title, p.address as property_address, p.city as property_city, u.name as agent_name
         FROM site_visits v
         JOIN properties p ON p.id = v.property_id
         JOIN users u ON u.id = p.agent_id
         ORDER BY v.visit_date ASC, v.visit_time ASC`
      )
      .all();
  } else if (req.user!.role === 'agent') {
    rows = db
      .prepare(
        `SELECT v.*, p.title as property_title, p.address as property_address, p.city as property_city
         FROM site_visits v
         JOIN properties p ON p.id = v.property_id
         WHERE p.agent_id = ? OR v.user_id = ?
         ORDER BY v.visit_date ASC, v.visit_time ASC`
      )
      .all(req.user!.id, req.user!.id);
  } else {
    rows = db
      .prepare(
        `SELECT v.*, p.title as property_title, p.address as property_address, p.city as property_city, u.name as agent_name, u.phone as agent_phone
         FROM site_visits v
         JOIN properties p ON p.id = v.property_id
         JOIN users u ON u.id = p.agent_id
         WHERE v.user_id = ?
         ORDER BY v.visit_date ASC, v.visit_time ASC`
      )
      .all(req.user!.id);
  }
  res.json({ visits: rows });
});

app.post('/api/visits', attachUserOptional, (req: AuthenticatedRequest, res) => {
  const { property_id, visitor_name, visitor_email, visitor_phone, visit_date, visit_time, notes } = req.body as {
    property_id?: number;
    visitor_name?: string;
    visitor_email?: string;
    visitor_phone?: string;
    visit_date?: string;
    visit_time?: string;
    notes?: string;
  };

  const propId = Number(property_id);
  if (!Number.isInteger(propId) || !visitor_name?.trim() || !isValidEmail(visitor_email) || !visitor_phone?.trim() || !visit_date?.trim() || !visit_time?.trim()) {
    res.status(400).json({ error: 'Please complete all required booking details.' });
    return;
  }

  const prop = db.prepare('SELECT id FROM properties WHERE id = ?').get(propId);
  if (!prop) {
    res.status(404).json({ error: 'Property not found.' });
    return;
  }

  const result = db
    .prepare(
      `INSERT INTO site_visits (property_id, user_id, visitor_name, visitor_email, visitor_phone, visit_date, visit_time, notes)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(
      propId,
      req.user?.id || null,
      visitor_name.trim(),
      visitor_email.trim().toLowerCase(),
      visitor_phone.trim(),
      visit_date.trim(),
      visit_time.trim(),
      typeof notes === 'string' ? notes.trim() : ''
    );

  const visit = db.prepare('SELECT * FROM site_visits WHERE id = ?').get(result.lastInsertRowid);
  res.status(201).json({ visit });
});

app.patch('/api/visits/:id', requireAuth, (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  const existing = db
    .prepare('SELECT v.*, p.agent_id FROM site_visits v JOIN properties p ON p.id = v.property_id WHERE v.id = ?')
    .get(id) as { id: number; user_id: number | null; agent_id: number; status: string } | undefined;

  if (!existing) {
    res.status(404).json({ error: 'Site visit booking not found.' });
    return;
  }

  const { status } = req.body as { status?: string };
  const allowed = ['Pending', 'Confirmed', 'Completed', 'Cancelled'];
  if (!status || !allowed.includes(status)) {
    res.status(400).json({ error: 'Invalid visit status.' });
    return;
  }

  const isOwnerCustomer = req.user!.id === existing.user_id && status === 'Cancelled';
  const isAgentOwner = req.user!.role === 'agent' && req.user!.id === existing.agent_id;
  const isAdmin = req.user!.role === 'admin';

  if (!isOwnerCustomer && !isAgentOwner && !isAdmin) {
    res.status(403).json({ error: 'Not authorized to update this booking.' });
    return;
  }

  db.prepare('UPDATE site_visits SET status = ? WHERE id = ?').run(status, id);
  const updated = db.prepare('SELECT * FROM site_visits WHERE id = ?').get(id);
  res.json({ visit: updated });
});

// Reviews
app.post('/api/properties/:id/reviews', attachUserOptional, (req: AuthenticatedRequest, res) => {
  const propId = Number(req.params.id);
  const { reviewer_name, rating, comment } = req.body as { reviewer_name?: string; rating?: number; comment?: string };

  const numRating = Number(rating);
  const finalName = req.user?.name || (typeof reviewer_name === 'string' ? reviewer_name.trim() : '');
  if (!finalName || !Number.isInteger(numRating) || numRating < 1 || numRating > 5 || !comment?.trim()) {
    res.status(400).json({ error: 'Please provide your name, a rating (1-5), and a review comment.' });
    return;
  }

  const prop = db.prepare('SELECT id FROM properties WHERE id = ?').get(propId);
  if (!prop) {
    res.status(404).json({ error: 'Property not found.' });
    return;
  }

  const result = db
    .prepare('INSERT INTO reviews (property_id, user_id, reviewer_name, rating, comment) VALUES (?, ?, ?, ?, ?)')
    .run(propId, req.user?.id || null, finalName, numRating, comment.trim());

  const review = db.prepare('SELECT * FROM reviews WHERE id = ?').get(result.lastInsertRowid);
  res.status(201).json({ review });
});

// Admin endpoints
app.get('/api/admin/users', requireRole('admin'), (_req, res) => {
  const users = db
    .prepare(
      `SELECT u.id, u.name, u.email, u.phone, u.city, u.role, u.is_verified, u.is_active, u.agency_name, u.created_at,
        (SELECT COUNT(*) FROM properties p WHERE p.agent_id = u.id) as listing_count
       FROM users u
       ORDER BY u.created_at DESC`
    )
    .all();
  res.json({ users });
});

app.patch('/api/admin/users/:id', requireRole('admin'), (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  const existing = db.prepare('SELECT * FROM users WHERE id = ?').get(id) as Record<string, unknown> | undefined;
  if (!existing) {
    res.status(404).json({ error: 'User not found.' });
    return;
  }

  const { is_verified, is_active, role } = req.body as { is_verified?: boolean; is_active?: boolean; role?: string };
  const nextVerified = is_verified !== undefined ? (is_verified ? 1 : 0) : Number(existing.is_verified);
  const nextActive = is_active !== undefined ? (is_active ? 1 : 0) : Number(existing.is_active);
  const allowedRoles = ['customer', 'agent', 'admin'];
  const nextRole = role && allowedRoles.includes(role) ? role : String(existing.role);

  if (id === req.user!.id && nextActive === 0) {
    res.status(400).json({ error: 'You cannot suspend your own active admin account.' });
    return;
  }

  db.prepare('UPDATE users SET is_verified = ?, is_active = ?, role = ? WHERE id = ?').run(
    nextVerified,
    nextActive,
    nextRole,
    id
  );

  const updated = db
    .prepare(
      `SELECT u.id, u.name, u.email, u.phone, u.city, u.role, u.is_verified, u.is_active, u.agency_name, u.created_at,
        (SELECT COUNT(*) FROM properties p WHERE p.agent_id = u.id) as listing_count
       FROM users u WHERE u.id = ?`
    )
    .get(id);
  res.json({ user: updated });
});

app.delete('/api/admin/users/:id', requireRole('admin'), (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  if (id === req.user!.id) {
    res.status(400).json({ error: 'Cannot delete your own admin account.' });
    return;
  }
  db.prepare('DELETE FROM users WHERE id = ?').run(id);
  res.json({ deleted: true });
});

app.patch('/api/admin/properties/:id/approval', requireRole('admin'), (req, res) => {
  const id = Number(req.params.id);
  const existing = db.prepare('SELECT * FROM properties WHERE id = ?').get(id) as Record<string, unknown> | undefined;
  if (!existing) {
    res.status(404).json({ error: 'Property not found.' });
    return;
  }

  const { approval_status, featured } = req.body as { approval_status?: string; featured?: boolean };
  const allowed = ['Approved', 'Pending', 'Rejected'];
  const nextApproval = approval_status && allowed.includes(approval_status) ? approval_status : String(existing.approval_status);
  const nextFeatured = featured !== undefined ? (featured ? 1 : 0) : Number(existing.featured);

  db.prepare("UPDATE properties SET approval_status = ?, featured = ?, updated_at = datetime('now') WHERE id = ?").run(
    nextApproval,
    nextFeatured,
    id
  );

  const updated = db
    .prepare(
      `SELECT p.*, u.name as agent_name, u.phone as agent_phone, u.email as agent_email, u.avatar_url as agent_avatar, u.is_verified as agent_verified
       FROM properties p JOIN users u ON u.id = p.agent_id WHERE p.id = ?`
    )
    .get(id) as Record<string, unknown>;

  res.json({ property: formatPropertyRow(updated) });
});

app.get('/api/admin/analytics', requireRole('admin'), (_req, res) => {
  const byType = db
    .prepare('SELECT property_type as label, COUNT(*) as count, COALESCE(SUM(price), 0) as total_value FROM properties GROUP BY property_type')
    .all();
  const byStatus = db
    .prepare('SELECT status as label, COUNT(*) as count FROM properties GROUP BY status')
    .all();
  const byApproval = db
    .prepare('SELECT approval_status as label, COUNT(*) as count FROM properties GROUP BY approval_status')
    .all();
  const topAgents = db
    .prepare(
      `SELECT u.id, u.name, u.agency_name, u.is_verified,
        COUNT(p.id) as listings,
        COALESCE(SUM(p.views_count), 0) as total_views,
        (SELECT COUNT(*) FROM enquiries e JOIN properties p2 ON p2.id = e.property_id WHERE p2.agent_id = u.id) as enquiries_received
       FROM users u
       LEFT JOIN properties p ON p.agent_id = u.id
       WHERE u.role = 'agent'
       GROUP BY u.id
       ORDER BY listings DESC, total_views DESC`
    )
    .all();
  const recentEnquiries = db
    .prepare(
      `SELECT e.*, p.title as property_title
       FROM enquiries e JOIN properties p ON p.id = e.property_id
       ORDER BY e.created_at DESC LIMIT 8`
    )
    .all();

  res.json({ byType, byStatus, byApproval, topAgents, recentEnquiries });
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Dream Homes Realty server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
