import Database from 'better-sqlite3';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const UPLOADS_DIR = path.join(DATA_DIR, 'uploads');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

const DB_PATH = path.join(DATA_DIR, 'dream_homes.db');
export const db = new Database(DB_PATH);

db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  const parts = storedHash.split(':');
  if (parts.length !== 2) return false;
  const [salt, keyHex] = parts;
  const keyBuffer = Buffer.from(keyHex, 'hex');
  const derived = crypto.scryptSync(password, salt, 64);
  if (keyBuffer.length !== derived.length) return false;
  return crypto.timingSafeEqual(keyBuffer, derived);
}

export function initializeDatabase() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      phone TEXT DEFAULT '',
      city TEXT DEFAULT '',
      bio TEXT DEFAULT '',
      avatar_url TEXT DEFAULT '',
      role TEXT NOT NULL CHECK(role IN ('customer', 'agent', 'admin')) DEFAULT 'customer',
      is_verified INTEGER NOT NULL DEFAULT 0,
      is_active INTEGER NOT NULL DEFAULT 1,
      agency_name TEXT DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS admin_claim (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      email TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      claimed_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS properties (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      price INTEGER NOT NULL,
      listing_type TEXT NOT NULL CHECK(listing_type IN ('buy', 'rent')),
      property_type TEXT NOT NULL CHECK(property_type IN ('Apartment', 'Villa', 'House', 'Penthouse', 'Commercial', 'Plot')),
      status TEXT NOT NULL CHECK(status IN ('Available', 'Under Offer', 'Sold', 'Rented')) DEFAULT 'Available',
      approval_status TEXT NOT NULL CHECK(approval_status IN ('Approved', 'Pending', 'Rejected')) DEFAULT 'Approved',
      featured INTEGER NOT NULL DEFAULT 0,
      address TEXT NOT NULL,
      city TEXT NOT NULL,
      neighborhood TEXT NOT NULL,
      latitude REAL NOT NULL DEFAULT 34.0259,
      longitude REAL NOT NULL DEFAULT -118.7798,
      bedrooms INTEGER NOT NULL DEFAULT 0,
      bathrooms INTEGER NOT NULL DEFAULT 0,
      area_sqft INTEGER NOT NULL,
      furnishing TEXT NOT NULL CHECK(furnishing IN ('Furnished', 'Semi-Furnished', 'Unfurnished')) DEFAULT 'Furnished',
      year_built INTEGER NOT NULL DEFAULT 2024,
      parking_spots INTEGER NOT NULL DEFAULT 2,
      amenities TEXT NOT NULL DEFAULT '[]',
      images TEXT NOT NULL DEFAULT '[]',
      agent_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      views_count INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS favorites (
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      property_id INTEGER NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      PRIMARY KEY (user_id, property_id)
    );

    CREATE TABLE IF NOT EXISTS enquiries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      property_id INTEGER NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
      user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
      name TEXT NOT NULL,
      email TEXT NOT NULL,
      phone TEXT NOT NULL,
      message TEXT NOT NULL,
      status TEXT NOT NULL CHECK(status IN ('New', 'In Progress', 'Resolved')) DEFAULT 'New',
      admin_notes TEXT DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS site_visits (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      property_id INTEGER NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
      user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
      visitor_name TEXT NOT NULL,
      visitor_email TEXT NOT NULL,
      visitor_phone TEXT NOT NULL,
      visit_date TEXT NOT NULL,
      visit_time TEXT NOT NULL,
      notes TEXT DEFAULT '',
      status TEXT NOT NULL CHECK(status IN ('Pending', 'Confirmed', 'Completed', 'Cancelled')) DEFAULT 'Pending',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS reviews (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      property_id INTEGER NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
      user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
      reviewer_name TEXT NOT NULL,
      rating INTEGER NOT NULL CHECK(rating >= 1 AND rating <= 5),
      comment TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);

  const userCountRow = db.prepare('SELECT COUNT(*) as count FROM users').get() as { count: number };
  if (userCountRow.count === 0) {
    seedInitialData();
  }
}

function seedInitialData() {
  const insertUser = db.prepare(`
    INSERT INTO users (name, email, password_hash, phone, city, bio, avatar_url, role, is_verified, is_active, agency_name)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const agent1Hash = hashPassword(crypto.randomBytes(24).toString('hex'));
  const agent2Hash = hashPassword(crypto.randomBytes(24).toString('hex'));
  const cust1Hash = hashPassword(crypto.randomBytes(24).toString('hex'));
  const cust2Hash = hashPassword(crypto.randomBytes(24).toString('hex'));

  const agent1Res = insertUser.run(
    'Elena Vance',
    'elena.vance@dreamhomes.realty',
    agent1Hash,
    '+1 (310) 555-0148',
    'Los Angeles, CA',
    'Senior Luxury Estates Advisor specializing in coastal villas and architectural penthouses.',
    '/src/assets/images/agent_portrait_one_1795250754201.jpg',
    'agent',
    1,
    1,
    'Dream Homes Private Estates'
  );

  const agent2Res = insertUser.run(
    'Marcus Thorne',
    'marcus.thorne@dreamhomes.realty',
    agent2Hash,
    '+1 (212) 555-0192',
    'New York, NY',
    'Principal Commercial & Urban Residential Broker with 14 years across prime metropolitan markets.',
    '/src/assets/images/agent_portrait_two_1795250754358.jpg',
    'agent',
    1,
    1,
    'Dream Homes Commercial & Urban'
  );

  const cust1Res = insertUser.run(
    'Claire Sterling',
    'claire.sterling@example.com',
    cust1Hash,
    '+1 (415) 555-0164',
    'San Francisco, CA',
    'Architect exploring coastal villas and modern city lofts.',
    '',
    'customer',
    1,
    1,
    ''
  );

  insertUser.run(
    'Julian Mercer',
    'julian.mercer@example.com',
    cust2Hash,
    '+1 (512) 555-0133',
    'Austin, TX',
    'Commercial investor seeking Class-A workspace assets.',
    '',
    'customer',
    1,
    1,
    ''
  );

  const agent1Id = Number(agent1Res.lastInsertRowid);
  const agent2Id = Number(agent2Res.lastInsertRowid);
  const cust1Id = Number(cust1Res.lastInsertRowid);

  const insertProperty = db.prepare(`
    INSERT INTO properties (
      title, description, price, listing_type, property_type, status, approval_status, featured,
      address, city, neighborhood, latitude, longitude, bedrooms, bathrooms, area_sqft,
      furnishing, year_built, parking_spots, amenities, images, agent_id, views_count
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const sampleProperties = [
    {
      title: 'The Cliffside Horizon Villa',
      description:
        'An extraordinary architectural sanctuary perched above the Pacific coastline. Designed with floor-to-ceiling low-iron glass walls, warm travertine stone floors, a zero-edge infinity pool, and seamless indoor-outdoor dining terraces.',
      price: 4850000,
      listing_type: 'buy',
      property_type: 'Villa',
      status: 'Available',
      approval_status: 'Approved',
      featured: 1,
      address: '28400 Pacific Coast Hwy',
      city: 'Malibu, CA',
      neighborhood: 'Point Dume',
      latitude: 34.0061,
      longitude: -118.8065,
      bedrooms: 5,
      bathrooms: 6,
      area_sqft: 5400,
      furnishing: 'Furnished',
      year_built: 2025,
      parking_spots: 4,
      amenities: JSON.stringify(['Infinity Pool', 'Ocean View', 'Smart Home', 'Wine Cellar', 'Private Gym', 'Solar Power', '24/7 Security']),
      images: JSON.stringify([
        '/src/assets/images/hero_luxury_villa_1795250754036.jpg',
        '/src/assets/images/prop_coastal_residence_1795250754032.jpg',
        '/src/assets/images/prop_modern_penthouse_1795250753657.jpg',
      ]),
      agent_id: agent1Id,
      views_count: 412,
    },
    {
      title: 'Skyline Residence at One Central',
      description:
        'Full-floor penthouse offering 270-degree metropolitan skyline views through 14-foot acoustic glazing. Features chevron European oak floors, a chef-grade Gaggenau kitchen, private elevator foyer, and dedicated concierge.',
      price: 3250000,
      listing_type: 'buy',
      property_type: 'Penthouse',
      status: 'Available',
      approval_status: 'Approved',
      featured: 1,
      address: '440 Park Avenue South, PH-A',
      city: 'New York, NY',
      neighborhood: 'Midtown South',
      latitude: 40.7443,
      longitude: -73.9832,
      bedrooms: 3,
      bathrooms: 4,
      area_sqft: 3150,
      furnishing: 'Furnished',
      year_built: 2024,
      parking_spots: 2,
      amenities: JSON.stringify(['Private Elevator', 'Sky Terrace', 'Concierge', 'Fitness Club', 'Smart Climate', 'EV Charging']),
      images: JSON.stringify([
        '/src/assets/images/prop_modern_penthouse_1795250753657.jpg',
        '/src/assets/images/prop_studio_loft_1795250754003.jpg',
      ]),
      agent_id: agent2Id,
      views_count: 358,
    },
    {
      title: 'Cedars Courtyard Coastal Home',
      description:
        'Sun-drenched contemporary courtyard residence framed by warm western red cedar soffits and crisp limestone terraces. Centered around a heated lap pool and lush subtropical garden courtyard just steps from the cove.',
      price: 14500,
      listing_type: 'rent',
      property_type: 'Villa',
      status: 'Available',
      approval_status: 'Approved',
      featured: 1,
      address: '718 Camino Del Mar',
      city: 'La Jolla, CA',
      neighborhood: 'Bird Rock',
      latitude: 32.8145,
      longitude: -117.2699,
      bedrooms: 4,
      bathrooms: 4,
      area_sqft: 3680,
      furnishing: 'Furnished',
      year_built: 2023,
      parking_spots: 3,
      amenities: JSON.stringify(['Courtyard Pool', 'Outdoor Kitchen', 'Home Office', 'Ocean Breeze Terrace', 'Smart Locks']),
      images: JSON.stringify([
        '/src/assets/images/prop_coastal_residence_1795250754032.jpg',
        '/src/assets/images/hero_luxury_villa_1795250754036.jpg',
      ]),
      agent_id: agent1Id,
      views_count: 289,
    },
    {
      title: 'Aurora Flagship Commercial Center',
      description:
        'LEED Gold Class-A commercial headquarters featuring anodized bronze curtain-wall glazing, column-free floor plates, private landscaped courtyard plaza, and direct transit access in the innovation corridor.',
      price: 6900000,
      listing_type: 'buy',
      property_type: 'Commercial',
      status: 'Available',
      approval_status: 'Approved',
      featured: 0,
      address: '140 Fortitude Boulevard',
      city: 'Austin, TX',
      neighborhood: 'Downtown Innovation District',
      latitude: 30.2672,
      longitude: -97.7431,
      bedrooms: 0,
      bathrooms: 8,
      area_sqft: 18500,
      furnishing: 'Semi-Furnished',
      year_built: 2024,
      parking_spots: 42,
      amenities: JSON.stringify(['24/7 Access Control', 'Fiber Backbone', 'Executive Lounge', 'Underground Garage', 'EV Superchargers', 'Rooftop Deck']),
      images: JSON.stringify([
        '/src/assets/images/prop_commercial_tower_1795250754667.jpg',
        '/src/assets/images/prop_modern_penthouse_1795250753657.jpg',
      ]),
      agent_id: agent2Id,
      views_count: 194,
    },
    {
      title: 'Oakridge Limestone Family Estate',
      description:
        'Timeless craftsmanship meets contemporary living on a quiet tree-lined avenue. Includes custom steel-framed windows, chef pantry, library study, landscaped half-acre grounds, and heated three-car carriage garage.',
      price: 2190000,
      listing_type: 'buy',
      property_type: 'House',
      status: 'Available',
      approval_status: 'Approved',
      featured: 1,
      address: '892 Oakridge Manor Lane',
      city: 'Greenwich, CT',
      neighborhood: 'Belle Haven',
      latitude: 41.0112,
      longitude: -73.6305,
      bedrooms: 5,
      bathrooms: 5,
      area_sqft: 4650,
      furnishing: 'Semi-Furnished',
      year_built: 2022,
      parking_spots: 3,
      amenities: JSON.stringify(['Private Garden', 'Library Study', 'Fireplace', '3-Car Garage', 'Mudroom', 'Security System']),
      images: JSON.stringify([
        '/src/assets/images/prop_suburban_manor_1795250753973.jpg',
        '/src/assets/images/prop_modern_penthouse_1795250753657.jpg',
      ]),
      agent_id: agent1Id,
      views_count: 247,
    },
    {
      title: 'The Foundry Arched Designer Loft',
      description:
        'Converted heritage warehouse residence featuring soaring 18-foot ceilings, iconic arched steel windows, mezzanine study, custom matte-navy cabinetry, and brass architectural fixtures in the Arts District.',
      price: 5800,
      listing_type: 'rent',
      property_type: 'Apartment',
      status: 'Available',
      approval_status: 'Approved',
      featured: 0,
      address: '315 Mateo Street, Loft 4B',
      city: 'Chicago, IL',
      neighborhood: 'Fulton Market',
      latitude: 41.8868,
      longitude: -87.6499,
      bedrooms: 2,
      bathrooms: 2,
      area_sqft: 1850,
      furnishing: 'Furnished',
      year_built: 2021,
      parking_spots: 1,
      amenities: JSON.stringify(['18ft Ceilings', 'Mezzanine Studio', 'Hardwood Floors', 'Rooftop Lounge', 'Pet Friendly', 'Bike Storage']),
      images: JSON.stringify([
        '/src/assets/images/prop_studio_loft_1795250754003.jpg',
        '/src/assets/images/prop_modern_penthouse_1795250753657.jpg',
      ]),
      agent_id: agent2Id,
      views_count: 301,
    },
    {
      title: 'Harborview Executive Suite Lease',
      description:
        'Turnkey commercial floor plate tailored for boutique wealth advisory, architecture studios, or technology teams. Includes boardroom glazing, acoustic phone booths, kitchen bar, and panoramic bay light.',
      price: 18900,
      listing_type: 'rent',
      property_type: 'Commercial',
      status: 'Available',
      approval_status: 'Approved',
      featured: 0,
      address: '500 Embarcadero Center, Suite 900',
      city: 'San Francisco, CA',
      neighborhood: 'Financial District',
      latitude: 37.7955,
      longitude: -122.3937,
      bedrooms: 0,
      bathrooms: 4,
      area_sqft: 5200,
      furnishing: 'Furnished',
      year_built: 2023,
      parking_spots: 10,
      amenities: JSON.stringify(['Boardroom', 'High-Speed Fiber', 'Concierge Lobby', 'Transit Adjacent', 'Shower Lockers']),
      images: JSON.stringify([
        '/src/assets/images/prop_commercial_tower_1795250754667.jpg',
        '/src/assets/images/prop_studio_loft_1795250754003.jpg',
      ]),
      agent_id: agent2Id,
      views_count: 142,
    },
    {
      title: 'Crestline Garden Residence',
      description:
        'Bright corner residence tucked into a tranquil hillside enclave. Offers open-concept dining, wide-plank oak flooring, private balcony garden, and resort-style courtyard amenities.',
      price: 4200,
      listing_type: 'rent',
      property_type: 'Apartment',
      status: 'Under Offer',
      approval_status: 'Approved',
      featured: 0,
      address: '1120 Crestline Drive, Apt 302',
      city: 'Seattle, WA',
      neighborhood: 'Queen Anne',
      latitude: 47.6323,
      longitude: -122.3571,
      bedrooms: 2,
      bathrooms: 2,
      area_sqft: 1420,
      furnishing: 'Semi-Furnished',
      year_built: 2023,
      parking_spots: 1,
      amenities: JSON.stringify(['Private Balcony', 'EV Garage', 'Fitness Studio', 'Package Concierge']),
      images: JSON.stringify([
        '/src/assets/images/prop_suburban_manor_1795250753973.jpg',
        '/src/assets/images/prop_coastal_residence_1795250754032.jpg',
      ]),
      agent_id: agent1Id,
      views_count: 165,
    },
  ];

  const propIds: number[] = [];
  for (const p of sampleProperties) {
    const res = insertProperty.run(
      p.title,
      p.description,
      p.price,
      p.listing_type,
      p.property_type,
      p.status,
      p.approval_status,
      p.featured,
      p.address,
      p.city,
      p.neighborhood,
      p.latitude,
      p.longitude,
      p.bedrooms,
      p.bathrooms,
      p.area_sqft,
      p.furnishing,
      p.year_built,
      p.parking_spots,
      p.amenities,
      p.images,
      p.agent_id,
      p.views_count
    );
    propIds.push(Number(res.lastInsertRowid));
  }

  // Seed reviews
  const insertReview = db.prepare(`
    INSERT INTO reviews (property_id, user_id, reviewer_name, rating, comment)
    VALUES (?, ?, ?, ?, ?)
  `);
  insertReview.run(
    propIds[0],
    cust1Id,
    'Claire Sterling',
    5,
    'The ocean horizon views at sunset are unreal. Elena arranged a seamless twilight tour and provided full structural specs.'
  );
  insertReview.run(
    propIds[1],
    cust1Id,
    'Claire Sterling',
    5,
    'Quiet acoustic glazing and immaculate travertine finishes throughout the great room.'
  );
  insertReview.run(
    propIds[5],
    null,
    'Daniel Park',
    4,
    'Incredible natural light from the arched steel windows. Great proximity to restaurants and transit.'
  );

  // Seed sample enquiries
  const insertEnquiry = db.prepare(`
    INSERT INTO enquiries (property_id, user_id, name, email, phone, message, status)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);
  insertEnquiry.run(
    propIds[0],
    cust1Id,
    'Claire Sterling',
    'claire.sterling@example.com',
    '+1 (415) 555-0164',
    'Interested in reviewing the architectural floor plans and solar battery capacity before scheduling a second visit.',
    'In Progress'
  );
  insertEnquiry.run(
    propIds[3],
    null,
    'Julian Mercer',
    'julian.mercer@example.com',
    '+1 (512) 555-0133',
    'Could we receive the current commercial cap rate sheet and tenant floor plate breakdown?',
    'New'
  );

  // Seed sample site visit
  const insertVisit = db.prepare(`
    INSERT INTO site_visits (property_id, user_id, visitor_name, visitor_email, visitor_phone, visit_date, visit_time, notes, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  insertVisit.run(
    propIds[0],
    cust1Id,
    'Claire Sterling',
    'claire.sterling@example.com',
    '+1 (415) 555-0164',
    '2026-11-28',
    '16:00',
    'Would like to see the twilight pool lighting and terrace.',
    'Confirmed'
  );
}
