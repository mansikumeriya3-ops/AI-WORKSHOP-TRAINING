import type {
  AnalyticsData,
  DashboardStats,
  Enquiry,
  Property,
  PropertyFilters,
  Review,
  SiteVisit,
  User,
} from '../types';

let memoryToken: string | null = null;

export function setAuthToken(token: string | null) {
  memoryToken = token;
}

export function getAuthToken(): string | null {
  return memoryToken;
}

async function request<T>(url: string, options: RequestInit = {}): Promise<T> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...((options.headers as Record<string, string>) || {}),
  };
  if (memoryToken) {
    headers.Authorization = `Bearer ${memoryToken}`;
  }

  const res = await fetch(url, { ...options, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error((data as { error?: string }).error || `Request failed (${res.status})`);
  }
  return data as T;
}

export const api = {
  getStats: () => request<DashboardStats>('/api/stats'),

  getAdminStatus: () => request<{ claimed: boolean; envConfigured: boolean }>('/api/auth/admin-status'),

  claimAdmin: (payload: { name: string; email: string; password: string }) =>
    request<{ token: string; user: User }>('/api/auth/claim-admin', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  register: (payload: {
    name: string;
    email: string;
    password: string;
    phone?: string;
    city?: string;
    role: 'customer' | 'agent';
    agency_name?: string;
  }) =>
    request<{ token: string; user: User }>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  login: (payload: { email?: string; password?: string; adminPasscode?: string }) =>
    request<{ token: string; user: User }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  getMe: () => request<{ user: User }>('/api/auth/me'),

  updateProfile: (payload: { name: string; phone: string; city: string; bio: string; agency_name: string }) =>
    request<{ user: User }>('/api/auth/profile', {
      method: 'PUT',
      body: JSON.stringify(payload),
    }),

  getSuggestions: (q: string) =>
    request<{ suggestions: string[] }>(`/api/properties/suggestions?q=${encodeURIComponent(q)}`),

  getProperties: (filters: Partial<PropertyFilters> & { featured?: boolean; agentOnly?: boolean; includeAll?: boolean } = {}) => {
    const params = new URLSearchParams();
    if (filters.q) params.set('q', filters.q);
    if (filters.location) params.set('location', filters.location);
    if (filters.listingType) params.set('listingType', filters.listingType);
    if (filters.propertyType && filters.propertyType !== 'All') params.set('propertyType', filters.propertyType);
    if (filters.minPrice) params.set('minPrice', filters.minPrice);
    if (filters.maxPrice) params.set('maxPrice', filters.maxPrice);
    if (filters.bedrooms && filters.bedrooms !== '0') params.set('bedrooms', filters.bedrooms);
    if (filters.bathrooms && filters.bathrooms !== '0') params.set('bathrooms', filters.bathrooms);
    if (filters.minArea) params.set('minArea', filters.minArea);
    if (filters.maxArea) params.set('maxArea', filters.maxArea);
    if (filters.furnishing && filters.furnishing !== 'All') params.set('furnishing', filters.furnishing);
    if (filters.sort) params.set('sort', filters.sort);
    if (filters.featured) params.set('featured', '1');
    if (filters.agentOnly) params.set('agentOnly', '1');
    if (filters.includeAll) params.set('includeAll', '1');

    const qs = params.toString();
    return request<{ properties: Property[] }>(`/api/properties${qs ? `?${qs}` : ''}`);
  },

  getPropertyDetail: (id: number) =>
    request<{ property: Property; reviews: Review[]; recommended: Property[] }>(`/api/properties/${id}`),

  uploadImages: (files: Array<{ name: string; dataUrl: string }>) =>
    request<{ urls: string[] }>('/api/upload', {
      method: 'POST',
      body: JSON.stringify({ files }),
    }),

  createProperty: (payload: Record<string, unknown>) =>
    request<{ property: Property }>('/api/properties', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  updateProperty: (id: number, payload: Record<string, unknown>) =>
    request<{ property: Property }>(`/api/properties/${id}`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    }),

  deleteProperty: (id: number) =>
    request<{ deleted: boolean }>(`/api/properties/${id}`, { method: 'DELETE' }),

  getFavorites: () => request<{ favorites: Property[]; favoriteIds: number[] }>('/api/favorites'),

  addFavorite: (propertyId: number) =>
    request<{ saved: boolean }>(`/api/favorites/${propertyId}`, { method: 'POST' }),

  removeFavorite: (propertyId: number) =>
    request<{ saved: boolean }>(`/api/favorites/${propertyId}`, { method: 'DELETE' }),

  getEnquiries: () => request<{ enquiries: Enquiry[] }>('/api/enquiries'),

  submitEnquiry: (payload: { property_id: number; name: string; email: string; phone: string; message: string }) =>
    request<{ enquiry: Enquiry }>('/api/enquiries', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  updateEnquiry: (id: number, payload: { status?: string; admin_notes?: string }) =>
    request<{ enquiry: Enquiry }>(`/api/enquiries/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),

  getVisits: () => request<{ visits: SiteVisit[] }>('/api/visits'),

  scheduleVisit: (payload: {
    property_id: number;
    visitor_name: string;
    visitor_email: string;
    visitor_phone: string;
    visit_date: string;
    visit_time: string;
    notes?: string;
  }) =>
    request<{ visit: SiteVisit }>('/api/visits', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  updateVisitStatus: (id: number, status: SiteVisit['status']) =>
    request<{ visit: SiteVisit }>(`/api/visits/${id}`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    }),

  addReview: (propertyId: number, payload: { reviewer_name?: string; rating: number; comment: string }) =>
    request<{ review: Review }>(`/api/properties/${propertyId}/reviews`, {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  adminGetUsers: () => request<{ users: User[] }>('/api/admin/users'),

  adminUpdateUser: (id: number, payload: { is_verified?: boolean; is_active?: boolean; role?: string }) =>
    request<{ user: User }>(`/api/admin/users/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),

  adminDeleteUser: (id: number) =>
    request<{ deleted: boolean }>(`/api/admin/users/${id}`, { method: 'DELETE' }),

  adminUpdatePropertyApproval: (id: number, payload: { approval_status?: string; featured?: boolean }) =>
    request<{ property: Property }>(`/api/admin/properties/${id}/approval`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),

  adminGetAnalytics: () => request<AnalyticsData>('/api/admin/analytics'),
};
