import React, { useCallback, useEffect, useState } from 'react';
import { GitCompareArrows, Heart } from 'lucide-react';
import { MotionConfig, motion } from 'motion/react';
import { api, setAuthToken } from './api/client';
import { AdminPanel } from './components/AdminPanel';
import { AgentPortal } from './components/AgentPortal';
import { AuthModal } from './components/AuthModal';
import { CompareView } from './components/CompareView';
import { DashboardHome } from './components/DashboardHome';
import { EMICalculator } from './components/EMICalculator';
import { Navbar, type ActiveTab } from './components/Navbar';
import { OfflineIndicator } from './components/OfflineIndicator';
import { PropertyCard } from './components/PropertyCard';
import { PropertyDetailModal } from './components/PropertyDetailModal';
import { DEFAULT_FILTERS, SearchFilterBar } from './components/SearchFilterBar';
import { UserPortal } from './components/UserPortal';
import type { DashboardStats, Property, PropertyFilters, User } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('home');
  const [user, setUser] = useState<User | null>(null);
  const [authModalOpen, setAuthModalOpen] = useState(false);

  const [stats, setStats] = useState<DashboardStats>({
    totalProperties: 0,
    forSaleCount: 0,
    forRentCount: 0,
    totalUsers: 0,
    pendingApprovalCount: 0,
    totalEnquiries: 0,
    totalVisits: 0,
  });

  const [allProperties, setAllProperties] = useState<Property[]>([]);
  const [filteredProperties, setFilteredProperties] = useState<Property[]>([]);
  const [filters, setFilters] = useState<PropertyFilters>(DEFAULT_FILTERS);
  const [loadingProperties, setLoadingProperties] = useState(true);

  const [selectedPropertyId, setSelectedPropertyId] = useState<number | null>(null);
  const [favorites, setFavorites] = useState<Property[]>([]);
  const [favoriteIds, setFavoriteIds] = useState<number[]>([]);
  const [compareList, setCompareList] = useState<Property[]>([]);

  const loadStatsAndFeatured = useCallback(() => {
    api.getStats().then(setStats).catch(() => {});
    api
      .getProperties({ sort: 'featured' })
      .then((res) => setAllProperties(res.properties))
      .catch(() => {});
  }, []);

  const loadFilteredProperties = useCallback((f: PropertyFilters) => {
    setLoadingProperties(true);
    api
      .getProperties(f)
      .then((res) => setFilteredProperties(res.properties))
      .catch(() => {})
      .finally(() => setLoadingProperties(false));
  }, []);

  const loadFavorites = useCallback(() => {
    if (!user) return;
    api
      .getFavorites()
      .then((res) => {
        setFavorites(res.favorites);
        setFavoriteIds(res.favoriteIds);
      })
      .catch(() => {});
  }, [user]);

  useEffect(() => {
    loadStatsAndFeatured();
  }, [loadStatsAndFeatured]);

  useEffect(() => {
    const timer = setTimeout(() => {
      loadFilteredProperties(filters);
    }, 150);
    return () => clearTimeout(timer);
  }, [filters, loadFilteredProperties]);

  useEffect(() => {
    if (user) {
      loadFavorites();
    }
  }, [user, loadFavorites]);

  const handleAuthSuccess = (authedUser: User, token: string) => {
    setAuthToken(token);
    setUser(authedUser);
    setAuthModalOpen(false);
    loadStatsAndFeatured();
    if (authedUser.role === 'admin' || authedUser.role === 'agent') {
      setActiveTab('portal');
    }
  };

  const handleLogout = () => {
    setAuthToken(null);
    setUser(null);
    setFavorites([]);
    setFavoriteIds([]);
    if (activeTab === 'portal') {
      setActiveTab('home');
    }
  };

  const handleToggleFavorite = async (propertyId: number) => {
    const currentlySaved = favoriteIds.includes(propertyId);
    if (user) {
      try {
        if (currentlySaved) {
          await api.removeFavorite(propertyId);
          setFavoriteIds((prev) => prev.filter((id) => id !== propertyId));
          setFavorites((prev) => prev.filter((p) => p.id !== propertyId));
        } else {
          await api.addFavorite(propertyId);
          loadFavorites();
        }
      } catch {
        // ignore
      }
    } else {
      // Guest in-session shortlist
      if (currentlySaved) {
        setFavoriteIds((prev) => prev.filter((id) => id !== propertyId));
        setFavorites((prev) => prev.filter((p) => p.id !== propertyId));
      } else {
        const match = allProperties.find((p) => p.id === propertyId) || filteredProperties.find((p) => p.id === propertyId);
        setFavoriteIds((prev) => [...prev, propertyId]);
        if (match) {
          setFavorites((prev) => [match, ...prev]);
        }
      }
    }
  };

  const handleToggleCompare = (property: Property) => {
    setCompareList((prev) => {
      if (prev.some((p) => p.id === property.id)) {
        return prev.filter((p) => p.id !== property.id);
      }
      if (prev.length >= 3) {
        return [...prev.slice(1), property];
      }
      return [...prev, property];
    });
  };

  const handleQuickSearch = (location: string, listingType: '' | 'buy' | 'rent') => {
    setFilters({ ...DEFAULT_FILTERS, location, listingType });
    setActiveTab('explore');
  };

  const compareIds = compareList.map((p) => p.id);

  return (
    <MotionConfig reducedMotion="user">
      <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
        <Navbar
          activeTab={activeTab}
          onTabChange={(tab) => {
            if (tab === 'portal' && !user) {
              setAuthModalOpen(true);
            } else {
              setActiveTab(tab);
            }
          }}
          user={user}
          compareCount={compareList.length}
          favoritesCount={favoriteIds.length}
          onOpenAuth={() => setAuthModalOpen(true)}
          onLogout={handleLogout}
        />

        <main className="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-8 py-6 sm:py-10 pb-24 lg:pb-12">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.18 }}
          >
            {activeTab === 'home' && (
              <DashboardHome
                stats={stats}
                properties={allProperties}
                favoriteIds={favoriteIds}
                compareIds={compareIds}
                onQuickSearch={handleQuickSearch}
                onSelectProperty={(p) => setSelectedPropertyId(p.id)}
                onToggleFavorite={handleToggleFavorite}
                onToggleCompare={handleToggleCompare}
                onExploreAll={() => setActiveTab('explore')}
                onOpenEmi={() => setActiveTab('emi')}
              />
            )}

            {activeTab === 'explore' && (
              <div className="space-y-6">
                <div className="flex flex-wrap items-end justify-between gap-4">
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-wider text-[#9A7213]">Property Catalog</p>
                    <h1 className="mt-1 font-display text-2xl sm:text-3xl font-semibold text-[#0B1D3A]">
                      Explore Verified Estates
                    </h1>
                  </div>
                  {compareList.length > 0 && (
                    <button
                      type="button"
                      onClick={() => setActiveTab('compare')}
                      className="inline-flex min-h-[40px] items-center gap-2 rounded-xl bg-[#0B1D3A] px-4 text-xs font-semibold text-white hover:bg-[#132C54]"
                    >
                      <GitCompareArrows className="h-4 w-4 text-[#D4AF37]" />
                      <span>Compare Selected ({compareList.length}/3)</span>
                    </button>
                  )}
                </div>

                <SearchFilterBar
                  filters={filters}
                  onChange={setFilters}
                  onReset={() => setFilters(DEFAULT_FILTERS)}
                  resultCount={filteredProperties.length}
                />

                {loadingProperties ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {[1, 2, 3].map((n) => (
                      <div key={n} className="h-80 rounded-2xl bg-slate-200 animate-pulse" />
                    ))}
                  </div>
                ) : filteredProperties.length === 0 ? (
                  <div className="rounded-2xl bg-white border border-slate-200 p-12 text-center">
                    <h3 className="font-display text-xl font-semibold text-[#0B1D3A]">No Matching Properties</h3>
                    <p className="mt-2 text-sm text-slate-600">
                      Try broadening your budget range, bedrooms, or city search criteria.
                    </p>
                    <button
                      type="button"
                      onClick={() => setFilters(DEFAULT_FILTERS)}
                      className="mt-5 rounded-xl bg-[#0B1D3A] px-5 py-2.5 text-xs font-semibold text-white hover:bg-[#132C54]"
                    >
                      Reset All Filters
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredProperties.map((p) => (
                      <PropertyCard
                        key={p.id}
                        property={p}
                        isFavorite={favoriteIds.includes(p.id)}
                        isCompared={compareIds.includes(p.id)}
                        onSelect={(item) => setSelectedPropertyId(item.id)}
                        onToggleFavorite={handleToggleFavorite}
                        onToggleCompare={handleToggleCompare}
                      />
                    ))}
                  </div>
                )}
              </div>
            )}

            {activeTab === 'emi' && (
              <div className="space-y-6">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wider text-[#9A7213]">Financial Planning</p>
                  <h1 className="mt-1 font-display text-2xl sm:text-3xl font-semibold text-[#0B1D3A]">
                    Home Loan & EMI Calculator
                  </h1>
                </div>
                <EMICalculator />
              </div>
            )}

            {activeTab === 'compare' && (
              <CompareView
                items={compareList}
                onRemove={(id) => setCompareList((prev) => prev.filter((p) => p.id !== id))}
                onClear={() => setCompareList([])}
                onSelectProperty={(p) => setSelectedPropertyId(p.id)}
                onBrowseProperties={() => setActiveTab('explore')}
              />
            )}

            {activeTab === 'favorites' && (
              <div className="space-y-6">
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-wider text-[#9A7213]">Personal Shortlist</p>
                    <h1 className="mt-1 font-display text-2xl sm:text-3xl font-semibold text-[#0B1D3A]">
                      Saved Properties ({favorites.length})
                    </h1>
                  </div>
                  {!user && (
                    <button
                      type="button"
                      onClick={() => setAuthModalOpen(true)}
                      className="rounded-xl bg-[#0B1D3A] px-4 py-2.5 text-xs font-semibold text-white hover:bg-[#132C54]"
                    >
                      Sign In to Sync Across Devices
                    </button>
                  )}
                </div>

                {favorites.length === 0 ? (
                  <div className="rounded-2xl bg-white border border-slate-200 p-12 text-center">
                    <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-xl bg-[#0B1D3A]/5 text-[#0B1D3A]">
                      <Heart className="h-6 w-6" />
                    </div>
                    <h3 className="mt-4 font-display text-xl font-semibold text-[#0B1D3A]">No Saved Listings Yet</h3>
                    <p className="mt-2 text-sm text-slate-600">
                      Tap the heart icon on any home or commercial listing to shortlist it here.
                    </p>
                    <button
                      type="button"
                      onClick={() => setActiveTab('explore')}
                      className="mt-5 rounded-xl bg-[#0B1D3A] px-5 py-2.5 text-xs font-semibold text-white hover:bg-[#132C54]"
                    >
                      Explore Properties
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {favorites.map((p) => (
                      <PropertyCard
                        key={p.id}
                        property={p}
                        isFavorite={favoriteIds.includes(p.id)}
                        isCompared={compareIds.includes(p.id)}
                        onSelect={(item) => setSelectedPropertyId(item.id)}
                        onToggleFavorite={handleToggleFavorite}
                        onToggleCompare={handleToggleCompare}
                      />
                    ))}
                  </div>
                )}
              </div>
            )}

            {activeTab === 'portal' && user && (
              <>
                {user.role === 'admin' && (
                  <AdminPanel
                    stats={stats}
                    onDataChanged={() => {
                      loadStatsAndFeatured();
                      loadFilteredProperties(filters);
                    }}
                    onSelectProperty={(p) => setSelectedPropertyId(p.id)}
                  />
                )}
                {user.role === 'agent' && (
                  <AgentPortal
                    user={user}
                    onPropertiesMutated={() => {
                      loadStatsAndFeatured();
                      loadFilteredProperties(filters);
                    }}
                    onSelectProperty={(p) => setSelectedPropertyId(p.id)}
                  />
                )}
                {user.role === 'customer' && (
                  <UserPortal
                    user={user}
                    favorites={favorites}
                    favoriteIds={favoriteIds}
                    compareIds={compareIds}
                    onUserUpdated={setUser}
                    onSelectProperty={(p) => setSelectedPropertyId(p.id)}
                    onToggleFavorite={handleToggleFavorite}
                    onToggleCompare={handleToggleCompare}
                  />
                )}
              </>
            )}
          </motion.div>
        </main>

        <footer className="hidden lg:block border-t border-slate-200 bg-white">
          <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-8 py-6 text-xs text-slate-500">
            <p className="font-display text-sm font-semibold text-[#0B1D3A]">Dream Homes Realty</p>
            <div className="flex items-center gap-6">
              <button type="button" onClick={() => setActiveTab('home')} className="hover:text-[#0B1D3A]">
                Dashboard
              </button>
              <button type="button" onClick={() => setActiveTab('explore')} className="hover:text-[#0B1D3A]">
                Properties
              </button>
              <button type="button" onClick={() => setActiveTab('emi')} className="hover:text-[#0B1D3A]">
                EMI Calculator
              </button>
              <button type="button" onClick={() => setActiveTab('compare')} className="hover:text-[#0B1D3A]">
                Compare
              </button>
            </div>
            <p>© {new Date().getFullYear()} Dream Homes Realty. All rights reserved.</p>
          </div>
        </footer>

        {/* Desktop floating Compare shortcut */}
        {compareList.length > 0 && activeTab !== 'compare' && (
          <button
            type="button"
            onClick={() => setActiveTab('compare')}
            className="hidden lg:inline-flex fixed bottom-6 right-6 z-30 items-center gap-2 rounded-xl bg-[#0B1D3A] px-5 py-3 text-xs font-semibold text-white shadow-xl border border-[#D4AF37]/40 hover:bg-[#132C54]"
          >
            <GitCompareArrows className="h-4 w-4 text-[#D4AF37]" />
            <span>Compare Properties ({compareList.length}/3)</span>
          </button>
        )}

        <PropertyDetailModal
          propertyId={selectedPropertyId}
          user={user}
          favoriteIds={favoriteIds}
          compareIds={compareIds}
          onClose={() => setSelectedPropertyId(null)}
          onSelectProperty={(p) => setSelectedPropertyId(p.id)}
          onToggleFavorite={handleToggleFavorite}
          onToggleCompare={handleToggleCompare}
        />

        <AuthModal
          isOpen={authModalOpen}
          onClose={() => setAuthModalOpen(false)}
          onSuccess={handleAuthSuccess}
        />

        <OfflineIndicator />
      </div>
    </MotionConfig>
  );
}
