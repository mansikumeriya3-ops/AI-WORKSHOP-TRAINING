export type UserRole = 'customer' | 'agent' | 'admin';

export interface User {
  id: number;
  name: string;
  email: string;
  phone: string;
  city: string;
  bio: string;
  avatar_url: string;
  role: UserRole;
  is_verified: number;
  is_active: number;
  agency_name: string;
  created_at: string;
  listing_count?: number;
}

export type ListingType = 'buy' | 'rent';
export type PropertyType = 'Apartment' | 'Villa' | 'House' | 'Penthouse' | 'Commercial' | 'Plot';
export type PropertyStatus = 'Available' | 'Under Offer' | 'Sold' | 'Rented';
export type ApprovalStatus = 'Approved' | 'Pending' | 'Rejected';
export type FurnishingStatus = 'Furnished' | 'Semi-Furnished' | 'Unfurnished';

export interface Property {
  id: number;
  title: string;
  description: string;
  price: number;
  listing_type: ListingType;
  property_type: PropertyType;
  status: PropertyStatus;
  approval_status: ApprovalStatus;
  featured: boolean;
  address: string;
  city: string;
  neighborhood: string;
  latitude: number;
  longitude: number;
  bedrooms: number;
  bathrooms: number;
  area_sqft: number;
  furnishing: FurnishingStatus;
  year_built: number;
  parking_spots: number;
  amenities: string[];
  images: string[];
  agent_id: number;
  agent_name: string;
  agent_email?: string;
  agent_phone?: string;
  agent_avatar?: string;
  agent_agency?: string;
  agent_verified?: number;
  avg_rating?: number;
  review_count?: number;
  views_count: number;
  created_at: string;
  updated_at: string;
}

export interface Review {
  id: number;
  property_id: number;
  user_id: number | null;
  reviewer_name: string;
  rating: number;
  comment: string;
  created_at: string;
}

export interface Enquiry {
  id: number;
  property_id: number;
  user_id: number | null;
  name: string;
  email: string;
  phone: string;
  message: string;
  status: 'New' | 'In Progress' | 'Resolved';
  admin_notes: string;
  created_at: string;
  property_title?: string;
  property_city?: string;
  property_price?: number;
  agent_name?: string;
}

export interface SiteVisit {
  id: number;
  property_id: number;
  user_id: number | null;
  visitor_name: string;
  visitor_email: string;
  visitor_phone: string;
  visit_date: string;
  visit_time: string;
  notes: string;
  status: 'Pending' | 'Confirmed' | 'Completed' | 'Cancelled';
  created_at: string;
  property_title?: string;
  property_address?: string;
  property_city?: string;
  agent_name?: string;
  agent_phone?: string;
}

export interface DashboardStats {
  totalProperties: number;
  forSaleCount: number;
  forRentCount: number;
  totalUsers: number;
  pendingApprovalCount: number;
  totalEnquiries: number;
  totalVisits: number;
}

export interface AnalyticsData {
  byType: Array<{ label: string; count: number; total_value: number }>;
  byStatus: Array<{ label: string; count: number }>;
  byApproval: Array<{ label: string; count: number }>;
  topAgents: Array<{
    id: number;
    name: string;
    agency_name: string;
    is_verified: number;
    listings: number;
    total_views: number;
    enquiries_received: number;
  }>;
  recentEnquiries: Enquiry[];
}

export interface PropertyFilters {
  q: string;
  location: string;
  listingType: '' | 'buy' | 'rent';
  propertyType: string;
  minPrice: string;
  maxPrice: string;
  bedrooms: string;
  bathrooms: string;
  minArea: string;
  maxArea: string;
  furnishing: string;
  sort: 'featured' | 'newest' | 'price_asc' | 'price_desc' | 'area_desc';
}
