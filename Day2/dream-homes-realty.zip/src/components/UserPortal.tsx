import React, { useEffect, useState } from 'react';
import { Calendar, Heart, Mail, User as UserIcon } from 'lucide-react';
import { api } from '../api/client';
import type { Enquiry, Property, SiteVisit, User } from '../types';
import { PropertyCard } from './PropertyCard';
import { PWAInstallButton } from './PWAInstallButton';

interface UserPortalProps {
  user: User;
  favorites: Property[];
  favoriteIds: number[];
  compareIds: number[];
  onUserUpdated: (user: User) => void;
  onSelectProperty: (property: Property) => void;
  onToggleFavorite: (propertyId: number) => void;
  onToggleCompare: (property: Property) => void;
}

export const UserPortal: React.FC<UserPortalProps> = ({
  user,
  favorites,
  favoriteIds,
  compareIds,
  onUserUpdated,
  onSelectProperty,
  onToggleFavorite,
  onToggleCompare,
}) => {
  const [subTab, setSubTab] = useState<'favorites' | 'enquiries' | 'visits' | 'profile'>('favorites');
  const [enquiries, setEnquiries] = useState<Enquiry[]>([]);
  const [visits, setVisits] = useState<SiteVisit[]>([]);

  // Profile form
  const [name, setName] = useState(user.name);
  const [phone, setPhone] = useState(user.phone || '');
  const [city, setCity] = useState(user.city || '');
  const [bio, setBio] = useState(user.bio || '');
  const [agencyName, setAgencyName] = useState(user.agency_name || '');
  const [profileMsg, setProfileMsg] = useState('');

  useEffect(() => {
    api.getEnquiries().then((res) => setEnquiries(res.enquiries)).catch(() => {});
    api.getVisits().then((res) => setVisits(res.visits)).catch(() => {});
  }, []);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setProfileMsg('');
    try {
      const res = await api.updateProfile({ name, phone, city, bio, agency_name: agencyName });
      onUserUpdated(res.user);
      setProfileMsg('Profile saved successfully.');
    } catch (err) {
      setProfileMsg(err instanceof Error ? err.message : 'Unable to save profile.');
    }
  };

  const handleCancelVisit = async (visitId: number) => {
    try {
      const res = await api.updateVisitStatus(visitId, 'Cancelled');
      setVisits((prev) => prev.map((v) => (v.id === visitId ? { ...v, status: res.visit.status } : v)));
    } catch {
      // ignore
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 rounded-2xl bg-[#0B1D3A] p-6 text-white">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-[#F5D376]">Customer Hub</p>
          <h2 className="mt-1 font-display text-2xl font-semibold">{user.name}</h2>
          <p className="text-xs text-slate-300 mt-1">
            {user.email} · {user.city || 'Location not set'}
          </p>
        </div>
        <PWAInstallButton variant="hero" />
      </div>

      {/* Sub-navigation */}
      <div className="flex flex-wrap gap-2">
        {[
          { id: 'favorites', label: `Saved (${favorites.length})`, icon: Heart },
          { id: 'enquiries', label: `Enquiry History (${enquiries.length})`, icon: Mail },
          { id: 'visits', label: `Site Visits (${visits.length})`, icon: Calendar },
          { id: 'profile', label: 'Profile Settings', icon: UserIcon },
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setSubTab(tab.id as typeof subTab)}
              className={`inline-flex min-h-[42px] items-center gap-2 rounded-xl px-4 text-xs font-semibold transition-colors ${
                subTab === tab.id
                  ? 'bg-[#0B1D3A] text-white'
                  : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
              }`}
            >
              <Icon className="h-4 w-4 text-[#D4AF37]" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {subTab === 'favorites' && (
        <div>
          {favorites.length === 0 ? (
            <div className="rounded-2xl bg-white border border-slate-200 p-10 text-center">
              <p className="font-display text-xl font-semibold text-[#0B1D3A]">No Saved Properties Yet</p>
              <p className="mt-2 text-sm text-slate-500">Tap the heart icon on any listing to save it here for quick mobile access.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {favorites.map((p) => (
                <PropertyCard
                  key={p.id}
                  property={p}
                  isFavorite={favoriteIds.includes(p.id)}
                  isCompared={compareIds.includes(p.id)}
                  onSelect={onSelectProperty}
                  onToggleFavorite={onToggleFavorite}
                  onToggleCompare={onToggleCompare}
                />
              ))}
            </div>
          )}
        </div>
      )}

      {subTab === 'enquiries' && (
        <div className="rounded-2xl bg-white border border-slate-200 divide-y divide-slate-100">
          {enquiries.length === 0 ? (
            <div className="p-10 text-center text-sm text-slate-500">You have not submitted any property enquiries yet.</div>
          ) : (
            enquiries.map((e) => (
              <div key={e.id} className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <p className="font-display text-base font-semibold text-[#0B1D3A]">{e.property_title}</p>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {e.property_city} · Sent {new Date(e.created_at).toLocaleDateString()}
                  </p>
                  <p className="mt-2 text-sm text-slate-700">{e.message}</p>
                  {e.admin_notes && (
                    <p className="mt-2 text-xs font-medium text-[#9A7213]">Advisor note: {e.admin_notes}</p>
                  )}
                </div>
                <span className="text-xs font-semibold text-[#0B1D3A] shrink-0">Status: {e.status}</span>
              </div>
            ))
          )}
        </div>
      )}

      {subTab === 'visits' && (
        <div className="rounded-2xl bg-white border border-slate-200 divide-y divide-slate-100">
          {visits.length === 0 ? (
            <div className="p-10 text-center text-sm text-slate-500">No site visits booked yet.</div>
          ) : (
            visits.map((v) => (
              <div key={v.id} className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <p className="font-display text-base font-semibold text-[#0B1D3A]">{v.property_title}</p>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {v.property_address}, {v.property_city}
                  </p>
                  <p className="mt-2 text-sm font-mono font-medium text-slate-800 tabular-nums">
                    Scheduled: {v.visit_date} at {v.visit_time}
                  </p>
                </div>
                <div className="flex items-center gap-3 shrink-0">
                  <span className="text-xs font-semibold text-[#9A7213]">{v.status}</span>
                  {(v.status === 'Pending' || v.status === 'Confirmed') && (
                    <button
                      type="button"
                      onClick={() => handleCancelVisit(v.id)}
                      className="rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-semibold text-rose-600 hover:bg-rose-50"
                    >
                      Cancel
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {subTab === 'profile' && (
        <form onSubmit={handleSaveProfile} className="rounded-2xl bg-white border border-slate-200 p-6 max-w-2xl space-y-4">
          <h3 className="font-display text-xl font-semibold text-[#0B1D3A]">Manage Profile</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Full Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3.5 text-sm focus:border-[#0B1D3A] focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Phone Number</label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3.5 text-sm focus:border-[#0B1D3A] focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">City</label>
              <input
                type="text"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3.5 text-sm focus:border-[#0B1D3A] focus:outline-none"
              />
            </div>
            {user.role === 'agent' && (
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Agency Name</label>
                <input
                  type="text"
                  value={agencyName}
                  onChange={(e) => setAgencyName(e.target.value)}
                  className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3.5 text-sm focus:border-[#0B1D3A] focus:outline-none"
                />
              </div>
            )}
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Bio / Preferences</label>
            <textarea
              rows={3}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              className="w-full rounded-xl border border-slate-200 p-3 text-sm focus:border-[#0B1D3A] focus:outline-none"
            />
          </div>
          {profileMsg && <p className="text-xs font-semibold text-[#9A7213]">{profileMsg}</p>}
          <button
            type="submit"
            className="min-h-[44px] rounded-xl bg-[#0B1D3A] px-6 text-sm font-semibold text-white hover:bg-[#132C54] transition-colors"
          >
            Save Profile
          </button>
        </form>
      )}
    </div>
  );
};
