import React, { useEffect, useState } from 'react';
import { RotateCcw, Search, SlidersHorizontal } from 'lucide-react';
import { api } from '../api/client';
import type { PropertyFilters } from '../types';

interface SearchFilterBarProps {
  filters: PropertyFilters;
  onChange: (next: PropertyFilters) => void;
  onReset: () => void;
  resultCount: number;
}

export const DEFAULT_FILTERS: PropertyFilters = {
  q: '',
  location: '',
  listingType: '',
  propertyType: 'All',
  minPrice: '',
  maxPrice: '',
  bedrooms: '0',
  bathrooms: '0',
  minArea: '',
  maxArea: '',
  furnishing: 'All',
  sort: 'featured',
};

export const SearchFilterBar: React.FC<SearchFilterBarProps> = ({
  filters,
  onChange,
  onReset,
  resultCount,
}) => {
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);

  useEffect(() => {
    const query = filters.location || filters.q;
    if (!query || query.trim().length < 2) {
      setSuggestions([]);
      return;
    }
    const timer = setTimeout(() => {
      api
        .getSuggestions(query.trim())
        .then((res) => setSuggestions(res.suggestions))
        .catch(() => setSuggestions([]));
    }, 180);
    return () => clearTimeout(timer);
  }, [filters.location, filters.q]);

  const update = (patch: Partial<PropertyFilters>) => {
    onChange({ ...filters, ...patch });
  };

  return (
    <section className="rounded-2xl bg-white border border-slate-200 p-4 sm:p-6 shadow-sm">
      {/* Primary search row */}
      <div className="flex flex-col lg:flex-row lg:items-center gap-3">
        {/* Buy / Rent / All segmented control */}
        <div className="inline-flex rounded-xl bg-slate-100 p-1 shrink-0">
          {[
            { value: '', label: 'All' },
            { value: 'buy', label: 'Buy' },
            { value: 'rent', label: 'Rent' },
          ].map((opt) => (
            <button
              key={opt.label}
              type="button"
              onClick={() => update({ listingType: opt.value as '' | 'buy' | 'rent' })}
              className={`min-h-[40px] rounded-lg px-4 text-xs font-semibold transition-colors whitespace-nowrap ${
                filters.listingType === opt.value
                  ? 'bg-[#0B1D3A] text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>

        {/* Location / Keyword search with autocomplete suggestions */}
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <input
            type="text"
            value={filters.location}
            onFocus={() => setShowSuggestions(true)}
            onBlur={() => setTimeout(() => setShowSuggestions(false), 160)}
            onChange={(e) => update({ location: e.target.value })}
            placeholder="Search by city, neighborhood, address, or property name..."
            className="w-full min-h-[44px] rounded-xl border border-slate-200 bg-slate-50 pl-10 pr-4 text-sm text-slate-900 placeholder:text-slate-400 focus:border-[#0B1D3A] focus:bg-white focus:outline-none"
          />
          {showSuggestions && suggestions.length > 0 && (
            <ul className="absolute left-0 right-0 top-full z-30 mt-1.5 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xl">
              {suggestions.map((item) => (
                <li key={item}>
                  <button
                    type="button"
                    onMouseDown={() => {
                      update({ location: item });
                      setShowSuggestions(false);
                    }}
                    className="flex w-full items-center gap-2 px-4 py-2.5 text-left text-sm text-slate-700 hover:bg-slate-50"
                  >
                    <Search className="h-3.5 w-3.5 text-[#9A7213]" />
                    <span>{item}</span>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Property Type */}
        <select
          aria-label="Property Type"
          value={filters.propertyType}
          onChange={(e) => update({ propertyType: e.target.value })}
          className="min-h-[44px] rounded-xl border border-slate-200 bg-slate-50 px-3.5 text-sm font-medium text-slate-800 focus:border-[#0B1D3A] focus:bg-white focus:outline-none"
        >
          <option value="All">All Property Types</option>
          <option value="Villa">Villa</option>
          <option value="Penthouse">Penthouse</option>
          <option value="House">House</option>
          <option value="Apartment">Apartment</option>
          <option value="Commercial">Commercial</option>
          <option value="Plot">Plot / Land</option>
        </select>

        {/* Advanced filters toggle */}
        <button
          type="button"
          onClick={() => setShowAdvanced((v) => !v)}
          className={`inline-flex min-h-[44px] items-center justify-center gap-2 rounded-xl border px-4 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
            showAdvanced
              ? 'border-[#0B1D3A] bg-[#0B1D3A] text-white'
              : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
          }`}
        >
          <SlidersHorizontal className="h-4 w-4" />
          <span>{showAdvanced ? 'Hide Filters' : 'Advanced Filters'}</span>
        </button>
      </div>

      {/* Expanded Advanced Search Grid */}
      {showAdvanced && (
        <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 border-t border-slate-100 pt-5">
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1.5">Min Budget ($)</label>
            <input
              type="number"
              min="0"
              value={filters.minPrice}
              onChange={(e) => update({ minPrice: e.target.value })}
              placeholder="e.g. 2500"
              className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3 text-sm tabular-nums focus:border-[#0B1D3A] focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1.5">Max Budget ($)</label>
            <input
              type="number"
              min="0"
              value={filters.maxPrice}
              onChange={(e) => update({ maxPrice: e.target.value })}
              placeholder="e.g. 5000000"
              className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3 text-sm tabular-nums focus:border-[#0B1D3A] focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1.5">Bedrooms</label>
            <select
              value={filters.bedrooms}
              onChange={(e) => update({ bedrooms: e.target.value })}
              className="w-full min-h-[42px] rounded-xl border border-slate-200 bg-white px-3 text-sm focus:border-[#0B1D3A] focus:outline-none"
            >
              <option value="0">Any Bedrooms</option>
              <option value="1">1+ Bedrooms</option>
              <option value="2">2+ Bedrooms</option>
              <option value="3">3+ Bedrooms</option>
              <option value="4">4+ Bedrooms</option>
              <option value="5">5+ Bedrooms</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1.5">Bathrooms</label>
            <select
              value={filters.bathrooms}
              onChange={(e) => update({ bathrooms: e.target.value })}
              className="w-full min-h-[42px] rounded-xl border border-slate-200 bg-white px-3 text-sm focus:border-[#0B1D3A] focus:outline-none"
            >
              <option value="0">Any Bathrooms</option>
              <option value="1">1+ Bathrooms</option>
              <option value="2">2+ Bathrooms</option>
              <option value="3">3+ Bathrooms</option>
              <option value="4">4+ Bathrooms</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1.5">Min Size (sq ft)</label>
            <input
              type="number"
              min="0"
              value={filters.minArea}
              onChange={(e) => update({ minArea: e.target.value })}
              placeholder="e.g. 1200"
              className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3 text-sm tabular-nums focus:border-[#0B1D3A] focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1.5">Max Size (sq ft)</label>
            <input
              type="number"
              min="0"
              value={filters.maxArea}
              onChange={(e) => update({ maxArea: e.target.value })}
              placeholder="e.g. 10000"
              className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3 text-sm tabular-nums focus:border-[#0B1D3A] focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1.5">Furnishing Status</label>
            <select
              value={filters.furnishing}
              onChange={(e) => update({ furnishing: e.target.value })}
              className="w-full min-h-[42px] rounded-xl border border-slate-200 bg-white px-3 text-sm focus:border-[#0B1D3A] focus:outline-none"
            >
              <option value="All">Any Furnishing</option>
              <option value="Furnished">Furnished</option>
              <option value="Semi-Furnished">Semi-Furnished</option>
              <option value="Unfurnished">Unfurnished</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1.5">Sort By</label>
            <select
              value={filters.sort}
              onChange={(e) => update({ sort: e.target.value as PropertyFilters['sort'] })}
              className="w-full min-h-[42px] rounded-xl border border-slate-200 bg-white px-3 text-sm focus:border-[#0B1D3A] focus:outline-none"
            >
              <option value="featured">Featured First</option>
              <option value="newest">Recently Added</option>
              <option value="price_asc">Price: Low to High</option>
              <option value="price_desc">Price: High to Low</option>
              <option value="area_desc">Largest Area (sq ft)</option>
            </select>
          </div>
        </div>
      )}

      {/* Results meta bar */}
      <div className="mt-4 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
        <span className="tabular-nums">
          Showing <strong className="font-semibold text-[#0B1D3A]">{resultCount}</strong> matching properties
        </span>
        <button
          type="button"
          onClick={onReset}
          className="inline-flex items-center gap-1.5 font-semibold text-[#9A7213] hover:text-[#0B1D3A] transition-colors"
        >
          <RotateCcw className="h-3.5 w-3.5" />
          <span>Reset Filters</span>
        </button>
      </div>
    </section>
  );
};
