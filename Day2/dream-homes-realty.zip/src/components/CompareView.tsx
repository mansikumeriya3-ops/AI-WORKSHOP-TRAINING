import React from 'react';
import { GitCompareArrows, Trash2, X } from 'lucide-react';
import type { Property } from '../types';
import { formatCurrency } from './PropertyCard';
import { PropertyImage } from './PropertyImage';

interface CompareViewProps {
  items: Property[];
  onRemove: (id: number) => void;
  onClear: () => void;
  onSelectProperty: (property: Property) => void;
  onBrowseProperties: () => void;
}

export const CompareView: React.FC<CompareViewProps> = ({
  items,
  onRemove,
  onClear,
  onSelectProperty,
  onBrowseProperties,
}) => {
  if (items.length === 0) {
    return (
      <div className="rounded-2xl bg-white border border-slate-200 p-12 text-center">
        <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-xl bg-[#0B1D3A]/5 text-[#0B1D3A]">
          <GitCompareArrows className="h-6 w-6" />
        </div>
        <h2 className="mt-4 font-display text-2xl font-semibold text-[#0B1D3A]">Compare Properties Side by Side</h2>
        <p className="mx-auto mt-2 max-w-md text-sm text-slate-600">
          Select up to 3 listings using the compare icon on any property card to evaluate pricing, square footage, and amenities side by side.
        </p>
        <button
          type="button"
          onClick={onBrowseProperties}
          className="mt-6 rounded-xl bg-[#0B1D3A] px-6 py-3 text-sm font-semibold text-white hover:bg-[#132C54] transition-colors"
        >
          Explore Properties
        </button>
      </div>
    );
  }

  const rows: Array<{ label: string; render: (p: Property) => string }> = [
    { label: 'Listing Purpose', render: (p) => (p.listing_type === 'buy' ? 'For Sale' : 'For Rent') },
    { label: 'Property Type', render: (p) => p.property_type },
    { label: 'Price', render: (p) => formatCurrency(p.price, p.listing_type) },
    {
      label: 'Price / sq ft',
      render: (p) => (p.area_sqft > 0 ? `$${Math.round(p.price / p.area_sqft).toLocaleString()}` : '—'),
    },
    { label: 'Area', render: (p) => `${p.area_sqft.toLocaleString()} sq ft` },
    { label: 'Bedrooms', render: (p) => (p.bedrooms > 0 ? String(p.bedrooms) : 'Commercial') },
    { label: 'Bathrooms', render: (p) => String(p.bathrooms) },
    { label: 'Furnishing', render: (p) => p.furnishing },
    { label: 'Parking', render: (p) => `${p.parking_spots} Spaces` },
    { label: 'Year Built', render: (p) => String(p.year_built) },
    { label: 'Availability', render: (p) => p.status },
    { label: 'Location', render: (p) => `${p.neighborhood}, ${p.city}` },
    { label: 'Amenities', render: (p) => (p.amenities.length > 0 ? p.amenities.join(', ') : 'Standard') },
    { label: 'Advisor', render: (p) => p.agent_name },
  ];

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl sm:text-3xl font-semibold text-[#0B1D3A]">
            Property Comparison ({items.length}/3)
          </h2>
          <p className="text-sm text-slate-600">Side-by-side specification, value, and amenity matrix</p>
        </div>
        <button
          type="button"
          onClick={onClear}
          className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-xs font-semibold text-slate-700 hover:bg-slate-50"
        >
          <Trash2 className="h-4 w-4" />
          <span>Clear All</span>
        </button>
      </div>

      <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white">
        <table className="w-full min-w-[680px] text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-200 bg-slate-50/70">
              <th className="w-44 p-4 text-xs font-semibold uppercase tracking-wider text-slate-500">Feature</th>
              {items.map((p) => (
                <th key={p.id} className="p-4 align-top">
                  <div className="relative aspect-[16/10] w-full overflow-hidden rounded-xl bg-slate-100">
                    <PropertyImage src={p.images?.[0]} alt={p.title} fallbackTitle={p.title} />
                    <button
                      type="button"
                      onClick={() => onRemove(p.id)}
                      aria-label={`Remove ${p.title}`}
                      className="absolute top-2 right-2 flex h-8 w-8 items-center justify-center rounded-lg bg-[#0B1D3A]/85 text-white hover:bg-[#0B1D3A]"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                  <button
                    type="button"
                    onClick={() => onSelectProperty(p)}
                    className="mt-3 block text-left font-display text-base font-semibold text-[#0B1D3A] hover:text-[#9A7213]"
                  >
                    {p.title}
                  </button>
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-sm">
            {rows.map((row) => (
              <tr key={row.label} className="hover:bg-slate-50/60">
                <td className="p-4 font-semibold text-slate-600">{row.label}</td>
                {items.map((p) => (
                  <td key={`${row.label}-${p.id}`} className="p-4 text-slate-800 tabular-nums">
                    {row.render(p)}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
