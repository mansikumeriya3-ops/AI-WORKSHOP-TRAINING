import React, { useState } from 'react';
import { ArrowRight, Building, Home, KeyRound, Search, Users } from 'lucide-react';
import type { DashboardStats, Property } from '../types';
import { PropertyCard } from './PropertyCard';
import { PWAInstallButton } from './PWAInstallButton';

interface DashboardHomeProps {
  stats: DashboardStats;
  properties: Property[];
  favoriteIds: number[];
  compareIds: number[];
  onQuickSearch: (location: string, listingType: '' | 'buy' | 'rent') => void;
  onSelectProperty: (property: Property) => void;
  onToggleFavorite: (propertyId: number) => void;
  onToggleCompare: (property: Property) => void;
  onExploreAll: () => void;
  onOpenEmi: () => void;
}

export const DashboardHome: React.FC<DashboardHomeProps> = ({
  stats,
  properties,
  favoriteIds,
  compareIds,
  onQuickSearch,
  onSelectProperty,
  onToggleFavorite,
  onToggleCompare,
  onExploreAll,
  onOpenEmi,
}) => {
  const [heroLocation, setHeroLocation] = useState('');
  const [heroIntent, setHeroIntent] = useState<'buy' | 'rent'>('buy');

  const featuredProperties = properties.filter((p) => p.featured).slice(0, 3);
  const recentProperties = [...properties]
    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
    .slice(0, 3);

  const handleHeroSearch = (e: React.FormEvent) => {
    e.preventDefault();
    onQuickSearch(heroLocation, heroIntent);
  };

  return (
    <div className="space-y-12">
      {/* Hero Showcase */}
      <section className="relative overflow-hidden rounded-3xl bg-[#0B1D3A] text-white">
        <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch">
          <div className="lg:col-span-6 p-6 sm:p-10 lg:p-12 flex flex-col justify-between gap-8">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.2em] text-[#F5D376]">
                Residential & Commercial Estates
              </p>
              <h1 className="mt-3 font-display text-3xl sm:text-5xl font-semibold leading-[1.12] text-balance">
                Discover Architecture Built for the Way You Live
              </h1>
              <p className="mt-4 max-w-xl text-sm sm:text-base text-slate-300 leading-relaxed">
                Explore curated homes, penthouses, villas, and commercial flagship spaces across premier neighborhoods — directly connected with verified advisors.
              </p>
            </div>

            {/* Quick Search Box */}
            <form onSubmit={handleHeroSearch} className="rounded-2xl bg-white/10 backdrop-blur-md border border-white/15 p-3 space-y-3">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setHeroIntent('buy')}
                  className={`rounded-lg px-4 py-1.5 text-xs font-semibold transition-colors ${
                    heroIntent === 'buy' ? 'bg-[#D4AF37] text-[#0B1D3A]' : 'text-slate-200 hover:bg-white/10'
                  }`}
                >
                  Buy Property
                </button>
                <button
                  type="button"
                  onClick={() => setHeroIntent('rent')}
                  className={`rounded-lg px-4 py-1.5 text-xs font-semibold transition-colors ${
                    heroIntent === 'rent' ? 'bg-[#D4AF37] text-[#0B1D3A]' : 'text-slate-200 hover:bg-white/10'
                  }`}
                >
                  Rent Property
                </button>
              </div>
              <div className="flex flex-col sm:flex-row gap-2">
                <div className="relative flex-1">
                  <Search className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-300" />
                  <input
                    type="text"
                    value={heroLocation}
                    onChange={(e) => setHeroLocation(e.target.value)}
                    placeholder="City or neighborhood (e.g. Malibu, Austin, New York)"
                    className="w-full min-h-[44px] rounded-xl bg-white px-10 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none"
                  />
                </div>
                <button
                  type="submit"
                  className="min-h-[44px] rounded-xl bg-[#D4AF37] px-6 text-sm font-semibold text-[#0B1D3A] hover:bg-[#E5C158] transition-colors whitespace-nowrap"
                >
                  Search
                </button>
              </div>
            </form>

            {/* Primary CTA + Install Mobile App Trigger */}
            <div className="flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={onExploreAll}
                className="inline-flex min-h-[44px] items-center gap-2 rounded-xl bg-white px-5 py-3 text-sm font-semibold text-[#0B1D3A] hover:bg-slate-100 transition-colors"
              >
                <span>Browse All Properties</span>
                <ArrowRight className="h-4 w-4" />
              </button>
              <PWAInstallButton variant="hero" />
            </div>
          </div>

          <div className="lg:col-span-6 relative min-h-[280px] lg:min-h-[500px]">
            <img
              src="/src/assets/images/hero_luxury_villa_1795250754036.jpg"
              alt="Twilight luxury villa estate with infinity pool"
              referrerPolicy="no-referrer"
              className="h-full w-full object-cover"
            />
            <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#0B1D3A]/60 via-transparent to-transparent lg:bg-gradient-to-r lg:from-[#0B1D3A] lg:via-[#0B1D3A]/15 lg:to-transparent" />
          </div>
        </div>
      </section>

      {/* 4-Column KPI Strip (Placed cleanly in full-width row below hero) */}
      <section aria-label="Platform Overview Metrics" className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
        <div className="rounded-2xl bg-white border border-slate-200 p-5 sm:p-6">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">Total Properties</span>
            <Building className="h-4 w-4 text-[#C99A2E]" />
          </div>
          <p className="mt-3 font-mono text-3xl font-bold text-[#0B1D3A] tabular-nums">{stats.totalProperties}</p>
          <p className="mt-1 text-xs text-slate-500">Verified active portfolio</p>
        </div>

        <div className="rounded-2xl bg-white border border-slate-200 p-5 sm:p-6">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">Available for Sale</span>
            <Home className="h-4 w-4 text-[#C99A2E]" />
          </div>
          <p className="mt-3 font-mono text-3xl font-bold text-[#0B1D3A] tabular-nums">{stats.forSaleCount}</p>
          <p className="mt-1 text-xs text-slate-500">Residential & commercial</p>
        </div>

        <div className="rounded-2xl bg-white border border-slate-200 p-5 sm:p-6">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">Available for Rent</span>
            <KeyRound className="h-4 w-4 text-[#C99A2E]" />
          </div>
          <p className="mt-3 font-mono text-3xl font-bold text-[#0B1D3A] tabular-nums">{stats.forRentCount}</p>
          <p className="mt-1 text-xs text-slate-500">Turnkey leases & suites</p>
        </div>

        <div className="rounded-2xl bg-white border border-slate-200 p-5 sm:p-6">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">Registered Users</span>
            <Users className="h-4 w-4 text-[#C99A2E]" />
          </div>
          <p className="mt-3 font-mono text-3xl font-bold text-[#0B1D3A] tabular-nums">{stats.totalUsers}</p>
          <p className="mt-1 text-xs text-slate-500 tabular-nums">{stats.totalEnquiries} customer enquiries logged</p>
        </div>
      </section>

      {/* Featured Properties */}
      <section>
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-[#9A7213]">Signature Collection</p>
            <h2 className="mt-1 font-display text-2xl sm:text-3xl font-semibold text-[#0B1D3A]">Featured Properties</h2>
          </div>
          <button
            type="button"
            onClick={onExploreAll}
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#0B1D3A] hover:text-[#9A7213] transition-colors"
          >
            <span>View Full Catalog</span>
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>

        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {featuredProperties.map((property) => (
            <PropertyCard
              key={property.id}
              property={property}
              isFavorite={favoriteIds.includes(property.id)}
              isCompared={compareIds.includes(property.id)}
              onSelect={onSelectProperty}
              onToggleFavorite={onToggleFavorite}
              onToggleCompare={onToggleCompare}
            />
          ))}
        </div>
      </section>

      {/* Recently Added Properties */}
      <section>
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-[#9A7213]">Fresh on Market</p>
            <h2 className="mt-1 font-display text-2xl sm:text-3xl font-semibold text-[#0B1D3A]">
              Recently Added Properties
            </h2>
          </div>
          <button
            type="button"
            onClick={onOpenEmi}
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#0B1D3A] hover:text-[#9A7213] transition-colors"
          >
            <span>Estimate Monthly EMI</span>
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>

        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {recentProperties.map((property) => (
            <PropertyCard
              key={`recent-${property.id}`}
              property={property}
              isFavorite={favoriteIds.includes(property.id)}
              isCompared={compareIds.includes(property.id)}
              onSelect={onSelectProperty}
              onToggleFavorite={onToggleFavorite}
              onToggleCompare={onToggleCompare}
            />
          ))}
        </div>
      </section>
    </div>
  );
};
