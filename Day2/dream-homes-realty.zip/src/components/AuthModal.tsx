import React, { useEffect, useState } from 'react';
import { ShieldCheck, UserPlus, X } from 'lucide-react';
import { api, setAuthToken } from '../api/client';
import type { User } from '../types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (user: User, token: string) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, onSuccess }) => {
  const [mode, setMode] = useState<'login' | 'register' | 'admin'>('login');
  const [adminStatus, setAdminStatus] = useState<{ claimed: boolean; envConfigured: boolean }>({
    claimed: true,
    envConfigured: false,
  });

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phone, setPhone] = useState('');
  const [city, setCity] = useState('');
  const [role, setRole] = useState<'customer' | 'agent'>('customer');
  const [agencyName, setAgencyName] = useState('');
  const [adminPasscode, setAdminPasscode] = useState('');

  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setError('');
      api
        .getAdminStatus()
        .then(setAdminStatus)
        .catch(() => {});
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      if (mode === 'login') {
        const res = await api.login({ email, password });
        setAuthToken(res.token);
        onSuccess(res.user, res.token);
      } else if (mode === 'register') {
        const res = await api.register({
          name,
          email,
          password,
          phone,
          city,
          role,
          agency_name: role === 'agent' ? agencyName : '',
        });
        setAuthToken(res.token);
        onSuccess(res.user, res.token);
      } else if (mode === 'admin') {
        if (adminStatus.envConfigured) {
          const res = await api.login({ adminPasscode });
          setAuthToken(res.token);
          onSuccess(res.user, res.token);
        } else if (!adminStatus.claimed) {
          const res = await api.claimAdmin({ name, email, password });
          setAuthToken(res.token);
          onSuccess(res.user, res.token);
        } else {
          const res = await api.login({ email, password });
          if (res.user.role !== 'admin') {
            throw new Error('This account does not have administrator privileges.');
          }
          setAuthToken(res.token);
          onSuccess(res.user, res.token);
        }
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Authentication failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-sm p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="auth-modal-title"
    >
      <div className="w-full max-w-md max-h-[92vh] overflow-y-auto rounded-2xl bg-white p-6 sm:p-7 shadow-2xl border border-slate-200">
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-[#9A7213]">Dream Homes Realty</p>
            <h2 id="auth-modal-title" className="mt-1 font-display text-2xl font-semibold text-[#0B1D3A]">
              {mode === 'login'
                ? 'Welcome Back'
                : mode === 'register'
                  ? 'Create Your Account'
                  : !adminStatus.claimed && !adminStatus.envConfigured
                    ? 'Initialize Admin Access'
                    : 'Administrator Sign In'}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close modal"
            className="flex h-10 w-10 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Mode Switcher */}
        <div className="mt-5 grid grid-cols-3 gap-1 rounded-xl bg-slate-100 p-1">
          <button
            type="button"
            onClick={() => {
              setMode('login');
              setError('');
            }}
            className={`min-h-[38px] rounded-lg text-xs font-semibold transition-colors ${
              mode === 'login' ? 'bg-[#0B1D3A] text-white' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Sign In
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('register');
              setError('');
            }}
            className={`min-h-[38px] rounded-lg text-xs font-semibold transition-colors ${
              mode === 'register' ? 'bg-[#0B1D3A] text-white' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Register
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('admin');
              setError('');
            }}
            className={`min-h-[38px] rounded-lg text-xs font-semibold transition-colors ${
              mode === 'admin' ? 'bg-[#0B1D3A] text-white' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Admin
          </button>
        </div>

        {error && (
          <div className="mt-4 rounded-xl bg-rose-50 border border-rose-200 px-3.5 py-2.5 text-xs font-medium text-rose-700">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-5 space-y-4">
          {mode === 'register' && (
            <>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">Account Type</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setRole('customer')}
                    className={`rounded-xl border px-3 py-2.5 text-xs font-semibold transition-colors ${
                      role === 'customer'
                        ? 'border-[#0B1D3A] bg-[#0B1D3A] text-white'
                        : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    Buyer / Renter
                  </button>
                  <button
                    type="button"
                    onClick={() => setRole('agent')}
                    className={`rounded-xl border px-3 py-2.5 text-xs font-semibold transition-colors ${
                      role === 'agent'
                        ? 'border-[#0B1D3A] bg-[#0B1D3A] text-white'
                        : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    Property Agent
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Alex Rivera"
                  className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3.5 text-sm focus:border-[#0B1D3A] focus:outline-none"
                />
              </div>

              {role === 'agent' && (
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Brokerage / Agency Name</label>
                  <input
                    type="text"
                    value={agencyName}
                    onChange={(e) => setAgencyName(e.target.value)}
                    placeholder="Horizon Estates Group"
                    className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3.5 text-sm focus:border-[#0B1D3A] focus:outline-none"
                  />
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Phone</label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+1 555 0199"
                    className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3.5 text-sm focus:border-[#0B1D3A] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">City</label>
                  <input
                    type="text"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    placeholder="Austin, TX"
                    className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3.5 text-sm focus:border-[#0B1D3A] focus:outline-none"
                  />
                </div>
              </div>
            </>
          )}

          {mode === 'admin' && !adminStatus.claimed && !adminStatus.envConfigured && (
            <>
              <div className="rounded-xl bg-amber-50 border border-amber-200 p-3 text-xs text-amber-900">
                First-run setup: Claim the administrator account by creating your admin credentials below.
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Administrator Name</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Platform Administrator"
                  className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3.5 text-sm focus:border-[#0B1D3A] focus:outline-none"
                />
              </div>
            </>
          )}

          {mode === 'admin' && adminStatus.envConfigured ? (
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Admin Passcode</label>
              <input
                type="password"
                required
                value={adminPasscode}
                onChange={(e) => setAdminPasscode(e.target.value)}
                placeholder="Enter configured server passcode"
                className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3.5 text-sm focus:border-[#0B1D3A] focus:outline-none"
              />
            </div>
          ) : (
            <>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Email Address</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3.5 text-sm focus:border-[#0B1D3A] focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Password {mode === 'admin' && !adminStatus.claimed ? '(min 8 chars)' : ''}
                </label>
                <input
                  type="password"
                  required
                  minLength={mode === 'admin' && !adminStatus.claimed ? 8 : 6}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3.5 text-sm focus:border-[#0B1D3A] focus:outline-none"
                />
              </div>
            </>
          )}

          <button
            type="submit"
            disabled={loading}
            className="flex w-full min-h-[46px] items-center justify-center gap-2 rounded-xl bg-[#0B1D3A] px-5 py-3 text-sm font-semibold text-white hover:bg-[#132C54] disabled:opacity-60 transition-colors"
          >
            {mode === 'register' ? (
              <UserPlus className="h-4 w-4 text-[#D4AF37]" />
            ) : (
              <ShieldCheck className="h-4 w-4 text-[#D4AF37]" />
            )}
            <span>
              {loading
                ? 'Please wait...'
                : mode === 'login'
                  ? 'Sign In'
                  : mode === 'register'
                    ? `Create ${role === 'agent' ? 'Agent' : 'Customer'} Account`
                    : !adminStatus.claimed && !adminStatus.envConfigured
                      ? 'Claim & Sign In as Admin'
                      : 'Sign In to Admin Console'}
            </span>
          </button>
        </form>
      </div>
    </div>
  );
};
