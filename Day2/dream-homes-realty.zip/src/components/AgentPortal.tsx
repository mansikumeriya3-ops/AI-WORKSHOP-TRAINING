import React, { useEffect, useState } from 'react';
import { Calendar, Edit3, Mail, Plus, Trash2, Upload, X } from 'lucide-react';
import { api } from '../api/client';
import type { Enquiry, Property, SiteVisit, User } from '../types';
import { formatCurrency } from './PropertyCard';
import { PropertyImage } from './PropertyImage';

interface AgentPortalProps {
  user: User;
  onPropertiesMutated: () => void;
  onSelectProperty: (property: Property) => void;
}

const PRESET_GALLERY = [
  '/src/assets/images/hero_luxury_villa_1795250754036.jpg',
  '/src/assets/images/prop_modern_penthouse_1795250753657.jpg',
  '/src/assets/images/prop_coastal_residence_1795250754032.jpg',
  '/src/assets/images/prop_commercial_tower_1795250754667.jpg',
  '/src/assets/images/prop_suburban_manor_1795250753973.jpg',
  '/src/assets/images/prop_studio_loft_1795250754003.jpg',
];

const COMMON_AMENITIES = [
  'Swimming Pool',
  'Smart Home',
  'Private Gym',
  '24/7 Security',
  'EV Charging',
  'Ocean View',
  'Concierge',
  'Garden Terrace',
  'Solar Power',
  'Elevator',
];

export const AgentPortal: React.FC<AgentPortalProps> = ({
  user,
  onPropertiesMutated,
  onSelectProperty,
}) => {
  const [subTab, setSubTab] = useState<'listings' | 'enquiries' | 'visits'>('listings');
  const [myProperties, setMyProperties] = useState<Property[]>([]);
  const [enquiries, setEnquiries] = useState<Enquiry[]>([]);
  const [visits, setVisits] = useState<SiteVisit[]>([]);

  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);

  // Property form state
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('1450000');
  const [listingType, setListingType] = useState<'buy' | 'rent'>('buy');
  const [propertyType, setPropertyType] = useState('Villa');
  const [status, setStatus] = useState('Available');
  const [furnishing, setFurnishing] = useState('Furnished');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [neighborhood, setNeighborhood] = useState('');
  const [bedrooms, setBedrooms] = useState('4');
  const [bathrooms, setBathrooms] = useState('3');
  const [areaSqft, setAreaSqft] = useState('3200');
  const [parkingSpots, setParkingSpots] = useState('2');
  const [yearBuilt, setYearBuilt] = useState('2025');
  const [selectedAmenities, setSelectedAmenities] = useState<string[]>(['Smart Home', '24/7 Security']);
  const [images, setImages] = useState<string[]>([PRESET_GALLERY[0]]);
  const [uploading, setUploading] = useState(false);
  const [formError, setFormError] = useState('');
  const [saving, setSaving] = useState(false);

  const loadAgentData = () => {
    api.getProperties({ agentOnly: true }).then((res) => setMyProperties(res.properties)).catch(() => {});
    api.getEnquiries().then((res) => setEnquiries(res.enquiries)).catch(() => {});
    api.getVisits().then((res) => setVisits(res.visits)).catch(() => {});
  };

  useEffect(() => {
    loadAgentData();
  }, []);

  const openNewForm = () => {
    setEditingId(null);
    setTitle('');
    setDescription('');
    setPrice('1450000');
    setListingType('buy');
    setPropertyType('Villa');
    setStatus('Available');
    setFurnishing('Furnished');
    setAddress('');
    setCity('');
    setNeighborhood('');
    setBedrooms('4');
    setBathrooms('3');
    setAreaSqft('3200');
    setParkingSpots('2');
    setYearBuilt('2025');
    setSelectedAmenities(['Smart Home', '24/7 Security']);
    setImages([PRESET_GALLERY[0]]);
    setFormError('');
    setShowForm(true);
  };

  const openEditForm = (p: Property) => {
    setEditingId(p.id);
    setTitle(p.title);
    setDescription(p.description);
    setPrice(String(p.price));
    setListingType(p.listing_type);
    setPropertyType(p.property_type);
    setStatus(p.status);
    setFurnishing(p.furnishing);
    setAddress(p.address);
    setCity(p.city);
    setNeighborhood(p.neighborhood);
    setBedrooms(String(p.bedrooms));
    setBathrooms(String(p.bathrooms));
    setAreaSqft(String(p.area_sqft));
    setParkingSpots(String(p.parking_spots));
    setYearBuilt(String(p.year_built));
    setSelectedAmenities(p.amenities || []);
    setImages(p.images.length > 0 ? p.images : [PRESET_GALLERY[0]]);
    setFormError('');
    setShowForm(true);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileList = e.target.files;
    if (!fileList || fileList.length === 0) return;
    setUploading(true);
    setFormError('');
    try {
      const filesToRead = Array.from(fileList).slice(0, 6);
      const encoded = await Promise.all(
        filesToRead.map(
          (file) =>
            new Promise<{ name: string; dataUrl: string }>((resolve, reject) => {
              const reader = new FileReader();
              reader.onload = () => resolve({ name: file.name, dataUrl: String(reader.result) });
              reader.onerror = () => reject(new Error('Failed to read image file'));
              reader.readAsDataURL(file);
            })
        )
      );
      const res = await api.uploadImages(encoded);
      setImages((prev) => [...prev, ...res.urls].slice(0, 8));
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Image upload failed.');
    } finally {
      setUploading(false);
    }
  };

  const handleSaveProperty = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');
    setSaving(true);
    try {
      const payload = {
        title,
        description,
        price: Number(price),
        listing_type: listingType,
        property_type: propertyType,
        status,
        furnishing,
        address,
        city,
        neighborhood: neighborhood || city,
        bedrooms: Number(bedrooms),
        bathrooms: Number(bathrooms),
        area_sqft: Number(areaSqft),
        parking_spots: Number(parkingSpots),
        year_built: Number(yearBuilt),
        amenities: selectedAmenities,
        images,
      };
      if (editingId) {
        await api.updateProperty(editingId, payload);
      } else {
        await api.createProperty(payload);
      }
      setShowForm(false);
      loadAgentData();
      onPropertiesMutated();
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Unable to save property.');
    } finally {
      setSaving(false);
    }
  };

  const handleQuickStatusChange = async (id: number, nextStatus: string) => {
    try {
      await api.updateProperty(id, { status: nextStatus });
      loadAgentData();
      onPropertiesMutated();
    } catch {
      // ignore
    }
  };

  const handleDelete = async (id: number) => {
    try {
      await api.deleteProperty(id);
      loadAgentData();
      onPropertiesMutated();
    } catch {
      // ignore
    }
  };

  const handleEnquiryStatus = async (id: number, nextStatus: string) => {
    try {
      await api.updateEnquiry(id, { status: nextStatus });
      loadAgentData();
    } catch {
      // ignore
    }
  };

  const handleVisitStatus = async (id: number, nextStatus: SiteVisit['status']) => {
    try {
      await api.updateVisitStatus(id, nextStatus);
      loadAgentData();
    } catch {
      // ignore
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 rounded-2xl bg-[#0B1D3A] p-6 text-white">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-[#F5D376]">Property Agent Studio</p>
          <h2 className="mt-1 font-display text-2xl font-semibold">{user.name}</h2>
          <p className="text-xs text-slate-300 mt-1">
            {user.agency_name || 'Independent Advisor'} · {user.is_verified ? 'Verified Broker' : 'Verification Pending'}
          </p>
        </div>
        <button
          type="button"
          onClick={openNewForm}
          className="inline-flex min-h-[44px] items-center justify-center gap-2 rounded-xl bg-[#D4AF37] px-5 text-sm font-semibold text-[#0B1D3A] hover:bg-[#E5C158] transition-colors whitespace-nowrap"
        >
          <Plus className="h-4 w-4" />
          <span>Add New Property</span>
        </button>
      </div>

      {/* Sub-tabs */}
      <div className="flex flex-wrap gap-2">
        <button
          type="button"
          onClick={() => setSubTab('listings')}
          className={`inline-flex min-h-[42px] items-center gap-2 rounded-xl px-4 text-xs font-semibold ${
            subTab === 'listings' ? 'bg-[#0B1D3A] text-white' : 'bg-white border border-slate-200 text-slate-700'
          }`}
        >
          <span>My Listings ({myProperties.length})</span>
        </button>
        <button
          type="button"
          onClick={() => setSubTab('enquiries')}
          className={`inline-flex min-h-[42px] items-center gap-2 rounded-xl px-4 text-xs font-semibold ${
            subTab === 'enquiries' ? 'bg-[#0B1D3A] text-white' : 'bg-white border border-slate-200 text-slate-700'
          }`}
        >
          <Mail className="h-4 w-4 text-[#D4AF37]" />
          <span>Client Enquiries ({enquiries.length})</span>
        </button>
        <button
          type="button"
          onClick={() => setSubTab('visits')}
          className={`inline-flex min-h-[42px] items-center gap-2 rounded-xl px-4 text-xs font-semibold ${
            subTab === 'visits' ? 'bg-[#0B1D3A] text-white' : 'bg-white border border-slate-200 text-slate-700'
          }`}
        >
          <Calendar className="h-4 w-4 text-[#D4AF37]" />
          <span>Site Visits ({visits.length})</span>
        </button>
      </div>

      {subTab === 'listings' && (
        <div className="rounded-2xl bg-white border border-slate-200 overflow-x-auto">
          {myProperties.length === 0 ? (
            <div className="p-10 text-center text-sm text-slate-500">
              No properties listed yet. Click &ldquo;Add New Property&rdquo; to publish your first estate.
            </div>
          ) : (
            <table className="w-full min-w-[760px] text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold uppercase tracking-wider text-slate-500">
                  <th className="p-4">Property</th>
                  <th className="p-4">Price</th>
                  <th className="p-4">Availability</th>
                  <th className="p-4">Approval</th>
                  <th className="p-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {myProperties.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50/70">
                    <td className="p-4">
                      <div className="flex items-center gap-3">
                        <div className="h-12 w-16 overflow-hidden rounded-lg bg-slate-100 shrink-0">
                          <PropertyImage src={p.images?.[0]} alt={p.title} />
                        </div>
                        <div>
                          <button
                            type="button"
                            onClick={() => onSelectProperty(p)}
                            className="font-semibold text-[#0B1D3A] hover:text-[#9A7213] text-left"
                          >
                            {p.title}
                          </button>
                          <p className="text-xs text-slate-500">
                            {p.property_type} · {p.city}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="p-4 font-mono font-semibold text-[#0B1D3A] tabular-nums">
                      {formatCurrency(p.price, p.listing_type)}
                    </td>
                    <td className="p-4">
                      <select
                        aria-label={`Availability for ${p.title}`}
                        value={p.status}
                        onChange={(e) => handleQuickStatusChange(p.id, e.target.value)}
                        className="rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-800"
                      >
                        <option value="Available">Available</option>
                        <option value="Under Offer">Under Offer</option>
                        <option value="Sold">Sold</option>
                        <option value="Rented">Rented</option>
                      </select>
                    </td>
                    <td className="p-4 text-xs font-semibold text-slate-700">{p.approval_status}</td>
                    <td className="p-4 text-right">
                      <div className="inline-flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => openEditForm(p)}
                          className="inline-flex items-center gap-1 rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50"
                        >
                          <Edit3 className="h-3.5 w-3.5" />
                          <span>Edit</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDelete(p.id)}
                          aria-label={`Delete ${p.title}`}
                          className="inline-flex items-center gap-1 rounded-lg border border-rose-200 px-2.5 py-1.5 text-xs font-semibold text-rose-600 hover:bg-rose-50"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}

      {subTab === 'enquiries' && (
        <div className="rounded-2xl bg-white border border-slate-200 divide-y divide-slate-100">
          {enquiries.length === 0 ? (
            <div className="p-10 text-center text-sm text-slate-500">No client enquiries received yet.</div>
          ) : (
            enquiries.map((e) => (
              <div key={e.id} className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <p className="font-semibold text-[#0B1D3A]">{e.property_title}</p>
                  <p className="text-xs text-slate-500 mt-0.5">
                    From {e.name} ({e.email} · {e.phone})
                  </p>
                  <p className="mt-2 text-sm text-slate-700">{e.message}</p>
                </div>
                <select
                  aria-label="Enquiry status"
                  value={e.status}
                  onChange={(ev) => handleEnquiryStatus(e.id, ev.target.value)}
                  className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-[#0B1D3A] shrink-0"
                >
                  <option value="New">New</option>
                  <option value="In Progress">In Progress</option>
                  <option value="Resolved">Resolved</option>
                </select>
              </div>
            ))
          )}
        </div>
      )}

      {subTab === 'visits' && (
        <div className="rounded-2xl bg-white border border-slate-200 divide-y divide-slate-100">
          {visits.length === 0 ? (
            <div className="p-10 text-center text-sm text-slate-500">No scheduled site visits yet.</div>
          ) : (
            visits.map((v) => (
              <div key={v.id} className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <p className="font-semibold text-[#0B1D3A]">{v.property_title}</p>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Visitor: {v.visitor_name} ({v.visitor_phone}) · {v.visit_date} at {v.visit_time}
                  </p>
                  {v.notes && <p className="mt-1.5 text-sm text-slate-600">{v.notes}</p>}
                </div>
                <select
                  aria-label="Site visit status"
                  value={v.status}
                  onChange={(ev) => handleVisitStatus(v.id, ev.target.value as SiteVisit['status'])}
                  className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-[#0B1D3A] shrink-0"
                >
                  <option value="Pending">Pending</option>
                  <option value="Confirmed">Confirmed</option>
                  <option value="Completed">Completed</option>
                  <option value="Cancelled">Cancelled</option>
                </select>
              </div>
            ))
          )}
        </div>
      )}

      {/* Add / Edit Property Modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-sm p-4">
          <div className="w-full max-w-3xl max-h-[92vh] overflow-y-auto rounded-2xl bg-white p-6 sm:p-8 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between gap-4 border-b border-slate-100 pb-4">
              <h3 className="font-display text-2xl font-semibold text-[#0B1D3A]">
                {editingId ? 'Edit Property Listing' : 'Add New Property'}
              </h3>
              <button
                type="button"
                onClick={() => setShowForm(false)}
                className="flex h-10 w-10 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {formError && (
              <div className="mt-4 rounded-xl bg-rose-50 border border-rose-200 p-3 text-xs font-medium text-rose-700">
                {formError}
              </div>
            )}

            <form onSubmit={handleSaveProperty} className="mt-5 space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Property Title *</label>
                  <input
                    type="text"
                    required
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g. Sunset Ridge Contemporary Villa"
                    className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3.5 text-sm focus:border-[#0B1D3A] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Listing Purpose</label>
                  <select
                    value={listingType}
                    onChange={(e) => setListingType(e.target.value as 'buy' | 'rent')}
                    className="w-full min-h-[42px] rounded-xl border border-slate-200 bg-white px-3 text-sm"
                  >
                    <option value="buy">For Sale (Buy)</option>
                    <option value="rent">For Rent</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Property Type</label>
                  <select
                    value={propertyType}
                    onChange={(e) => setPropertyType(e.target.value)}
                    className="w-full min-h-[42px] rounded-xl border border-slate-200 bg-white px-3 text-sm"
                  >
                    <option value="Villa">Villa</option>
                    <option value="Penthouse">Penthouse</option>
                    <option value="House">House</option>
                    <option value="Apartment">Apartment</option>
                    <option value="Commercial">Commercial</option>
                    <option value="Plot">Plot</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Price ($) {listingType === 'rent' ? 'per month' : ''} *
                  </label>
                  <input
                    type="number"
                    required
                    min={100}
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3.5 text-sm tabular-nums"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Availability Status</label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value)}
                    className="w-full min-h-[42px] rounded-xl border border-slate-200 bg-white px-3 text-sm"
                  >
                    <option value="Available">Available</option>
                    <option value="Under Offer">Under Offer</option>
                    <option value="Sold">Sold</option>
                    <option value="Rented">Rented</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Street Address *</label>
                  <input
                    type="text"
                    required
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="450 Ocean View Blvd"
                    className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3.5 text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">City *</label>
                  <input
                    type="text"
                    required
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    placeholder="Santa Monica, CA"
                    className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3.5 text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Neighborhood</label>
                  <input
                    type="text"
                    value={neighborhood}
                    onChange={(e) => setNeighborhood(e.target.value)}
                    placeholder="North of Montana"
                    className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3.5 text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Furnishing Status</label>
                  <select
                    value={furnishing}
                    onChange={(e) => setFurnishing(e.target.value)}
                    className="w-full min-h-[42px] rounded-xl border border-slate-200 bg-white px-3 text-sm"
                  >
                    <option value="Furnished">Furnished</option>
                    <option value="Semi-Furnished">Semi-Furnished</option>
                    <option value="Unfurnished">Unfurnished</option>
                  </select>
                </div>

                <div className="sm:col-span-2 grid grid-cols-2 sm:grid-cols-5 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Beds</label>
                    <input
                      type="number"
                      min={0}
                      value={bedrooms}
                      onChange={(e) => setBedrooms(e.target.value)}
                      className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3 text-sm tabular-nums"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Baths</label>
                    <input
                      type="number"
                      min={0}
                      value={bathrooms}
                      onChange={(e) => setBathrooms(e.target.value)}
                      className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3 text-sm tabular-nums"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Sq Ft *</label>
                    <input
                      type="number"
                      required
                      min={100}
                      value={areaSqft}
                      onChange={(e) => setAreaSqft(e.target.value)}
                      className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3 text-sm tabular-nums"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Parking</label>
                    <input
                      type="number"
                      min={0}
                      value={parkingSpots}
                      onChange={(e) => setParkingSpots(e.target.value)}
                      className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3 text-sm tabular-nums"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Year Built</label>
                    <input
                      type="number"
                      min={1900}
                      max={2030}
                      value={yearBuilt}
                      onChange={(e) => setYearBuilt(e.target.value)}
                      className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3 text-sm tabular-nums"
                    />
                  </div>
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Description *</label>
                  <textarea
                    required
                    rows={3}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Highlight architectural materials, natural lighting, nearby landmarks..."
                    className="w-full rounded-xl border border-slate-200 p-3 text-sm"
                  />
                </div>
              </div>

              {/* Amenities Checkboxes */}
              <div>
                <p className="text-xs font-semibold text-slate-700 mb-2">Amenities</p>
                <div className="flex flex-wrap gap-2">
                  {COMMON_AMENITIES.map((am) => {
                    const active = selectedAmenities.includes(am);
                    return (
                      <button
                        key={am}
                        type="button"
                        onClick={() =>
                          setSelectedAmenities((prev) =>
                            prev.includes(am) ? prev.filter((x) => x !== am) : [...prev, am]
                          )
                        }
                        className={`rounded-lg border px-3 py-1.5 text-xs font-medium transition-colors ${
                          active
                            ? 'border-[#0B1D3A] bg-[#0B1D3A] text-white'
                            : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        {am}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Multi-Image Upload + Architectural Gallery Selector */}
              <div>
                <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                  <label className="text-xs font-semibold text-slate-700">
                    Property Images ({images.length}/8)
                  </label>
                  <label className="inline-flex cursor-pointer items-center gap-1.5 rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-semibold text-[#0B1D3A] hover:bg-slate-50">
                    <Upload className="h-3.5 w-3.5 text-[#9A7213]" />
                    <span>{uploading ? 'Uploading...' : 'Upload Photos'}</span>
                    <input
                      type="file"
                      accept="image/png,image/jpeg,image/webp"
                      multiple
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                  </label>
                </div>

                <div className="flex flex-wrap gap-2.5">
                  {images.map((img, i) => (
                    <div key={`${img}-${i}`} className="relative h-20 w-28 overflow-hidden rounded-xl border border-slate-200">
                      <PropertyImage src={img} alt={`Property preview ${i + 1}`} />
                      {images.length > 1 && (
                        <button
                          type="button"
                          onClick={() => setImages((prev) => prev.filter((_, idx) => idx !== i))}
                          className="absolute top-1 right-1 flex h-6 w-6 items-center justify-center rounded-md bg-slate-950/75 text-white"
                        >
                          <X className="h-3.5 w-3.5" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>

                <p className="mt-2.5 text-[11px] text-slate-500">Or attach from architectural portfolio presets:</p>
                <div className="mt-1.5 flex gap-2 overflow-x-auto pb-1">
                  {PRESET_GALLERY.map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => {
                        if (!images.includes(preset) && images.length < 8) {
                          setImages((prev) => [...prev, preset]);
                        }
                      }}
                      className="h-12 w-16 shrink-0 overflow-hidden rounded-lg border border-slate-200 hover:border-[#D4AF37]"
                    >
                      <PropertyImage src={preset} alt="Preset architecture" />
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 border-t border-slate-100 pt-4">
                <button
                  type="button"
                  onClick={() => setShowForm(false)}
                  className="min-h-[44px] rounded-xl border border-slate-200 px-5 text-sm font-semibold text-slate-700 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="min-h-[44px] rounded-xl bg-[#0B1D3A] px-6 text-sm font-semibold text-white hover:bg-[#132C54] disabled:opacity-60"
                >
                  {saving ? 'Saving...' : editingId ? 'Save Changes' : 'Submit Listing'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
