import React, { useMemo, useState } from 'react';
import { Calculator } from 'lucide-react';

interface EMICalculatorProps {
  initialPrice?: number;
  compact?: boolean;
}

export const EMICalculator: React.FC<EMICalculatorProps> = ({ initialPrice = 1250000, compact = false }) => {
  const [propertyPrice, setPropertyPrice] = useState(initialPrice);
  const [downPaymentPct, setDownPaymentPct] = useState(20);
  const [interestRate, setInterestRate] = useState(6.25);
  const [tenureYears, setTenureYears] = useState(20);

  const metrics = useMemo(() => {
    const downPayment = Math.round((propertyPrice * downPaymentPct) / 100);
    const principal = Math.max(0, propertyPrice - downPayment);
    const monthlyRate = interestRate / 12 / 100;
    const months = tenureYears * 12;

    let emi = 0;
    if (principal > 0 && months > 0) {
      if (monthlyRate === 0) {
        emi = principal / months;
      } else {
        const factor = Math.pow(1 + monthlyRate, months);
        emi = (principal * monthlyRate * factor) / (factor - 1);
      }
    }

    const totalPayable = emi * months;
    const totalInterest = Math.max(0, totalPayable - principal);
    const principalRatio = totalPayable > 0 ? (principal / totalPayable) * 100 : 100;

    return {
      downPayment,
      principal,
      emi: Math.round(emi),
      totalInterest: Math.round(totalInterest),
      totalPayable: Math.round(totalPayable),
      principalRatio,
    };
  }, [propertyPrice, downPaymentPct, interestRate, tenureYears]);

  const fmt = (val: number) =>
    new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(val);

  return (
    <div className="rounded-2xl bg-white border border-slate-200 p-5 sm:p-7">
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#0B1D3A] text-[#D4AF37]">
          <Calculator className="h-5 w-5" />
        </div>
        <div>
          <h3 className="font-display text-xl font-semibold text-[#0B1D3A]">Mortgage & EMI Calculator</h3>
          <p className="text-xs text-slate-500">Estimate monthly payments, down payment, and total interest</p>
        </div>
      </div>

      <div className={`mt-6 grid gap-6 ${compact ? 'grid-cols-1' : 'grid-cols-1 lg:grid-cols-12'}`}>
        {/* Controls */}
        <div className={`space-y-5 ${compact ? '' : 'lg:col-span-7'}`}>
          <div>
            <div className="flex items-center justify-between text-sm">
              <label className="font-medium text-slate-700">Property Price</label>
              <span className="font-mono font-semibold text-[#0B1D3A] tabular-nums">{fmt(propertyPrice)}</span>
            </div>
            <input
              type="range"
              min={100000}
              max={10000000}
              step={25000}
              value={propertyPrice}
              onChange={(e) => setPropertyPrice(Number(e.target.value))}
              className="mt-2 w-full accent-[#0B1D3A]"
            />
          </div>

          <div>
            <div className="flex items-center justify-between text-sm">
              <label className="font-medium text-slate-700">Down Payment ({downPaymentPct}%)</label>
              <span className="font-mono font-semibold text-[#0B1D3A] tabular-nums">{fmt(metrics.downPayment)}</span>
            </div>
            <input
              type="range"
              min={5}
              max={60}
              step={1}
              value={downPaymentPct}
              onChange={(e) => setDownPaymentPct(Number(e.target.value))}
              className="mt-2 w-full accent-[#0B1D3A]"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <div className="flex items-center justify-between text-sm">
                <label className="font-medium text-slate-700">Interest Rate</label>
                <span className="font-mono font-semibold text-[#0B1D3A] tabular-nums">{interestRate.toFixed(2)}%</span>
              </div>
              <input
                type="range"
                min={2.5}
                max={14}
                step={0.1}
                value={interestRate}
                onChange={(e) => setInterestRate(Number(e.target.value))}
                className="mt-2 w-full accent-[#C99A2E]"
              />
            </div>

            <div>
              <div className="flex items-center justify-between text-sm">
                <label className="font-medium text-slate-700">Loan Tenure</label>
                <span className="font-mono font-semibold text-[#0B1D3A] tabular-nums">{tenureYears} Years</span>
              </div>
              <input
                type="range"
                min={5}
                max={30}
                step={1}
                value={tenureYears}
                onChange={(e) => setTenureYears(Number(e.target.value))}
                className="mt-2 w-full accent-[#C99A2E]"
              />
            </div>
          </div>
        </div>

        {/* Summary panel */}
        <div className={`rounded-2xl bg-[#0B1D3A] p-6 text-white ${compact ? '' : 'lg:col-span-5'}`}>
          <p className="text-xs font-semibold uppercase tracking-wider text-[#F5D376]">Estimated Monthly EMI</p>
          <p className="mt-2 font-mono text-3xl sm:text-4xl font-bold tracking-tight tabular-nums">
            {fmt(metrics.emi)}
            <span className="text-sm font-normal text-slate-300"> / mo</span>
          </p>

          {/* Principal vs Interest visual bar */}
          <div className="mt-5">
            <div className="h-2.5 w-full overflow-hidden rounded-full bg-white/15 flex">
              <div
                style={{ width: `${metrics.principalRatio}%` }}
                className="h-full bg-[#D4AF37]"
              />
            </div>
            <div className="mt-2 flex items-center justify-between text-xs text-slate-300">
              <span className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-sm bg-[#D4AF37]" />
                Principal ({Math.round(metrics.principalRatio)}%)
              </span>
              <span className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-sm bg-white/30" />
                Interest ({Math.round(100 - metrics.principalRatio)}%)
              </span>
            </div>
          </div>

          <dl className="mt-6 space-y-2.5 border-t border-white/15 pt-4 text-xs">
            <div className="flex items-center justify-between">
              <dt className="text-slate-300">Loan Principal</dt>
              <dd className="font-mono font-semibold tabular-nums">{fmt(metrics.principal)}</dd>
            </div>
            <div className="flex items-center justify-between">
              <dt className="text-slate-300">Total Interest Payable</dt>
              <dd className="font-mono font-semibold text-[#F5D376] tabular-nums">{fmt(metrics.totalInterest)}</dd>
            </div>
            <div className="flex items-center justify-between border-t border-white/10 pt-2.5 text-sm">
              <dt className="font-medium text-white">Total Loan Cost</dt>
              <dd className="font-mono font-bold tabular-nums">{fmt(metrics.totalPayable)}</dd>
            </div>
          </dl>
        </div>
      </div>
    </div>
  );
};
