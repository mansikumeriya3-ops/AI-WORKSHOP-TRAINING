import React, { useState } from 'react';
import { Building2 } from 'lucide-react';

interface PropertyImageProps {
  src?: string;
  alt: string;
  className?: string;
  fallbackTitle?: string;
}

export const PropertyImage: React.FC<PropertyImageProps> = ({
  src,
  alt,
  className = 'h-full w-full object-cover',
  fallbackTitle,
}) => {
  const [errored, setErrored] = useState(false);

  if (!src || errored) {
    return (
      <div className="flex h-full w-full flex-col items-center justify-center bg-gradient-to-br from-[#0B1D3A] via-[#132C54] to-[#0F2444] p-4 text-center text-white">
        <Building2 className="h-8 w-8 text-[#D4AF37]" />
        {fallbackTitle && (
          <p className="mt-2 line-clamp-2 text-xs font-medium text-slate-200">{fallbackTitle}</p>
        )}
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setErrored(true)}
      className={className}
    />
  );
};
