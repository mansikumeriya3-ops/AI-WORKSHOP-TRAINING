import React, { useState } from 'react';
import { Download, Smartphone, X, Share2, MoreVertical } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface PWAInstallButtonProps {
  variant?: 'hero' | 'compact' | 'card';
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({ variant = 'hero' }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showGuide, setShowGuide] = useState(false);

  if (isInstalled) {
    return null;
  }

  const handleClick = async () => {
    if (isInstallable) {
      await install();
    } else {
      setShowGuide(true);
    }
  };

  const buttonClass =
    variant === 'compact'
      ? 'inline-flex items-center gap-1.5 rounded-lg border border-[#D4AF37]/50 bg-[#D4AF37]/15 px-3 py-2 text-xs font-semibold text-[#F5D376] hover:bg-[#D4AF37]/25 transition-colors whitespace-nowrap shrink-0 min-h-[40px]'
      : variant === 'card'
        ? 'inline-flex items-center justify-center gap-2 rounded-xl bg-[#0B1D3A] px-5 py-3 text-sm font-semibold text-white hover:bg-[#132C54] transition-colors whitespace-nowrap shrink-0 min-h-[44px]'
        : 'inline-flex items-center justify-center gap-2 rounded-xl border border-white/25 bg-white/10 backdrop-blur-md px-5 py-3 text-sm font-semibold text-white hover:bg-white/20 transition-colors whitespace-nowrap shrink-0 min-h-[44px]';

  return (
    <>
      <button type="button" onClick={handleClick} className={buttonClass}>
        {isInstallable ? <Download className="h-4 w-4 text-[#D4AF37]" /> : <Smartphone className="h-4 w-4 text-[#D4AF37]" />}
        <span>{isInstallable ? 'Install Mobile App' : 'Get Mobile App'}</span>
      </button>

      {showGuide && (
        <div
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/60 backdrop-blur-sm p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="install-guide-title"
        >
          <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl border border-slate-200 text-slate-900">
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-[#9A7213]">Android & iOS Mobile App</p>
                <h3 id="install-guide-title" className="mt-1 text-xl font-semibold text-[#0B1D3A]">
                  Install Dream Homes Realty
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowGuide(false)}
                aria-label="Close install instructions"
                className="flex h-10 w-10 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 hover:text-slate-900"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <p className="mt-3 text-sm text-slate-600 leading-relaxed">
              Install Dream Homes Realty directly onto your phone home screen for full-screen mobile browsing, instant property access, and offline saved listings.
            </p>

            <div className="mt-5 space-y-4 border-t border-slate-100 pt-4">
              {isIOS ? (
                <div className="space-y-2.5 text-sm text-slate-700">
                  <p className="font-semibold text-[#0B1D3A]">On iPhone / iPad (Safari):</p>
                  <p className="flex items-center gap-2">
                    <Share2 className="h-4 w-4 text-[#9A7213] shrink-0" />
                    <span>1. Tap the <strong>Share</strong> icon in Safari&apos;s toolbar.</span>
                  </p>
                  <p>2. Scroll down and tap <strong>Add to Home Screen</strong>, then confirm.</p>
                </div>
              ) : (
                <div className="space-y-2.5 text-sm text-slate-700">
                  <p className="font-semibold text-[#0B1D3A]">On Android (Google Chrome):</p>
                  <p className="flex items-center gap-2">
                    <MoreVertical className="h-4 w-4 text-[#9A7213] shrink-0" />
                    <span>1. Tap the <strong>Chrome Menu (⋮)</strong> in the top-right corner.</span>
                  </p>
                  <p>2. Tap <strong>Install app</strong> or <strong>Add to Home screen</strong> to install on your phone.</p>
                </div>
              )}
            </div>

            <button
              type="button"
              onClick={() => setShowGuide(false)}
              className="mt-6 w-full rounded-xl bg-[#0B1D3A] py-3 text-sm font-semibold text-white hover:bg-[#132C54] transition-colors"
            >
              Got It
            </button>
          </div>
        </div>
      )}
    </>
  );
};
