import React from 'react';
import { GitCompareArrows, Heart, MapPin, Star } from 'lucide-react';
import type { Property } from '../types';
import { PropertyImage } from './PropertyImage';

interface PropertyCardProps {
  property: Property;
  isFavorite: boolean;
  isCompared: boolean;
  onSelect: (property: Property) => void;
  onToggleFavorite: (propertyId: number) => void;
  onToggleCompare: (property: Property) => void;
}

export function formatCurrency(price: number, listingType: 'buy' | 'rent'): string {
  const formatted = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0,
  }).format(price);
  return listingType === 'rent' ? `${formatted}/mo` : formatted;
}

export const PropertyCard: React.FC<PropertyCardProps> = ({
  property,
  isFavorite,
  isCompared,
  onSelect,
  onToggleFavorite,
  onToggleCompare,
}) => {
  const primaryImage = property.images?.[0];
  const pricePerSqft = property.area_sqft > 0 ? Math.round(property.price / property.area_sqft) : 0;

  return (
    <article className="group flex flex-col overflow-hidden rounded-2xl bg-white border border-slate-200 transition-all duration-200 hover:-translate-y-0.5 hover:shadow-lg hover:border-slate-300">
      <div className="relative aspect-[4/3] w-full overflow-hidden bg-slate-100">
        <button
          type="button"
          onClick={() => onSelect(property)}
          className="block h-full w-full text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-[#D4AF37]"
        >
          <PropertyImage
            src={primaryImage}
            alt={property.title}
            fallbackTitle={property.title}
            className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
          />
          <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-slate-950/65 via-slate-950/10 to-transparent" />
        </button>

        {/* Top-right functional action controls (44px hitbox) */}
        <div className="absolute top-2.5 right-2.5 flex items-center gap-1.5">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onToggleCompare(property);
            }}
            aria-label={isCompared ? 'Remove from comparison' : 'Compare property'}
            title={isCompared ? 'Added to compare' : 'Compare'}
            className={`flex h-11 w-11 items-center justify-center rounded-xl backdrop-blur-md transition-colors ${
              isCompared
                ? 'bg-[#D4AF37] text-[#0B1D3A]'
                : 'bg-[#0B1D3A]/75 text-white hover:bg-[#0B1D3A]'
            }`}
          >
            <GitCompareArrows className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onToggleFavorite(property.id);
            }}
            aria-label={isFavorite ? 'Remove from favourites' : 'Save to favourites'}
            title={isFavorite ? 'Saved' : 'Save property'}
            className={`flex h-11 w-11 items-center justify-center rounded-xl backdrop-blur-md transition-colors ${
              isFavorite
                ? 'bg-white text-rose-600'
                : 'bg-[#0B1D3A]/75 text-white hover:bg-[#0B1D3A]'
            }`}
          >
            <Heart className={`h-4 w-4 ${isFavorite ? 'fill-rose-600' : ''}`} />
          </button>
        </div>

        {/* Bottom price overlay with contrast scrim */}
        <div className="pointer-events-none absolute bottom-3 left-4 right-4 flex items-end justify-between text-white">
          <div>
            <p className="text-xl font-bold tracking-tight tabular-nums font-mono">
              {formatCurrency(property.price, property.listing_type)}
            </p>
            {property.listing_type === 'buy' && pricePerSqft > 0 && (
              <p className="text-[11px] text-slate-200 tabular-nums font-mono">
                ${pricePerSqft.toLocaleString()} / sq ft
              </p>
            )}
          </div>
          <span className="text-xs font-semibold tracking-wide text-[#F5D376]">
            {property.status}
          </span>
        </div>
      </div>

      {/* Card Body: Unboxed clean metadata (Zero-Pill Rule) */}
      <div className="flex flex-1 flex-col p-5">
        <div className="flex items-center justify-between gap-2 text-xs text-slate-500">
          <div className="flex items-center gap-1.5 truncate">
            <span className="font-semibold text-[#9A7213]">
              {property.listing_type === 'buy' ? 'For Sale' : 'For Rent'}
            </span>
            <span aria-hidden="true">·</span>
            <span>{property.property_type}</span>
            {property.featured && (
              <>
                <span aria-hidden="true">·</span>
                <span className="font-medium text-[#0B1D3A]">Featured</span>
              </>
            )}
          </div>
          {Number(property.avg_rating) > 0 && (
            <span className="inline-flex items-center gap-1 font-medium text-slate-700 shrink-0 tabular-nums">
              <Star className="h-3.5 w-3.5 fill-[#D4AF37] text-[#D4AF37]" />
              {Number(property.avg_rating).toFixed(1)}
            </span>
          )}
        </div>

        <button
          type="button"
          onClick={() => onSelect(property)}
          className="mt-2 text-left focus:outline-none"
        >
          <h3 className="font-display text-lg font-semibold text-[#0B1D3A] group-hover:text-[#9A7213] transition-colors line-clamp-1">
            {property.title}
          </h3>
        </button>

        <p className="mt-1 flex items-center gap-1 text-xs text-slate-500 line-clamp-1">
          <MapPin className="h-3.5 w-3.5 text-slate-400 shrink-0" />
          <span>
            {property.neighborhood}, {property.city}
          </span>
        </p>

        <div className="mt-4 flex flex-wrap items-center gap-x-2 gap-y-1 border-t border-slate-100 pt-3.5 text-xs font-medium text-slate-600 tabular-nums">
          {property.bedrooms > 0 && (
            <>
              <span>{property.bedrooms} Beds</span>
              <span aria-hidden="true" className="text-slate-300">·</span>
            </>
          )}
          <span>{property.bathrooms} Baths</span>
          <span aria-hidden="true" className="text-slate-300">·</span>
          <span>{property.area_sqft.toLocaleString()} sq ft</span>
          <span aria-hidden="true" className="text-slate-300">·</span>
          <span>{property.furnishing}</span>
        </div>

        <div className="mt-4 flex items-center justify-between gap-3 pt-1">
          <span className="text-xs text-slate-500 truncate">
            Advisor: <strong className="font-medium text-slate-700">{property.agent_name}</strong>
          </span>
          <button
            type="button"
            onClick={() => onSelect(property)}
            className="text-xs font-semibold text-[#0B1D3A] hover:text-[#9A7213] transition-colors whitespace-nowrap shrink-0"
          >
            View Details →
          </button>
        </div>
      </div>
    </article>
  );
};
