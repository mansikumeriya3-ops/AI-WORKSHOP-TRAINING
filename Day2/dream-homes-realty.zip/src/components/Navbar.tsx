import React from 'react';
import { Building2, Calculator, GitCompareArrows, Heart, Home, LayoutDashboard, Search, ShieldCheck, UserCircle2 } from 'lucide-react';
import type { User } from '../types';
import { PWAInstallButton } from './PWAInstallButton';

export type ActiveTab = 'home' | 'explore' | 'emi' | 'compare' | 'favorites' | 'portal';

interface NavbarProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  user: User | null;
  compareCount: number;
  favoritesCount: number;
  onOpenAuth: () => void;
  onLogout: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  onTabChange,
  user,
  compareCount,
  favoritesCount,
  onOpenAuth,
  onLogout,
}) => {
  const portalLabel =
    user?.role === 'admin'
      ? 'Admin Console'
      : user?.role === 'agent'
        ? 'Agent Studio'
        : 'My Account';

  return (
    <>
      {/* Desktop Header: Strictly 3 zones (Brand Wordmark | 5 single-line links | 1 primary CTA) */}
      <header className="hidden lg:block sticky top-0 z-40 bg-[#0B1D3A] text-white border-b border-white/10">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-8 px-8 h-16">
          {/* Zone 1: Single text element wordmark */}
          <button
            type="button"
            onClick={() => onTabChange('home')}
            className="font-display text-xl font-semibold tracking-tight text-white hover:text-[#F5D376] transition-colors whitespace-nowrap shrink-0"
          >
            Dream Homes Realty
          </button>

          {/* Zone 2: 5 clean single-line text navigation links */}
          <nav className="flex items-center gap-7 text-sm font-medium" aria-label="Primary Navigation">
            <button
              type="button"
              onClick={() => onTabChange('home')}
              className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors ${
                activeTab === 'home'
                  ? 'border-[#D4AF37] text-white'
                  : 'border-transparent text-slate-300 hover:text-white'
              }`}
            >
              Dashboard
            </button>
            <button
              type="button"
              onClick={() => onTabChange('explore')}
              className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors ${
                activeTab === 'explore'
                  ? 'border-[#D4AF37] text-white'
                  : 'border-transparent text-slate-300 hover:text-white'
              }`}
            >
              Properties
            </button>
            <button
              type="button"
              onClick={() => onTabChange('emi')}
              className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors ${
                activeTab === 'emi'
                  ? 'border-[#D4AF37] text-white'
                  : 'border-transparent text-slate-300 hover:text-white'
              }`}
            >
              EMI Tools
            </button>
            <button
              type="button"
              onClick={() => onTabChange('compare')}
              className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors ${
                activeTab === 'compare'
                  ? 'border-[#D4AF37] text-white'
                  : 'border-transparent text-slate-300 hover:text-white'
              }`}
            >
              Compare ({compareCount})
            </button>
            <button
              type="button"
              onClick={() => (user ? onTabChange('portal') : onOpenAuth())}
              className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors ${
                activeTab === 'portal'
                  ? 'border-[#D4AF37] text-white'
                  : 'border-transparent text-slate-300 hover:text-white'
              }`}
            >
              {portalLabel}
            </button>
          </nav>

          {/* Zone 3: 1 primary action */}
          <div className="shrink-0">
            {user ? (
              <button
                type="button"
                onClick={onLogout}
                className="rounded-lg bg-[#D4AF37] px-4 py-2 text-xs font-semibold text-[#0B1D3A] hover:bg-[#E5C158] transition-colors whitespace-nowrap shrink-0"
              >
                Sign Out ({user.name.split(' ')[0]})
              </button>
            ) : (
              <button
                type="button"
                onClick={onOpenAuth}
                className="rounded-lg bg-[#D4AF37] px-5 py-2 text-xs font-semibold text-[#0B1D3A] hover:bg-[#E5C158] transition-colors whitespace-nowrap shrink-0"
              >
                Sign In
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Mobile Top App Bar (52px height, obeys <= 15% mobile sticky cap) */}
      <header className="lg:hidden sticky top-0 z-40 flex h-[52px] items-center justify-between gap-3 bg-[#0B1D3A] px-4 text-white border-b border-white/10">
        <button
          type="button"
          onClick={() => onTabChange('home')}
          className="flex items-center gap-2 text-left min-w-0"
        >
          <Building2 className="h-5 w-5 text-[#D4AF37] shrink-0" />
          <span className="font-display text-base font-semibold tracking-tight truncate">
            Dream Homes Realty
          </span>
        </button>

        <div className="flex items-center gap-2 shrink-0">
          <PWAInstallButton variant="compact" />
          <button
            type="button"
            onClick={() => (user ? onTabChange('portal') : onOpenAuth())}
            aria-label={user ? 'Open account portal' : 'Sign in'}
            className="flex h-10 w-10 items-center justify-center rounded-lg bg-white/10 text-white hover:bg-white/20"
          >
            {user?.role === 'admin' ? (
              <ShieldCheck className="h-5 w-5 text-[#D4AF37]" />
            ) : (
              <UserCircle2 className="h-5 w-5 text-[#D4AF37]" />
            )}
          </button>
        </div>
      </header>

      {/* Mobile Fixed Bottom Tab Bar (64px height, thumb-zone ergonomics) */}
      <nav
        className="lg:hidden fixed bottom-0 left-0 right-0 z-40 grid grid-cols-5 items-center h-16 pb-safe bg-white/95 backdrop-blur-md border-t border-slate-200"
        aria-label="Mobile Bottom Navigation"
      >
        <button
          type="button"
          onClick={() => onTabChange('home')}
          className={`flex flex-col items-center justify-center h-full min-h-[44px] ${
            activeTab === 'home' ? 'text-[#0B1D3A]' : 'text-slate-500'
          }`}
        >
          <Home className={`h-5 w-5 ${activeTab === 'home' ? 'text-[#C99A2E]' : ''}`} />
          <span className="mt-1 text-[10px] font-semibold tracking-tight">Home</span>
        </button>

        <button
          type="button"
          onClick={() => onTabChange('explore')}
          className={`flex flex-col items-center justify-center h-full min-h-[44px] ${
            activeTab === 'explore' ? 'text-[#0B1D3A]' : 'text-slate-500'
          }`}
        >
          <Search className={`h-5 w-5 ${activeTab === 'explore' ? 'text-[#C99A2E]' : ''}`} />
          <span className="mt-1 text-[10px] font-semibold tracking-tight">Explore</span>
        </button>

        <button
          type="button"
          onClick={() => onTabChange('emi')}
          className={`flex flex-col items-center justify-center h-full min-h-[44px] ${
            activeTab === 'emi' ? 'text-[#0B1D3A]' : 'text-slate-500'
          }`}
        >
          <Calculator className={`h-5 w-5 ${activeTab === 'emi' ? 'text-[#C99A2E]' : ''}`} />
          <span className="mt-1 text-[10px] font-semibold tracking-tight">EMI</span>
        </button>

        <button
          type="button"
          onClick={() => onTabChange('favorites')}
          className={`relative flex flex-col items-center justify-center h-full min-h-[44px] ${
            activeTab === 'favorites' ? 'text-[#0B1D3A]' : 'text-slate-500'
          }`}
        >
          <Heart className={`h-5 w-5 ${activeTab === 'favorites' ? 'text-[#C99A2E]' : ''}`} />
          <span className="mt-1 text-[10px] font-semibold tracking-tight">
            Saved{favoritesCount > 0 ? ` (${favoritesCount})` : ''}
          </span>
        </button>

        <button
          type="button"
          onClick={() => (user ? onTabChange('portal') : onOpenAuth())}
          className={`flex flex-col items-center justify-center h-full min-h-[44px] ${
            activeTab === 'portal' ? 'text-[#0B1D3A]' : 'text-slate-500'
          }`}
        >
          {compareCount > 0 && activeTab !== 'portal' ? (
            <GitCompareArrows className="h-5 w-5 text-[#C99A2E]" />
          ) : (
            <LayoutDashboard className={`h-5 w-5 ${activeTab === 'portal' ? 'text-[#C99A2E]' : ''}`} />
          )}
          <span className="mt-1 text-[10px] font-semibold tracking-tight">
            {user ? 'Portal' : 'Sign In'}
          </span>
        </button>
      </nav>
    </>
  );
};
