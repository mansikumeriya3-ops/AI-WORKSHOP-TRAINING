import React, { useEffect, useState } from 'react';
import {
  BarChart3,
  Building2,
  Calendar,
  Check,
  Download,
  Mail,
  ShieldCheck,
  Star,
  Trash2,
  Users,
  X,
} from 'lucide-react';
import { api } from '../api/client';
import type { AnalyticsData, DashboardStats, Enquiry, Property, SiteVisit, User } from '../types';
import { formatCurrency } from './PropertyCard';

interface AdminPanelProps {
  stats: DashboardStats;
  onDataChanged: () => void;
  onSelectProperty: (property: Property) => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  stats,
  onDataChanged,
  onSelectProperty,
}) => {
  const [section, setSection] = useState<'analytics' | 'properties' | 'users' | 'enquiries' | 'visits'>('analytics');
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);
  const [allProperties, setAllProperties] = useState<Property[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [enquiries, setEnquiries] = useState<Enquiry[]>([]);
  const [visits, setVisits] = useState<SiteVisit[]>([]);

  const loadAll = () => {
    api.adminGetAnalytics().then(setAnalytics).catch(() => {});
    api.getProperties({ includeAll: true }).then((res) => setAllProperties(res.properties)).catch(() => {});
    api.adminGetUsers().then((res) => setUsers(res.users)).catch(() => {});
    api.getEnquiries().then((res) => setEnquiries(res.enquiries)).catch(() => {});
    api.getVisits().then((res) => setVisits(res.visits)).catch(() => {});
  };

  useEffect(() => {
    loadAll();
  }, []);

  const handleApproval = async (id: number, approval_status: string) => {
    await api.adminUpdatePropertyApproval(id, { approval_status });
    loadAll();
    onDataChanged();
  };

  const handleFeatureToggle = async (id: number, featured: boolean) => {
    await api.adminUpdatePropertyApproval(id, { featured });
    loadAll();
    onDataChanged();
  };

  const handleDeleteProperty = async (id: number) => {
    await api.deleteProperty(id);
    loadAll();
    onDataChanged();
  };

  const handleUserUpdate = async (id: number, patch: { is_verified?: boolean; is_active?: boolean; role?: string }) => {
    await api.adminUpdateUser(id, patch);
    loadAll();
    onDataChanged();
  };

  const handleUserDelete = async (id: number) => {
    await api.adminDeleteUser(id);
    loadAll();
    onDataChanged();
  };

  const handleEnquiryStatus = async (id: number, status: string) => {
    await api.updateEnquiry(id, { status });
    loadAll();
    onDataChanged();
  };

  const handleVisitStatus = async (id: number, status: SiteVisit['status']) => {
    await api.updateVisitStatus(id, status);
    loadAll();
    onDataChanged();
  };

  const exportCsvReport = () => {
    const header = ['ID', 'Title', 'Type', 'Purpose', 'Price', 'City', 'Status', 'Approval', 'Agent'];
    const lines = allProperties.map((p) =>
      [
        p.id,
        `"${p.title.replace(/"/g, '""')}"`,
        p.property_type,
        p.listing_type,
        p.price,
        `"${p.city}"`,
        p.status,
        p.approval_status,
        `"${p.agent_name}"`,
      ].join(',')
    );
    const csv = [header.join(','), ...lines].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'dream-homes-portfolio-report.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 rounded-2xl bg-[#0B1D3A] p-6 text-white">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-[#F5D376]">Administration</p>
          <h2 className="mt-1 font-display text-2xl sm:text-3xl font-semibold">Dream Homes Command Console</h2>
          <p className="text-xs text-slate-300 mt-1 tabular-nums">
            {stats.pendingApprovalCount} pending approvals · {stats.totalEnquiries} enquiries · {stats.totalVisits} site visits
          </p>
        </div>
        <button
          type="button"
          onClick={exportCsvReport}
          className="inline-flex min-h-[42px] items-center gap-2 rounded-xl bg-[#D4AF37] px-4 text-xs font-semibold text-[#0B1D3A] hover:bg-[#E5C158] whitespace-nowrap"
        >
          <Download className="h-4 w-4" />
          <span>Export Portfolio CSV</span>
        </button>
      </div>

      {/* Section Tabs */}
      <div className="flex flex-wrap gap-2">
        {[
          { id: 'analytics', label: 'Analytics & Reports', icon: BarChart3 },
          { id: 'properties', label: `Properties & Approvals (${allProperties.length})`, icon: Building2 },
          { id: 'users', label: `Users & Agents (${users.length})`, icon: Users },
          { id: 'enquiries', label: `Enquiries (${enquiries.length})`, icon: Mail },
          { id: 'visits', label: `Site Visits (${visits.length})`, icon: Calendar },
        ].map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setSection(item.id as typeof section)}
              className={`inline-flex min-h-[42px] items-center gap-2 rounded-xl px-4 text-xs font-semibold transition-colors ${
                section === item.id
                  ? 'bg-[#0B1D3A] text-white'
                  : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
              }`}
            >
              <Icon className="h-4 w-4 text-[#D4AF37]" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>

      {section === 'analytics' && analytics && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-6 rounded-2xl bg-white border border-slate-200 p-6">
            <h3 className="font-display text-lg font-semibold text-[#0B1D3A]">Inventory by Property Type</h3>
            <div className="mt-5 space-y-4">
              {analytics.byType.map((row) => {
                const maxCount = Math.max(1, ...analytics.byType.map((r) => r.count));
                const widthPct = Math.round((row.count / maxCount) * 100);
                return (
                  <div key={row.label}>
                    <div className="flex items-center justify-between text-xs font-medium text-slate-700">
                      <span>{row.label}</span>
                      <span className="font-mono tabular-nums">
                        {row.count} listings · ${(row.total_value / 1000000).toFixed(2)}M total
                      </span>
                    </div>
                    <div className="mt-1.5 h-2.5 w-full rounded-full bg-slate-100 overflow-hidden">
                      <div style={{ width: `${widthPct}%` }} className="h-full bg-[#0B1D3A]" />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="lg:col-span-6 rounded-2xl bg-white border border-slate-200 p-6">
            <h3 className="font-display text-lg font-semibold text-[#0B1D3A]">Top Performing Property Agents</h3>
            <div className="mt-4 divide-y divide-slate-100">
              {analytics.topAgents.map((ag) => (
                <div key={ag.id} className="py-3 flex items-center justify-between gap-4 text-sm">
                  <div>
                    <p className="font-semibold text-[#0B1D3A]">
                      {ag.name} {ag.is_verified ? '· Verified' : ''}
                    </p>
                    <p className="text-xs text-slate-500">{ag.agency_name || 'Advisor'}</p>
                  </div>
                  <div className="text-right font-mono text-xs text-slate-700 tabular-nums">
                    <p>{ag.listings} listings</p>
                    <p className="text-slate-500">
                      {ag.total_views} views · {ag.enquiries_received} leads
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {section === 'properties' && (
        <div className="rounded-2xl bg-white border border-slate-200 overflow-x-auto">
          <table className="w-full min-w-[820px] text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold uppercase tracking-wider text-slate-500">
                <th className="p-4">Property</th>
                <th className="p-4">Advisor</th>
                <th className="p-4">Price</th>
                <th className="p-4">Approval Status</th>
                <th className="p-4">Featured</th>
                <th className="p-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm">
              {allProperties.map((p) => (
                <tr key={p.id} className="hover:bg-slate-50/70">
                  <td className="p-4">
                    <button
                      type="button"
                      onClick={() => onSelectProperty(p)}
                      className="font-semibold text-[#0B1D3A] hover:text-[#9A7213] text-left"
                    >
                      {p.title}
                    </button>
                    <p className="text-xs text-slate-500">
                      {p.property_type} · {p.city} · {p.status}
                    </p>
                  </td>
                  <td className="p-4 text-xs text-slate-700">{p.agent_name}</td>
                  <td className="p-4 font-mono font-semibold text-[#0B1D3A] tabular-nums">
                    {formatCurrency(p.price, p.listing_type)}
                  </td>
                  <td className="p-4 text-xs font-semibold">
                    <span
                      className={
                        p.approval_status === 'Approved'
                          ? 'text-emerald-700'
                          : p.approval_status === 'Pending'
                            ? 'text-amber-700'
                            : 'text-rose-700'
                      }
                    >
                      {p.approval_status}
                    </span>
                  </td>
                  <td className="p-4">
                    <button
                      type="button"
                      onClick={() => handleFeatureToggle(p.id, !p.featured)}
                      aria-label={`Toggle featured for ${p.title}`}
                      className={`inline-flex items-center gap-1 rounded-lg border px-2.5 py-1 text-xs font-semibold ${
                        p.featured
                          ? 'border-[#D4AF37] bg-[#D4AF37]/15 text-[#9A7213]'
                          : 'border-slate-200 text-slate-500 hover:bg-slate-50'
                      }`}
                    >
                      <Star className={`h-3.5 w-3.5 ${p.featured ? 'fill-[#D4AF37]' : ''}`} />
                      <span>{p.featured ? 'Featured' : 'Standard'}</span>
                    </button>
                  </td>
                  <td className="p-4 text-right">
                    <div className="inline-flex items-center gap-1.5">
                      {p.approval_status !== 'Approved' && (
                        <button
                          type="button"
                          onClick={() => handleApproval(p.id, 'Approved')}
                          className="inline-flex items-center gap-1 rounded-lg bg-emerald-700 px-2.5 py-1.5 text-xs font-semibold text-white hover:bg-emerald-800"
                        >
                          <Check className="h-3.5 w-3.5" />
                          <span>Approve</span>
                        </button>
                      )}
                      {p.approval_status !== 'Rejected' && (
                        <button
                          type="button"
                          onClick={() => handleApproval(p.id, 'Rejected')}
                          className="inline-flex items-center gap-1 rounded-lg border border-amber-300 px-2.5 py-1.5 text-xs font-semibold text-amber-800 hover:bg-amber-50"
                        >
                          <X className="h-3.5 w-3.5" />
                          <span>Reject</span>
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => handleDeleteProperty(p.id)}
                        aria-label={`Delete ${p.title}`}
                        className="inline-flex items-center rounded-lg border border-rose-200 p-1.5 text-rose-600 hover:bg-rose-50"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {section === 'users' && (
        <div className="rounded-2xl bg-white border border-slate-200 overflow-x-auto">
          <table className="w-full min-w-[780px] text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold uppercase tracking-wider text-slate-500">
                <th className="p-4">User</th>
                <th className="p-4">Role</th>
                <th className="p-4">Verification</th>
                <th className="p-4">Account Status</th>
                <th className="p-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm">
              {users.map((u) => (
                <tr key={u.id} className="hover:bg-slate-50/70">
                  <td className="p-4">
                    <p className="font-semibold text-[#0B1D3A]">{u.name}</p>
                    <p className="text-xs text-slate-500">
                      {u.email} {u.agency_name ? `· ${u.agency_name}` : ''}
                    </p>
                  </td>
                  <td className="p-4">
                    <select
                      aria-label={`Role for ${u.name}`}
                      value={u.role}
                      onChange={(e) => handleUserUpdate(u.id, { role: e.target.value })}
                      className="rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-semibold text-slate-800"
                    >
                      <option value="customer">Customer</option>
                      <option value="agent">Agent</option>
                      <option value="admin">Admin</option>
                    </select>
                  </td>
                  <td className="p-4">
                    <button
                      type="button"
                      onClick={() => handleUserUpdate(u.id, { is_verified: u.is_verified !== 1 })}
                      className={`inline-flex items-center gap-1 rounded-lg border px-2.5 py-1 text-xs font-semibold ${
                        u.is_verified === 1
                          ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
                          : 'border-slate-200 text-slate-600'
                      }`}
                    >
                      <ShieldCheck className="h-3.5 w-3.5" />
                      <span>{u.is_verified === 1 ? 'Verified' : 'Verify'}</span>
                    </button>
                  </td>
                  <td className="p-4">
                    <button
                      type="button"
                      onClick={() => handleUserUpdate(u.id, { is_active: u.is_active !== 1 })}
                      className={`rounded-lg border px-2.5 py-1 text-xs font-semibold ${
                        u.is_active === 1
                          ? 'border-slate-200 text-slate-700 hover:bg-slate-50'
                          : 'border-rose-200 bg-rose-50 text-rose-700'
                      }`}
                    >
                      {u.is_active === 1 ? 'Active' : 'Suspended'}
                    </button>
                  </td>
                  <td className="p-4 text-right">
                    <button
                      type="button"
                      onClick={() => handleUserDelete(u.id)}
                      aria-label={`Delete ${u.name}`}
                      className="inline-flex items-center rounded-lg border border-rose-200 p-1.5 text-rose-600 hover:bg-rose-50"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {section === 'enquiries' && (
        <div className="rounded-2xl bg-white border border-slate-200 divide-y divide-slate-100">
          {enquiries.map((e) => (
            <div key={e.id} className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <p className="font-semibold text-[#0B1D3A]">
                  {e.property_title} <span className="text-xs font-normal text-slate-500">({e.agent_name})</span>
                </p>
                <p className="text-xs text-slate-500 mt-0.5">
                  From {e.name} · {e.email} · {e.phone}
                </p>
                <p className="mt-2 text-sm text-slate-700">{e.message}</p>
              </div>
              <select
                value={e.status}
                onChange={(ev) => handleEnquiryStatus(e.id, ev.target.value)}
                className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-[#0B1D3A] shrink-0"
              >
                <option value="New">New</option>
                <option value="In Progress">In Progress</option>
                <option value="Resolved">Resolved</option>
              </select>
            </div>
          ))}
        </div>
      )}

      {section === 'visits' && (
        <div className="rounded-2xl bg-white border border-slate-200 divide-y divide-slate-100">
          {visits.map((v) => (
            <div key={v.id} className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <p className="font-semibold text-[#0B1D3A]">{v.property_title}</p>
                <p className="text-xs text-slate-500 mt-0.5">
                  {v.visitor_name} ({v.visitor_phone}) · {v.visit_date} at {v.visit_time} · Advisor: {v.agent_name}
                </p>
              </div>
              <select
                value={v.status}
                onChange={(ev) => handleVisitStatus(v.id, ev.target.value as SiteVisit['status'])}
                className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-[#0B1D3A] shrink-0"
              >
                <option value="Pending">Pending</option>
                <option value="Confirmed">Confirmed</option>
                <option value="Completed">Completed</option>
                <option value="Cancelled">Cancelled</option>
              </select>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
