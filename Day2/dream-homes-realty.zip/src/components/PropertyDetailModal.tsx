import React, { useEffect, useState } from 'react';
import {
  ArrowLeft,
  Calendar,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  ExternalLink,
  GitCompareArrows,
  Heart,
  MapPin,
  MessageCircle,
  Phone,
  Send,
  Star,
} from 'lucide-react';
import { api } from '../api/client';
import type { Property, Review, User } from '../types';
import { EMICalculator } from './EMICalculator';
import { PropertyCard, formatCurrency } from './PropertyCard';
import { PropertyImage } from './PropertyImage';

interface PropertyDetailModalProps {
  propertyId: number | null;
  user: User | null;
  favoriteIds: number[];
  compareIds: number[];
  onClose: () => void;
  onSelectProperty: (property: Property) => void;
  onToggleFavorite: (propertyId: number) => void;
  onToggleCompare: (property: Property) => void;
}

export const PropertyDetailModal: React.FC<PropertyDetailModalProps> = ({
  propertyId,
  user,
  favoriteIds,
  compareIds,
  onClose,
  onSelectProperty,
  onToggleFavorite,
  onToggleCompare,
}) => {
  const [property, setProperty] = useState<Property | null>(null);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [recommended, setRecommended] = useState<Property[]>([]);
  const [loading, setLoading] = useState(false);
  const [activeImg, setActiveImg] = useState(0);

  // Action tab inside right column
  const [actionMode, setActionMode] = useState<'enquiry' | 'visit'>('enquiry');

  // Enquiry form
  const [enqName, setEnqName] = useState('');
  const [enqEmail, setEnqEmail] = useState('');
  const [enqPhone, setEnqPhone] = useState('');
  const [enqMsg, setEnqMsg] = useState('');
  const [enqSuccess, setEnqSuccess] = useState('');
  const [enqError, setEnqError] = useState('');
  const [submittingEnq, setSubmittingEnq] = useState(false);

  // Site Visit form
  const [visitDate, setVisitDate] = useState('2026-12-05');
  const [visitTime, setVisitTime] = useState('11:00');
  const [visitNotes, setVisitNotes] = useState('');
  const [visitSuccess, setVisitSuccess] = useState('');
  const [visitError, setVisitError] = useState('');
  const [submittingVisit, setSubmittingVisit] = useState(false);

  // Review form
  const [revName, setRevName] = useState('');
  const [revRating, setRevRating] = useState(5);
  const [revComment, setRevComment] = useState('');
  const [revFeedback, setRevFeedback] = useState('');

  useEffect(() => {
    if (user) {
      setEnqName(user.name);
      setEnqEmail(user.email);
      setEnqPhone(user.phone || '');
      setRevName(user.name);
    }
  }, [user]);

  useEffect(() => {
    if (!propertyId) return;
    setLoading(true);
    setActiveImg(0);
    setEnqSuccess('');
    setEnqError('');
    setVisitSuccess('');
    setVisitError('');
    setRevFeedback('');
    api
      .getPropertyDetail(propertyId)
      .then((res) => {
        setProperty(res.property);
        setReviews(res.reviews);
        setRecommended(res.recommended);
        setEnqMsg(`Hello ${res.property.agent_name}, I would like more information about "${res.property.title}".`);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [propertyId]);

  if (!propertyId) return null;

  const handleEnquirySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!property) return;
    setEnqError('');
    setEnqSuccess('');
    setSubmittingEnq(true);
    try {
      await api.submitEnquiry({
        property_id: property.id,
        name: enqName,
        email: enqEmail,
        phone: enqPhone,
        message: enqMsg,
      });
      setEnqSuccess('Your enquiry has been sent to the listing advisor.');
    } catch (err) {
      setEnqError(err instanceof Error ? err.message : 'Unable to send enquiry.');
    } finally {
      setSubmittingEnq(false);
    }
  };

  const handleVisitSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!property) return;
    setVisitError('');
    setVisitSuccess('');
    setSubmittingVisit(true);
    try {
      await api.scheduleVisit({
        property_id: property.id,
        visitor_name: enqName,
        visitor_email: enqEmail,
        visitor_phone: enqPhone,
        visit_date: visitDate,
        visit_time: visitTime,
        notes: visitNotes,
      });
      setVisitSuccess(`Site visit requested for ${visitDate} at ${visitTime}.`);
      setVisitNotes('');
    } catch (err) {
      setVisitError(err instanceof Error ? err.message : 'Unable to book site visit.');
    } finally {
      setSubmittingVisit(false);
    }
  };

  const handleReviewSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!property) return;
    setRevFeedback('');
    try {
      const res = await api.addReview(property.id, {
        reviewer_name: revName,
        rating: revRating,
        comment: revComment,
      });
      setReviews((prev) => [res.review, ...prev]);
      setRevComment('');
      setRevFeedback('Thank you — your review is now published.');
    } catch (err) {
      setRevFeedback(err instanceof Error ? err.message : 'Could not publish review.');
    }
  };

  const whatsappDigits = (property?.agent_phone || '13105550148').replace(/\D/g, '');
  const whatsappHref = property
    ? `https://wa.me/${whatsappDigits}?text=${encodeURIComponent(
        `Hello ${property.agent_name}, I am interested in ${property.title} (${property.address}, ${property.city}) listed at ${formatCurrency(property.price, property.listing_type)}.`
      )}`
    : '#';

  const osmEmbedUrl = property
    ? `https://www.openstreetmap.org/export/embed.html?bbox=${property.longitude - 0.015},${property.latitude - 0.01},${property.longitude + 0.015},${property.latitude + 0.01}&layer=mapnik&marker=${property.latitude},${property.longitude}`
    : '';

  const externalMapHref = property
    ? `https://www.google.com/maps/search/?api=1&query=${property.latitude},${property.longitude}`
    : '#';

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-50">
      {/* Sticky Top Bar */}
      <div className="sticky top-0 z-30 border-b border-slate-200 bg-white/95 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 sm:px-8 h-16">
          <button
            type="button"
            onClick={onClose}
            className="inline-flex min-h-[40px] items-center gap-2 rounded-xl px-3 text-sm font-semibold text-[#0B1D3A] hover:bg-slate-100 transition-colors"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Back to Listings</span>
          </button>

          {property && (
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => onToggleCompare(property)}
                className={`inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border px-3.5 text-xs font-semibold transition-colors ${
                  compareIds.includes(property.id)
                    ? 'border-[#D4AF37] bg-[#D4AF37]/15 text-[#0B1D3A]'
                    : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                }`}
              >
                <GitCompareArrows className="h-4 w-4" />
                <span className="hidden sm:inline">
                  {compareIds.includes(property.id) ? 'Comparing' : 'Compare'}
                </span>
              </button>
              <button
                type="button"
                onClick={() => onToggleFavorite(property.id)}
                className={`inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border px-3.5 text-xs font-semibold transition-colors ${
                  favoriteIds.includes(property.id)
                    ? 'border-rose-200 bg-rose-50 text-rose-700'
                    : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                }`}
              >
                <Heart className={`h-4 w-4 ${favoriteIds.includes(property.id) ? 'fill-rose-600 text-rose-600' : ''}`} />
                <span className="hidden sm:inline">
                  {favoriteIds.includes(property.id) ? 'Saved' : 'Save'}
                </span>
              </button>
            </div>
          )}
        </div>
      </div>

      {loading || !property ? (
        <div className="mx-auto max-w-7xl px-4 sm:px-8 py-12 space-y-6">
          <div className="h-96 rounded-2xl bg-slate-200 animate-pulse" />
          <div className="h-40 rounded-2xl bg-slate-200 animate-pulse" />
        </div>
      ) : (
        <div className="mx-auto max-w-7xl px-4 sm:px-8 py-6 sm:py-10 space-y-10 pb-24">
          {/* Gallery Carousel */}
          <div className="space-y-3">
            <div className="relative aspect-[16/9] max-h-[540px] w-full overflow-hidden rounded-2xl bg-slate-900">
              <PropertyImage
                src={property.images?.[activeImg] || property.images?.[0]}
                alt={`${property.title} image ${activeImg + 1}`}
                fallbackTitle={property.title}
                className="h-full w-full object-cover"
              />
              {property.images.length > 1 && (
                <>
                  <button
                    type="button"
                    aria-label="Previous image"
                    onClick={() => setActiveImg((prev) => (prev - 1 + property.images.length) % property.images.length)}
                    className="absolute left-3 top-1/2 -translate-y-1/2 flex h-11 w-11 items-center justify-center rounded-xl bg-[#0B1D3A]/80 text-white hover:bg-[#0B1D3A]"
                  >
                    <ChevronLeft className="h-5 w-5" />
                  </button>
                  <button
                    type="button"
                    aria-label="Next image"
                    onClick={() => setActiveImg((prev) => (prev + 1) % property.images.length)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 flex h-11 w-11 items-center justify-center rounded-xl bg-[#0B1D3A]/80 text-white hover:bg-[#0B1D3A]"
                  >
                    <ChevronRight className="h-5 w-5" />
                  </button>
                </>
              )}
              <div className="absolute bottom-3 right-3 rounded-lg bg-[#0B1D3A]/85 px-3 py-1 text-xs font-mono text-white">
                {activeImg + 1} / {Math.max(1, property.images.length)}
              </div>
            </div>

            {property.images.length > 1 && (
              <div className="flex gap-3 overflow-x-auto pb-1">
                {property.images.map((img, idx) => (
                  <button
                    key={`${img}-${idx}`}
                    type="button"
                    onClick={() => setActiveImg(idx)}
                    className={`relative h-20 w-28 shrink-0 overflow-hidden rounded-xl border-2 transition-all ${
                      activeImg === idx ? 'border-[#D4AF37]' : 'border-transparent opacity-70 hover:opacity-100'
                    }`}
                  >
                    <PropertyImage src={img} alt={`Thumbnail ${idx + 1}`} />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* 2-Column Main Content + Contiguous Action Module */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Left 8 cols: Specs, Description, Amenities, Map, EMI, Reviews */}
            <div className="lg:col-span-8 space-y-8">
              <div className="rounded-2xl bg-white border border-slate-200 p-6 sm:p-8">
                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                  <span className="font-semibold text-[#9A7213]">
                    {property.listing_type === 'buy' ? 'For Sale' : 'For Rent'}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span>{property.property_type}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-semibold text-[#0B1D3A]">{property.status}</span>
                  <span aria-hidden="true">·</span>
                  <span>Built {property.year_built}</span>
                </div>

                <div className="mt-3 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
                  <div>
                    <h1 className="font-display text-2xl sm:text-4xl font-semibold text-[#0B1D3A]">
                      {property.title}
                    </h1>
                    <p className="mt-2 flex items-center gap-1.5 text-sm text-slate-600">
                      <MapPin className="h-4 w-4 text-[#9A7213] shrink-0" />
                      <span>
                        {property.address}, {property.neighborhood}, {property.city}
                      </span>
                    </p>
                  </div>
                  <div className="sm:text-right shrink-0">
                    <p className="font-mono text-2xl sm:text-3xl font-bold text-[#0B1D3A] tabular-nums">
                      {formatCurrency(property.price, property.listing_type)}
                    </p>
                    {property.area_sqft > 0 && property.listing_type === 'buy' && (
                      <p className="text-xs font-mono text-slate-500 tabular-nums">
                        ${Math.round(property.price / property.area_sqft).toLocaleString()} per sq ft
                      </p>
                    )}
                  </div>
                </div>

                {/* Key Specifications Grid */}
                <dl className="mt-6 grid grid-cols-2 sm:grid-cols-4 gap-4 border-y border-slate-100 py-5">
                  <div>
                    <dt className="text-xs text-slate-500">Bedrooms</dt>
                    <dd className="mt-1 text-base font-semibold text-[#0B1D3A] tabular-nums">
                      {property.bedrooms > 0 ? `${property.bedrooms} Bedrooms` : 'Commercial'}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-xs text-slate-500">Bathrooms</dt>
                    <dd className="mt-1 text-base font-semibold text-[#0B1D3A] tabular-nums">
                      {property.bathrooms} Bathrooms
                    </dd>
                  </div>
                  <div>
                    <dt className="text-xs text-slate-500">Total Area</dt>
                    <dd className="mt-1 text-base font-semibold text-[#0B1D3A] tabular-nums">
                      {property.area_sqft.toLocaleString()} sq ft
                    </dd>
                  </div>
                  <div>
                    <dt className="text-xs text-slate-500">Furnishing & Parking</dt>
                    <dd className="mt-1 text-base font-semibold text-[#0B1D3A]">
                      {property.furnishing} · {property.parking_spots}P
                    </dd>
                  </div>
                </dl>

                <div className="mt-6">
                  <h2 className="font-display text-xl font-semibold text-[#0B1D3A]">Architectural Overview</h2>
                  <p className="mt-3 text-sm sm:text-base leading-relaxed text-slate-700">{property.description}</p>
                </div>

                {property.amenities.length > 0 && (
                  <div className="mt-7 border-t border-slate-100 pt-6">
                    <h2 className="font-display text-xl font-semibold text-[#0B1D3A]">Key Amenities</h2>
                    <div className="mt-4 grid grid-cols-2 sm:grid-cols-3 gap-3">
                      {property.amenities.map((amenity) => (
                        <div key={amenity} className="flex items-center gap-2 text-sm text-slate-700">
                          <CheckCircle2 className="h-4 w-4 text-[#C99A2E] shrink-0" />
                          <span>{amenity}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Location & Interactive Map Section */}
              <div className="rounded-2xl bg-white border border-slate-200 p-6 sm:p-8">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <h2 className="font-display text-xl font-semibold text-[#0B1D3A]">Location & Neighborhood</h2>
                    <p className="mt-1 text-xs text-slate-500 font-mono tabular-nums">
                      {property.address}, {property.city} ({property.latitude.toFixed(4)}, {property.longitude.toFixed(4)})
                    </p>
                  </div>
                  <a
                    href={externalMapHref}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-slate-200 px-3.5 text-xs font-semibold text-[#0B1D3A] hover:bg-slate-50"
                  >
                    <ExternalLink className="h-3.5 w-3.5 text-[#9A7213]" />
                    <span>Open in Maps</span>
                  </a>
                </div>

                <div className="mt-4 h-72 w-full overflow-hidden rounded-xl border border-slate-200 bg-slate-100">
                  <iframe
                    title={`Map for ${property.title}`}
                    src={osmEmbedUrl}
                    className="h-full w-full border-0"
                    loading="lazy"
                  />
                </div>
              </div>

              {/* Embedded EMI Calculator for Sale Properties */}
              {property.listing_type === 'buy' && <EMICalculator initialPrice={property.price} compact />}

              {/* Customer Reviews & Ratings */}
              <div className="rounded-2xl bg-white border border-slate-200 p-6 sm:p-8">
                <div className="flex items-center justify-between gap-4">
                  <div>
                    <h2 className="font-display text-xl font-semibold text-[#0B1D3A]">Customer Reviews & Ratings</h2>
                    <p className="text-xs text-slate-500 tabular-nums">
                      {reviews.length} verified client {reviews.length === 1 ? 'review' : 'reviews'}
                    </p>
                  </div>
                  {Number(property.avg_rating) > 0 && (
                    <div className="flex items-center gap-1.5 font-mono text-lg font-bold text-[#0B1D3A] tabular-nums">
                      <Star className="h-5 w-5 fill-[#D4AF37] text-[#D4AF37]" />
                      <span>{Number(property.avg_rating).toFixed(1)} / 5</span>
                    </div>
                  )}
                </div>

                <form onSubmit={handleReviewSubmit} className="mt-5 grid grid-cols-1 sm:grid-cols-12 gap-3 border-b border-slate-100 pb-6">
                  {!user && (
                    <input
                      type="text"
                      required
                      value={revName}
                      onChange={(e) => setRevName(e.target.value)}
                      placeholder="Your name"
                      className="sm:col-span-4 min-h-[42px] rounded-xl border border-slate-200 px-3.5 text-sm focus:border-[#0B1D3A] focus:outline-none"
                    />
                  )}
                  <select
                    aria-label="Rating"
                    value={revRating}
                    onChange={(e) => setRevRating(Number(e.target.value))}
                    className={`${user ? 'sm:col-span-3' : 'sm:col-span-3'} min-h-[42px] rounded-xl border border-slate-200 bg-white px-3 text-sm focus:border-[#0B1D3A] focus:outline-none`}
                  >
                    <option value={5}>5 Stars — Exceptional</option>
                    <option value={4}>4 Stars — Very Good</option>
                    <option value={3}>3 Stars — Good</option>
                    <option value={2}>2 Stars — Fair</option>
                    <option value={1}>1 Star — Poor</option>
                  </select>
                  <input
                    type="text"
                    required
                    value={revComment}
                    onChange={(e) => setRevComment(e.target.value)}
                    placeholder="Share your impression of this property or tour..."
                    className={`${user ? 'sm:col-span-6' : 'sm:col-span-5'} min-h-[42px] rounded-xl border border-slate-200 px-3.5 text-sm focus:border-[#0B1D3A] focus:outline-none`}
                  />
                  <button
                    type="submit"
                    className="sm:col-span-3 min-h-[42px] rounded-xl bg-[#0B1D3A] px-4 text-xs font-semibold text-white hover:bg-[#132C54] transition-colors"
                  >
                    Post Review
                  </button>
                  {revFeedback && (
                    <p className="sm:col-span-12 text-xs font-medium text-[#9A7213]">{revFeedback}</p>
                  )}
                </form>

                <div className="mt-5 space-y-4">
                  {reviews.length === 0 ? (
                    <p className="text-sm text-slate-500">Be the first client to review this property.</p>
                  ) : (
                    reviews.map((rev) => (
                      <div key={rev.id} className="border-b border-slate-100 pb-4 last:border-b-0 last:pb-0">
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-sm font-semibold text-[#0B1D3A]">{rev.reviewer_name}</span>
                          <span className="inline-flex items-center gap-1 text-xs font-mono font-semibold text-[#9A7213]">
                            <Star className="h-3.5 w-3.5 fill-[#D4AF37] text-[#D4AF37]" />
                            {rev.rating}.0
                          </span>
                        </div>
                        <p className="mt-1.5 text-sm text-slate-600">{rev.comment}</p>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>

            {/* Right 4 cols: Sticky Agent & Contact / Site Visit Booking Panel */}
            <aside className="lg:col-span-4 lg:sticky lg:top-24 space-y-5">
              <div className="rounded-2xl bg-white border border-slate-200 p-6 shadow-sm">
                <div className="flex items-center gap-4">
                  <div className="h-14 w-14 overflow-hidden rounded-full bg-slate-100 shrink-0">
                    <PropertyImage
                      src={property.agent_avatar}
                      alt={property.agent_name}
                      fallbackTitle={property.agent_name}
                    />
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs font-semibold uppercase tracking-wider text-[#9A7213]">Listing Advisor</p>
                    <h3 className="font-display text-lg font-semibold text-[#0B1D3A] truncate">{property.agent_name}</h3>
                    <p className="text-xs text-slate-500 truncate">{property.agent_agency || 'Dream Homes Realty'}</p>
                  </div>
                </div>

                <div className="mt-4 grid grid-cols-2 gap-2.5">
                  <a
                    href={`tel:${property.agent_phone || '+13105550148'}`}
                    className="inline-flex min-h-[42px] items-center justify-center gap-1.5 rounded-xl border border-slate-200 px-3 text-xs font-semibold text-[#0B1D3A] hover:bg-slate-50"
                  >
                    <Phone className="h-3.5 w-3.5 text-[#9A7213]" />
                    <span>Call Advisor</span>
                  </a>
                  <a
                    href={whatsappHref}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex min-h-[42px] items-center justify-center gap-1.5 rounded-xl bg-emerald-700 px-3 text-xs font-semibold text-white hover:bg-emerald-800 transition-colors"
                  >
                    <MessageCircle className="h-3.5 w-3.5" />
                    <span>WhatsApp</span>
                  </a>
                </div>

                {/* Toggle Contact Agent vs Schedule Site Visit */}
                <div className="mt-5 grid grid-cols-2 gap-1 rounded-xl bg-slate-100 p-1">
                  <button
                    type="button"
                    onClick={() => setActionMode('enquiry')}
                    className={`min-h-[38px] rounded-lg text-xs font-semibold transition-colors ${
                      actionMode === 'enquiry' ? 'bg-[#0B1D3A] text-white' : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Contact Agent
                  </button>
                  <button
                    type="button"
                    onClick={() => setActionMode('visit')}
                    className={`min-h-[38px] rounded-lg text-xs font-semibold transition-colors ${
                      actionMode === 'visit' ? 'bg-[#0B1D3A] text-white' : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Schedule Visit
                  </button>
                </div>

                {actionMode === 'enquiry' ? (
                  <form onSubmit={handleEnquirySubmit} className="mt-4 space-y-3">
                    <input
                      type="text"
                      required
                      value={enqName}
                      onChange={(e) => setEnqName(e.target.value)}
                      placeholder="Your Full Name"
                      className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3.5 text-sm focus:border-[#0B1D3A] focus:outline-none"
                    />
                    <input
                      type="email"
                      required
                      value={enqEmail}
                      onChange={(e) => setEnqEmail(e.target.value)}
                      placeholder="Email Address"
                      className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3.5 text-sm focus:border-[#0B1D3A] focus:outline-none"
                    />
                    <input
                      type="tel"
                      required
                      value={enqPhone}
                      onChange={(e) => setEnqPhone(e.target.value)}
                      placeholder="Phone Number"
                      className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3.5 text-sm focus:border-[#0B1D3A] focus:outline-none"
                    />
                    <textarea
                      required
                      rows={3}
                      value={enqMsg}
                      onChange={(e) => setEnqMsg(e.target.value)}
                      placeholder="Your message or questions..."
                      className="w-full rounded-xl border border-slate-200 p-3 text-sm focus:border-[#0B1D3A] focus:outline-none"
                    />
                    {enqError && <p className="text-xs text-rose-600 font-medium">{enqError}</p>}
                    {enqSuccess && <p className="text-xs text-emerald-700 font-medium">{enqSuccess}</p>}
                    <button
                      type="submit"
                      disabled={submittingEnq}
                      className="flex w-full min-h-[44px] items-center justify-center gap-2 rounded-xl bg-[#0B1D3A] px-4 text-sm font-semibold text-white hover:bg-[#132C54] disabled:opacity-60"
                    >
                      <Send className="h-4 w-4 text-[#D4AF37]" />
                      <span>{submittingEnq ? 'Sending...' : 'Send Property Enquiry'}</span>
                    </button>
                  </form>
                ) : (
                  <form onSubmit={handleVisitSubmit} className="mt-4 space-y-3">
                    <input
                      type="text"
                      required
                      value={enqName}
                      onChange={(e) => setEnqName(e.target.value)}
                      placeholder="Visitor Name"
                      className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3.5 text-sm focus:border-[#0B1D3A] focus:outline-none"
                    />
                    <input
                      type="email"
                      required
                      value={enqEmail}
                      onChange={(e) => setEnqEmail(e.target.value)}
                      placeholder="Visitor Email"
                      className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3.5 text-sm focus:border-[#0B1D3A] focus:outline-none"
                    />
                    <input
                      type="tel"
                      required
                      value={enqPhone}
                      onChange={(e) => setEnqPhone(e.target.value)}
                      placeholder="Visitor Phone"
                      className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3.5 text-sm focus:border-[#0B1D3A] focus:outline-none"
                    />
                    <div className="grid grid-cols-2 gap-2.5">
                      <input
                        type="date"
                        required
                        value={visitDate}
                        onChange={(e) => setVisitDate(e.target.value)}
                        className="w-full min-h-[42px] rounded-xl border border-slate-200 px-3 text-sm focus:border-[#0B1D3A] focus:outline-none"
                      />
                      <select
                        value={visitTime}
                        onChange={(e) => setVisitTime(e.target.value)}
                        className="w-full min-h-[42px] rounded-xl border border-slate-200 bg-white px-3 text-sm focus:border-[#0B1D3A] focus:outline-none"
                      >
                        <option value="09:30">09:30 AM</option>
                        <option value="11:00">11:00 AM</option>
                        <option value="14:00">02:00 PM</option>
                        <option value="16:00">04:00 PM</option>
                        <option value="17:30">05:30 PM</option>
                      </select>
                    </div>
                    <textarea
                      rows={2}
                      value={visitNotes}
                      onChange={(e) => setVisitNotes(e.target.value)}
                      placeholder="Any special tour preferences..."
                      className="w-full rounded-xl border border-slate-200 p-3 text-sm focus:border-[#0B1D3A] focus:outline-none"
                    />
                    {visitError && <p className="text-xs text-rose-600 font-medium">{visitError}</p>}
                    {visitSuccess && <p className="text-xs text-emerald-700 font-medium">{visitSuccess}</p>}
                    <button
                      type="submit"
                      disabled={submittingVisit}
                      className="flex w-full min-h-[44px] items-center justify-center gap-2 rounded-xl bg-[#D4AF37] px-4 text-sm font-semibold text-[#0B1D3A] hover:bg-[#E5C158] disabled:opacity-60"
                    >
                      <Calendar className="h-4 w-4" />
                      <span>{submittingVisit ? 'Booking...' : 'Book Private Site Visit'}</span>
                    </button>
                  </form>
                )}
              </div>
            </aside>
          </div>

          {/* Recommended Similar Properties */}
          {recommended.length > 0 && (
            <section className="pt-4 border-t border-slate-200">
              <h2 className="font-display text-2xl font-semibold text-[#0B1D3A]">Recommended Similar Properties</h2>
              <p className="mt-1 text-sm text-slate-600">Curated alternatives matching property style and purpose</p>
              <div className="mt-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {recommended.map((item) => (
                  <PropertyCard
                    key={item.id}
                    property={item}
                    isFavorite={favoriteIds.includes(item.id)}
                    isCompared={compareIds.includes(item.id)}
                    onSelect={onSelectProperty}
                    onToggleFavorite={onToggleFavorite}
                    onToggleCompare={onToggleCompare}
                  />
                ))}
              </div>
            </section>
          )}
        </div>
      )}
    </div>
  );
};
