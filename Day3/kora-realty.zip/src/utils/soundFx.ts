class SoundEngine {
  private ctx: AudioContext | null = null;
  public muted = false;

  private ensureContext(): AudioContext | null {
    if (this.muted || typeof window === 'undefined') return null;
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return null;
    if (!this.ctx) {
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  private playTone(
    freqStart: number,
    freqEnd: number,
    duration: number,
    type: OscillatorType,
    volume: number
  ) {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freqStart, now);
    osc.frequency.exponentialRampToValueAtTime(Math.max(25, freqEnd), now + duration);

    gain.gain.setValueAtTime(volume, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + duration);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + duration);
  }

  playSwing() {
    this.playTone(260, 110, 0.08, 'sine', 0.09);
  }

  playHit(heavy = false) {
    this.playTone(heavy ? 150 : 210, 42, heavy ? 0.16 : 0.1, 'triangle', heavy ? 0.24 : 0.17);
  }

  playBlock() {
    this.playTone(540, 290, 0.09, 'square', 0.09);
  }

  playDash() {
    this.playTone(320, 140, 0.11, 'sine', 0.08);
  }

  playSuper() {
    this.playTone(220, 660, 0.28, 'sawtooth', 0.14);
  }

  playRoundBell() {
    this.playTone(680, 660, 0.32, 'triangle', 0.14);
  }

  playKO() {
    this.playTone(180, 38, 0.45, 'sawtooth', 0.22);
  }
}

export const soundFx = new SoundEngine();
