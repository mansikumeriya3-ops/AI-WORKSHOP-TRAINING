import React, { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { Check, Copy, Download, Share, Smartphone, X } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

const PUBLIC_APP_URL = 'https://ais-pre-jgj4mbj4bszgxkfyiozsma-811708600805.asia-east1.run.app';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, isAndroid, install } = usePWAInstall();
  const [showGuide, setShowGuide] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [qrDataUrl, setQrDataUrl] = useState<string>('');

  const targetUrl =
    typeof window !== 'undefined' &&
    window.location.hostname !== 'localhost' &&
    window.location.hostname !== '127.0.0.1'
      ? window.location.origin
      : PUBLIC_APP_URL;

  useEffect(() => {
    if (!showGuide) return;
    let active = true;
    QRCode.toDataURL(targetUrl, {
      width: 176,
      margin: 1,
      color: {
        dark: '#0F172A',
        light: '#FFFFFF',
      },
    })
      .then((url) => {
        if (active) setQrDataUrl(url);
      })
      .catch(() => {});
    return () => {
      active = false;
    };
  }, [showGuide, targetUrl]);

  if (isInstalled) {
    return null;
  }

  const handleClick = async () => {
    if (isInstallable) {
      const accepted = await install();
      if (!accepted) {
        setShowGuide(true);
      }
      return;
    }
    setShowGuide(true);
  };

  const handleCopyUrl = async () => {
    try {
      await navigator.clipboard.writeText(targetUrl);
      setCopiedUrl(true);
      window.setTimeout(() => setCopiedUrl(false), 2000);
    } catch {
      // Ignore clipboard failure
    }
  };

  return (
    <>
      <button
        type="button"
        onClick={handleClick}
        className="inline-flex min-h-[44px] items-center justify-center gap-2 rounded-xl bg-[#F59E0B] px-4 py-2 text-sm font-semibold text-[#0F172A] transition-colors hover:bg-[#D97706] active:scale-[0.98] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#F59E0B]"
      >
        <Download className="h-4 w-4 shrink-0" aria-hidden="true" />
        <span>{isAndroid ? 'Install Android App' : 'Install App'}</span>
      </button>

      {showGuide && (
        <div
          className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 backdrop-blur-sm sm:items-center sm:p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="install-guide-title"
          onClick={() => setShowGuide(false)}
        >
          <div
            className="max-h-[90dvh] w-full max-w-md overflow-y-auto rounded-t-3xl border border-[#334155] bg-[#1E293B] p-6 text-[#F8FAFC] shadow-2xl sm:rounded-3xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mx-auto mb-4 h-1.5 w-10 rounded-full bg-[#475569] sm:hidden" />
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-[#F59E0B]/15 text-[#F59E0B]">
                  <Smartphone className="h-5 w-5" aria-hidden="true" />
                </div>
                <div>
                  <h3 id="install-guide-title" className="font-display text-xl font-bold tracking-wide text-white">
                    Install Ironbound on Android
                  </h3>
                  <p className="text-xs text-[#94A3B8]">Home screen icon & full-screen offline play</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowGuide(false)}
                aria-label="Close installation guide"
                className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl text-[#94A3B8] hover:bg-[#334155] hover:text-white"
              >
                <X className="h-5 w-5" aria-hidden="true" />
              </button>
            </div>

            <div className="mt-5 space-y-4 text-sm text-[#CBD5E1]">
              {!isAndroid && !isIOS && qrDataUrl && (
                <div className="flex items-center gap-4 rounded-2xl border border-[#334155] bg-[#0F172A] p-4">
                  <img
                    src={qrDataUrl}
                    alt="QR code to install Ironbound Arena on Android"
                    className="h-28 w-28 shrink-0 rounded-xl bg-white p-1.5"
                  />
                  <div className="space-y-1.5">
                    <p className="text-sm font-semibold text-white">Scan with Android Camera</p>
                    <p className="text-xs leading-relaxed text-[#94A3B8]">
                      Point your Android phone camera here to open the game in Chrome and tap Install.
                    </p>
                  </div>
                </div>
              )}

              {isIOS ? (
                <div className="rounded-2xl border border-[#334155] bg-[#0F172A] p-4 space-y-2.5">
                  <p className="font-semibold text-white">iPhone & iPad (Safari)</p>
                  <ol className="list-decimal space-y-1.5 pl-4 text-[13px] leading-relaxed text-[#CBD5E1]">
                    <li>
                      Tap <span className="inline-flex items-center gap-1 font-medium text-white"><Share className="h-3.5 w-3.5" aria-hidden="true" /> Share</span> in Safari.
                    </li>
                    <li>
                      Select <strong className="font-semibold text-white">Add to Home Screen</strong>, then tap <strong className="font-semibold text-white">Add</strong>.
                    </li>
                  </ol>
                </div>
              ) : (
                <div className="rounded-2xl border border-[#334155] bg-[#0F172A] p-4 space-y-2.5">
                  <p className="font-semibold text-white">Android (Google Chrome)</p>
                  <ol className="list-decimal space-y-1.5 pl-4 text-[13px] leading-relaxed text-[#CBD5E1]">
                    <li>
                      Open Ironbound Arena in <strong className="font-semibold text-white">Chrome</strong> on your Android mobile.
                    </li>
                    <li>
                      Tap the <strong className="font-semibold text-white">⋮</strong> menu in the top right and select{' '}
                      <strong className="font-semibold text-white">Install app</strong> (or <strong className="font-semibold text-white">Add to Home screen</strong>).
                    </li>
                    <li>
                      Launch from your Android home screen for full-screen arcade controls offline.
                    </li>
                  </ol>
                </div>
              )}

              <div className="flex items-center justify-between gap-3 rounded-2xl border border-[#334155] bg-[#0F172A] px-4 py-3">
                <div className="min-w-0">
                  <p className="text-xs font-medium text-white">Mobile App Link</p>
                  <p className="truncate text-xs text-[#94A3B8]">{targetUrl}</p>
                </div>
                <button
                  type="button"
                  onClick={handleCopyUrl}
                  className="inline-flex min-h-[44px] items-center gap-1.5 rounded-xl bg-[#334155] px-3.5 py-2 text-xs font-semibold text-white hover:bg-[#475569] whitespace-nowrap shrink-0"
                >
                  {copiedUrl ? <Check className="h-3.5 w-3.5 text-[#10B981]" /> : <Copy className="h-3.5 w-3.5" />}
                  <span>{copiedUrl ? 'Copied' : 'Copy Link'}</span>
                </button>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setShowGuide(false)}
              className="mt-5 flex min-h-[48px] w-full items-center justify-center rounded-xl bg-[#F59E0B] px-4 py-2.5 text-sm font-semibold text-[#0F172A] hover:bg-[#D97706]"
            >
              Done
            </button>
          </div>
        </div>
      )}
    </>
  );
};
