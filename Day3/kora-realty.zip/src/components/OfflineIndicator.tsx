import React from 'react';
import { WifiOff } from 'lucide-react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div
      role="status"
      aria-live="polite"
      className="fixed bottom-4 left-4 right-4 z-40 mx-auto flex max-w-sm items-center justify-center gap-2 rounded-xl border border-[#334155] bg-[#1E293B] px-4 py-2 text-xs font-medium text-[#F8FAFC] shadow-lg"
    >
      <WifiOff className="h-4 w-4 shrink-0 text-[#F59E0B]" aria-hidden="true" />
      <span>Offline mode — full arena gameplay ready</span>
    </div>
  );
};
