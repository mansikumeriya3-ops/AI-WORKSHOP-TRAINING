import React, { useEffect, useRef } from 'react';
import {
  ActionState,
  ArenaStage,
  ControlInputState,
  Difficulty,
  FighterProfile,
  HudSnapshot,
  RoundResult,
} from '../types/game';
import { soundFx } from '../utils/soundFx';

interface FightingCanvasProps {
  playerFighter: FighterProfile;
  opponentFighter: FighterProfile;
  stage: ArenaStage;
  difficulty: Difficulty;
  roundNumber: number;
  isPlaying: boolean;
  inputRef: React.MutableRefObject<ControlInputState>;
  onHudUpdate: (hud: HudSnapshot) => void;
  onRoundEnd: (result: RoundResult) => void;
}

interface FighterRuntime {
  x: number;
  y: number;
  vx: number;
  vy: number;
  facing: 1 | -1;
  hp: number;
  maxHp: number;
  superMeter: number;
  action: ActionState;
  actionTimer: number;
  actionDuration: number;
  hitConfirmed: boolean;
  comboCount: number;
  comboResetTimer: number;
  invulnTimer: number;
  profile: FighterProfile;
}

interface SparkParticle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  color: string;
  size: number;
}

interface FloatingText {
  x: number;
  y: number;
  text: string;
  color: string;
  life: number;
}

const ARENA_WIDTH = 960;
const ARENA_HEIGHT = 480;
const FLOOR_Y = 408;
const GRAVITY = 2100;
const FIGHTER_HALF_W = 34;

export const FightingCanvas: React.FC<FightingCanvasProps> = ({
  playerFighter,
  opponentFighter,
  stage,
  difficulty,
  roundNumber,
  isPlaying,
  inputRef,
  onHudUpdate,
  onRoundEnd,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const bgImgRef = useRef<HTMLImageElement | null>(null);
  const isPlayingRef = useRef(isPlaying);
  const onHudUpdateRef = useRef(onHudUpdate);
  const onRoundEndRef = useRef(onRoundEnd);

  useEffect(() => {
    isPlayingRef.current = isPlaying;
  }, [isPlaying]);

  useEffect(() => {
    onHudUpdateRef.current = onHudUpdate;
    onRoundEndRef.current = onRoundEnd;
  }, [onHudUpdate, onRoundEnd]);

  // Load stage artwork onto an Image object for smooth 60fps canvas draws
  useEffect(() => {
    const img = new Image();
    img.referrerPolicy = 'no-referrer';
    img.src = stage.imageUrl;
    img.onload = () => {
      bgImgRef.current = img;
    };
  }, [stage.imageUrl]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const createFighter = (profile: FighterProfile, x: number, facing: 1 | -1): FighterRuntime => {
      const maxHp = 100 + Math.round(profile.stats.defense * 3);
      return {
        x,
        y: FLOOR_Y,
        vx: 0,
        vy: 0,
        facing,
        hp: maxHp,
        maxHp,
        superMeter: 0,
        action: 'idle',
        actionTimer: 0,
        actionDuration: 0,
        hitConfirmed: false,
        comboCount: 0,
        comboResetTimer: 0,
        invulnTimer: 0,
        profile,
      };
    };

    const p1 = createFighter(playerFighter, 230, 1);
    const p2 = createFighter(opponentFighter, 730, -1);

    let timeLeft = 99;
    let hitStop = 0;
    let shakeTimer = 0;
    let roundFinished = false;
    let maxComboP1 = 0;
    let damageDealtP1 = 0;
    let aiDecisionCooldown = 0.25;
    let aiWalkDir: -1 | 0 | 1 = 0;
    let aiBlocking = false;
    let hudThrottle = 0;

    const particles: SparkParticle[] = [];
    const floatingTexts: FloatingText[] = [];

    const spawnSparks = (x: number, y: number, color: string, count: number) => {
      for (let i = 0; i < count; i++) {
        const angle = Math.random() * Math.PI * 2;
        const speed = 90 + Math.random() * 260;
        particles.push({
          x,
          y,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed - 60,
          life: 0.28 + Math.random() * 0.2,
          maxLife: 0.45,
          color,
          size: 3 + Math.random() * 4,
        });
      }
    };

    const startAttack = (f: FighterRuntime, kind: 'jab' | 'kick' | 'dash' | 'super') => {
      if (f.action === 'hitstun' || f.action === 'ko') return;
      if (f.action === 'jab' || f.action === 'kick' || f.action === 'super' || f.action === 'dash') {
        return;
      }

      if (kind === 'super') {
        if (f.superMeter < 100) return;
        f.superMeter = 0;
        f.action = 'super';
        f.actionTimer = 0;
        f.actionDuration = 0.56;
        f.hitConfirmed = false;
        f.vx = f.facing * 420;
        f.invulnTimer = 0.35;
        soundFx.playSuper();
        spawnSparks(f.x, f.y - 75, f.profile.palette.accent, 14);
        return;
      }

      if (kind === 'dash') {
        f.action = 'dash';
        f.actionTimer = 0;
        f.actionDuration = 0.22;
        f.vx = f.facing * (440 + f.profile.stats.speed * 18);
        f.invulnTimer = 0.14;
        soundFx.playDash();
        return;
      }

      f.action = kind;
      f.actionTimer = 0;
      f.actionDuration = kind === 'jab' ? 0.26 : 0.42;
      f.hitConfirmed = false;
      f.vx = f.facing * (kind === 'jab' ? 85 : 130);
      soundFx.playSwing();
    };

    const updateFighterPhysics = (
      f: FighterRuntime,
      opp: FighterRuntime,
      dt: number,
      left: boolean,
      right: boolean,
      up: boolean,
      down: boolean,
      block: boolean
    ) => {
      if (f.invulnTimer > 0) f.invulnTimer = Math.max(0, f.invulnTimer - dt);
      if (f.comboResetTimer > 0) {
        f.comboResetTimer -= dt;
        if (f.comboResetTimer <= 0) f.comboCount = 0;
      }

      const isGrounded = f.y >= FLOOR_Y - 0.5;
      if (isGrounded && f.action !== 'jab' && f.action !== 'kick' && f.action !== 'super' && f.action !== 'hitstun' && f.action !== 'ko') {
        f.facing = opp.x >= f.x ? 1 : -1;
      }

      const isBusy =
        f.action === 'jab' ||
        f.action === 'kick' ||
        f.action === 'dash' ||
        f.action === 'super' ||
        f.action === 'hitstun' ||
        f.action === 'ko';

      if (isBusy) {
        f.actionTimer += dt;
        if (f.action !== 'ko' && f.actionTimer >= f.actionDuration) {
          f.action = isGrounded ? 'idle' : 'jump';
          f.actionTimer = 0;
          f.vx *= 0.35;
        } else if (f.action === 'hitstun' || f.action === 'jab' || f.action === 'kick') {
          f.vx *= Math.pow(0.08, dt);
        } else if (f.action === 'ko') {
          f.vx *= Math.pow(0.04, dt);
        }
      } else {
        const moveSpeed = 230 + f.profile.stats.speed * 18;
        if (block && isGrounded) {
          f.action = 'block';
          f.vx = 0;
        } else if (down && isGrounded) {
          f.action = 'crouch';
          f.vx = 0;
        } else {
          let dir = 0;
          if (left) dir -= 1;
          if (right) dir += 1;
          f.vx = dir * moveSpeed;
          if (up && isGrounded) {
            f.vy = -760;
            f.action = 'jump';
          } else if (!isGrounded) {
            f.action = 'jump';
          } else {
            f.action = dir !== 0 ? 'walk' : 'idle';
          }
        }
      }

      f.x += f.vx * dt;
      f.vy += GRAVITY * dt;
      f.y += f.vy * dt;

      if (f.y >= FLOOR_Y) {
        f.y = FLOOR_Y;
        f.vy = 0;
        if (f.action === 'jump') {
          f.action = 'idle';
        }
      }

      f.x = Math.max(54, Math.min(ARENA_WIDTH - 54, f.x));
    };

    const resolveFighterPushbox = () => {
      const minDist = FIGHTER_HALF_W * 1.85;
      const dx = p2.x - p1.x;
      if (Math.abs(dx) < minDist && Math.abs(p1.y - p2.y) < 95) {
        const overlap = (minDist - Math.abs(dx)) * 0.5;
        const sign = dx >= 0 ? 1 : -1;
        p1.x = Math.max(54, p1.x - sign * overlap);
        p2.x = Math.min(ARENA_WIDTH - 54, p2.x + sign * overlap);
      }
    };

    const checkAttackHit = (attacker: FighterRuntime, defender: FighterRuntime, isP1Attacker: boolean) => {
      if (attacker.hitConfirmed) return;
      if (defender.action === 'ko' || defender.invulnTimer > 0) return;

      let activeStart = 0;
      let activeEnd = 0;
      let reach = 82;
      let rawDamage = 8;
      let hitstunDur = 0.24;
      let knockback = 150;

      if (attacker.action === 'jab') {
        activeStart = 0.06;
        activeEnd = 0.16;
        reach = 86;
        rawDamage = 7 + Math.round(attacker.profile.stats.power * 0.45);
        hitstunDur = 0.22;
        knockback = 130;
      } else if (attacker.action === 'kick') {
        activeStart = 0.14;
        activeEnd = 0.29;
        reach = 104;
        rawDamage = 13 + Math.round(attacker.profile.stats.power * 0.75);
        hitstunDur = 0.34;
        knockback = 240;
      } else if (attacker.action === 'super') {
        activeStart = 0.12;
        activeEnd = 0.44;
        reach = 136;
        rawDamage = 26 + attacker.profile.stats.power;
        hitstunDur = 0.48;
        knockback = 360;
      } else {
        return;
      }

      if (attacker.actionTimer < activeStart || attacker.actionTimer > activeEnd) {
        return;
      }

      const distX = (defender.x - attacker.x) * attacker.facing;
      const distY = Math.abs(defender.y - attacker.y);
      if (distX < -10 || distX > reach || distY > 105) {
        return;
      }

      attacker.hitConfirmed = true;
      const isGuarding = defender.action === 'block' || (defender.action === 'crouch' && attacker.action === 'jab');

      if (isGuarding && attacker.action !== 'super') {
        const chipDamage = Math.max(1, Math.round(rawDamage * 0.2));
        defender.hp = Math.max(0, defender.hp - chipDamage);
        defender.vx = attacker.facing * (knockback * 0.45);
        attacker.superMeter = Math.min(100, attacker.superMeter + 8);
        defender.superMeter = Math.min(100, defender.superMeter + 10);
        soundFx.playBlock();
        spawnSparks(defender.x - defender.facing * 20, defender.y - 80, '#38BDF8', 8);
        floatingTexts.push({
          x: defender.x,
          y: defender.y - 135,
          text: `BLOCK -${chipDamage}`,
          color: '#38BDF8',
          life: 0.55,
        });
      } else {
        const defenseMitigation = 1 - defender.profile.stats.defense * 0.025;
        const finalDamage = Math.max(4, Math.round(rawDamage * defenseMitigation));
        defender.hp = Math.max(0, defender.hp - finalDamage);
        defender.action = defender.hp <= 0 ? 'ko' : 'hitstun';
        defender.actionTimer = 0;
        defender.actionDuration = defender.hp <= 0 ? 1.5 : hitstunDur;
        defender.vx = attacker.facing * knockback;
        if (attacker.action === 'super') {
          defender.vy = -260;
        }

        attacker.comboCount += 1;
        attacker.comboResetTimer = 1.45;
        attacker.superMeter = Math.min(100, attacker.superMeter + (attacker.action === 'super' ? 0 : 18));
        defender.superMeter = Math.min(100, defender.superMeter + 12);

        if (isP1Attacker) {
          damageDealtP1 += finalDamage;
          if (attacker.comboCount > maxComboP1) maxComboP1 = attacker.comboCount;
        }

        hitStop = attacker.action === 'super' ? 0.085 : attacker.action === 'kick' ? 0.055 : 0.03;
        shakeTimer = attacker.action === 'super' ? 0.26 : attacker.action === 'kick' ? 0.14 : 0.07;

        soundFx.playHit(attacker.action === 'kick' || attacker.action === 'super');
        spawnSparks(
          defender.x - defender.facing * 14,
          defender.y - 82,
          attacker.action === 'super' ? '#F59E0B' : '#EF4444',
          attacker.action === 'super' ? 20 : 12
        );
        floatingTexts.push({
          x: defender.x,
          y: defender.y - 135,
          text: attacker.comboCount > 1 ? `-${finalDamage} · ${attacker.comboCount}x` : `-${finalDamage}`,
          color: attacker.action === 'super' ? '#F59E0B' : '#F87171',
          life: 0.68,
        });
      }
    };

    const runOpponentAI = (dt: number) => {
      aiDecisionCooldown -= dt;
      const dist = p1.x - p2.x;
      const absDist = Math.abs(dist);
      const towardsP1: -1 | 1 = dist >= 0 ? 1 : -1;

      const aggression = difficulty === 'Master' ? 0.85 : difficulty === 'Contender' ? 0.6 : 0.36;
      const blockChance = difficulty === 'Master' ? 0.72 : difficulty === 'Contender' ? 0.44 : 0.18;

      if (aiDecisionCooldown <= 0) {
        aiDecisionCooldown = difficulty === 'Master' ? 0.14 : difficulty === 'Contender' ? 0.24 : 0.38;
        aiBlocking = false;
        aiWalkDir = 0;

        const p1Attacking = p1.action === 'jab' || p1.action === 'kick' || p1.action === 'super';
        if (p1Attacking && absDist < 125 && Math.random() < blockChance) {
          aiBlocking = true;
          return;
        }

        if (p2.superMeter >= 100 && absDist < 140 && Math.random() < aggression) {
          startAttack(p2, 'super');
          return;
        }

        if (absDist > 115) {
          aiWalkDir = towardsP1;
          if (absDist > 260 && Math.random() < aggression * 0.35) {
            startAttack(p2, 'dash');
          }
        } else {
          if (Math.random() < aggression) {
            startAttack(p2, Math.random() < 0.56 ? 'jab' : 'kick');
          } else if (Math.random() < 0.25) {
            aiWalkDir = (towardsP1 * -1) as -1 | 1;
          }
        }
      }

      const aiJump = absDist > 160 && Math.random() < 0.008 * (difficulty === 'Master' ? 2 : 1);
      updateFighterPhysics(
        p2,
        p1,
        dt,
        aiWalkDir === -1,
        aiWalkDir === 1,
        aiJump,
        false,
        aiBlocking
      );
    };

    const drawFighter = (f: FighterRuntime, timeSec: number) => {
      ctx.save();
      ctx.translate(f.x, f.y);

      // Ground contact shadow
      const heightRatio = Math.max(0.35, 1 - (FLOOR_Y - f.y) / 240);
      ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
      ctx.beginPath();
      ctx.ellipse(0, FLOOR_Y - f.y + 4, 34 * heightRatio, 9 * heightRatio, 0, 0, Math.PI * 2);
      ctx.fill();

      ctx.scale(f.facing, 1);

      const { skin, primary, secondary, accent, headgear } = f.profile.palette;

      if (f.action === 'ko') {
        ctx.translate(0, -18);
        ctx.rotate(-Math.PI / 2);
      }

      const crouchOffset = f.action === 'crouch' || f.action === 'block' ? 22 : 0;
      const idleBob = f.action === 'idle' ? Math.sin(timeSec * 5) * 2.5 : 0;
      const walkSwing = f.action === 'walk' ? Math.sin(timeSec * 14) * 16 : 0;

      // Dash afterimage
      if (f.action === 'dash') {
        ctx.globalAlpha = 0.28;
        ctx.fillStyle = accent;
        ctx.fillRect(-38, -110, 36, 95);
        ctx.globalAlpha = 1;
      }

      // Super aura
      if (f.action === 'super') {
        ctx.fillStyle = `${accent}44`;
        ctx.beginPath();
        ctx.arc(10, -68, 66, 0, Math.PI * 2);
        ctx.fill();
      }

      // Legs
      ctx.lineCap = 'round';
      ctx.lineWidth = 14;
      ctx.strokeStyle = primary;

      // Back leg
      ctx.beginPath();
      ctx.moveTo(-8, -46 + crouchOffset);
      ctx.lineTo(-18 - walkSwing * 0.7, -4);
      ctx.stroke();

      // Front leg (extends during kick or super)
      ctx.beginPath();
      ctx.moveTo(8, -46 + crouchOffset);
      if (f.action === 'kick') {
        const prog = Math.sin(Math.min(1, f.actionTimer / f.actionDuration) * Math.PI);
        ctx.lineTo(18 + prog * 68, -64 + crouchOffset * 0.4);
      } else if (f.action === 'super') {
        ctx.lineTo(74, -52);
      } else {
        ctx.lineTo(18 + walkSwing * 0.7, -4);
      }
      ctx.stroke();

      // Foot wraps
      ctx.fillStyle = secondary;
      if (f.action === 'kick') {
        const prog = Math.sin(Math.min(1, f.actionTimer / f.actionDuration) * Math.PI);
        ctx.beginPath();
        ctx.arc(18 + prog * 68, -64 + crouchOffset * 0.4, 9, 0, Math.PI * 2);
        ctx.fill();
      }

      // Torso
      const torsoTop = -102 + crouchOffset + idleBob;
      ctx.fillStyle = primary;
      ctx.beginPath();
      ctx.roundRect(-20, torsoTop, 40, 58 - crouchOffset * 0.35, 10);
      ctx.fill();

      // Sash / trim
      ctx.fillStyle = secondary;
      ctx.fillRect(-20, torsoTop + 34, 40, 10);

      // Head
      const headY = torsoTop - 16;
      ctx.fillStyle = skin;
      ctx.beginPath();
      ctx.arc(2, headY, 16, 0, Math.PI * 2);
      ctx.fill();

      // Hair / Headgear
      if (headgear === 'headband') {
        ctx.fillStyle = '#0F172A';
        ctx.beginPath();
        ctx.arc(1, headY - 4, 16, Math.PI, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = secondary;
        ctx.fillRect(-15, headY - 7, 33, 6);
        ctx.fillRect(-26, headY - 5, 12, 4);
      } else if (headgear === 'ponytail') {
        ctx.fillStyle = '#1E1B18';
        ctx.beginPath();
        ctx.arc(0, headY - 4, 16, Math.PI * 0.85, Math.PI * 2.05);
        ctx.fill();
        ctx.lineWidth = 7;
        ctx.strokeStyle = '#1E1B18';
        ctx.beginPath();
        ctx.moveTo(-14, headY - 4);
        ctx.lineTo(-28 - walkSwing * 0.3, headY + 12);
        ctx.stroke();
      } else if (headgear === 'hood') {
        ctx.fillStyle = '#0F172A';
        ctx.beginPath();
        ctx.arc(0, headY - 1, 18, Math.PI * 0.75, Math.PI * 2.2);
        ctx.fill();
        ctx.fillStyle = secondary;
        ctx.fillRect(6, headY - 3, 7, 3);
      } else {
        ctx.fillStyle = '#1C1917';
        ctx.beginPath();
        ctx.arc(0, headY - 5, 16, Math.PI, Math.PI * 2);
        ctx.fill();
      }

      // Guard Shield
      if (f.action === 'block') {
        ctx.strokeStyle = '#38BDF8';
        ctx.lineWidth = 4;
        ctx.fillStyle = 'rgba(56, 189, 248, 0.16)';
        ctx.beginPath();
        ctx.arc(22, torsoTop + 20, 34, -Math.PI * 0.42, Math.PI * 0.42);
        ctx.stroke();
        ctx.fill();
      }

      // Front Arm / Punch
      ctx.lineWidth = 11;
      ctx.strokeStyle = skin;
      ctx.beginPath();
      ctx.moveTo(8, torsoTop + 14);
      if (f.action === 'jab') {
        const prog = Math.sin(Math.min(1, f.actionTimer / f.actionDuration) * Math.PI);
        const reachX = 24 + prog * 54;
        ctx.lineTo(reachX, torsoTop + 12);
        ctx.stroke();
        ctx.fillStyle = accent;
        ctx.beginPath();
        ctx.arc(reachX, torsoTop + 12, 9, 0, Math.PI * 2);
        ctx.fill();
      } else if (f.action === 'super') {
        ctx.lineTo(74, torsoTop + 10);
        ctx.stroke();
        ctx.fillStyle = accent;
        ctx.beginPath();
        ctx.arc(82, torsoTop + 10, 18, 0, Math.PI * 2);
        ctx.fill();
      } else {
        ctx.lineTo(22, torsoTop + 26);
        ctx.lineTo(28, torsoTop + 10);
        ctx.stroke();
        ctx.fillStyle = secondary;
        ctx.beginPath();
        ctx.arc(28, torsoTop + 10, 7, 0, Math.PI * 2);
        ctx.fill();
      }

      // Hitstun flash
      if (f.action === 'hitstun') {
        ctx.fillStyle = 'rgba(239, 68, 68, 0.35)';
        ctx.beginPath();
        ctx.arc(0, -68, 44, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.restore();
    };

    let rafId = 0;
    let lastTime = performance.now();

    const frame = (now: number) => {
      const rawDt = Math.min(0.05, (now - lastTime) / 1000);
      lastTime = now;

      if (isPlayingRef.current && !roundFinished) {
        if (hitStop > 0) {
          hitStop -= rawDt;
        } else {
          const dt = rawDt;
          timeLeft = Math.max(0, timeLeft - dt);

          const inp = inputRef.current;
          if (inp.superPressed) {
            inp.superPressed = false;
            startAttack(p1, 'super');
          } else if (inp.kickPressed) {
            inp.kickPressed = false;
            startAttack(p1, 'kick');
          } else if (inp.jabPressed) {
            inp.jabPressed = false;
            startAttack(p1, 'jab');
          } else if (inp.dashPressed) {
            inp.dashPressed = false;
            startAttack(p1, 'dash');
          }

          updateFighterPhysics(p1, p2, dt, inp.left, inp.right, inp.up, inp.down, inp.block);
          runOpponentAI(dt);
          resolveFighterPushbox();
          checkAttackHit(p1, p2, true);
          checkAttackHit(p2, p1, false);

          if (p1.hp <= 0 || p2.hp <= 0 || timeLeft <= 0) {
            roundFinished = true;
            soundFx.playKO();
            let winner: 'p1' | 'p2' | 'draw' = 'draw';
            let reason: 'KO' | 'Time Over' | 'Double KO' = 'Time Over';

            if (p1.hp <= 0 && p2.hp <= 0) {
              winner = 'draw';
              reason = 'Double KO';
            } else if (p2.hp <= 0) {
              winner = 'p1';
              reason = 'KO';
            } else if (p1.hp <= 0) {
              winner = 'p2';
              reason = 'KO';
            } else {
              const p1Pct = p1.hp / p1.maxHp;
              const p2Pct = p2.hp / p2.maxHp;
              winner = p1Pct > p2Pct ? 'p1' : p2Pct > p1Pct ? 'p2' : 'draw';
              reason = 'Time Over';
            }

            window.setTimeout(() => {
              onRoundEndRef.current({
                roundNumber,
                winner,
                reason,
                p1RemainingHp: p1.hp,
                p2RemainingHp: p2.hp,
                maxComboP1,
                damageDealtP1,
              });
            }, 650);
          }
        }
      }

      if (shakeTimer > 0) shakeTimer = Math.max(0, shakeTimer - rawDt);

      // Update sparks & floating text
      for (let i = particles.length - 1; i >= 0; i--) {
        const pt = particles[i];
        pt.x += pt.vx * rawDt;
        pt.y += pt.vy * rawDt;
        pt.vy += 520 * rawDt;
        pt.life -= rawDt;
        if (pt.life <= 0) particles.splice(i, 1);
      }
      for (let i = floatingTexts.length - 1; i >= 0; i--) {
        const ft = floatingTexts[i];
        ft.y -= 36 * rawDt;
        ft.life -= rawDt;
        if (ft.life <= 0) floatingTexts.splice(i, 1);
      }

      // Render Scene
      ctx.save();
      if (shakeTimer > 0) {
        const mag = shakeTimer * 28;
        ctx.translate((Math.random() - 0.5) * mag, (Math.random() - 0.5) * mag);
      }

      // Stage Background
      const bg = bgImgRef.current;
      if (bg && bg.complete && bg.naturalWidth > 0) {
        const scale = Math.max(ARENA_WIDTH / bg.naturalWidth, ARENA_HEIGHT / bg.naturalHeight);
        const w = bg.naturalWidth * scale;
        const h = bg.naturalHeight * scale;
        ctx.drawImage(bg, (ARENA_WIDTH - w) / 2, (ARENA_HEIGHT - h) / 2, w, h);
        ctx.fillStyle = 'rgba(15, 23, 42, 0.28)';
        ctx.fillRect(0, 0, ARENA_WIDTH, ARENA_HEIGHT);
      } else {
        const grad = ctx.createLinearGradient(0, 0, 0, ARENA_HEIGHT);
        grad.addColorStop(0, '#0F172A');
        grad.addColorStop(1, '#1E293B');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, ARENA_WIDTH, ARENA_HEIGHT);
      }

      // Arena Floor Deck
      ctx.fillStyle = stage.floorColor;
      ctx.fillRect(0, FLOOR_Y, ARENA_WIDTH, ARENA_HEIGHT - FLOOR_Y);
      ctx.fillStyle = stage.floorAccent;
      ctx.fillRect(0, FLOOR_Y, ARENA_WIDTH, 3);

      // Draw Fighters
      drawFighter(p2, now / 1000);
      drawFighter(p1, now / 1000);

      // Draw Sparks
      for (const pt of particles) {
        ctx.globalAlpha = Math.max(0, pt.life / pt.maxLife);
        ctx.fillStyle = pt.color;
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, pt.size, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;

      // Draw Floating Damage Numbers
      ctx.font = '700 18px "JetBrains Mono", monospace';
      ctx.textAlign = 'center';
      for (const ft of floatingTexts) {
        ctx.globalAlpha = Math.min(1, ft.life * 2);
        ctx.fillStyle = '#0F172A';
        ctx.fillText(ft.text, ft.x + 1.5, ft.y + 1.5);
        ctx.fillStyle = ft.color;
        ctx.fillText(ft.text, ft.x, ft.y);
      }
      ctx.globalAlpha = 1;

      ctx.restore();

      // Throttle React HUD state sync (~20fps is plenty for bars & timer)
      hudThrottle += rawDt;
      if (hudThrottle >= 0.05) {
        hudThrottle = 0;
        onHudUpdateRef.current({
          p1Hp: p1.hp,
          p1MaxHp: p1.maxHp,
          p1Super: p1.superMeter,
          p1Combo: p1.comboCount,
          p1Action: p1.action,
          p2Hp: p2.hp,
          p2MaxHp: p2.maxHp,
          p2Super: p2.superMeter,
          p2Combo: p2.comboCount,
          p2Action: p2.action,
          timeLeft: Math.ceil(timeLeft),
        });
      }

      rafId = window.requestAnimationFrame(frame);
    };

    rafId = window.requestAnimationFrame(frame);
    return () => window.cancelAnimationFrame(rafId);
  }, [playerFighter, opponentFighter, stage, difficulty, roundNumber, inputRef]);

  return (
    <canvas
      ref={canvasRef}
      width={ARENA_WIDTH}
      height={ARENA_HEIGHT}
      className="h-full w-full rounded-2xl border border-[#334155] bg-[#0F172A] object-contain shadow-2xl"
    />
  );
};
