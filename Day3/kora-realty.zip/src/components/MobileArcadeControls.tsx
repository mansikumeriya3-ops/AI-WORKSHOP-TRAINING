import React from 'react';
import { ArrowDown, ArrowLeft, ArrowRight, ArrowUp, Flame, Shield, Zap } from 'lucide-react';
import { ControlInputState } from '../types/game';

interface MobileArcadeControlsProps {
  inputRef: React.MutableRefObject<ControlInputState>;
  superReady: boolean;
}

export const MobileArcadeControls: React.FC<MobileArcadeControlsProps> = ({
  inputRef,
  superReady,
}) => {
  const bindHold = (key: 'left' | 'right' | 'up' | 'down' | 'block') => ({
    onPointerDown: (e: React.PointerEvent) => {
      e.preventDefault();
      e.currentTarget.setPointerCapture?.(e.pointerId);
      inputRef.current[key] = true;
    },
    onPointerUp: (e: React.PointerEvent) => {
      e.preventDefault();
      inputRef.current[key] = false;
    },
    onPointerCancel: () => {
      inputRef.current[key] = false;
    },
  });

  const bindTap = (key: 'jabPressed' | 'kickPressed' | 'dashPressed' | 'superPressed') => ({
    onPointerDown: (e: React.PointerEvent) => {
      e.preventDefault();
      inputRef.current[key] = true;
    },
  });

  return (
    <div
      className="touch-arcade flex items-end justify-between gap-3 px-3 pb-safe pt-2 select-none sm:px-5"
      aria-label="Touch arcade controls"
    >
      {/* Left Thumb Zone: Directional Pad */}
      <div className="grid grid-cols-3 gap-1.5 w-[164px] shrink-0">
        <div />
        <button
          type="button"
          aria-label="Jump"
          {...bindHold('up')}
          className="flex h-12 items-center justify-center rounded-xl border border-[#334155] bg-[#1E293B] text-[#F8FAFC] active:scale-95 active:bg-[#334155]"
        >
          <ArrowUp className="h-5 w-5" aria-hidden="true" />
        </button>
        <div />

        <button
          type="button"
          aria-label="Move left"
          {...bindHold('left')}
          className="flex h-12 items-center justify-center rounded-xl border border-[#334155] bg-[#1E293B] text-[#F8FAFC] active:scale-95 active:bg-[#334155]"
        >
          <ArrowLeft className="h-5 w-5" aria-hidden="true" />
        </button>
        <button
          type="button"
          aria-label="Crouch or Block"
          {...bindHold('block')}
          className="flex h-12 items-center justify-center rounded-xl border border-[#334155] bg-[#1E293B] text-[#38BDF8] active:scale-95 active:bg-[#334155]"
        >
          <Shield className="h-5 w-5" aria-hidden="true" />
        </button>
        <button
          type="button"
          aria-label="Move right"
          {...bindHold('right')}
          className="flex h-12 items-center justify-center rounded-xl border border-[#334155] bg-[#1E293B] text-[#F8FAFC] active:scale-95 active:bg-[#334155]"
        >
          <ArrowRight className="h-5 w-5" aria-hidden="true" />
        </button>

        <div />
        <button
          type="button"
          aria-label="Crouch"
          {...bindHold('down')}
          className="flex h-11 items-center justify-center rounded-xl border border-[#334155] bg-[#1E293B]/80 text-[#94A3B8] active:scale-95 active:bg-[#334155]"
        >
          <ArrowDown className="h-4 w-4" aria-hidden="true" />
        </button>
        <div />
      </div>

      {/* Right Thumb Zone: Combat Actions */}
      <div className="grid grid-cols-2 gap-2 w-[176px] shrink-0">
        <button
          type="button"
          aria-label="Light Jab"
          {...bindTap('jabPressed')}
          className="flex h-14 flex-col items-center justify-center rounded-2xl border border-[#475569] bg-[#1E293B] text-white active:scale-95 active:bg-[#334155]"
        >
          <span className="font-display text-base font-bold tracking-wide">JAB</span>
          <span className="text-[10px] text-[#94A3B8]">Fast</span>
        </button>

        <button
          type="button"
          aria-label="Heavy Kick"
          {...bindTap('kickPressed')}
          className="flex h-14 flex-col items-center justify-center rounded-2xl border border-[#DC2626]/60 bg-[#991B1B]/35 text-white active:scale-95 active:bg-[#991B1B]/60"
        >
          <span className="font-display text-base font-bold tracking-wide">KICK</span>
          <span className="text-[10px] text-[#FCA5A5]">Heavy</span>
        </button>

        <button
          type="button"
          aria-label="Dash Step"
          {...bindTap('dashPressed')}
          className="flex h-12 items-center justify-center gap-1.5 rounded-2xl border border-[#334155] bg-[#1E293B] text-xs font-semibold text-[#CBD5E1] active:scale-95 active:bg-[#334155]"
        >
          <Zap className="h-4 w-4 text-[#38BDF8]" aria-hidden="true" />
          <span>DASH</span>
        </button>

        <button
          type="button"
          aria-label="Super Strike"
          disabled={!superReady}
          {...bindTap('superPressed')}
          className={`flex h-12 items-center justify-center gap-1.5 rounded-2xl border text-xs font-bold transition-colors active:scale-95 ${
            superReady
              ? 'border-[#F59E0B] bg-[#F59E0B] text-[#0F172A] shadow-lg shadow-[#F59E0B]/25'
              : 'border-[#334155] bg-[#0F172A] text-[#475569]'
          }`}
        >
          <Flame className="h-4 w-4" aria-hidden="true" />
          <span>SUPER</span>
        </button>
      </div>
    </div>
  );
};
