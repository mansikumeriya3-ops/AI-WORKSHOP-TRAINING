import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Pause,
  Play,
  RotateCcw,
  Shield,
  Swords,
  Trophy,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { ARENA_STAGES, FIGHTERS } from './data/fighters';
import { useLocalStorage } from './hooks/useLocalStorage';
import {
  ArenaStage,
  CareerRecord,
  ControlInputState,
  Difficulty,
  FighterProfile,
  GameState,
  HudSnapshot,
  RoundResult,
} from './types/game';
import { soundFx } from './utils/soundFx';
import { PWAInstallButton } from './components/PWAInstallButton';
import { OfflineIndicator } from './components/OfflineIndicator';
import { FightingCanvas } from './components/FightingCanvas';
import { MobileArcadeControls } from './components/MobileArcadeControls';

const DIFFICULTIES: Difficulty[] = ['Rookie', 'Contender', 'Master'];

function getInitialGameState(): GameState {
  if (typeof window === 'undefined') return 'TITLE_MENU';
  const mode = new URLSearchParams(window.location.search).get('mode');
  if (mode === 'roster') return 'FIGHTER_SELECT';
  if (mode === 'quick') return 'PLAYING';
  return 'TITLE_MENU';
}

export default function App() {
  const [gameState, setGameState] = useState<GameState>(getInitialGameState);
  const [difficulty, setDifficulty] = useState<Difficulty>('Contender');
  const [playerFighter, setPlayerFighter] = useState<FighterProfile>(FIGHTERS[0]);
  const [opponentFighter, setOpponentFighter] = useState<FighterProfile>(FIGHTERS[1]);
  const [stage, setStage] = useState<ArenaStage>(ARENA_STAGES[0]);
  const [muted, setMuted] = useState(false);

  const [roundNumber, setRoundNumber] = useState(1);
  const [p1RoundsWon, setP1RoundsWon] = useState(0);
  const [p2RoundsWon, setP2RoundsWon] = useState(0);
  const [roundHistory, setRoundHistory] = useState<RoundResult[]>([]);
  const [lastRoundResult, setLastRoundResult] = useState<RoundResult | null>(null);
  const [imgErrors, setImgErrors] = useState<Record<string, boolean>>({});

  const [career, setCareer] = useLocalStorage<CareerRecord>('ironbound_career_v1', {
    wins: 0,
    losses: 0,
    bestCombo: 0,
    streak: 0,
  });

  const [hud, setHud] = useState<HudSnapshot>({
    p1Hp: 121,
    p1MaxHp: 121,
    p1Super: 0,
    p1Combo: 0,
    p1Action: 'idle',
    p2Hp: 115,
    p2MaxHp: 115,
    p2Super: 0,
    p2Combo: 0,
    p2Action: 'idle',
    timeLeft: 99,
  });

  const inputRef = useRef<ControlInputState>({
    left: false,
    right: false,
    up: false,
    down: false,
    block: false,
    jabPressed: false,
    kickPressed: false,
    dashPressed: false,
    superPressed: false,
  });

  const resetInputs = () => {
    inputRef.current = {
      left: false,
      right: false,
      up: false,
      down: false,
      block: false,
      jabPressed: false,
      kickPressed: false,
      dashPressed: false,
      superPressed: false,
    };
  };

  const toggleMute = () => {
    const next = !muted;
    setMuted(next);
    soundFx.muted = next;
  };

  const startFreshMatch = useCallback(() => {
    resetInputs();
    setRoundNumber(1);
    setP1RoundsWon(0);
    setP2RoundsWon(0);
    setRoundHistory([]);
    setLastRoundResult(null);
    setGameState('PLAYING');
    soundFx.playRoundBell();
  }, []);

  const handleRoundEnd = useCallback(
    (result: RoundResult) => {
      resetInputs();
      setLastRoundResult(result);
      setRoundHistory((prev) => [...prev, result]);

      const nextP1Wins = p1RoundsWon + (result.winner === 'p1' ? 1 : 0);
      const nextP2Wins = p2RoundsWon + (result.winner === 'p2' ? 1 : 0);
      setP1RoundsWon(nextP1Wins);
      setP2RoundsWon(nextP2Wins);

      const matchOver = nextP1Wins >= 2 || nextP2Wins >= 2 || roundNumber >= 3;
      if (matchOver) {
        const playerWonMatch = nextP1Wins > nextP2Wins;
        const bestRoundCombo = Math.max(
          result.maxComboP1,
          ...roundHistory.map((r) => r.maxComboP1)
        );
        setCareer((prev) => ({
          wins: prev.wins + (playerWonMatch ? 1 : 0),
          losses: prev.losses + (!playerWonMatch && nextP1Wins !== nextP2Wins ? 1 : 0),
          bestCombo: Math.max(prev.bestCombo, bestRoundCombo),
          streak: playerWonMatch ? prev.streak + 1 : 0,
        }));
        setGameState('GAME_OVER');
      } else {
        setGameState('ROUND_SUMMARY');
      }
    },
    [p1RoundsWon, p2RoundsWon, roundNumber, roundHistory, setCareer]
  );

  const startNextRound = () => {
    resetInputs();
    setRoundNumber((r) => r + 1);
    setGameState('PLAYING');
    soundFx.playRoundBell();
  };

  // Keyboard Controls (Desktop & Bluetooth Android Keyboards)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (gameState !== 'PLAYING') {
        if (e.key === 'Escape' && gameState === 'PAUSED') {
          setGameState('PLAYING');
        }
        return;
      }

      const key = e.key.toLowerCase();
      if (key === 'a' || e.key === 'ArrowLeft') inputRef.current.left = true;
      if (key === 'd' || e.key === 'ArrowRight') inputRef.current.right = true;
      if (key === 'w' || e.key === 'ArrowUp') inputRef.current.up = true;
      if (key === 's' || e.key === 'ArrowDown') inputRef.current.block = true;
      if (key === 'j' || key === 'z') inputRef.current.jabPressed = true;
      if (key === 'k' || key === 'x') inputRef.current.kickPressed = true;
      if (key === 'l' || key === 'shift') inputRef.current.dashPressed = true;
      if (key === ' ' || key === 'u') {
        e.preventDefault();
        inputRef.current.superPressed = true;
      }
      if (e.key === 'Escape') {
        setGameState('PAUSED');
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase();
      if (key === 'a' || e.key === 'ArrowLeft') inputRef.current.left = false;
      if (key === 'd' || e.key === 'ArrowRight') inputRef.current.right = false;
      if (key === 'w' || e.key === 'ArrowUp') inputRef.current.up = false;
      if (key === 's' || e.key === 'ArrowDown') inputRef.current.block = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [gameState]);

  const markImgError = (id: string) => {
    setImgErrors((prev) => ({ ...prev, [id]: true }));
  };

  const p1HpPercent = Math.max(0, Math.min(100, (hud.p1Hp / hud.p1MaxHp) * 100));
  const p2HpPercent = Math.max(0, Math.min(100, (hud.p2Hp / hud.p2MaxHp) * 100));

  return (
    <div className="min-h-[100dvh] bg-[#0F172A] text-[#F8FAFC] flex flex-col">
      {/* Top Bar (Hidden during active combat to preserve maximum arena screen area on mobile) */}
      {gameState !== 'PLAYING' && gameState !== 'PAUSED' && gameState !== 'ROUND_SUMMARY' && (
        <header className="border-b border-[#1E293B] bg-[#0F172A]/95 backdrop-blur-md">
          <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-8 px-4 sm:px-6">
            <button
              type="button"
              onClick={() => setGameState('TITLE_MENU')}
              className="font-display text-2xl font-bold tracking-wider text-white whitespace-nowrap shrink-0"
            >
              IRONBOUND
            </button>

            <nav aria-label="Game navigation" className="hidden md:flex items-center gap-6 text-sm font-medium text-[#94A3B8]">
              <button
                type="button"
                onClick={() => setGameState('TITLE_MENU')}
                className={`hover:text-white whitespace-nowrap shrink-0 ${gameState === 'TITLE_MENU' ? 'text-[#F59E0B]' : ''}`}
              >
                Home
              </button>
              <button
                type="button"
                onClick={() => setGameState('FIGHTER_SELECT')}
                className={`hover:text-white whitespace-nowrap shrink-0 ${gameState === 'FIGHTER_SELECT' ? 'text-[#F59E0B]' : ''}`}
              >
                Roster
              </button>
              <button
                type="button"
                onClick={startFreshMatch}
                className="hover:text-white whitespace-nowrap shrink-0"
              >
                Quick Match
              </button>
            </nav>

            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={toggleMute}
                aria-label={muted ? 'Unmute sound effects' : 'Mute sound effects'}
                className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl border border-[#334155] bg-[#1E293B] text-[#CBD5E1] hover:text-white"
              >
                {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
              </button>
              <PWAInstallButton />
            </div>
          </div>
        </header>
      )}

      {/* TITLE MENU */}
      {gameState === 'TITLE_MENU' && (
        <main className="mx-auto flex w-full max-w-6xl flex-1 flex-col justify-center gap-8 px-4 py-6 sm:px-6 sm:py-10">
          <section className="grid gap-8 lg:grid-cols-12 lg:items-stretch">
            <div className="flex flex-col justify-between gap-6 rounded-3xl border border-[#334155] bg-[#1E293B] p-6 sm:p-8 lg:col-span-7">
              <div>
                <p className="text-xs font-semibold tracking-wider text-[#F59E0B]">
                  ANDROID ARCADE FIGHTER · BEST OF 3 ROUNDS
                </p>
                <h1 className="mt-2 font-display text-4xl font-bold leading-none tracking-tight text-white text-balance sm:text-5xl lg:text-6xl">
                  MASTER THE STRIKE. RULE THE ARENA.
                </h1>
                <p className="mt-4 max-w-xl text-sm leading-relaxed text-[#CBD5E1] sm:text-base">
                  Chain fast jabs, heavy kicks, timed blocks, and full-meter Super Strikes in a 60fps 2D arena built for Android touchscreens and offline play.
                </p>
              </div>

              <div className="space-y-4">
                <div>
                  <span className="block text-xs font-medium text-[#94A3B8]">AI Difficulty</span>
                  <div className="mt-2 grid grid-cols-3 gap-2">
                    {DIFFICULTIES.map((level) => (
                      <button
                        key={level}
                        type="button"
                        onClick={() => setDifficulty(level)}
                        className={`min-h-[44px] rounded-xl border text-xs font-semibold transition-colors whitespace-nowrap ${
                          difficulty === level
                            ? 'border-[#F59E0B] bg-[#F59E0B] text-[#0F172A]'
                            : 'border-[#334155] bg-[#0F172A] text-[#CBD5E1] hover:border-[#64748B]'
                        }`}
                      >
                        {level}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex flex-col gap-3 sm:flex-row">
                  <button
                    type="button"
                    onClick={startFreshMatch}
                    className="flex min-h-[52px] flex-1 items-center justify-center gap-2 rounded-2xl bg-[#F59E0B] px-6 text-base font-bold text-[#0F172A] transition-colors hover:bg-[#D97706] active:scale-[0.98]"
                  >
                    <Swords className="h-5 w-5" aria-hidden="true" />
                    <span>Start Game</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setGameState('FIGHTER_SELECT')}
                    className="flex min-h-[52px] items-center justify-center rounded-2xl border border-[#475569] bg-[#0F172A] px-6 text-sm font-semibold text-white transition-colors hover:border-white whitespace-nowrap shrink-0"
                  >
                    Select Fighter ({playerFighter.name.split(' ')[0]})
                  </button>
                </div>
              </div>
            </div>

            <div className="flex flex-col justify-between gap-4 rounded-3xl border border-[#334155] bg-[#1E293B] p-6 lg:col-span-5">
              <div className="relative aspect-[16/9] w-full overflow-hidden rounded-2xl bg-[#0F172A]">
                {!imgErrors[stage.id] ? (
                  <img
                    src={stage.imageUrl}
                    alt={stage.name}
                    referrerPolicy="no-referrer"
                    onError={() => markImgError(stage.id)}
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <div className="flex h-full w-full items-center justify-center text-sm text-[#94A3B8]">
                    {stage.name}
                  </div>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-[#0F172A]/90 via-transparent to-transparent" />
                <div className="absolute bottom-3 left-4 right-4 flex items-end justify-between">
                  <div>
                    <p className="text-xs text-[#F59E0B] font-semibold">Featured Stage</p>
                    <p className="font-display text-xl font-bold text-white">{stage.name}</p>
                  </div>
                  <span className="text-xs text-[#CBD5E1]">{stage.location}</span>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3 rounded-2xl border border-[#334155] bg-[#0F172A] p-4 text-center">
                <div>
                  <p className="font-mono text-2xl font-bold tabular-nums text-white">{career.wins}</p>
                  <p className="text-xs text-[#94A3B8]">Wins</p>
                </div>
                <div>
                  <p className="font-mono text-2xl font-bold tabular-nums text-[#F59E0B]">{career.streak}</p>
                  <p className="text-xs text-[#94A3B8]">Win Streak</p>
                </div>
                <div>
                  <p className="font-mono text-2xl font-bold tabular-nums text-[#10B981]">{career.bestCombo}x</p>
                  <p className="text-xs text-[#94A3B8]">Best Combo</p>
                </div>
              </div>

              <div className="rounded-2xl border border-[#334155] bg-[#0F172A] p-4 text-xs text-[#CBD5E1] space-y-1.5">
                <p className="font-semibold text-white">Controls (Android Touch & Keyboard)</p>
                <p>Move: Touch D-Pad or A / D · Jump: Up / W · Guard: Shield / S</p>
                <p>Jab: J · Kick: K · Dash: L / Shift · Super (100%): Space</p>
              </div>
            </div>
          </section>
        </main>
      )}

      {/* FIGHTER & STAGE SELECT */}
      {gameState === 'FIGHTER_SELECT' && (
        <main className="mx-auto flex w-full max-w-6xl flex-1 flex-col gap-6 px-4 py-6 sm:px-6">
          <div className="flex flex-col justify-between gap-4 border-b border-[#1E293B] pb-4 sm:flex-row sm:items-end">
            <div>
              <h1 className="font-display text-3xl font-bold tracking-tight text-white">
                CHOOSE YOUR FIGHTER & OPPONENT
              </h1>
              <p className="mt-1 text-sm text-[#94A3B8]">
                {playerFighter.name} vs {opponentFighter.name} · Stage: {stage.name}
              </p>
            </div>
            <button
              type="button"
              onClick={startFreshMatch}
              className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-xl bg-[#F59E0B] px-6 text-sm font-bold text-[#0F172A] hover:bg-[#D97706] whitespace-nowrap shrink-0"
            >
              <Swords className="h-4 w-4" aria-hidden="true" />
              <span>Enter Arena</span>
            </button>
          </div>

          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {FIGHTERS.map((fighter) => {
              const isPlayer = playerFighter.id === fighter.id;
              const isOpp = opponentFighter.id === fighter.id;
              return (
                <div
                  key={fighter.id}
                  className={`flex flex-col justify-between overflow-hidden rounded-2xl border bg-[#1E293B] transition-colors ${
                    isPlayer
                      ? 'border-[#F59E0B]'
                      : isOpp
                      ? 'border-[#DC2626]'
                      : 'border-[#334155]'
                  }`}
                >
                  <div>
                    <div className="relative aspect-square w-full bg-[#0F172A]">
                      {!imgErrors[fighter.id] ? (
                        <img
                          src={fighter.portraitUrl}
                          alt={fighter.name}
                          referrerPolicy="no-referrer"
                          onError={() => markImgError(fighter.id)}
                          className="h-full w-full object-cover"
                        />
                      ) : (
                        <div className="flex h-full w-full items-center justify-center font-display text-2xl font-bold text-white">
                          {fighter.name}
                        </div>
                      )}
                    </div>

                    <div className="p-4">
                      <div className="flex items-center gap-2 text-xs text-[#94A3B8]">
                        <span className="font-semibold text-[#F59E0B]">{fighter.style}</span>
                        <span aria-hidden="true">·</span>
                        <span>{fighter.superName}</span>
                      </div>
                      <h2 className="mt-1 font-display text-2xl font-bold text-white">{fighter.name}</h2>
                      <p className="mt-1.5 text-xs leading-relaxed text-[#CBD5E1]">{fighter.bio}</p>

                      <div className="mt-3 space-y-1.5 font-mono text-[11px] tabular-nums text-[#CBD5E1]">
                        <div className="flex items-center justify-between">
                          <span>Power</span>
                          <span>{fighter.stats.power}/10</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span>Speed</span>
                          <span>{fighter.stats.speed}/10</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span>Defense</span>
                          <span>{fighter.stats.defense}/10</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 border-t border-[#334155] p-3">
                    <button
                      type="button"
                      onClick={() => setPlayerFighter(fighter)}
                      className={`min-h-[44px] rounded-xl text-xs font-bold transition-colors ${
                        isPlayer
                          ? 'bg-[#F59E0B] text-[#0F172A]'
                          : 'bg-[#0F172A] text-white hover:bg-[#334155]'
                      }`}
                    >
                      {isPlayer ? 'Your Fighter' : 'Pick P1'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setOpponentFighter(fighter)}
                      className={`min-h-[44px] rounded-xl text-xs font-bold transition-colors ${
                        isOpp
                          ? 'bg-[#DC2626] text-white'
                          : 'bg-[#0F172A] text-[#CBD5E1] hover:bg-[#334155]'
                      }`}
                    >
                      {isOpp ? 'Opponent' : 'Set Rival'}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="space-y-3">
            <h2 className="font-display text-xl font-bold text-white">Arena Stage</h2>
            <div className="grid gap-4 sm:grid-cols-2">
              {ARENA_STAGES.map((item) => {
                const selected = stage.id === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setStage(item)}
                    className={`flex items-center gap-4 rounded-2xl border p-3 text-left transition-colors ${
                      selected
                        ? 'border-[#F59E0B] bg-[#1E293B]'
                        : 'border-[#334155] bg-[#1E293B]/60 hover:border-[#64748B]'
                    }`}
                  >
                    <img
                      src={item.imageUrl}
                      alt={item.name}
                      referrerPolicy="no-referrer"
                      className="h-16 w-28 shrink-0 rounded-xl object-cover bg-[#0F172A]"
                    />
                    <div>
                      <p className="font-display text-lg font-bold text-white">{item.name}</p>
                      <p className="text-xs text-[#94A3B8]">{item.location}</p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </main>
      )}

      {/* ACTIVE FIGHTING ARENA */}
      {(gameState === 'PLAYING' || gameState === 'PAUSED' || gameState === 'ROUND_SUMMARY') && (
        <main className="mx-auto flex h-[100dvh] w-full max-w-6xl flex-col justify-between overflow-hidden px-2 py-2 sm:px-4 sm:py-3">
          {/* Combat HUD */}
          <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-2 sm:gap-4 px-1">
            {/* Player 1 HUD */}
            <div className="space-y-1">
              <div className="flex items-baseline justify-between gap-2">
                <span className="font-display text-sm font-bold tracking-wide text-white truncate sm:text-lg">
                  {playerFighter.name}
                </span>
                <span className="font-mono text-xs font-bold tabular-nums text-[#F59E0B]">
                  HP {hud.p1Hp}/{hud.p1MaxHp}
                </span>
              </div>
              <div className="h-3.5 w-full overflow-hidden rounded-md border border-[#334155] bg-[#1E293B]">
                <div
                  className="h-full bg-[#10B981] transition-all duration-75"
                  style={{ width: `${p1HpPercent}%` }}
                />
              </div>
              <div className="flex items-center justify-between gap-2">
                <div className="h-2 flex-1 overflow-hidden rounded-sm bg-[#1E293B]">
                  <div
                    className={`h-full transition-all duration-75 ${
                      hud.p1Super >= 100 ? 'bg-[#F59E0B]' : 'bg-[#38BDF8]'
                    }`}
                    style={{ width: `${hud.p1Super}%` }}
                  />
                </div>
                <span className="font-mono text-[10px] tabular-nums text-[#94A3B8]">
                  ROUNDS {p1RoundsWon}/2
                </span>
              </div>
            </div>

            {/* Center Arcade Timer & Pause */}
            <div className="flex flex-col items-center justify-center px-1">
              <span className="text-[10px] font-semibold tracking-wider text-[#F59E0B]">
                ROUND {roundNumber}
              </span>
              <div className="font-mono text-2xl font-bold leading-none tabular-nums text-white sm:text-3xl">
                {hud.timeLeft}
              </div>
              <div className="mt-1 flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => setGameState(gameState === 'PAUSED' ? 'PLAYING' : 'PAUSED')}
                  aria-label="Pause match"
                  className="flex h-8 w-8 items-center justify-center rounded-lg border border-[#334155] bg-[#1E293B] text-[#CBD5E1] hover:text-white"
                >
                  <Pause className="h-3.5 w-3.5" aria-hidden="true" />
                </button>
                <button
                  type="button"
                  onClick={toggleMute}
                  aria-label={muted ? 'Unmute audio' : 'Mute audio'}
                  className="flex h-8 w-8 items-center justify-center rounded-lg border border-[#334155] bg-[#1E293B] text-[#CBD5E1] hover:text-white"
                >
                  {muted ? <VolumeX className="h-3.5 w-3.5" /> : <Volume2 className="h-3.5 w-3.5" />}
                </button>
              </div>
            </div>

            {/* Opponent HUD */}
            <div className="space-y-1">
              <div className="flex items-baseline justify-between gap-2">
                <span className="font-mono text-xs font-bold tabular-nums text-[#F87171]">
                  HP {hud.p2Hp}/{hud.p2MaxHp}
                </span>
                <span className="font-display text-sm font-bold tracking-wide text-white truncate sm:text-lg">
                  {opponentFighter.name}
                </span>
              </div>
              <div className="h-3.5 w-full overflow-hidden rounded-md border border-[#334155] bg-[#1E293B]">
                <div
                  className="ml-auto h-full bg-[#DC2626] transition-all duration-75"
                  style={{ width: `${p2HpPercent}%` }}
                />
              </div>
              <div className="flex items-center justify-between gap-2">
                <span className="font-mono text-[10px] tabular-nums text-[#94A3B8]">
                  ROUNDS {p2RoundsWon}/2
                </span>
                <div className="h-2 flex-1 overflow-hidden rounded-sm bg-[#1E293B]">
                  <div
                    className="ml-auto h-full bg-[#F59E0B] transition-all duration-75"
                    style={{ width: `${hud.p2Super}%` }}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* 2D Arena Viewport */}
          <div className="relative my-2 flex-1 min-h-0 flex items-center justify-center">
            <FightingCanvas
              playerFighter={playerFighter}
              opponentFighter={opponentFighter}
              stage={stage}
              difficulty={difficulty}
              roundNumber={roundNumber}
              isPlaying={gameState === 'PLAYING'}
              inputRef={inputRef}
              onHudUpdate={setHud}
              onRoundEnd={handleRoundEnd}
            />

            {hud.p1Combo >= 2 && gameState === 'PLAYING' && (
              <div className="pointer-events-none absolute left-4 top-4 rounded-xl bg-[#0F172A]/85 px-3 py-1.5 border border-[#F59E0B]/50">
                <span className="font-mono text-sm font-bold tabular-nums text-[#F59E0B]">
                  {hud.p1Combo} HIT COMBO
                </span>
              </div>
            )}

            {/* Pause Modal */}
            {gameState === 'PAUSED' && (
              <div className="absolute inset-0 z-20 flex items-center justify-center rounded-2xl bg-black/70 backdrop-blur-xs p-4">
                <div className="w-full max-w-xs space-y-3 rounded-2xl border border-[#334155] bg-[#1E293B] p-6 text-center shadow-2xl">
                  <h2 className="font-display text-3xl font-bold text-white">MATCH PAUSED</h2>
                  <button
                    type="button"
                    onClick={() => setGameState('PLAYING')}
                    className="flex min-h-[48px] w-full items-center justify-center gap-2 rounded-xl bg-[#F59E0B] text-sm font-bold text-[#0F172A]"
                  >
                    <Play className="h-4 w-4" />
                    <span>Resume Fight</span>
                  </button>
                  <button
                    type="button"
                    onClick={startFreshMatch}
                    className="flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl border border-[#475569] bg-[#0F172A] text-sm font-semibold text-white"
                  >
                    <RotateCcw className="h-4 w-4" />
                    <span>Restart Match</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setGameState('TITLE_MENU')}
                    className="flex min-h-[44px] w-full items-center justify-center rounded-xl text-xs font-medium text-[#94A3B8] hover:text-white"
                  >
                    Exit to Title
                  </button>
                </div>
              </div>
            )}

            {/* Round Summary Modal */}
            {gameState === 'ROUND_SUMMARY' && lastRoundResult && (
              <div className="absolute inset-0 z-20 flex items-center justify-center rounded-2xl bg-black/75 backdrop-blur-xs p-4">
                <div className="w-full max-w-sm space-y-4 rounded-2xl border border-[#334155] bg-[#1E293B] p-6 text-center shadow-2xl">
                  <p className="text-xs font-semibold tracking-wider text-[#F59E0B]">
                    ROUND {lastRoundResult.roundNumber} · {lastRoundResult.reason.toUpperCase()}
                  </p>
                  <h2 className="font-display text-4xl font-bold text-white">
                    {lastRoundResult.winner === 'p1'
                      ? `${playerFighter.name.split(' ')[0].toUpperCase()} WINS ROUND`
                      : lastRoundResult.winner === 'p2'
                      ? `${opponentFighter.name.split(' ')[0].toUpperCase()} TAKES ROUND`
                      : 'ROUND DRAW'}
                  </h2>
                  <div className="grid grid-cols-2 gap-3 rounded-xl bg-[#0F172A] p-3 font-mono text-xs tabular-nums">
                    <div>
                      <p className="text-[#94A3B8]">Damage Dealt</p>
                      <p className="mt-0.5 text-base font-bold text-white">{lastRoundResult.damageDealtP1}</p>
                    </div>
                    <div>
                      <p className="text-[#94A3B8]">Max Combo</p>
                      <p className="mt-0.5 text-base font-bold text-[#F59E0B]">{lastRoundResult.maxComboP1}x</p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={startNextRound}
                    className="flex min-h-[48px] w-full items-center justify-center rounded-xl bg-[#F59E0B] text-sm font-bold text-[#0F172A] hover:bg-[#D97706]"
                  >
                    Start Round {roundNumber + 1}
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Mobile Ergonomic Touch Arcade Pad */}
          <MobileArcadeControls inputRef={inputRef} superReady={hud.p1Super >= 100} />
        </main>
      )}

      {/* MATCH GAME OVER */}
      {gameState === 'GAME_OVER' && (
        <main className="mx-auto flex w-full max-w-2xl flex-1 flex-col items-center justify-center px-4 py-8">
          <div className="w-full space-y-6 rounded-3xl border border-[#334155] bg-[#1E293B] p-6 text-center sm:p-8">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-[#F59E0B]/15 text-[#F59E0B]">
              {p1RoundsWon >= p2RoundsWon ? (
                <Trophy className="h-8 w-8" aria-hidden="true" />
              ) : (
                <Shield className="h-8 w-8" aria-hidden="true" />
              )}
            </div>

            <div>
              <p className="text-xs font-semibold tracking-wider text-[#F59E0B]">
                FINAL MATCH SCORE · {p1RoundsWon} – {p2RoundsWon}
              </p>
              <h1 className="mt-1 font-display text-4xl font-bold text-white sm:text-5xl">
                {p1RoundsWon > p2RoundsWon
                  ? 'VICTORY IN THE ARENA'
                  : p2RoundsWon > p1RoundsWon
                  ? 'DEFEATED — REMATCH READY'
                  : 'SPLIT DECISION DRAW'}
              </h1>
            </div>

            <div className="grid grid-cols-3 gap-3 rounded-2xl border border-[#334155] bg-[#0F172A] p-4 font-mono tabular-nums">
              <div>
                <p className="text-xs text-[#94A3B8]">Total Damage</p>
                <p className="mt-1 text-xl font-bold text-white">
                  {roundHistory.reduce((sum, r) => sum + r.damageDealtP1, 0)}
                </p>
              </div>
              <div>
                <p className="text-xs text-[#94A3B8]">Peak Combo</p>
                <p className="mt-1 text-xl font-bold text-[#F59E0B]">
                  {Math.max(0, ...roundHistory.map((r) => r.maxComboP1))}x
                </p>
              </div>
              <div>
                <p className="text-xs text-[#94A3B8]">Career Wins</p>
                <p className="mt-1 text-xl font-bold text-[#10B981]">{career.wins}</p>
              </div>
            </div>

            <div className="flex flex-col gap-3 sm:flex-row">
              <button
                type="button"
                onClick={startFreshMatch}
                className="flex min-h-[50px] flex-1 items-center justify-center gap-2 rounded-2xl bg-[#F59E0B] px-6 text-sm font-bold text-[#0F172A] hover:bg-[#D97706]"
              >
                <RotateCcw className="h-4 w-4" aria-hidden="true" />
                <span>Play Again</span>
              </button>
              <button
                type="button"
                onClick={() => setGameState('FIGHTER_SELECT')}
                className="flex min-h-[50px] flex-1 items-center justify-center rounded-2xl border border-[#475569] bg-[#0F172A] px-6 text-sm font-semibold text-white hover:border-white"
              >
                Change Fighter
              </button>
            </div>
          </div>
        </main>
      )}

      <OfflineIndicator />
    </div>
  );
}
