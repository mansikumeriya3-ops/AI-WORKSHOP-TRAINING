import { ArenaStage, FighterProfile } from '../types/game';

export const FIGHTERS: FighterProfile[] = [
  {
    id: 'ren',
    name: 'Ren Sato',
    style: 'Kyokushin Strike',
    portraitUrl: '/src/assets/images/fighter_ren_1795535710030.jpg',
    superName: 'Crimson Breaker',
    bio: 'Balanced dojo veteran built around crisp frame-trap jabs and punishing roundhouse counters.',
    stats: {
      power: 8,
      speed: 7,
      defense: 7,
    },
    palette: {
      skin: '#E0AC82',
      primary: '#1E293B',
      secondary: '#B91C1C',
      accent: '#F8FAFC',
      headgear: 'headband',
    },
  },
  {
    id: 'kaelen',
    name: 'Kaelen Vance',
    style: 'Kinetic Kickboxing',
    portraitUrl: '/src/assets/images/fighter_kaelen_1795535711398.jpg',
    superName: 'Gale Surge',
    bio: 'Lightning-fast rushdown specialist with extended leg reach and relentless dash pressure.',
    stats: {
      power: 7,
      speed: 10,
      defense: 5,
    },
    palette: {
      skin: '#D9A178',
      primary: '#1E3A8A',
      secondary: '#F59E0B',
      accent: '#FDE68A',
      headgear: 'ponytail',
    },
  },
  {
    id: 'nyx',
    name: 'Nyx Mercer',
    style: 'Shadow Palm',
    portraitUrl: '/src/assets/images/fighter_nyx_1795535711182.jpg',
    superName: 'Emerald Eclipse',
    bio: 'Elusive counter-striker whose rapid steps and emerald gauntlet bursts break heavy guards.',
    stats: {
      power: 7,
      speed: 9,
      defense: 7,
    },
    palette: {
      skin: '#C8926E',
      primary: '#0F172A',
      secondary: '#10B981',
      accent: '#34D399',
      headgear: 'hood',
    },
  },
  {
    id: 'titan',
    name: 'Titan Briggs',
    style: 'Iron Gauntlet',
    portraitUrl: '/src/assets/images/fighter_titan_1795535711782.jpg',
    superName: 'Seismic Slam',
    bio: 'Heavyweight powerhouse boasting armored poise and devastating close-range bronze gauntlets.',
    stats: {
      power: 10,
      speed: 5,
      defense: 9,
    },
    palette: {
      skin: '#BA815C',
      primary: '#365314',
      secondary: '#B45309',
      accent: '#F59E0B',
      headgear: 'none',
    },
  },
];

export const ARENA_STAGES: ArenaStage[] = [
  {
    id: 'dojo',
    name: 'Twilight Courtyard',
    location: 'Kyoto Mountain Dojo',
    imageUrl: '/src/assets/images/arena_dojo_sunset_1795535709669.jpg',
    floorColor: 'rgba(15, 23, 42, 0.72)',
    floorAccent: '#F59E0B',
  },
  {
    id: 'rooftop',
    name: 'Skyline Helipad',
    location: 'Metro Tower 64',
    imageUrl: '/src/assets/images/arena_rooftop_rain_1795535709312.jpg',
    floorColor: 'rgba(15, 23, 42, 0.78)',
    floorAccent: '#38BDF8',
  },
];
