export type GameState =
  | 'TITLE_MENU'
  | 'FIGHTER_SELECT'
  | 'PLAYING'
  | 'PAUSED'
  | 'ROUND_SUMMARY'
  | 'GAME_OVER';

export type Difficulty = 'Rookie' | 'Contender' | 'Master';

export type ActionState =
  | 'idle'
  | 'walk'
  | 'jump'
  | 'crouch'
  | 'block'
  | 'jab'
  | 'kick'
  | 'dash'
  | 'super'
  | 'hitstun'
  | 'ko';

export interface FighterProfile {
  id: string;
  name: string;
  style: string;
  portraitUrl: string;
  superName: string;
  bio: string;
  stats: {
    power: number;   // 1-10
    speed: number;   // 1-10
    defense: number; // 1-10
  };
  palette: {
    skin: string;
    primary: string;
    secondary: string;
    accent: string;
    headgear: 'headband' | 'ponytail' | 'hood' | 'none';
  };
}

export interface ArenaStage {
  id: string;
  name: string;
  location: string;
  imageUrl: string;
  floorColor: string;
  floorAccent: string;
}

export interface ControlInputState {
  left: boolean;
  right: boolean;
  up: boolean;
  down: boolean;
  block: boolean;
  jabPressed: boolean;
  kickPressed: boolean;
  dashPressed: boolean;
  superPressed: boolean;
}

export interface HudSnapshot {
  p1Hp: number;
  p1MaxHp: number;
  p1Super: number;
  p1Combo: number;
  p1Action: ActionState;
  p2Hp: number;
  p2MaxHp: number;
  p2Super: number;
  p2Combo: number;
  p2Action: ActionState;
  timeLeft: number;
}

export interface RoundResult {
  roundNumber: number;
  winner: 'p1' | 'p2' | 'draw';
  reason: 'KO' | 'Time Over' | 'Double KO';
  p1RemainingHp: number;
  p2RemainingHp: number;
  maxComboP1: number;
  damageDealtP1: number;
}

export interface CareerRecord {
  wins: number;
  losses: number;
  bestCombo: number;
  streak: number;
}
