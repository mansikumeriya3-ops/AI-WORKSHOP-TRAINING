import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  ClipboardList,
  PackageSearch,
  ShoppingCart,
  UserCircle,
  X,
} from 'lucide-react';
import { AccountView } from './components/AccountView';
import { CartView } from './components/CartView';
import { CatalogView } from './components/CatalogView';
import { OfflineIndicator } from './components/OfflineIndicator';
import { OrdersView } from './components/OrdersView';
import { ProductDetailSheet } from './components/ProductDetailSheet';
import { PWAInstallButton } from './components/PWAInstallButton';
import {
  CATALOG_PRODUCTS,
  INITIAL_PURCHASE_ORDERS,
} from './data/catalogData';
import { usePWAInstall } from './hooks/usePWAInstall';
import {
  AppTab,
  CartItem,
  OrderLineItem,
  Product,
  ProductCategory,
  PurchaseOrder,
  SortOption,
} from './types/catalog';

const CART_STORAGE_KEY = 'meridian_supply_cart_v1';
const ORDERS_STORAGE_KEY = 'meridian_supply_orders_v1';
const THEME_STORAGE_KEY = 'meridian_supply_theme_v1';

interface SnackbarState {
  message: string;
  actionLabel?: string;
  onAction?: () => void;
}

export default function App() {
  const { isInstallable, isIOS, isInstalled } = usePWAInstall();

  const [activeTab, setActiveTab] = useState<AppTab>('catalog');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<ProductCategory>(
    ProductCategory.ALL
  );
  const [selectedSort, setSelectedSort] = useState<SortOption>(
    SortOption.FEATURED
  );
  const [isLoading, setIsLoading] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [snackbar, setSnackbar] = useState<SnackbarState | null>(null);
  const snackbarTimerRef = useRef<number | null>(null);

  const [isDark, setIsDark] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem(THEME_STORAGE_KEY);
      if (saved === 'dark') return true;
      if (saved === 'light') return false;
    } catch {
      // Ignore storage access failures
    }
    return false;
  });

  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const raw = localStorage.getItem(CART_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as CartItem[];
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {
      // Ignore malformed storage
    }
    return [];
  });

  const [orders, setOrders] = useState<PurchaseOrder[]>(() => {
    try {
      const raw = localStorage.getItem(ORDERS_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as PurchaseOrder[];
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // Ignore malformed storage
    }
    return INITIAL_PURCHASE_ORDERS;
  });

  useEffect(() => {
    const root = document.documentElement;
    if (isDark) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    try {
      localStorage.setItem(THEME_STORAGE_KEY, isDark ? 'dark' : 'light');
    } catch {
      // Ignore storage failures
    }
  }, [isDark]);

  useEffect(() => {
    try {
      localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cart));
    } catch {
      // Ignore storage failures
    }
  }, [cart]);

  useEffect(() => {
    try {
      localStorage.setItem(ORDERS_STORAGE_KEY, JSON.stringify(orders));
    } catch {
      // Ignore storage failures
    }
  }, [orders]);

  useEffect(() => {
    return () => {
      if (snackbarTimerRef.current !== null) {
        window.clearTimeout(snackbarTimerRef.current);
      }
    };
  }, []);

  const showSnackbar = (next: SnackbarState) => {
    if (snackbarTimerRef.current !== null) {
      window.clearTimeout(snackbarTimerRef.current);
    }
    setSnackbar(next);
    snackbarTimerRef.current = window.setTimeout(() => {
      setSnackbar(null);
    }, 4000);
  };

  const cartCount = useMemo(
    () => cart.reduce((sum, item) => sum + item.qty, 0),
    [cart]
  );

  const filteredProducts = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    const list = CATALOG_PRODUCTS.filter((p) => {
      const matchesCat =
        selectedCategory === ProductCategory.ALL || p.category === selectedCategory;
      const matchesSearch =
        q.length === 0 ||
        p.name.toLowerCase().includes(q) ||
        p.sku.toLowerCase().includes(q) ||
        p.specs.toLowerCase().includes(q);
      return matchesCat && matchesSearch;
    });

    const sorted = [...list];
    switch (selectedSort) {
      case SortOption.PRICE_LOW_TO_HIGH:
        sorted.sort((a, b) => a.unitPrice - b.unitPrice);
        break;
      case SortOption.PRICE_HIGH_TO_LOW:
        sorted.sort((a, b) => b.unitPrice - a.unitPrice);
        break;
      case SortOption.BULK_SAVINGS:
        sorted.sort(
          (a, b) =>
            (b.unitPrice - b.bulkPrice) / b.unitPrice -
            (a.unitPrice - a.bulkPrice) / a.unitPrice
        );
        break;
      case SortOption.STOCK_HIGH_TO_LOW:
        sorted.sort((a, b) => b.inStockQty - a.inStockQty);
        break;
      case SortOption.FEATURED:
      default:
        break;
    }
    return sorted;
  }, [searchQuery, selectedCategory, selectedSort]);

  const handleAddToCart = (product: Product, qty: number) => {
    if (product.inStockQty <= 0 || qty <= 0) return;

    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        const nextQty = Math.min(product.inStockQty, existing.qty + qty);
        return prev.map((item) =>
          item.product.id === product.id ? { ...item, qty: nextQty } : item
        );
      }
      return [...prev, { product, qty: Math.min(product.inStockQty, qty) }];
    });

    setSelectedProduct(null);
    showSnackbar({
      message: `Added ${qty}x ${product.name}`,
      actionLabel: 'View Cart',
      onAction: () => {
        setSnackbar(null);
        setActiveTab('cart');
      },
    });
  };

  const handleUpdateCartQty = (productId: string, qty: number) => {
    if (qty <= 0) {
      setCart((prev) => prev.filter((i) => i.product.id !== productId));
      return;
    }
    setCart((prev) =>
      prev.map((i) =>
        i.product.id === productId
          ? { ...i, qty: Math.min(i.product.inStockQty, qty) }
          : i
      )
    );
  };

  const handleRemoveCartItem = (productId: string) => {
    setCart((prev) => prev.filter((i) => i.product.id !== productId));
  };

  const handleSubmitOrder = (details: {
    poNumber: string;
    siteName: string;
    paymentTerms: string;
    notes: string;
  }) => {
    const standardSubtotal = cart.reduce(
      (sum, item) => sum + item.product.unitPrice * item.qty,
      0
    );
    const netSubtotal = cart.reduce((sum, item) => {
      const rate =
        item.qty >= item.product.bulkMinQty
          ? item.product.bulkPrice
          : item.product.unitPrice;
      return sum + rate * item.qty;
    }, 0);
    const bulkSavings = standardSubtotal - netSubtotal;
    const freight = netSubtotal >= 1500 ? 0 : 45;

    const lineItems: OrderLineItem[] = cart.map((item) => {
      const isBulk = item.qty >= item.product.bulkMinQty;
      return {
        productId: item.product.id,
        sku: item.product.sku,
        name: item.product.name,
        unitLabel: item.product.unitLabel,
        qty: item.qty,
        appliedUnitPrice: isBulk
          ? item.product.bulkPrice
          : item.product.unitPrice,
        isBulkRate: isBulk,
      };
    });

    const newOrder: PurchaseOrder = {
      id: `po-${Date.now()}`,
      poNumber: details.poNumber,
      createdAt: new Date().toISOString(),
      siteName: details.siteName,
      paymentTerms: details.paymentTerms,
      notes: details.notes,
      status: 'Submitted',
      items: lineItems,
      subtotal: netSubtotal,
      bulkSavings,
      freight,
      total: netSubtotal + freight,
    };

    setOrders((prev) => [newOrder, ...prev]);
    setCart([]);
    setActiveTab('orders');
    showSnackbar({
      message: `Purchase Order ${newOrder.poNumber} submitted`,
    });
  };

  const handleReorder = (order: PurchaseOrder) => {
    let addedCount = 0;
    setCart((prev) => {
      const updated = [...prev];
      order.items.forEach((line) => {
        const product = CATALOG_PRODUCTS.find((p) => p.id === line.productId);
        if (!product || product.inStockQty <= 0) return;
        addedCount += 1;
        const existingIdx = updated.findIndex((i) => i.product.id === product.id);
        if (existingIdx >= 0) {
          updated[existingIdx] = {
            ...updated[existingIdx],
            qty: Math.min(product.inStockQty, updated[existingIdx].qty + line.qty),
          };
        } else {
          updated.push({
            product,
            qty: Math.min(product.inStockQty, line.qty),
          });
        }
      });
      return updated;
    });

    if (addedCount > 0) {
      showSnackbar({
        message: `Added ${addedCount} stocked SKUs from ${order.poNumber}`,
        actionLabel: 'View Cart',
        onAction: () => {
          setSnackbar(null);
          setActiveTab('cart');
        },
      });
    }
  };

  const handleRefreshStock = () => {
    setIsLoading(true);
    window.setTimeout(() => {
      setIsLoading(false);
    }, 450);
  };

  const handleResetFilters = () => {
    setSearchQuery('');
    setSelectedCategory(ProductCategory.ALL);
    setSelectedSort(SortOption.FEATURED);
  };

  const totalSpent = useMemo(
    () => orders.reduce((sum, o) => sum + o.total, 0),
    [orders]
  );

  const showInstallCTAInHeader = !isInstalled && (isInstallable || isIOS);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-100">
      {/* Desktop Top Bar (Strict 3-Zone Contract) */}
      <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/95 backdrop-blur-md dark:border-slate-800 dark:bg-slate-900/95">
        <div className="mx-auto flex h-12 max-w-7xl items-center justify-between gap-8 px-4 sm:px-6 md:h-16">
          {/* Zone 1: Single-line Brand Wordmark */}
          <button
            type="button"
            onClick={() => setActiveTab('catalog')}
            className="font-display text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0 dark:text-slate-50"
          >
            Meridian Supply
          </button>

          {/* Zone 2: 4 Clean Single-Line Nav Links (Desktop) */}
          <nav
            aria-label="Primary navigation"
            className="hidden items-center gap-7 md:flex"
          >
            {(
              [
                { id: 'catalog', label: 'Catalog' },
                { id: 'orders', label: 'Orders' },
                { id: 'cart', label: cartCount > 0 ? `PO Cart (${cartCount})` : 'PO Cart' },
                { id: 'account', label: 'Account' },
              ] as const
            ).map((navItem) => {
              const active = activeTab === navItem.id;
              return (
                <button
                  key={navItem.id}
                  type="button"
                  onClick={() => setActiveTab(navItem.id)}
                  className={`relative py-2 text-sm font-medium transition-colors whitespace-nowrap shrink-0 ${
                    active
                      ? 'text-slate-950 dark:text-sky-400'
                      : 'text-slate-600 hover:text-slate-950 dark:text-slate-400 dark:hover:text-slate-100'
                  }`}
                >
                  {navItem.label}
                  {active && (
                    <span className="absolute right-0 bottom-0 left-0 h-0.5 rounded-full bg-slate-900 dark:bg-sky-400" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Single Primary Action */}
          <div className="flex items-center shrink-0">
            <div className="hidden md:block">
              {showInstallCTAInHeader ? (
                <PWAInstallButton variant="header" />
              ) : (
                <button
                  type="button"
                  onClick={() => setActiveTab('cart')}
                  className="inline-flex min-h-[40px] items-center gap-2 rounded-lg bg-slate-900 px-4 py-2 text-xs font-semibold text-white transition-colors hover:bg-slate-800 whitespace-nowrap shrink-0 dark:bg-sky-500 dark:text-slate-950 dark:hover:bg-sky-400"
                >
                  <ShoppingCart className="h-3.5 w-3.5" />
                  <span>{cartCount > 0 ? `Review PO (${cartCount})` : 'Draft PO'}</span>
                </button>
              )}
            </div>

            {/* Mobile compact cart trigger (keeps top bar clean at 48px) */}
            <button
              type="button"
              onClick={() => setActiveTab('cart')}
              aria-label={`Open PO Cart, ${cartCount} items`}
              className="relative flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl text-slate-700 hover:bg-slate-100 md:hidden dark:text-slate-200 dark:hover:bg-slate-800"
            >
              <ShoppingCart className="h-5 w-5" />
              {cartCount > 0 && (
                <span className="absolute top-1.5 right-1 flex h-4 min-w-[1rem] items-center justify-center rounded-full bg-amber-600 px-1 font-mono text-[10px] font-bold tabular-nums text-white dark:bg-amber-500 dark:text-slate-950">
                  {cartCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Main Scrollable Viewport */}
      <main className="mx-auto max-w-7xl px-4 pt-5 pb-24 sm:px-6 md:pt-8 md:pb-12">
        {activeTab === 'catalog' && (
          <CatalogView
            products={filteredProducts}
            searchQuery={searchQuery}
            onSearchQueryChange={setSearchQuery}
            selectedCategory={selectedCategory}
            onCategoryChange={setSelectedCategory}
            selectedSort={selectedSort}
            onSortChange={setSelectedSort}
            isLoading={isLoading}
            onRefresh={handleRefreshStock}
            onProductClick={setSelectedProduct}
            onQuickAdd={(p) => handleAddToCart(p, 1)}
            onResetFilters={handleResetFilters}
          />
        )}

        {activeTab === 'orders' && (
          <OrdersView orders={orders} onReorder={handleReorder} />
        )}

        {activeTab === 'cart' && (
          <CartView
            items={cart}
            onUpdateQty={handleUpdateCartQty}
            onRemoveItem={handleRemoveCartItem}
            onClearCart={() => setCart([])}
            onBrowseCatalog={() => setActiveTab('catalog')}
            onSubmitOrder={handleSubmitOrder}
          />
        )}

        {activeTab === 'account' && (
          <AccountView
            isDark={isDark}
            onToggleTheme={() => setIsDark((d) => !d)}
            totalSpent={totalSpent}
          />
        )}
      </main>

      {/* Mobile Fixed Bottom Tab Bar (Thumb-Zone Navigation, 60px height) */}
      <nav
        aria-label="Mobile bottom navigation"
        className="fixed right-0 bottom-0 left-0 z-40 border-t border-slate-200 bg-white/95 backdrop-blur-md pb-safe md:hidden dark:border-slate-800 dark:bg-slate-900/95"
      >
        <div className="grid h-[60px] grid-cols-4 items-center">
          {(
            [
              { id: 'catalog', label: 'Catalog', icon: PackageSearch },
              { id: 'orders', label: 'Orders', icon: ClipboardList },
              { id: 'cart', label: 'Cart', icon: ShoppingCart, badge: cartCount },
              { id: 'account', label: 'Account', icon: UserCircle },
            ] as const
          ).map((tab) => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id)}
                className={`relative flex h-full flex-col items-center justify-center gap-0.5 transition-colors ${
                  active
                    ? 'text-slate-950 dark:text-sky-400'
                    : 'text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100'
                }`}
              >
                <div className="relative">
                  <Icon className="h-5 w-5" />
                  {'badge' in tab && tab.badge > 0 && (
                    <span className="absolute -top-1.5 -right-2.5 flex h-4 min-w-[1rem] items-center justify-center rounded-full bg-amber-600 px-1 font-mono text-[10px] font-bold tabular-nums text-white dark:bg-amber-500 dark:text-slate-950">
                      {tab.badge}
                    </span>
                  )}
                </div>
                <span className="text-[11px] font-medium tracking-tight whitespace-nowrap">
                  {tab.label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Product Detail & Bulk Tier Bottom Sheet */}
      <ProductDetailSheet
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onAddToCart={handleAddToCart}
      />

      {/* Snackbar Feedback */}
      {snackbar && (
        <div
          role="status"
          aria-live="polite"
          className="fixed right-4 bottom-20 left-4 z-50 flex items-center justify-between gap-3 rounded-xl bg-slate-900 px-4 py-3 text-sm text-white shadow-xl md:bottom-6 md:left-auto md:w-96 dark:border dark:border-slate-700 dark:bg-slate-800"
        >
          <span className="truncate font-medium">{snackbar.message}</span>
          <div className="flex items-center gap-1 shrink-0">
            {snackbar.actionLabel && snackbar.onAction && (
              <button
                type="button"
                onClick={snackbar.onAction}
                className="min-h-[36px] rounded-lg px-2.5 py-1 text-xs font-bold text-amber-400 hover:bg-slate-800 dark:hover:bg-slate-700 whitespace-nowrap"
              >
                {snackbar.actionLabel}
              </button>
            )}
            <button
              type="button"
              onClick={() => setSnackbar(null)}
              aria-label="Dismiss notification"
              className="flex min-h-[36px] min-w-[36px] items-center justify-center rounded-lg text-slate-400 hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}

      {/* Offline Connectivity Banner */}
      <OfflineIndicator />
    </div>
  );
}
