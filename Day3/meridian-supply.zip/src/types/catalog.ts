export enum ProductCategory {
  ALL = 'ALL',
  FASTENERS = 'FASTENERS',
  ELECTRICAL = 'ELECTRICAL',
  SAFETY = 'SAFETY',
  PACKAGING = 'PACKAGING',
  ADHESIVES = 'ADHESIVES',
}

export const PRODUCT_CATEGORY_LABELS: Record<ProductCategory, string> = {
  [ProductCategory.ALL]: 'All Supplies',
  [ProductCategory.FASTENERS]: 'Fasteners',
  [ProductCategory.ELECTRICAL]: 'Electrical',
  [ProductCategory.SAFETY]: 'Safety & PPE',
  [ProductCategory.PACKAGING]: 'Packaging',
  [ProductCategory.ADHESIVES]: 'Adhesives',
};

export enum SortOption {
  FEATURED = 'FEATURED',
  PRICE_LOW_TO_HIGH = 'PRICE_LOW_TO_HIGH',
  PRICE_HIGH_TO_LOW = 'PRICE_HIGH_TO_LOW',
  BULK_SAVINGS = 'BULK_SAVINGS',
  STOCK_HIGH_TO_LOW = 'STOCK_HIGH_TO_LOW',
}

export const SORT_OPTION_LABELS: Record<SortOption, string> = {
  [SortOption.FEATURED]: 'Featured SKUs',
  [SortOption.PRICE_LOW_TO_HIGH]: 'Unit Price: Low to High',
  [SortOption.PRICE_HIGH_TO_LOW]: 'Unit Price: High to Low',
  [SortOption.BULK_SAVINGS]: 'Highest Bulk Savings',
  [SortOption.STOCK_HIGH_TO_LOW]: 'Highest Stock Level',
};

export interface Product {
  id: string;
  sku: string;
  name: string;
  category: Exclude<ProductCategory, ProductCategory.ALL>;
  unitLabel: string;
  unitPrice: number;
  bulkPrice: number;
  bulkMinQty: number;
  inStockQty: number;
  warehouseBin: string;
  leadTime: string;
  specs: string;
  imageUrl: string;
}

export interface CartItem {
  product: Product;
  qty: number;
}

export type OrderStatus = 'Submitted' | 'In Transit' | 'Delivered';

export interface OrderLineItem {
  productId: string;
  sku: string;
  name: string;
  unitLabel: string;
  qty: number;
  appliedUnitPrice: number;
  isBulkRate: boolean;
}

export interface PurchaseOrder {
  id: string;
  poNumber: string;
  createdAt: string;
  siteName: string;
  paymentTerms: string;
  notes: string;
  status: OrderStatus;
  items: OrderLineItem[];
  subtotal: number;
  bulkSavings: number;
  freight: number;
  total: number;
}

export type AppTab = 'catalog' | 'orders' | 'cart' | 'account';
