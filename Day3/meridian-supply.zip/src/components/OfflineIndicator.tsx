import React from 'react';
import { WifiOff } from 'lucide-react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div
      role="status"
      aria-live="polite"
      className="fixed bottom-20 left-4 right-4 z-50 flex items-center justify-center gap-2 rounded-xl border border-amber-300 bg-amber-50 px-4 py-2.5 text-xs font-semibold text-amber-900 shadow-md md:bottom-4 md:left-auto md:right-4 md:w-auto dark:border-amber-800 dark:bg-amber-950 dark:text-amber-200"
    >
      <WifiOff className="h-4 w-4 shrink-0" />
      <span>Offline mode — Using cached catalog and local draft PO</span>
    </div>
  );
};
