import React, { useState } from 'react';
import {
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Clock,
  RotateCcw,
  Truck,
} from 'lucide-react';
import { OrderStatus, PurchaseOrder } from '../types/catalog';
import { formatCurrency, formatOrderDate } from '../utils/format';

interface OrdersViewProps {
  orders: PurchaseOrder[];
  onReorder: (order: PurchaseOrder) => void;
}

const STATUS_META: Record<
  OrderStatus,
  { icon: React.FC<{ className?: string }>; textClass: string }
> = {
  Submitted: {
    icon: Clock,
    textClass: 'text-amber-700 dark:text-amber-400',
  },
  'In Transit': {
    icon: Truck,
    textClass: 'text-sky-700 dark:text-sky-400',
  },
  Delivered: {
    icon: CheckCircle2,
    textClass: 'text-emerald-700 dark:text-emerald-400',
  },
};

export const OrdersView: React.FC<OrdersViewProps> = ({ orders, onReorder }) => {
  const [statusFilter, setStatusFilter] = useState<'ALL' | OrderStatus>('ALL');
  const [expandedOrderId, setExpandedOrderId] = useState<string | null>(
    orders[0]?.id ?? null
  );

  const filteredOrders =
    statusFilter === 'ALL'
      ? orders
      : orders.filter((o) => o.status === statusFilter);

  return (
    <section aria-label="Purchase Orders" className="space-y-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl dark:text-slate-50">
            Purchase Orders
          </h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
            Track warehouse dispatch status and reorder past jobsite requisitions in one tap.
          </p>
        </div>

        <div
          role="tablist"
          aria-label="Filter orders by status"
          className="no-scrollbar flex items-center gap-1.5 overflow-x-auto"
        >
          {(['ALL', 'Submitted', 'In Transit', 'Delivered'] as const).map((status) => {
            const active = statusFilter === status;
            return (
              <button
                key={status}
                type="button"
                role="tab"
                aria-selected={active}
                onClick={() => setStatusFilter(status)}
                className={`min-h-[44px] rounded-xl px-3.5 py-2 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                  active
                    ? 'bg-slate-900 text-white dark:bg-sky-500 dark:text-slate-950'
                    : 'border border-slate-200 bg-white text-slate-700 hover:bg-slate-100 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-slate-800'
                }`}
              >
                {status === 'ALL' ? 'All Orders' : status}
              </button>
            );
          })}
        </div>
      </div>

      {filteredOrders.length === 0 ? (
        <div className="rounded-2xl border border-slate-200 bg-white px-6 py-14 text-center dark:border-slate-800 dark:bg-slate-900">
          <p className="text-sm font-medium text-slate-600 dark:text-slate-400">
            No purchase orders match the selected status filter.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredOrders.map((order) => {
            const isExpanded = expandedOrderId === order.id;
            const statusCfg = STATUS_META[order.status];
            const StatusIcon = statusCfg.icon;

            return (
              <article
                key={order.id}
                className="rounded-2xl border border-slate-200 bg-white p-4 sm:p-5 dark:border-slate-800 dark:bg-slate-900"
              >
                <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs">
                      <span className="font-mono text-sm font-bold text-slate-900 dark:text-slate-50">
                        {order.poNumber}
                      </span>
                      <span aria-hidden="true" className="text-slate-400">
                        ·
                      </span>
                      <span className="text-slate-500 dark:text-slate-400">
                        {formatOrderDate(order.createdAt)}
                      </span>
                      <span aria-hidden="true" className="text-slate-400">
                        ·
                      </span>
                      <span
                        className={`inline-flex items-center gap-1 font-semibold ${statusCfg.textClass}`}
                      >
                        <StatusIcon className="h-3.5 w-3.5" />
                        <span>{order.status}</span>
                      </span>
                    </div>

                    <div className="text-sm font-medium text-slate-700 dark:text-slate-300">
                      {order.siteName} · {order.paymentTerms}
                    </div>
                  </div>

                  <div className="flex items-center justify-between gap-3 sm:justify-end">
                    <div className="text-left sm:text-right">
                      <div className="font-mono text-lg font-bold tabular-nums text-slate-900 dark:text-slate-50">
                        {formatCurrency(order.total)}
                      </div>
                      <div className="text-xs text-slate-500 dark:text-slate-400">
                        {order.items.length} line{' '}
                        {order.items.length === 1 ? 'item' : 'items'}
                        {order.bulkSavings > 0 &&
                          ` · Saved ${formatCurrency(order.bulkSavings)}`}
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() =>
                        setExpandedOrderId(isExpanded ? null : order.id)
                      }
                      aria-expanded={isExpanded}
                      aria-label={
                        isExpanded ? 'Hide order line items' : 'Show order line items'
                      }
                      className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl border border-slate-200 text-slate-600 transition-colors hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
                    >
                      {isExpanded ? (
                        <ChevronUp className="h-4 w-4" />
                      ) : (
                        <ChevronDown className="h-4 w-4" />
                      )}
                    </button>
                  </div>
                </div>

                {isExpanded && (
                  <div className="mt-4 border-t border-slate-100 pt-4 dark:border-slate-800">
                    <div className="space-y-2.5">
                      {order.items.map((line) => (
                        <div
                          key={line.productId}
                          className="flex items-center justify-between gap-4 text-sm"
                        >
                          <div className="min-w-0">
                            <div className="truncate font-medium text-slate-900 dark:text-slate-100">
                              {line.name}
                            </div>
                            <div className="text-xs text-slate-500 dark:text-slate-400">
                              <span className="font-mono">{line.sku}</span> ·{' '}
                              <span className="font-mono tabular-nums">
                                {line.qty}
                              </span>{' '}
                              × {formatCurrency(line.appliedUnitPrice)} (
                              {line.unitLabel})
                              {line.isBulkRate && ' · Bulk rate'}
                            </div>
                          </div>
                          <div className="shrink-0 font-mono font-semibold tabular-nums text-slate-900 dark:text-slate-100">
                            {formatCurrency(line.qty * line.appliedUnitPrice)}
                          </div>
                        </div>
                      ))}
                    </div>

                    {order.notes && (
                      <p className="mt-3 text-xs text-slate-500 dark:text-slate-400">
                        Note: {order.notes}
                      </p>
                    )}

                    <div className="mt-4 flex justify-end">
                      <button
                        type="button"
                        onClick={() => onReorder(order)}
                        className="inline-flex min-h-[44px] items-center gap-2 rounded-xl bg-slate-900 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-slate-800 dark:bg-sky-500 dark:text-slate-950 dark:hover:bg-sky-400"
                      >
                        <RotateCcw className="h-4 w-4" />
                        <span>Reorder to Cart</span>
                      </button>
                    </div>
                  </div>
                )}
              </article>
            );
          })}
        </div>
      )}
    </section>
  );
};
