import React, { useEffect, useState } from 'react';
import { Check, Minus, Plus, X, AlertCircle } from 'lucide-react';
import { Product, PRODUCT_CATEGORY_LABELS } from '../types/catalog';
import { formatCurrency } from '../utils/format';
import { ProductImage } from './ProductImage';

interface ProductDetailSheetProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, qty: number) => void;
}

export const ProductDetailSheet: React.FC<ProductDetailSheetProps> = ({
  product,
  onClose,
  onAddToCart,
}) => {
  const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    if (product) {
      setQuantity(product.inStockQty > 0 ? 1 : 0);
    }
  }, [product]);

  useEffect(() => {
    if (!product) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [product, onClose]);

  if (!product) return null;

  const isOutOfStock = product.inStockQty <= 0;
  const isBulkUnlocked = quantity >= product.bulkMinQty;
  const activePrice = isBulkUnlocked ? product.bulkPrice : product.unitPrice;
  const lineTotal = activePrice * quantity;
  const totalSavings = isBulkUnlocked ? (product.unitPrice - product.bulkPrice) * quantity : 0;
  const unitsNeededForBulk = Math.max(0, product.bulkMinQty - quantity);

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-slate-950/55 backdrop-blur-xs sm:items-center sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="product-sheet-title"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="max-h-[90dvh] w-full max-w-lg overflow-y-auto rounded-t-3xl border border-slate-200 bg-white shadow-2xl sm:rounded-2xl dark:border-slate-800 dark:bg-slate-900">
        {/* Mobile drag handle */}
        <div className="sticky top-0 z-10 flex justify-center bg-white/95 pt-3 pb-1 backdrop-blur-sm sm:hidden dark:bg-slate-900/95">
          <div className="h-1.5 w-10 rounded-full bg-slate-300 dark:bg-slate-700" />
        </div>

        <div className="px-5 pt-3 pb-6 sm:p-6">
          <div className="flex items-start justify-between gap-4">
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-slate-500 dark:text-slate-400">
                <span className="font-mono font-medium text-slate-700 dark:text-slate-300">
                  {product.sku}
                </span>
                <span aria-hidden="true">·</span>
                <span>{PRODUCT_CATEGORY_LABELS[product.category]}</span>
                <span aria-hidden="true">·</span>
                <span>{product.warehouseBin}</span>
              </div>
              <h2
                id="product-sheet-title"
                className="mt-1.5 font-display text-xl font-bold leading-snug text-slate-900 text-balance dark:text-slate-50"
              >
                {product.name}
              </h2>
            </div>

            <button
              type="button"
              onClick={onClose}
              aria-label="Close product details"
              className="flex min-h-[44px] min-w-[44px] shrink-0 items-center justify-center rounded-xl text-slate-500 transition-colors hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-slate-100"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          <div className="mt-4 overflow-hidden rounded-xl bg-slate-100 dark:bg-slate-800">
            <ProductImage
              src={product.imageUrl}
              alt={product.name}
              sku={product.sku}
              className="aspect-[16/10] w-full"
            />
          </div>

          <p className="mt-4 text-sm leading-relaxed text-slate-600 dark:text-slate-300">
            {product.specs}
          </p>

          <div className="mt-3 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs font-medium">
            {isOutOfStock ? (
              <span className="inline-flex items-center gap-1.5 text-rose-700 dark:text-rose-400">
                <AlertCircle className="h-3.5 w-3.5" />
                Out of Stock · {product.leadTime}
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 text-emerald-700 dark:text-emerald-400">
                <Check className="h-3.5 w-3.5" />
                {product.inStockQty} units available · {product.leadTime}
              </span>
            )}
          </div>

          {/* Standard vs Bulk Tier Surface */}
          <div className="mt-5 grid grid-cols-2 gap-3 rounded-xl bg-slate-100 p-4 dark:bg-slate-800/80">
            <div>
              <div className="text-xs font-medium text-slate-500 dark:text-slate-400">
                Standard ({product.unitLabel})
              </div>
              <div
                className={`mt-1 font-mono text-lg font-bold tabular-nums ${
                  !isBulkUnlocked
                    ? 'text-slate-900 dark:text-slate-50'
                    : 'text-slate-500 line-through dark:text-slate-400'
                }`}
              >
                {formatCurrency(product.unitPrice)}
              </div>
            </div>

            <div className="text-right">
              <div className="text-xs font-medium text-slate-500 dark:text-slate-400">
                Bulk Tier ({product.bulkMinQty}+ units)
              </div>
              <div className="mt-1 font-mono text-lg font-bold tabular-nums text-sky-700 dark:text-sky-400">
                {formatCurrency(product.bulkPrice)}
              </div>
            </div>
          </div>

          {/* Bulk tier progress or savings line */}
          {!isOutOfStock && (
            <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-xs">
              {isBulkUnlocked ? (
                <span className="inline-flex items-center gap-1.5 font-semibold text-emerald-700 dark:text-emerald-400">
                  <Check className="h-3.5 w-3.5" />
                  Bulk tier active · Saving {formatCurrency(totalSavings)} on this line
                </span>
              ) : (
                <>
                  <span className="text-slate-600 dark:text-slate-300">
                    Add <span className="font-mono font-semibold tabular-nums">{unitsNeededForBulk}</span> more for{' '}
                    <span className="font-mono font-semibold tabular-nums">
                      {formatCurrency(product.bulkPrice)}
                    </span>
                    /unit
                  </span>
                  {product.inStockQty >= product.bulkMinQty && (
                    <button
                      type="button"
                      onClick={() => setQuantity(product.bulkMinQty)}
                      className="min-h-[36px] rounded-lg px-2.5 py-1 text-xs font-semibold text-sky-700 transition-colors hover:bg-sky-50 whitespace-nowrap shrink-0 dark:text-sky-400 dark:hover:bg-sky-950/50"
                    >
                      Set to {product.bulkMinQty} (Bulk)
                    </button>
                  )}
                </>
              )}
            </div>
          )}

          {/* Quantity Stepper & Primary Add Action */}
          <div className="mt-6 flex flex-wrap items-center justify-between gap-3 border-t border-slate-200 pt-5 dark:border-slate-800">
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                disabled={isOutOfStock || quantity <= 1}
                aria-label="Decrease quantity"
                className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl border border-slate-300 text-slate-700 transition-colors hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-40 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
              >
                <Minus className="h-4 w-4" />
              </button>
              <span className="min-w-[3.25rem] text-center font-mono text-base font-bold tabular-nums text-slate-900 dark:text-slate-100">
                {quantity}
              </span>
              <button
                type="button"
                onClick={() => setQuantity((q) => Math.min(product.inStockQty, q + 1))}
                disabled={isOutOfStock || quantity >= product.inStockQty}
                aria-label="Increase quantity"
                className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl border border-slate-300 text-slate-700 transition-colors hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-40 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
              >
                <Plus className="h-4 w-4" />
              </button>
            </div>

            <button
              type="button"
              disabled={isOutOfStock}
              onClick={() => onAddToCart(product, quantity)}
              className="min-h-[48px] flex-1 rounded-xl bg-amber-600 px-5 py-3 font-display text-sm font-bold text-white shadow-sm transition-transform hover:bg-amber-700 active:scale-[0.98] disabled:cursor-not-allowed disabled:bg-slate-300 disabled:text-slate-500 whitespace-nowrap dark:bg-amber-500 dark:text-slate-950 dark:hover:bg-amber-400 dark:disabled:bg-slate-800 dark:disabled:text-slate-500"
            >
              {isOutOfStock ? 'Out of Stock' : `Add · ${formatCurrency(lineTotal)}`}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
