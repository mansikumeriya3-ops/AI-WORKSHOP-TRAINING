import React, { useEffect, useRef, useState } from 'react';
import {
  AlertCircle,
  ArrowUpDown,
  Check,
  CheckCircle2,
  Plus,
  RefreshCw,
  Search,
  SearchX,
  X,
} from 'lucide-react';
import {
  Product,
  ProductCategory,
  PRODUCT_CATEGORY_LABELS,
  SortOption,
  SORT_OPTION_LABELS,
} from '../types/catalog';
import { formatCurrency } from '../utils/format';
import { ProductImage } from './ProductImage';

interface CatalogViewProps {
  products: Product[];
  searchQuery: string;
  onSearchQueryChange: (q: string) => void;
  selectedCategory: ProductCategory;
  onCategoryChange: (c: ProductCategory) => void;
  selectedSort: SortOption;
  onSortChange: (s: SortOption) => void;
  isLoading: boolean;
  onRefresh: () => void;
  onProductClick: (product: Product) => void;
  onQuickAdd: (product: Product) => void;
  onResetFilters: () => void;
}

export const CatalogView: React.FC<CatalogViewProps> = ({
  products,
  searchQuery,
  onSearchQueryChange,
  selectedCategory,
  onCategoryChange,
  selectedSort,
  onSortChange,
  isLoading,
  onRefresh,
  onProductClick,
  onQuickAdd,
  onResetFilters,
}) => {
  const [sortOpen, setSortOpen] = useState(false);
  const sortRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!sortOpen) return;
    const handleOutside = (e: MouseEvent) => {
      if (sortRef.current && !sortRef.current.contains(e.target as Node)) {
        setSortOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutside);
    return () => document.removeEventListener('mousedown', handleOutside);
  }, [sortOpen]);

  return (
    <section aria-label="Wholesale Catalog" className="space-y-5">
      {/* Page Intro + Controls Header */}
      <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight text-slate-900 text-balance sm:text-3xl dark:text-slate-50">
            Wholesale Catalog
          </h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
            Commercial SKU pricing with automatic bulk-tier discounts at checkout.
          </p>
        </div>

        {/* Search + Sort + Sync Row */}
        <div className="flex w-full items-center gap-2 lg:w-auto lg:min-w-[440px]">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute top-1/2 left-3.5 h-4 w-4 -translate-y-1/2 text-slate-400 dark:text-slate-500" />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => onSearchQueryChange(e.target.value)}
              placeholder="Search SKU or product name..."
              aria-label="Search SKU or product name"
              className="min-h-[46px] w-full rounded-xl border border-slate-300 bg-white pr-10 pl-10 text-sm text-slate-900 placeholder:text-slate-400 focus:border-sky-600 focus:outline-none focus:ring-2 focus:ring-sky-600/20 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:placeholder:text-slate-500 dark:focus:border-sky-400"
            />
            {searchQuery.length > 0 && (
              <button
                type="button"
                onClick={() => onSearchQueryChange('')}
                aria-label="Clear search"
                className="absolute top-1/2 right-1 flex min-h-[40px] min-w-[40px] -translate-y-1/2 items-center justify-center rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>

          <div className="relative" ref={sortRef}>
            <button
              type="button"
              onClick={() => setSortOpen((v) => !v)}
              aria-haspopup="menu"
              aria-expanded={sortOpen}
              aria-label="Sort products"
              className="flex min-h-[46px] min-w-[46px] items-center justify-center gap-2 rounded-xl border border-slate-300 bg-white px-3 text-sm font-medium text-slate-700 transition-colors hover:bg-slate-100 focus-visible:outline-2 focus-visible:outline-sky-600 whitespace-nowrap shrink-0 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              <ArrowUpDown className="h-4 w-4" />
              <span className="hidden sm:inline">Sort</span>
            </button>

            {sortOpen && (
              <div
                role="menu"
                className="absolute right-0 z-30 mt-2 w-60 rounded-xl border border-slate-200 bg-white p-1.5 shadow-xl dark:border-slate-800 dark:bg-slate-900"
              >
                {Object.values(SortOption).map((option) => {
                  const isActive = option === selectedSort;
                  return (
                    <button
                      key={option}
                      type="button"
                      role="menuitemradio"
                      aria-checked={isActive}
                      onClick={() => {
                        onSortChange(option);
                        setSortOpen(false);
                      }}
                      className={`flex min-h-[44px] w-full items-center justify-between rounded-lg px-3 py-2 text-left text-sm transition-colors ${
                        isActive
                          ? 'bg-slate-100 font-semibold text-slate-900 dark:bg-slate-800 dark:text-slate-50'
                          : 'text-slate-700 hover:bg-slate-50 dark:text-slate-300 dark:hover:bg-slate-800/60'
                      }`}
                    >
                      <span>{SORT_OPTION_LABELS[option]}</span>
                      {isActive && <Check className="h-4 w-4 text-sky-700 dark:text-sky-400" />}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          <button
            type="button"
            onClick={onRefresh}
            aria-label="Sync warehouse stock"
            title="Sync live warehouse stock"
            className="flex min-h-[46px] min-w-[46px] items-center justify-center rounded-xl border border-slate-300 bg-white text-slate-700 transition-colors hover:bg-slate-100 focus-visible:outline-2 focus-visible:outline-sky-600 shrink-0 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800"
          >
            <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Category Filter Buttons (Interactive Controls) */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div
          role="tablist"
          aria-label="Product categories"
          className="no-scrollbar flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0"
        >
          {Object.values(ProductCategory).map((category) => {
            const active = selectedCategory === category;
            return (
              <button
                key={category}
                type="button"
                role="tab"
                aria-selected={active}
                onClick={() => onCategoryChange(category)}
                className={`min-h-[44px] rounded-xl px-4 py-2 text-sm font-medium transition-colors whitespace-nowrap shrink-0 ${
                  active
                    ? 'bg-slate-900 text-white dark:bg-sky-500 dark:text-slate-950'
                    : 'border border-slate-200 bg-white text-slate-700 hover:bg-slate-100 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-slate-800'
                }`}
              >
                {PRODUCT_CATEGORY_LABELS[category]}
              </button>
            );
          })}
        </div>

        <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
          <span className="font-mono tabular-nums">{products.length}</span>
          <span>{products.length === 1 ? 'SKU matched' : 'SKUs matched'}</span>
          <span aria-hidden="true">·</span>
          <span>{SORT_OPTION_LABELS[selectedSort]}</span>
        </div>
      </div>

      {/* Shimmer Loading / Empty State / Product Grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, idx) => (
            <div
              key={idx}
              className="h-36 rounded-2xl border border-slate-200 bg-white p-4 sm:h-72 dark:border-slate-800 dark:bg-slate-900"
            >
              <div className="shimmer-surface h-full w-full rounded-xl" />
            </div>
          ))}
        </div>
      ) : products.length === 0 ? (
        <div className="flex flex-col items-center justify-center rounded-2xl border border-slate-200 bg-white px-6 py-16 text-center dark:border-slate-800 dark:bg-slate-900">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400">
            <SearchX className="h-7 w-7" />
          </div>
          <h2 className="mt-4 font-display text-lg font-bold text-slate-900 dark:text-slate-100">
            No matching SKUs found
          </h2>
          <p className="mt-1.5 max-w-sm text-sm text-slate-600 dark:text-slate-400">
            Try adjusting your search keyword or clearing active category filters.
          </p>
          <button
            type="button"
            onClick={onResetFilters}
            className="mt-6 min-h-[44px] rounded-xl bg-slate-900 px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-slate-800 dark:bg-sky-500 dark:text-slate-950 dark:hover:bg-sky-400"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
          {products.map((product) => {
            const isOutOfStock = product.inStockQty <= 0;
            return (
              <article
                key={product.id}
                className="group flex flex-row items-center gap-3.5 rounded-2xl border border-slate-200 bg-white p-3.5 transition-colors hover:border-slate-300 md:flex-col md:items-stretch md:gap-0 md:p-0 dark:border-slate-800 dark:bg-slate-900 dark:hover:border-slate-700"
              >
                {/* Clickable product media */}
                <button
                  type="button"
                  onClick={() => onProductClick(product)}
                  aria-label={`View ${product.name} details`}
                  className="h-24 w-24 shrink-0 overflow-hidden rounded-xl bg-slate-100 focus-visible:outline-2 focus-visible:outline-sky-600 md:aspect-[4/3] md:h-auto md:w-full md:rounded-t-2xl md:rounded-b-none dark:bg-slate-800"
                >
                  <ProductImage
                    src={product.imageUrl}
                    alt={product.name}
                    sku={product.sku}
                    className="h-full w-full transition-transform duration-200 group-hover:scale-[1.02]"
                  />
                </button>

                {/* Product content & Quick Add */}
                <div className="flex min-w-0 flex-1 items-center justify-between gap-3 md:flex-col md:items-stretch md:p-4">
                  <button
                    type="button"
                    onClick={() => onProductClick(product)}
                    className="min-w-0 flex-1 text-left focus-visible:outline-2 focus-visible:outline-sky-600"
                  >
                    <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
                      <span className="truncate font-mono">{product.sku}</span>
                      <span aria-hidden="true">·</span>
                      <span className="shrink-0">{PRODUCT_CATEGORY_LABELS[product.category]}</span>
                    </div>

                    <h2 className="mt-1 line-clamp-2 font-display text-sm font-bold leading-snug text-slate-900 md:text-base dark:text-slate-100">
                      {product.name}
                    </h2>

                    <p className="mt-1 truncate text-xs text-slate-600 dark:text-slate-400">
                      {product.unitLabel} · Bulk{' '}
                      <span className="font-mono font-semibold tabular-nums text-slate-800 dark:text-slate-200">
                        {formatCurrency(product.bulkPrice)}
                      </span>{' '}
                      ({product.bulkMinQty}+)
                    </p>
                  </button>

                  <div className="flex shrink-0 flex-col items-end gap-2 md:mt-4 md:flex-row md:items-center md:justify-between md:border-t md:border-slate-100 md:pt-3 dark:md:border-slate-800">
                    <div className="text-right md:text-left">
                      <div className="font-mono text-base font-bold tabular-nums text-slate-900 dark:text-slate-50">
                        {formatCurrency(product.unitPrice)}
                      </div>
                      {isOutOfStock ? (
                        <div className="mt-0.5 inline-flex items-center gap-1 text-[11px] font-semibold text-rose-700 dark:text-rose-400">
                          <AlertCircle className="h-3 w-3 shrink-0" />
                          <span>Out of Stock</span>
                        </div>
                      ) : (
                        <div className="mt-0.5 inline-flex items-center gap-1 text-[11px] font-medium text-emerald-700 dark:text-emerald-400">
                          <CheckCircle2 className="h-3 w-3 shrink-0" />
                          <span className="tabular-nums">{product.inStockQty} in stock</span>
                        </div>
                      )}
                    </div>

                    <button
                      type="button"
                      onClick={() => onQuickAdd(product)}
                      disabled={isOutOfStock}
                      aria-label={`Add ${product.name} to cart`}
                      className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl bg-amber-600 text-white transition-transform hover:bg-amber-700 active:scale-95 disabled:cursor-not-allowed disabled:bg-slate-200 disabled:text-slate-400 dark:bg-amber-500 dark:text-slate-950 dark:hover:bg-amber-400 dark:disabled:bg-slate-800 dark:disabled:text-slate-600"
                    >
                      <Plus className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </section>
  );
};
