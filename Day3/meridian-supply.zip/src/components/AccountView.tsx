import React, { useState } from 'react';
import {
  Building2,
  ChevronDown,
  ChevronUp,
  Code2,
  Moon,
  ShieldCheck,
  Smartphone,
  Sun,
} from 'lucide-react';
import { formatCurrency } from '../utils/format';
import { PWAInstallButton } from './PWAInstallButton';

interface AccountViewProps {
  isDark: boolean;
  onToggleTheme: () => void;
  totalSpent: number;
}

export const AccountView: React.FC<AccountViewProps> = ({
  isDark,
  onToggleTheme,
  totalSpent,
}) => {
  const [showComposeRef, setShowComposeRef] = useState(false);

  const creditLimit = 50000;
  const currentBalance = 14200 + totalSpent;
  const availableCredit = Math.max(0, creditLimit - currentBalance);
  const utilizationPct = Math.min(100, Math.round((currentBalance / creditLimit) * 100));

  return (
    <section aria-label="Account & Device Settings" className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl dark:text-slate-50">
          Buyer Account
        </h1>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
          Commercial credit line, Android home screen installation, and display preferences.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
        {/* Commercial Account & Credit Line */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-slate-900 text-white dark:bg-slate-800">
                <Building2 className="h-5 w-5" />
              </div>
              <div>
                <h2 className="font-display text-base font-bold text-slate-900 dark:text-slate-100">
                  Apex Industrial Fabrication LLC
                </h2>
                <p className="font-mono text-xs text-slate-500 dark:text-slate-400">
                  ACCT-88412 · Net 30 Verified
                </p>
              </div>
            </div>
            <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700 dark:text-emerald-400">
              <ShieldCheck className="h-4 w-4" />
              Active
            </span>
          </div>

          <div className="mt-6 space-y-2">
            <div className="flex items-baseline justify-between text-sm">
              <span className="text-slate-600 dark:text-slate-400">
                Available Net-30 Credit
              </span>
              <span className="font-mono text-lg font-bold tabular-nums text-slate-900 dark:text-slate-50">
                {formatCurrency(availableCredit)}
              </span>
            </div>

            <div className="h-2.5 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
              <div
                className="h-full rounded-full bg-sky-700 transition-all duration-300 dark:bg-sky-400"
                style={{ width: `${utilizationPct}%` }}
              />
            </div>

            <div className="flex justify-between text-xs text-slate-500 dark:text-slate-400">
              <span className="font-mono tabular-nums">
                Used: {formatCurrency(currentBalance)} ({utilizationPct}%)
              </span>
              <span className="font-mono tabular-nums">
                Limit: {formatCurrency(creditLimit)}
              </span>
            </div>
          </div>
        </div>

        {/* Android PWA Installation */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300">
              <Smartphone className="h-5 w-5" />
            </div>
            <div>
              <h2 className="font-display text-base font-bold text-slate-900 dark:text-slate-100">
                Android Mobile App (PWA)
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Standalone launch, touch-first thumb navigation, and offline catalog cache.
              </p>
            </div>
          </div>

          <div className="mt-5">
            <PWAInstallButton variant="card" />
          </div>

          <p className="mt-3 text-xs leading-relaxed text-slate-500 dark:text-slate-400">
            Install directly onto Android Chrome or iOS Safari home screens for full-screen floor ordering without browser chrome.
          </p>
        </div>

        {/* Display Preferences */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-200">
                {isDark ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
              </div>
              <div>
                <h2 className="font-display text-base font-bold text-slate-900 dark:text-slate-100">
                  Warehouse Appearance
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {isDark ? 'Dark mode active for low-light bays' : 'High-contrast daylight theme active'}
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={onToggleTheme}
              aria-pressed={isDark}
              className="min-h-[44px] rounded-xl border border-slate-300 bg-slate-50 px-4 py-2 text-sm font-semibold text-slate-900 transition-colors hover:bg-slate-100 whitespace-nowrap shrink-0 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100 dark:hover:bg-slate-700"
            >
              {isDark ? 'Switch to Light' : 'Switch to Dark'}
            </button>
          </div>
        </div>

        {/* Jetpack Compose Architecture Reference */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <button
            type="button"
            onClick={() => setShowComposeRef((v) => !v)}
            aria-expanded={showComposeRef}
            className="flex min-h-[44px] w-full items-center justify-between gap-3 text-left"
          >
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-200">
                <Code2 className="h-5 w-5" />
              </div>
              <div>
                <h2 className="font-display text-base font-bold text-slate-900 dark:text-slate-100">
                  Android Compose Feature Map
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Package parity with com.meridiansupply.app.feature.catalog
                </p>
              </div>
            </div>
            {showComposeRef ? (
              <ChevronUp className="h-5 w-5 text-slate-500" />
            ) : (
              <ChevronDown className="h-5 w-5 text-slate-500" />
            )}
          </button>

          {showComposeRef && (
            <div className="mt-4 space-y-2 border-t border-slate-100 pt-4 font-mono text-xs text-slate-600 dark:border-slate-800 dark:text-slate-300">
              <div>CatalogScreen → Search, SortMenu, Category FilterChips, Shimmer, EmptyState</div>
              <div>CatalogProductCard → SKU, Unit/Bulk Price, Stock Indicator, Quick Add FAB</div>
              <div>ProductDetailSheetContent → ModalBottomSheet, Bulk Tier Comparison, Stepper</div>
              <div>Cart &amp; Orders → Persistent local PO drafts, Net-30 Terms, 1-Tap Reorder</div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};
