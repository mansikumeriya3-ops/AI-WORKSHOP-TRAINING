import React, { useState } from 'react';
import { Download, Smartphone, X } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface PWAInstallButtonProps {
  variant?: 'header' | 'card';
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({ variant = 'header' }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showGuide, setShowGuide] = useState(false);

  if (isInstalled) {
    if (variant === 'card') {
      return (
        <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-medium text-emerald-800 dark:border-emerald-900/60 dark:bg-emerald-950/40 dark:text-emerald-300">
          Installed on device — running in standalone app mode
        </div>
      );
    }
    return null;
  }

  const handleAction = async () => {
    if (isInstallable) {
      await install();
    } else {
      setShowGuide(true);
    }
  };

  if (variant === 'header' && !isInstallable && !isIOS) {
    return null;
  }

  return (
    <>
      <button
        type="button"
        onClick={handleAction}
        className={
          variant === 'header'
            ? 'inline-flex min-h-[40px] items-center gap-2 rounded-lg bg-slate-900 px-4 py-2 text-xs font-medium text-white transition-colors hover:bg-slate-800 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-900 whitespace-nowrap shrink-0 dark:bg-sky-500 dark:text-slate-950 dark:hover:bg-sky-400'
            : 'inline-flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl bg-amber-600 px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-amber-700 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-amber-600 whitespace-nowrap shrink-0 dark:bg-amber-500 dark:text-slate-950 dark:hover:bg-amber-400'
        }
      >
        {isInstallable ? (
          <>
            <Download className="h-4 w-4 shrink-0" />
            <span>Install Android App</span>
          </>
        ) : isIOS ? (
          <>
            <Smartphone className="h-4 w-4 shrink-0" />
            <span>Install on iOS</span>
          </>
        ) : (
          <>
            <Smartphone className="h-4 w-4 shrink-0" />
            <span>Android Install Guide</span>
          </>
        )}
      </button>

      {showGuide && (
        <div
          className="fixed inset-0 z-50 flex items-end justify-center bg-slate-950/50 p-0 backdrop-blur-sm sm:items-center sm:p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="install-guide-title"
        >
          <div className="w-full max-w-md rounded-t-3xl border border-slate-200 bg-white p-6 shadow-xl sm:rounded-2xl dark:border-slate-800 dark:bg-slate-900">
            <div className="mx-auto mb-4 h-1.5 w-10 rounded-full bg-slate-300 sm:hidden dark:bg-slate-700" />
            <div className="flex items-start justify-between gap-4">
              <h3
                id="install-guide-title"
                className="font-display text-lg font-bold text-slate-900 dark:text-slate-100"
              >
                {isIOS ? 'Install on iPhone or iPad' : 'Install Meridian Supply on Android'}
              </h3>
              <button
                type="button"
                onClick={() => setShowGuide(false)}
                aria-label="Close installation guide"
                className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-slate-100"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {isIOS ? (
              <ol className="mt-4 space-y-3 text-sm leading-relaxed text-slate-600 dark:text-slate-300">
                <li>1. Tap the Share button in the Safari browser toolbar.</li>
                <li>2. Scroll down and select Add to Home Screen.</li>
                <li>3. Confirm by tapping Add in the upper-right corner.</li>
              </ol>
            ) : (
              <ol className="mt-4 space-y-3 text-sm leading-relaxed text-slate-600 dark:text-slate-300">
                <li>1. Open this app in Google Chrome on your Android device.</li>
                <li>2. Tap the three-dot browser menu in the upper-right corner.</li>
                <li>3. Select Add to Home screen or Install app to launch Meridian Supply full-screen with offline catalog caching.</li>
              </ol>
            )}

            <button
              type="button"
              onClick={() => setShowGuide(false)}
              className="mt-6 min-h-[44px] w-full rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-slate-800 dark:bg-slate-100 dark:text-slate-900 dark:hover:bg-white"
            >
              Done
            </button>
          </div>
        </div>
      )}
    </>
  );
};
