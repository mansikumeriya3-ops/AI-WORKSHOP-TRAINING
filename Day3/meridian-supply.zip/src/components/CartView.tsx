import React, { useState } from 'react';
import {
  ArrowRight,
  Check,
  Minus,
  Plus,
  ShoppingBag,
  Trash2,
} from 'lucide-react';
import {
  DELIVERY_SITES,
  PAYMENT_TERMS_OPTIONS,
} from '../data/catalogData';
import { CartItem } from '../types/catalog';
import { formatCurrency } from '../utils/format';
import { ProductImage } from './ProductImage';

interface CartViewProps {
  items: CartItem[];
  onUpdateQty: (productId: string, qty: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
  onBrowseCatalog: () => void;
  onSubmitOrder: (details: {
    poNumber: string;
    siteName: string;
    paymentTerms: string;
    notes: string;
  }) => void;
}

export const CartView: React.FC<CartViewProps> = ({
  items,
  onUpdateQty,
  onRemoveItem,
  onClearCart,
  onBrowseCatalog,
  onSubmitOrder,
}) => {
  const [poNumber, setPoNumber] = useState(
    () => `PO-2026-${Math.floor(1000 + Math.random() * 8999)}`
  );
  const [siteName, setSiteName] = useState(DELIVERY_SITES[0]);
  const [paymentTerms, setPaymentTerms] = useState(PAYMENT_TERMS_OPTIONS[0]);
  const [notes, setNotes] = useState('');
  const [poError, setPoError] = useState('');

  const standardSubtotal = items.reduce(
    (sum, item) => sum + item.product.unitPrice * item.qty,
    0
  );
  const netSubtotal = items.reduce((sum, item) => {
    const rate =
      item.qty >= item.product.bulkMinQty
        ? item.product.bulkPrice
        : item.product.unitPrice;
    return sum + rate * item.qty;
  }, 0);
  const bulkSavings = standardSubtotal - netSubtotal;
  const freight = netSubtotal === 0 || netSubtotal >= 1500 ? 0 : 45;
  const total = netSubtotal + freight;
  const freeFreightGap = Math.max(0, 1500 - netSubtotal);

  const handleCheckout = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = poNumber.trim();
    if (!trimmed) {
      setPoError('Enter a Purchase Order number before submitting.');
      return;
    }
    setPoError('');
    onSubmitOrder({
      poNumber: trimmed,
      siteName,
      paymentTerms,
      notes: notes.trim(),
    });
  };

  if (items.length === 0) {
    return (
      <section aria-label="Purchase Order Cart" className="space-y-6">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl dark:text-slate-50">
            Purchase Order Cart
          </h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
            Add wholesale SKUs to calculate bulk tier pricing and submit a Purchase Order.
          </p>
        </div>

        <div className="flex flex-col items-center justify-center rounded-2xl border border-slate-200 bg-white px-6 py-16 text-center dark:border-slate-800 dark:bg-slate-900">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400">
            <ShoppingBag className="h-7 w-7" />
          </div>
          <h2 className="mt-4 font-display text-lg font-bold text-slate-900 dark:text-slate-100">
            Your PO draft is empty
          </h2>
          <p className="mt-1.5 max-w-sm text-sm text-slate-600 dark:text-slate-400">
            Browse stocked industrial fasteners, electrical fixtures, safety gear, and packaging supplies.
          </p>
          <button
            type="button"
            onClick={onBrowseCatalog}
            className="mt-6 inline-flex min-h-[44px] items-center gap-2 rounded-xl bg-slate-900 px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-slate-800 dark:bg-sky-500 dark:text-slate-950 dark:hover:bg-sky-400"
          >
            <span>Browse Wholesale Catalog</span>
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      </section>
    );
  }

  return (
    <section aria-label="Purchase Order Cart" className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl dark:text-slate-50">
            Purchase Order Cart
          </h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
            {items.reduce((acc, i) => acc + i.qty, 0)} total units across {items.length}{' '}
            {items.length === 1 ? 'SKU' : 'SKUs'}
          </p>
        </div>

        <button
          type="button"
          onClick={onClearCart}
          className="min-h-[44px] rounded-xl px-3.5 py-2 text-sm font-medium text-rose-700 transition-colors hover:bg-rose-50 dark:text-rose-400 dark:hover:bg-rose-950/40"
        >
          Clear Draft
        </button>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12 lg:items-start">
        {/* Line Items Column */}
        <div className="space-y-3 lg:col-span-7">
          {items.map(({ product, qty }) => {
            const isBulk = qty >= product.bulkMinQty;
            const unitRate = isBulk ? product.bulkPrice : product.unitPrice;
            const lineTotal = unitRate * qty;
            const lineSavings = isBulk
              ? (product.unitPrice - product.bulkPrice) * qty
              : 0;
            const toBulk = Math.max(0, product.bulkMinQty - qty);

            return (
              <div
                key={product.id}
                className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900"
              >
                <div className="flex gap-3.5">
                  <div className="h-20 w-20 shrink-0 overflow-hidden rounded-xl bg-slate-100 dark:bg-slate-800">
                    <ProductImage
                      src={product.imageUrl}
                      alt={product.name}
                      sku={product.sku}
                      className="h-full w-full"
                    />
                  </div>

                  <div className="min-w-0 flex-1">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <div className="font-mono text-xs text-slate-500 dark:text-slate-400">
                          {product.sku} · {product.unitLabel}
                        </div>
                        <h2 className="mt-0.5 font-display text-sm font-bold text-slate-900 sm:text-base dark:text-slate-100">
                          {product.name}
                        </h2>
                      </div>

                      <button
                        type="button"
                        onClick={() => onRemoveItem(product.id)}
                        aria-label={`Remove ${product.name}`}
                        className="flex min-h-[44px] min-w-[44px] -mt-2 -mr-2 shrink-0 items-center justify-center rounded-xl text-slate-400 transition-colors hover:bg-slate-100 hover:text-rose-600 dark:hover:bg-slate-800 dark:hover:text-rose-400"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>

                    {/* Bulk tier status */}
                    <div className="mt-1.5 text-xs">
                      {isBulk ? (
                        <span className="inline-flex items-center gap-1 font-semibold text-emerald-700 dark:text-emerald-400">
                          <Check className="h-3.5 w-3.5" />
                          Bulk tier active ({formatCurrency(unitRate)}/unit · Saved{' '}
                          {formatCurrency(lineSavings)})
                        </span>
                      ) : (
                        <div className="flex flex-wrap items-center gap-2 text-slate-600 dark:text-slate-400">
                          <span>
                            Add <strong className="font-mono tabular-nums">{toBulk}</strong> more for{' '}
                            <span className="font-mono font-semibold tabular-nums">
                              {formatCurrency(product.bulkPrice)}
                            </span>
                            /unit
                          </span>
                          {product.inStockQty >= product.bulkMinQty && (
                            <button
                              type="button"
                              onClick={() => onUpdateQty(product.id, product.bulkMinQty)}
                              className="font-semibold text-sky-700 underline-offset-2 hover:underline dark:text-sky-400"
                            >
                              Apply {product.bulkMinQty}x bulk
                            </button>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Stepper + Line Total */}
                    <div className="mt-3 flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 pt-3 dark:border-slate-800">
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => onUpdateQty(product.id, qty - 1)}
                          aria-label={`Decrease ${product.name} quantity`}
                          className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl border border-slate-300 text-slate-700 transition-colors hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
                        >
                          <Minus className="h-4 w-4" />
                        </button>
                        <span className="min-w-[2.75rem] text-center font-mono text-sm font-bold tabular-nums text-slate-900 dark:text-slate-100">
                          {qty}
                        </span>
                        <button
                          type="button"
                          onClick={() =>
                            onUpdateQty(
                              product.id,
                              Math.min(product.inStockQty, qty + 1)
                            )
                          }
                          disabled={qty >= product.inStockQty}
                          aria-label={`Increase ${product.name} quantity`}
                          className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl border border-slate-300 text-slate-700 transition-colors hover:bg-slate-100 disabled:opacity-40 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
                        >
                          <Plus className="h-4 w-4" />
                        </button>
                      </div>

                      <div className="text-right">
                        <div className="font-mono text-base font-bold tabular-nums text-slate-900 dark:text-slate-50">
                          {formatCurrency(lineTotal)}
                        </div>
                        <div className="font-mono text-[11px] tabular-nums text-slate-500 dark:text-slate-400">
                          {formatCurrency(unitRate)} / unit
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* PO Details & Summary Column */}
        <form
          onSubmit={handleCheckout}
          className="space-y-5 rounded-2xl border border-slate-200 bg-white p-5 lg:col-span-5 dark:border-slate-800 dark:bg-slate-900"
        >
          <h2 className="font-display text-lg font-bold text-slate-900 dark:text-slate-100">
            Purchase Order Details
          </h2>

          <div className="space-y-4">
            <div>
              <label
                htmlFor="po-number"
                className="block text-xs font-semibold text-slate-700 dark:text-slate-300"
              >
                PO Reference Number
              </label>
              <input
                id="po-number"
                type="text"
                value={poNumber}
                onChange={(e) => {
                  setPoNumber(e.target.value);
                  if (poError) setPoError('');
                }}
                className="mt-1.5 min-h-[44px] w-full rounded-xl border border-slate-300 bg-white px-3.5 font-mono text-sm text-slate-900 focus:border-sky-600 focus:outline-none focus:ring-2 focus:ring-sky-600/20 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
              {poError && (
                <p className="mt-1 text-xs font-medium text-rose-600 dark:text-rose-400">
                  {poError}
                </p>
              )}
            </div>

            <div>
              <label
                htmlFor="delivery-site"
                className="block text-xs font-semibold text-slate-700 dark:text-slate-300"
              >
                Receiving Facility / Jobsite
              </label>
              <select
                id="delivery-site"
                value={siteName}
                onChange={(e) => setSiteName(e.target.value)}
                className="mt-1.5 min-h-[44px] w-full rounded-xl border border-slate-300 bg-white px-3.5 text-sm text-slate-900 focus:border-sky-600 focus:outline-none focus:ring-2 focus:ring-sky-600/20 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              >
                {DELIVERY_SITES.map((site) => (
                  <option key={site} value={site}>
                    {site}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label
                htmlFor="payment-terms"
                className="block text-xs font-semibold text-slate-700 dark:text-slate-300"
              >
                Payment Terms
              </label>
              <select
                id="payment-terms"
                value={paymentTerms}
                onChange={(e) => setPaymentTerms(e.target.value)}
                className="mt-1.5 min-h-[44px] w-full rounded-xl border border-slate-300 bg-white px-3.5 text-sm text-slate-900 focus:border-sky-600 focus:outline-none focus:ring-2 focus:ring-sky-600/20 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              >
                {PAYMENT_TERMS_OPTIONS.map((term) => (
                  <option key={term} value={term}>
                    {term}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label
                htmlFor="receiving-notes"
                className="block text-xs font-semibold text-slate-700 dark:text-slate-300"
              >
                Dock &amp; Receiving Notes (Optional)
              </label>
              <textarea
                id="receiving-notes"
                rows={2}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Gate code, liftgate requirement, or dock hours..."
                className="mt-1.5 w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-sky-600 focus:outline-none focus:ring-2 focus:ring-sky-600/20 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100 dark:placeholder:text-slate-500"
              />
            </div>
          </div>

          <div className="space-y-2.5 border-t border-slate-200 pt-4 text-sm dark:border-slate-800">
            <div className="flex justify-between text-slate-600 dark:text-slate-400">
              <span>Standard Subtotal</span>
              <span className="font-mono tabular-nums">
                {formatCurrency(standardSubtotal)}
              </span>
            </div>

            {bulkSavings > 0 && (
              <div className="flex justify-between font-medium text-emerald-700 dark:text-emerald-400">
                <span>Bulk Tier Savings</span>
                <span className="font-mono tabular-nums">
                  -{formatCurrency(bulkSavings)}
                </span>
              </div>
            )}

            <div className="flex justify-between text-slate-600 dark:text-slate-400">
              <span>Pallet Freight</span>
              <span className="font-mono tabular-nums">
                {freight === 0 ? 'Free' : formatCurrency(freight)}
              </span>
            </div>

            {freeFreightGap > 0 && (
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Add{' '}
                <span className="font-mono font-semibold tabular-nums">
                  {formatCurrency(freeFreightGap)}
                </span>{' '}
                more to qualify for free commercial freight.
              </p>
            )}

            <div className="flex items-baseline justify-between border-t border-slate-200 pt-3 dark:border-slate-800">
              <span className="font-display text-base font-bold text-slate-900 dark:text-slate-50">
                Total PO Amount
              </span>
              <span className="font-mono text-xl font-bold tabular-nums text-slate-900 dark:text-slate-50">
                {formatCurrency(total)}
              </span>
            </div>
          </div>

          <button
            type="submit"
            className="min-h-[48px] w-full rounded-xl bg-amber-600 px-5 py-3 font-display text-sm font-bold text-white shadow-sm transition-transform hover:bg-amber-700 active:scale-[0.98] dark:bg-amber-500 dark:text-slate-950 dark:hover:bg-amber-400"
          >
            Submit Purchase Order · {formatCurrency(total)}
          </button>
        </form>
      </div>
    </section>
  );
};
