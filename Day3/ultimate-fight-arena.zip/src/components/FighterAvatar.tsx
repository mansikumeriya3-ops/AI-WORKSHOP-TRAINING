import React from 'react';
import { FighterProfile } from '../types/game';

interface FighterAvatarProps {
  fighter: FighterProfile;
  size?: number;
  mirrored?: boolean;
  className?: string;
}

export const FighterAvatar: React.FC<FighterAvatarProps> = ({
  fighter,
  size = 64,
  mirrored = false,
  className = '',
}) => {
  const { palette, gear, id } = fighter;

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      className={className}
      style={mirrored ? { transform: 'scaleX(-1)' } : undefined}
      aria-label={fighter.name}
    >
      <defs>
        <linearGradient id={`bg-${id}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor={palette.primary} stopOpacity="0.45" />
          <stop offset="100%" stopColor="#09090b" stopOpacity="0.95" />
        </linearGradient>
      </defs>
      <rect x="2" y="2" width="96" height="96" rx="14" fill={`url(#bg-${id})`} stroke={palette.accent} strokeOpacity="0.55" strokeWidth="2.5" />

      {/* Shoulders / Gi / Armor */}
      <path d="M16 96 C18 72, 34 66, 50 66 C66 66, 82 72, 84 96 Z" fill={palette.secondary} />
      <path d="M35 67 L50 88 L65 67" fill="none" stroke={palette.primary} strokeWidth="6" strokeLinejoin="round" />

      {/* Neck & Face */}
      <rect x="42" y="54" width="16" height="16" rx="4" fill={palette.skin} />
      <path d="M31 40 C31 24, 69 24, 69 40 C69 55, 60 63, 50 63 C40 63, 31 55, 31 40 Z" fill={palette.skin} />

      {/* Hair / Base Headwear */}
      {gear !== 'monk' && (
        <path d="M29 38 C28 19, 72 19, 71 38 C64 29, 55 28, 50 31 C44 28, 35 29, 29 38 Z" fill={palette.hair} />
      )}

      {/* Gear specifics */}
      {gear === 'headband' && (
        <>
          <rect x="29" y="29" width="42" height="7" rx="2" fill={palette.primary} />
          <path d="M70 31 L84 26 L80 35 Z" fill={palette.primary} />
        </>
      )}
      {gear === 'mask' && (
        <path d="M31 44 L69 44 C68 56, 60 64, 50 64 C40 64, 32 56, 31 44 Z" fill={palette.secondary} />
      )}
      {gear === 'horns' && (
        <>
          <path d="M32 30 L21 15 L37 25 Z" fill={palette.accent} />
          <path d="M68 30 L79 15 L63 25 Z" fill={palette.accent} />
        </>
      )}
      {gear === 'bandana' && (
        <path d="M30 29 C38 22, 62 22, 70 29 L68 36 L32 36 Z" fill={palette.accent} />
      )}
      {gear === 'visor' && (
        <rect x="33" y="36" width="34" height="9" rx="3" fill={palette.accent} opacity="0.92" />
      )}
      {gear === 'kabuto' && (
        <>
          <path d="M24 35 C27 16, 73 16, 76 35 Z" fill={palette.primary} />
          <path d="M40 22 L50 10 L60 22 L50 26 Z" fill={palette.accent} />
        </>
      )}
      {gear === 'monk' && (
        <>
          <circle cx="44" cy="28" r="2" fill={palette.accent} />
          <circle cx="50" cy="27" r="2" fill={palette.accent} />
          <circle cx="56" cy="28" r="2" fill={palette.accent} />
        </>
      )}
      {gear === 'crown' && (
        <path d="M30 30 L34 15 L44 24 L50 12 L56 24 L66 15 L70 30 Z" fill={palette.accent} />
      )}

      {/* Fierce Eyes (unless visor) */}
      {gear !== 'visor' && (
        <>
          <path d="M36 40 L45 42 L43 45 L37 44 Z" fill="#18181b" />
          <path d="M64 40 L55 42 L57 45 L63 44 Z" fill="#18181b" />
          <circle cx="41" cy="42.5" r="1.4" fill={palette.accent} />
          <circle cx="59" cy="42.5" r="1.4" fill={palette.accent} />
        </>
      )}

      {/* Mouth / Scar */}
      {gear !== 'mask' && (
        <path d="M44 53 L56 52" stroke="#523526" strokeWidth="2.2" strokeLinecap="round" />
      )}
    </svg>
  );
};
