import React, { useState } from 'react';
import { ArrowLeft, Globe, Keyboard, Music, Shield, Smartphone, Trash2, Volume2 } from 'lucide-react';
import { TranslationStrings } from '../data/i18n';
import { Difficulty, GameSettings, Language } from '../types/game';
import { soundEngine } from '../utils/audio';
import { PWAInstallButton } from './PWAInstallButton';

interface SettingsScreenProps {
  t: TranslationStrings;
  settings: GameSettings;
  onUpdateSettings: (next: Partial<GameSettings>) => void;
  onResetProgress: () => void;
  onBack: () => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  t,
  settings,
  onUpdateSettings,
  onResetProgress,
  onBack,
}) => {
  const [confirmReset, setConfirmReset] = useState(false);

  const difficulties: { id: Difficulty; label: string; desc: string }[] = [
    { id: 'easy', label: t.easy, desc: 'Relaxed CPU · +1.0x Rewards' },
    { id: 'normal', label: t.normal, desc: 'Balanced CPU · +1.25x Rewards' },
    { id: 'hard', label: t.hard, desc: 'Aggressive Combos · +1.5x Rewards' },
    { id: 'brutal', label: t.brutal, desc: 'Champion Reflexes · +2.0x Rewards' },
  ];

  const languages: { id: Language; label: string }[] = [
    { id: 'en', label: 'English' },
    { id: 'es', label: 'Español' },
    { id: 'ja', label: '日本語' },
    { id: 'hi', label: 'हिन्दी' },
  ];

  return (
    <div className="min-h-screen bg-[#09090b] text-zinc-100 flex flex-col">
      <header className="sticky top-0 z-30 bg-[#09090b]/90 backdrop-blur-md border-b border-white/10">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between">
          <button
            onClick={() => {
              soundEngine.playClick();
              onBack();
            }}
            className="min-h-[44px] px-2 -ml-2 flex items-center gap-2 text-sm font-semibold text-zinc-300 hover:text-white"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>{t.back}</span>
          </button>
          <h1 className="font-display text-2xl font-extrabold tracking-wide text-white">
            {t.settings}
          </h1>
          <div className="w-16" />
        </div>
      </header>

      <main className="flex-1 max-w-3xl w-full mx-auto px-4 sm:px-6 py-6 space-y-6">
        {/* Audio Controls */}
        <section className="rounded-2xl bg-[#141418] border border-white/10 divide-y divide-white/10">
          <div className="p-4 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <Volume2 className="w-5 h-5 text-red-400" />
              <div>
                <div className="text-sm font-semibold text-white">{t.soundFx}</div>
                <div className="text-xs text-zinc-400">Impact hits, blocks, bells, and special attacks</div>
              </div>
            </div>
            <button
              onClick={() => {
                onUpdateSettings({ soundEnabled: !settings.soundEnabled });
              }}
              className={`min-h-[44px] min-w-[76px] px-4 rounded-xl text-xs font-bold transition-colors ${
                settings.soundEnabled
                  ? 'bg-red-600 text-white'
                  : 'bg-zinc-800 text-zinc-400'
              }`}
            >
              {settings.soundEnabled ? 'ON' : 'OFF'}
            </button>
          </div>

          <div className="p-4 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <Music className="w-5 h-5 text-orange-400" />
              <div>
                <div className="text-sm font-semibold text-white">{t.music}</div>
                <div className="text-xs text-zinc-400">High-tempo arena synth soundtrack</div>
              </div>
            </div>
            <button
              onClick={() => {
                soundEngine.playClick();
                onUpdateSettings({ musicEnabled: !settings.musicEnabled });
              }}
              className={`min-h-[44px] min-w-[76px] px-4 rounded-xl text-xs font-bold transition-colors ${
                settings.musicEnabled
                  ? 'bg-orange-600 text-white'
                  : 'bg-zinc-800 text-zinc-400'
              }`}
            >
              {settings.musicEnabled ? 'ON' : 'OFF'}
            </button>
          </div>

          <div className="p-4 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <Smartphone className="w-5 h-5 text-amber-400" />
              <div>
                <div className="text-sm font-semibold text-white">On-Screen Touch Pad</div>
                <div className="text-xs text-zinc-400">Show Android touch buttons in the arena</div>
              </div>
            </div>
            <button
              onClick={() => {
                soundEngine.playClick();
                onUpdateSettings({ showTouchControls: !settings.showTouchControls });
              }}
              className={`min-h-[44px] min-w-[76px] px-4 rounded-xl text-xs font-bold transition-colors ${
                settings.showTouchControls
                  ? 'bg-red-600 text-white'
                  : 'bg-zinc-800 text-zinc-400'
              }`}
            >
              {settings.showTouchControls ? 'ON' : 'OFF'}
            </button>
          </div>
        </section>

        {/* Difficulty */}
        <section className="rounded-2xl bg-[#141418] border border-white/10 p-4 space-y-3">
          <div className="flex items-center gap-2 text-sm font-semibold text-white">
            <Shield className="w-4 h-4 text-red-400" />
            <span>{t.difficulty}</span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            {difficulties.map((d) => {
              const active = settings.difficulty === d.id;
              return (
                <button
                  key={d.id}
                  onClick={() => {
                    soundEngine.playClick();
                    onUpdateSettings({ difficulty: d.id });
                  }}
                  className={`min-h-[56px] p-3 rounded-xl border text-left transition-all ${
                    active
                      ? 'bg-red-600/20 border-red-500 text-white'
                      : 'bg-zinc-900 border-white/10 text-zinc-300 hover:border-white/25'
                  }`}
                >
                  <div className="text-sm font-bold">{d.label}</div>
                  <div className="text-[11px] text-zinc-400 mt-0.5">{d.desc}</div>
                </button>
              );
            })}
          </div>
        </section>

        {/* Language Selection */}
        <section className="rounded-2xl bg-[#141418] border border-white/10 p-4 space-y-3">
          <div className="flex items-center gap-2 text-sm font-semibold text-white">
            <Globe className="w-4 h-4 text-orange-400" />
            <span>{t.language}</span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            {languages.map((lang) => {
              const active = settings.language === lang.id;
              return (
                <button
                  key={lang.id}
                  onClick={() => {
                    soundEngine.playClick();
                    onUpdateSettings({ language: lang.id });
                  }}
                  className={`min-h-[44px] px-3 py-2 rounded-xl border text-sm font-semibold transition-all ${
                    active
                      ? 'bg-orange-600 border-orange-500 text-white'
                      : 'bg-zinc-900 border-white/10 text-zinc-300 hover:border-white/25'
                  }`}
                >
                  {lang.label}
                </button>
              );
            })}
          </div>
        </section>

        {/* Controls Reference */}
        <section className="rounded-2xl bg-[#141418] border border-white/10 p-4 space-y-2.5">
          <div className="flex items-center gap-2 text-sm font-semibold text-white">
            <Keyboard className="w-4 h-4 text-zinc-400" />
            <span>Controls Guide</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-zinc-300">
            <div className="rounded-xl bg-zinc-950 border border-white/10 p-3 space-y-1">
              <div className="font-bold text-red-400">Player 1 (Keyboard / Touch)</div>
              <div>Move: A / D · Jump: W · Block: S</div>
              <div>Punch: F · Kick: G · Special: H</div>
            </div>
            <div className="rounded-xl bg-zinc-950 border border-white/10 p-3 space-y-1">
              <div className="font-bold text-orange-400">Player 2 (2P Local Mode)</div>
              <div>Move: Left / Right · Jump: Up · Block: Down</div>
              <div>Punch: J · Kick: K · Special: L</div>
            </div>
          </div>
        </section>

        {/* Install & Reset */}
        <div className="flex flex-wrap items-center justify-between gap-4 pt-2">
          <PWAInstallButton label={t.installApp} />

          {!confirmReset ? (
            <button
              onClick={() => {
                soundEngine.playClick();
                setConfirmReset(true);
              }}
              className="min-h-[44px] px-4 py-2 rounded-xl bg-zinc-900 border border-white/10 text-xs font-semibold text-zinc-400 hover:text-red-400 hover:border-red-500/40 flex items-center gap-2"
            >
              <Trash2 className="w-4 h-4" />
              <span>{t.resetProgress}</span>
            </button>
          ) : (
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  onResetProgress();
                  setConfirmReset(false);
                }}
                className="min-h-[44px] px-4 py-2 rounded-xl bg-red-600 text-xs font-bold text-white hover:bg-red-500"
              >
                {t.confirmReset}
              </button>
              <button
                onClick={() => setConfirmReset(false)}
                className="min-h-[44px] px-4 py-2 rounded-xl bg-zinc-800 text-xs font-semibold text-zinc-200 hover:bg-zinc-700"
              >
                {t.cancel}
              </button>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};
