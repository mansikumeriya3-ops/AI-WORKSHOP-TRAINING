import React from 'react';
import {
  Flame,
  Gamepad2,
  Play,
  Settings,
  Swords,
  Trophy,
  Users,
} from 'lucide-react';
import { HOME_BACKDROP } from '../data/fighters';
import { TranslationStrings } from '../data/i18n';
import { FighterProfile, GameMode, PlayerProgress, ScreenRoute } from '../types/game';
import { soundEngine } from '../utils/audio';
import { FighterAvatar } from './FighterAvatar';
import { PWAInstallButton } from './PWAInstallButton';

interface HomeScreenProps {
  t: TranslationStrings;
  progress: PlayerProgress;
  activeFighter: FighterProfile;
  activeMode: GameMode;
  onNavigate: (route: ScreenRoute) => void;
  onQuickStart: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  t,
  progress,
  activeFighter,
  activeMode,
  onNavigate,
  onQuickStart,
}) => {
  const modeLabel = {
    single: t.modeSingle,
    pvc: t.modePvc,
    two_player: t.modeTwoPlayer,
    tournament: t.modeTournament,
    survival: t.modeSurvival,
  }[activeMode];

  const handleNav = (route: ScreenRoute) => {
    soundEngine.playClick();
    onNavigate(route);
  };

  return (
    <div className="relative min-h-screen w-full flex flex-col justify-between overflow-hidden bg-[#09090b]">
      {/* Background Art + Measured Contrast Scrim */}
      <div className="absolute inset-0 pointer-events-none">
        <img
          src={HOME_BACKDROP}
          alt="Ultimate Fight Arena Stadium"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover opacity-55"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#09090b]/85 via-[#09090b]/60 to-[#09090b]" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#09090b]/90 via-transparent to-[#09090b]/85" />
      </div>

      {/* Compact Top Bar */}
      <header className="relative z-10 w-full max-w-6xl mx-auto px-4 sm:px-8 pt-safe py-4 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-red-600 to-orange-500 flex items-center justify-center shadow-lg shadow-red-600/25 shrink-0">
            <Swords className="w-5 h-5 text-white" />
          </div>
          <span className="font-display text-2xl sm:text-3xl font-extrabold tracking-wide text-white whitespace-nowrap">
            {t.appName}
          </span>
        </div>

        <div className="flex items-center gap-3 sm:gap-5">
          <div className="hidden sm:flex items-center gap-3 text-sm text-zinc-300 font-mono-num">
            <span>{progress.coins} {t.coins}</span>
            <span className="text-zinc-600" aria-hidden="true">·</span>
            <span>{progress.totalWins} {t.wins}</span>
            <span className="text-zinc-600" aria-hidden="true">·</span>
            <span>{progress.unlockedFighters.length}/8 {t.fighters}</span>
          </div>
          <PWAInstallButton label={t.installApp} />
          <button
            onClick={() => handleNav('settings')}
            aria-label={t.settings}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl bg-zinc-900/90 border border-white/10 text-zinc-200 hover:bg-zinc-800 hover:border-orange-500/40 active:scale-[0.97] transition-all"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Main Hero & Menu Grid */}
      <main className="relative z-10 w-full max-w-6xl mx-auto px-4 sm:px-8 py-6 lg:py-10 flex-1 flex flex-col justify-center">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          {/* Left Column: Game Identity & Primary Launch */}
          <div className="lg:col-span-7 space-y-6">
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-xs sm:text-sm font-semibold tracking-wider text-orange-400">
                <Flame className="w-4 h-4" />
                <span>{t.tagline}</span>
                <span className="text-zinc-600" aria-hidden="true">·</span>
                <span className="text-zinc-300">{modeLabel}</span>
              </div>

              <h1 className="font-display text-5xl sm:text-7xl lg:text-8xl font-black tracking-tight leading-[0.95] text-white [text-wrap:balance]">
                ULTIMATE <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 via-orange-500 to-amber-400">FIGHT ARENA</span>
              </h1>

              <p className="text-sm sm:text-base text-zinc-300 max-w-xl leading-relaxed">
                Master 8 unique martial artists, chain devastating combos, unleash special energy attacks, and conquer arcade, tournament, and survival bouts.
              </p>
            </div>

            {/* Mobile Stats Line */}
            <div className="flex sm:hidden items-center gap-3 text-xs text-zinc-300 font-mono-num">
              <span>{progress.coins} {t.coins}</span>
              <span className="text-zinc-600" aria-hidden="true">·</span>
              <span>{progress.totalWins} {t.wins}</span>
              <span className="text-zinc-600" aria-hidden="true">·</span>
              <span>{progress.unlockedFighters.length}/8 {t.fighters}</span>
            </div>

            {/* Primary Action + Secondary Menu Grid */}
            <div className="space-y-3 pt-1 max-w-lg">
              <button
                onClick={() => {
                  soundEngine.playClick();
                  onQuickStart();
                }}
                className="w-full min-h-[56px] px-6 py-3.5 rounded-2xl bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-500 hover:to-orange-500 text-white font-display text-2xl sm:text-3xl font-extrabold tracking-wide flex items-center justify-center gap-3 shadow-xl shadow-red-600/25 active:scale-[0.98] transition-all"
              >
                <Play className="w-6 h-6 fill-current" />
                <span>{t.startGame}</span>
              </button>

              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => handleNav('fighters')}
                  className="min-h-[52px] px-4 py-3 rounded-xl bg-zinc-900/90 border border-white/10 hover:border-red-500/50 hover:bg-zinc-800/90 text-zinc-100 font-semibold text-sm flex items-center justify-center gap-2.5 active:scale-[0.98] transition-all whitespace-nowrap"
                >
                  <Users className="w-4 h-4 text-red-400 shrink-0" />
                  <span className="truncate">{t.selectFighter}</span>
                </button>

                <button
                  onClick={() => handleNav('modes')}
                  className="min-h-[52px] px-4 py-3 rounded-xl bg-zinc-900/90 border border-white/10 hover:border-orange-500/50 hover:bg-zinc-800/90 text-zinc-100 font-semibold text-sm flex items-center justify-center gap-2.5 active:scale-[0.98] transition-all whitespace-nowrap"
                >
                  <Gamepad2 className="w-4 h-4 text-orange-400 shrink-0" />
                  <span className="truncate">{t.gameModes}</span>
                </button>

                <button
                  onClick={() => handleNav('leaderboard')}
                  className="min-h-[52px] px-4 py-3 rounded-xl bg-zinc-900/90 border border-white/10 hover:border-orange-500/50 hover:bg-zinc-800/90 text-zinc-100 font-semibold text-sm flex items-center justify-center gap-2.5 active:scale-[0.98] transition-all whitespace-nowrap"
                >
                  <Trophy className="w-4 h-4 text-amber-400 shrink-0" />
                  <span className="truncate">{t.leaderboard}</span>
                </button>

                <button
                  onClick={() => handleNav('settings')}
                  className="min-h-[52px] px-4 py-3 rounded-xl bg-zinc-900/90 border border-white/10 hover:border-zinc-500/60 hover:bg-zinc-800/90 text-zinc-100 font-semibold text-sm flex items-center justify-center gap-2.5 active:scale-[0.98] transition-all whitespace-nowrap"
                >
                  <Settings className="w-4 h-4 text-zinc-400 shrink-0" />
                  <span className="truncate">{t.settings}</span>
                </button>
              </div>
            </div>
          </div>

          {/* Right Column: Active Fighter Spotlight Card */}
          <div className="lg:col-span-5">
            <div className="rounded-2xl bg-[#141418]/90 border border-white/10 p-5 sm:p-6 backdrop-blur-md">
              <div className="flex items-center justify-between text-xs text-zinc-400 mb-4">
                <span>Active Fighter</span>
                <button
                  onClick={() => handleNav('fighters')}
                  className="text-orange-400 hover:text-orange-300 font-semibold"
                >
                  Change Fighter
                </button>
              </div>

              <div className="flex items-center gap-4">
                <FighterAvatar fighter={activeFighter} size={84} className="shrink-0" />
                <div className="min-w-0">
                  <h2 className="font-display text-3xl font-extrabold text-white tracking-wide truncate">
                    {activeFighter.name}
                  </h2>
                  <p className="text-xs sm:text-sm text-orange-400 font-medium">
                    {activeFighter.title} · {activeFighter.style}
                  </p>
                  <p className="text-xs text-zinc-400 mt-1.5">
                    {t.specialMove}: <span className="text-zinc-200 font-medium">{activeFighter.specialName}</span>
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-4 gap-3 mt-5 pt-4 border-t border-white/10 text-center">
                <div>
                  <div className="text-[11px] text-zinc-400">{t.strength}</div>
                  <div className="font-mono-num text-base font-bold text-red-400">{activeFighter.stats.strength}</div>
                </div>
                <div>
                  <div className="text-[11px] text-zinc-400">{t.speed}</div>
                  <div className="font-mono-num text-base font-bold text-orange-400">{activeFighter.stats.speed}</div>
                </div>
                <div>
                  <div className="text-[11px] text-zinc-400">{t.health}</div>
                  <div className="font-mono-num text-base font-bold text-zinc-100">{activeFighter.maxHp}</div>
                </div>
                <div>
                  <div className="text-[11px] text-zinc-400">{t.skill}</div>
                  <div className="font-mono-num text-base font-bold text-amber-400">{activeFighter.stats.skill}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Quiet Footer */}
      <footer className="relative z-10 w-full max-w-6xl mx-auto px-4 sm:px-8 pb-safe py-3 flex items-center justify-between text-xs text-zinc-500">
        <span>Touch &amp; Keyboard Combat Ready</span>
        <span>Best Survival Wave: {progress.bestSurvivalWave}</span>
      </footer>
    </div>
  );
};
