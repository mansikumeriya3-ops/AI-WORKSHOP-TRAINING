import React from 'react';
import {
  ArrowLeft,
  Cpu,
  Flame,
  Play,
  ShieldAlert,
  Trophy,
  User,
  Users,
} from 'lucide-react';
import { FIGHTERS } from '../data/fighters';
import { TranslationStrings } from '../data/i18n';
import { GameMode, TournamentMatch } from '../types/game';
import { soundEngine } from '../utils/audio';
import { FighterAvatar } from './FighterAvatar';

interface GameModesScreenProps {
  t: TranslationStrings;
  activeMode: GameMode;
  tournamentBracket: TournamentMatch[];
  onBack: () => void;
  onSelectMode: (mode: GameMode) => void;
  onLaunchMode: (mode: GameMode) => void;
}

export const GameModesScreen: React.FC<GameModesScreenProps> = ({
  t,
  activeMode,
  tournamentBracket,
  onBack,
  onSelectMode,
  onLaunchMode,
}) => {
  const modes: {
    id: GameMode;
    title: string;
    desc: string;
    meta: string;
    icon: React.ReactNode;
  }[] = [
    {
      id: 'single',
      title: t.modeSingle,
      desc: t.modeSingleDesc,
      meta: '4-Stage Ladder · Best of 3',
      icon: <User className="w-6 h-6 text-red-400" />,
    },
    {
      id: 'pvc',
      title: t.modePvc,
      desc: t.modePvcDesc,
      meta: 'Custom 1v1 · Adjustable Difficulty',
      icon: <Cpu className="w-6 h-6 text-orange-400" />,
    },
    {
      id: 'two_player',
      title: t.modeTwoPlayer,
      desc: t.modeTwoPlayerDesc,
      meta: 'Local Versus · Dual Touch & Keyboard',
      icon: <Users className="w-6 h-6 text-amber-400" />,
    },
    {
      id: 'tournament',
      title: t.modeTournament,
      desc: t.modeTournamentDesc,
      meta: '8-Fighter Knockout Bracket',
      icon: <Trophy className="w-6 h-6 text-red-400" />,
    },
    {
      id: 'survival',
      title: t.modeSurvival,
      desc: t.modeSurvivalDesc,
      meta: 'Endless Gauntlet · HP Carryover',
      icon: <Flame className="w-6 h-6 text-orange-500" />,
    },
  ];

  const getFighter = (id: string | null) => FIGHTERS.find((f) => f.id === id) || null;

  return (
    <div className="min-h-screen bg-[#09090b] text-zinc-100 flex flex-col">
      <header className="sticky top-0 z-30 bg-[#09090b]/90 backdrop-blur-md border-b border-white/10">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between">
          <button
            onClick={() => {
              soundEngine.playClick();
              onBack();
            }}
            className="min-h-[44px] px-2 -ml-2 flex items-center gap-2 text-sm font-semibold text-zinc-300 hover:text-white"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>{t.back}</span>
          </button>
          <h1 className="font-display text-2xl font-extrabold tracking-wide text-white">
            {t.gameModes}
          </h1>
          <div className="w-16" />
        </div>
      </header>

      <main className="flex-1 max-w-6xl w-full mx-auto px-4 sm:px-6 py-6 space-y-8">
        {/* 5 Modes Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {modes.map((m) => {
            const selected = activeMode === m.id;
            return (
              <div
                key={m.id}
                onClick={() => {
                  soundEngine.playClick();
                  onSelectMode(m.id);
                }}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    onSelectMode(m.id);
                  }
                }}
                className={`rounded-2xl p-5 border transition-all cursor-pointer flex flex-col justify-between gap-4 ${
                  selected
                    ? 'bg-zinc-900 border-red-500 ring-2 ring-red-500/25'
                    : 'bg-[#141418] border-white/10 hover:border-white/25'
                }`}
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="w-11 h-11 rounded-xl bg-zinc-950 border border-white/10 flex items-center justify-center">
                      {m.icon}
                    </div>
                    <span className="text-xs text-zinc-400">{m.meta}</span>
                  </div>
                  <div>
                    <h2 className="font-display text-2xl font-extrabold text-white tracking-wide">
                      {m.title}
                    </h2>
                    <p className="text-xs text-zinc-400 mt-1 leading-relaxed">{m.desc}</p>
                  </div>
                </div>

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    soundEngine.playClick();
                    onLaunchMode(m.id);
                  }}
                  className={`min-h-[44px] w-full rounded-xl font-semibold text-sm flex items-center justify-center gap-2 transition-all ${
                    selected
                      ? 'bg-gradient-to-r from-red-600 to-orange-600 text-white hover:from-red-500 hover:to-orange-500'
                      : 'bg-zinc-800 text-zinc-100 hover:bg-zinc-700'
                  }`}
                >
                  <Play className="w-4 h-4 fill-current" />
                  <span>{t.startGame}</span>
                </button>
              </div>
            );
          })}
        </div>

        {/* Live 8-Fighter Tournament Bracket Preview when Tournament selected */}
        {activeMode === 'tournament' && tournamentBracket.length > 0 && (
          <section className="rounded-2xl bg-[#141418] border border-white/10 p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Trophy className="w-5 h-5 text-amber-400" />
                <h2 className="font-display text-2xl font-extrabold text-white tracking-wide">
                  Tournament Knockout Bracket
                </h2>
              </div>
              <span className="text-xs text-zinc-400">Quarterfinals · Semifinals · Grand Final</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {[1, 2, 3].map((roundNum) => {
                const roundMatches = tournamentBracket.filter((m) => m.round === roundNum);
                const roundTitle = roundNum === 1 ? 'Quarterfinals' : roundNum === 2 ? 'Semifinals' : 'Grand Final';
                return (
                  <div key={roundNum} className="space-y-2.5">
                    <div className="text-xs font-semibold text-orange-400">{roundTitle}</div>
                    {roundMatches.map((match) => {
                      const f1 = getFighter(match.p1Id);
                      const f2 = getFighter(match.p2Id);
                      return (
                        <div
                          key={match.id}
                          className="rounded-xl bg-zinc-950 border border-white/10 p-3 space-y-2"
                        >
                          {[f1, f2].map((f, idx) => (
                            <div
                              key={idx}
                              className={`flex items-center justify-between text-xs ${
                                f && match.winnerId === f.id ? 'text-amber-400 font-bold' : 'text-zinc-300'
                              }`}
                            >
                              <div className="flex items-center gap-2 min-w-0">
                                {f ? (
                                  <FighterAvatar fighter={f} size={24} />
                                ) : (
                                  <div className="w-6 h-6 rounded bg-zinc-800 flex items-center justify-center">
                                    <ShieldAlert className="w-3 h-3 text-zinc-600" />
                                  </div>
                                )}
                                <span className="truncate">{f ? f.name : 'TBD'}</span>
                              </div>
                              {f && match.winnerId === f.id && <span>WIN</span>}
                            </div>
                          ))}
                        </div>
                      );
                    })}
                  </div>
                );
              })}
            </div>
          </section>
        )}
      </main>
    </div>
  );
};
