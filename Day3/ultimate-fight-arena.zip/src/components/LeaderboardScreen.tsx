import React, { useState } from 'react';
import { ArrowLeft, Award, Flame, Swords, Trophy } from 'lucide-react';
import { FIGHTERS } from '../data/fighters';
import { TranslationStrings } from '../data/i18n';
import { GameMode, LeaderboardEntry, PlayerProgress } from '../types/game';
import { soundEngine } from '../utils/audio';
import { FighterAvatar } from './FighterAvatar';

interface LeaderboardScreenProps {
  t: TranslationStrings;
  entries: LeaderboardEntry[];
  progress: PlayerProgress;
  onBack: () => void;
}

export const LeaderboardScreen: React.FC<LeaderboardScreenProps> = ({
  t,
  entries,
  progress,
  onBack,
}) => {
  const [filter, setFilter] = useState<'all' | GameMode>('all');

  const filtered = filter === 'all' ? entries : entries.filter((e) => e.mode === filter);

  const modeTitle = (mode: GameMode) => {
    switch (mode) {
      case 'single':
        return 'Single Player';
      case 'pvc':
        return 'vs CPU';
      case 'two_player':
        return '2P Versus';
      case 'tournament':
        return 'Tournament';
      case 'survival':
        return 'Survival';
    }
  };

  return (
    <div className="min-h-screen bg-[#09090b] text-zinc-100 flex flex-col">
      <header className="sticky top-0 z-30 bg-[#09090b]/90 backdrop-blur-md border-b border-white/10">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between">
          <button
            onClick={() => {
              soundEngine.playClick();
              onBack();
            }}
            className="min-h-[44px] px-2 -ml-2 flex items-center gap-2 text-sm font-semibold text-zinc-300 hover:text-white"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>{t.back}</span>
          </button>
          <h1 className="font-display text-2xl font-extrabold tracking-wide text-white">
            {t.leaderboard}
          </h1>
          <div className="w-16" />
        </div>
      </header>

      <main className="flex-1 max-w-5xl w-full mx-auto px-4 sm:px-6 py-6 space-y-6">
        {/* Career Summary Strip */}
        <section className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="rounded-2xl bg-[#141418] border border-white/10 p-4">
            <div className="text-xs text-zinc-400 flex items-center gap-1.5">
              <Swords className="w-3.5 h-3.5 text-red-400" />
              <span>Total Wins</span>
            </div>
            <div className="font-mono-num text-2xl font-bold text-white mt-1">
              {progress.totalWins}
            </div>
          </div>

          <div className="rounded-2xl bg-[#141418] border border-white/10 p-4">
            <div className="text-xs text-zinc-400 flex items-center gap-1.5">
              <Flame className="w-3.5 h-3.5 text-orange-400" />
              <span>Best Survival</span>
            </div>
            <div className="font-mono-num text-2xl font-bold text-orange-400 mt-1">
              Wave {progress.bestSurvivalWave}
            </div>
          </div>

          <div className="rounded-2xl bg-[#141418] border border-white/10 p-4">
            <div className="text-xs text-zinc-400 flex items-center gap-1.5">
              <Trophy className="w-3.5 h-3.5 text-amber-400" />
              <span>Tournaments</span>
            </div>
            <div className="font-mono-num text-2xl font-bold text-amber-400 mt-1">
              {progress.tournamentChampionships}
            </div>
          </div>

          <div className="rounded-2xl bg-[#141418] border border-white/10 p-4">
            <div className="text-xs text-zinc-400 flex items-center gap-1.5">
              <Award className="w-3.5 h-3.5 text-rose-400" />
              <span>Total KOs</span>
            </div>
            <div className="font-mono-num text-2xl font-bold text-white mt-1">
              {progress.totalKOs}
            </div>
          </div>
        </section>

        {/* Interactive Mode Filter Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
          {(['all', 'single', 'pvc', 'tournament', 'survival', 'two_player'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => {
                soundEngine.playClick();
                setFilter(tab);
              }}
              className={`min-h-[40px] px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap shrink-0 transition-colors ${
                filter === tab
                  ? 'bg-red-600 text-white'
                  : 'bg-[#141418] text-zinc-400 border border-white/10 hover:text-white'
              }`}
            >
              {tab === 'all' ? 'All Modes' : modeTitle(tab)}
            </button>
          ))}
        </div>

        {/* Records Table */}
        {filtered.length === 0 ? (
          <div className="rounded-2xl bg-[#141418] border border-white/10 p-10 text-center space-y-2">
            <Trophy className="w-8 h-8 text-zinc-600 mx-auto" />
            <p className="text-sm text-zinc-400 max-w-md mx-auto">{t.noRecords}</p>
          </div>
        ) : (
          <div className="rounded-2xl bg-[#141418] border border-white/10 overflow-hidden">
            <div className="divide-y divide-white/10">
              {filtered.map((entry, idx) => {
                const fighter = FIGHTERS.find((f) => f.id === entry.fighterId) || FIGHTERS[0];
                return (
                  <div
                    key={entry.id}
                    className="px-4 py-3.5 flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <span
                        className={`font-mono-num text-sm font-bold w-6 text-center shrink-0 ${
                          idx === 0 ? 'text-amber-400' : idx === 1 ? 'text-zinc-300' : idx === 2 ? 'text-orange-400' : 'text-zinc-500'
                        }`}
                      >
                        #{idx + 1}
                      </span>
                      <FighterAvatar fighter={fighter} size={40} className="shrink-0" />
                      <div className="min-w-0">
                        <div className="text-sm font-bold text-white truncate">{entry.fighterName}</div>
                        <div className="text-xs text-zinc-400 truncate">
                          {modeTitle(entry.mode)} · {entry.difficulty} · {entry.won ? 'Victory' : 'Ended'}
                        </div>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <div className="font-mono-num text-base font-bold text-orange-400">
                        {entry.score.toLocaleString()}
                      </div>
                      <div className="font-mono-num text-[11px] text-zinc-500">
                        {entry.mode === 'survival' ? `Wave ${entry.wavesOrRounds}` : `${entry.wavesOrRounds} Stage`}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </main>
    </div>
  );
};
