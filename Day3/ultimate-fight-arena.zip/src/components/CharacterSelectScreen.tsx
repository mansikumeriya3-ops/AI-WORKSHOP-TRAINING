import React from 'react';
import { ArrowLeft, Check, Coins, Lock, Play, Shield, Sparkles, Swords } from 'lucide-react';
import { ARENA_STAGES, COMBAT_SKILLS, FIGHTERS } from '../data/fighters';
import { TranslationStrings } from '../data/i18n';
import { FighterProfile, GameMode, PlayerProgress, SkillId } from '../types/game';
import { soundEngine } from '../utils/audio';
import { FighterAvatar } from './FighterAvatar';

interface CharacterSelectScreenProps {
  t: TranslationStrings;
  progress: PlayerProgress;
  activeMode: GameMode;
  onBack: () => void;
  onSelectFighter: (id: string) => void;
  onUnlockFighter: (fighter: FighterProfile) => void;
  onSelectOpponent: (id: string) => void;
  onSelectStage: (id: string) => void;
  onUnlockSkill: (skillId: SkillId, cost: number) => void;
  onToggleSkill: (skillId: SkillId) => void;
  onStartFight: () => void;
}

export const CharacterSelectScreen: React.FC<CharacterSelectScreenProps> = ({
  t,
  progress,
  activeMode,
  onBack,
  onSelectFighter,
  onUnlockFighter,
  onSelectOpponent,
  onSelectStage,
  onUnlockSkill,
  onToggleSkill,
  onStartFight,
}) => {
  const selectedFighter = FIGHTERS.find((f) => f.id === progress.selectedFighterId) || FIGHTERS[0];
  const isUnlocked = progress.unlockedFighters.includes(selectedFighter.id);
  const canAfford = progress.coins >= selectedFighter.unlockCost;
  const needsOpponentPicker = activeMode === 'pvc' || activeMode === 'two_player';

  return (
    <div className="min-h-screen bg-[#09090b] text-zinc-100 flex flex-col">
      {/* Sticky Mobile Top App Bar */}
      <header className="sticky top-0 z-30 bg-[#09090b]/90 backdrop-blur-md border-b border-white/10">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-4">
          <button
            onClick={() => {
              soundEngine.playClick();
              onBack();
            }}
            className="min-h-[44px] px-2 -ml-2 flex items-center gap-2 text-sm font-semibold text-zinc-300 hover:text-white"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>{t.back}</span>
          </button>

          <h1 className="font-display text-2xl font-extrabold tracking-wide text-white truncate">
            {t.selectFighter}
          </h1>

          <div className="flex items-center gap-1.5 font-mono-num text-sm font-bold text-amber-400">
            <Coins className="w-4 h-4" />
            <span>{progress.coins}</span>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-6xl w-full mx-auto px-4 sm:px-6 py-5 pb-28 space-y-7">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Fighter Roster Grid (8 Characters) */}
          <section className="lg:col-span-7 space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-semibold text-zinc-300">{t.fighters} (8)</h2>
              <span className="text-xs text-zinc-500">Tap to inspect or select</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {FIGHTERS.map((fighter) => {
                const unlocked = progress.unlockedFighters.includes(fighter.id);
                const isSelected = progress.selectedFighterId === fighter.id;
                return (
                  <button
                    key={fighter.id}
                    onClick={() => {
                      soundEngine.playClick();
                      onSelectFighter(fighter.id);
                    }}
                    className={`relative rounded-2xl p-3 text-left transition-all border ${
                      isSelected
                        ? 'bg-zinc-900 border-red-500 ring-2 ring-red-500/30'
                        : 'bg-[#141418] border-white/10 hover:border-white/25'
                    }`}
                  >
                    <div className="flex justify-center mb-2.5 relative">
                      <FighterAvatar
                        fighter={fighter}
                        size={72}
                        className={!unlocked ? 'opacity-50 grayscale-[40%]' : ''}
                      />
                      {!unlocked && (
                        <div className="absolute inset-0 flex items-center justify-center">
                          <div className="w-8 h-8 rounded-full bg-black/80 border border-amber-500/50 flex items-center justify-center">
                            <Lock className="w-4 h-4 text-amber-400" />
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="font-display text-lg font-extrabold text-white leading-tight truncate">
                      {fighter.name}
                    </div>
                    <div className="text-[11px] text-zinc-400 truncate mt-0.5">
                      {unlocked ? fighter.title : `${fighter.unlockCost} ${t.coins}`}
                    </div>
                  </button>
                );
              })}
            </div>
          </section>

          {/* Selected Fighter Detail Inspector */}
          <section className="lg:col-span-5 rounded-2xl bg-[#141418] border border-white/10 p-5 space-y-5">
            <div className="flex items-start gap-4">
              <FighterAvatar fighter={selectedFighter} size={88} className="shrink-0" />
              <div className="min-w-0 flex-1">
                <div className="text-xs font-semibold text-orange-400">{selectedFighter.style}</div>
                <h2 className="font-display text-3xl font-black text-white leading-none mt-1">
                  {selectedFighter.name}
                </h2>
                <p className="text-xs text-zinc-400 mt-1">{selectedFighter.title}</p>

                {!isUnlocked && (
                  <button
                    onClick={() => {
                      soundEngine.playClick();
                      onUnlockFighter(selectedFighter);
                    }}
                    disabled={!canAfford}
                    className={`mt-3 min-h-[44px] px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all ${
                      canAfford
                        ? 'bg-amber-500 text-zinc-950 hover:bg-amber-400'
                        : 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
                    }`}
                  >
                    <Lock className="w-3.5 h-3.5" />
                    <span>{t.unlockFor} · {selectedFighter.unlockCost} {t.coins}</span>
                  </button>
                )}
              </div>
            </div>

            {/* Stat Bars */}
            <div className="space-y-2.5">
              {[
                { label: t.strength, val: selectedFighter.stats.strength, color: 'bg-red-500' },
                { label: t.speed, val: selectedFighter.stats.speed, color: 'bg-orange-500' },
                { label: `${t.health} (${selectedFighter.maxHp} HP)`, val: selectedFighter.stats.health, color: 'bg-amber-400' },
                { label: t.skill, val: selectedFighter.stats.skill, color: 'bg-rose-400' },
              ].map((stat) => (
                <div key={stat.label} className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-zinc-300">{stat.label}</span>
                    <span className="font-mono-num text-zinc-200 font-semibold">{stat.val}/100</span>
                  </div>
                  <div className="h-2 rounded-full bg-zinc-800 overflow-hidden">
                    <div
                      className={`h-full rounded-full ${stat.color} transition-all duration-300`}
                      style={{ width: `${stat.val}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>

            {/* Special Ability */}
            <div className="pt-3 border-t border-white/10">
              <div className="flex items-center gap-2 text-xs font-semibold text-orange-400">
                <Sparkles className="w-4 h-4" />
                <span>{t.specialMove}: {selectedFighter.specialName}</span>
              </div>
              <p className="text-xs text-zinc-400 mt-1 leading-relaxed">
                {selectedFighter.specialDesc}
              </p>
            </div>
          </section>
        </div>

        {/* Unlockable Combat Skills */}
        <section className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-zinc-200 flex items-center gap-2">
              <Shield className="w-4 h-4 text-orange-400" />
              <span>{t.combatSkills}</span>
            </h2>
            <span className="text-xs text-zinc-500">Applies to your fighter in combat</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {COMBAT_SKILLS.map((skill) => {
              const unlocked = progress.unlockedSkills.includes(skill.id);
              const equipped = progress.equippedSkills.includes(skill.id);
              const affordable = progress.coins >= skill.cost;

              return (
                <div
                  key={skill.id}
                  className="rounded-2xl bg-[#141418] border border-white/10 p-4 flex flex-col justify-between gap-3"
                >
                  <div>
                    <div className="flex items-center justify-between gap-2">
                      <h3 className="text-sm font-bold text-white">{skill.name}</h3>
                      <span className="text-xs font-mono-num text-orange-400">{skill.bonusLabel}</span>
                    </div>
                    <p className="text-xs text-zinc-400 mt-1 leading-relaxed">{skill.description}</p>
                  </div>

                  {unlocked ? (
                    <button
                      onClick={() => {
                        soundEngine.playClick();
                        onToggleSkill(skill.id);
                      }}
                      className={`min-h-[44px] w-full rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
                        equipped
                          ? 'bg-red-600 text-white'
                          : 'bg-zinc-800 text-zinc-200 hover:bg-zinc-700'
                      }`}
                    >
                      {equipped && <Check className="w-4 h-4" />}
                      <span>{equipped ? t.equipped : t.equip}</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => {
                        soundEngine.playClick();
                        onUnlockSkill(skill.id, skill.cost);
                      }}
                      disabled={!affordable}
                      className={`min-h-[44px] w-full rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                        affordable
                          ? 'bg-amber-500 text-zinc-950 hover:bg-amber-400'
                          : 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
                      }`}
                    >
                      <Lock className="w-3.5 h-3.5" />
                      <span>{t.unlockFor} · {skill.cost} {t.coins}</span>
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        </section>

        {/* Opponent Picker (when PvC or 2P) & Arena Stage Selector */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {needsOpponentPicker && (
            <section className="space-y-3">
              <h2 className="text-sm font-semibold text-zinc-200 flex items-center gap-2">
                <Swords className="w-4 h-4 text-red-400" />
                <span>{t.opponent} ({activeMode === 'two_player' ? 'Player 2' : 'CPU'})</span>
              </h2>
              <div className="grid grid-cols-4 gap-2">
                {FIGHTERS.map((f) => {
                  const active = progress.selectedOpponentId === f.id;
                  return (
                    <button
                      key={f.id}
                      onClick={() => {
                        soundEngine.playClick();
                        onSelectOpponent(f.id);
                      }}
                      className={`p-2 rounded-xl border text-center transition-all ${
                        active
                          ? 'bg-zinc-900 border-orange-500 ring-2 ring-orange-500/30'
                          : 'bg-[#141418] border-white/10 hover:border-white/25'
                      }`}
                    >
                      <div className="flex justify-center">
                        <FighterAvatar fighter={f} size={46} mirrored />
                      </div>
                      <div className="text-[11px] font-semibold text-zinc-200 truncate mt-1">
                        {f.name.split(' ')[0]}
                      </div>
                    </button>
                  );
                })}
              </div>
            </section>
          )}

          <section className={`space-y-3 ${!needsOpponentPicker ? 'lg:col-span-2' : ''}`}>
            <h2 className="text-sm font-semibold text-zinc-200">{t.arenaStage}</h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {ARENA_STAGES.map((stage) => {
                const active = progress.selectedStageId === stage.id;
                return (
                  <button
                    key={stage.id}
                    onClick={() => {
                      soundEngine.playClick();
                      onSelectStage(stage.id);
                    }}
                    className={`group relative rounded-2xl overflow-hidden border text-left transition-all ${
                      active
                        ? 'border-orange-500 ring-2 ring-orange-500/30'
                        : 'border-white/10 hover:border-white/25'
                    }`}
                  >
                    <div className="aspect-video w-full bg-zinc-900 overflow-hidden">
                      <img
                        src={stage.imagePath}
                        alt={stage.name}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                    <div className="p-3 bg-[#141418]">
                      <div className="text-xs font-bold text-white truncate">{stage.name}</div>
                      <div className="text-[11px] text-zinc-400 truncate">{stage.subtitle}</div>
                    </div>
                  </button>
                );
              })}
            </div>
          </section>
        </div>
      </main>

      {/* Sticky Bottom Fight CTA */}
      <div className="fixed bottom-0 left-0 right-0 z-30 p-4 pb-safe bg-gradient-to-t from-[#09090b] via-[#09090b]/95 to-transparent">
        <div className="max-w-6xl mx-auto flex items-center justify-between gap-4">
          <div className="hidden sm:block text-xs text-zinc-400">
            Selected: <span className="text-white font-semibold">{selectedFighter.name}</span>
          </div>
          <button
            onClick={() => {
              soundEngine.playClick();
              onStartFight();
            }}
            disabled={!isUnlocked}
            className={`w-full sm:w-auto sm:min-w-[260px] min-h-[48px] px-6 rounded-xl font-display text-2xl font-extrabold tracking-wide flex items-center justify-center gap-2 transition-all ${
              isUnlocked
                ? 'bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-500 hover:to-orange-500 text-white shadow-lg shadow-red-600/25 active:scale-[0.98]'
                : 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
            }`}
          >
            <Play className="w-5 h-5 fill-current" />
            <span>{isUnlocked ? t.enterArena : 'Unlock Fighter First'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
