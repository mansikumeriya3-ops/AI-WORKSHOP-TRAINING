import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  Coins,
  Flame,
  Hand,
  Pause,
  Play,
  RotateCcw,
  Shield,
  Sparkles,
  Trophy,
  Volume2,
  VolumeX,
  Zap,
} from 'lucide-react';
import { TranslationStrings } from '../data/i18n';
import { FightCanvas, HudSnapshot, MatchResult, PlayerInputState } from '../engine/FightCanvas';
import {
  ArenaStage,
  Difficulty,
  FighterProfile,
  GameMode,
  GameSettings,
  SkillId,
} from '../types/game';
import { soundEngine } from '../utils/audio';
import { FighterAvatar } from './FighterAvatar';

interface ArenaScreenProps {
  t: TranslationStrings;
  p1Profile: FighterProfile;
  p2Profile: FighterProfile;
  stage: ArenaStage;
  mode: GameMode;
  difficulty: Difficulty;
  settings: GameSettings;
  p1Skills: SkillId[];
  matchKey: number;
  stageLabel: string;
  initialP1Hp?: number;
  survivalWave?: number;
  hasNextBout: boolean;
  onToggleSound: () => void;
  onToggleMusic: () => void;
  onMatchFinished: (result: MatchResult) => { coinsEarned: number; isChampion?: boolean };
  onNextBout: () => void;
  onRestart: () => void;
  onQuit: () => void;
}

const emptyInput = (): PlayerInputState => ({
  left: false,
  right: false,
  jump: false,
  block: false,
  punch: false,
  kick: false,
  special: false,
});

export const ArenaScreen: React.FC<ArenaScreenProps> = ({
  t,
  p1Profile,
  p2Profile,
  stage,
  mode,
  difficulty,
  settings,
  p1Skills,
  matchKey,
  stageLabel,
  initialP1Hp,
  survivalWave = 1,
  hasNextBout,
  onToggleSound,
  onToggleMusic,
  onMatchFinished,
  onNextBout,
  onRestart,
  onQuit,
}) => {
  const [isPaused, setIsPaused] = useState(false);
  const [matchResult, setMatchResult] = useState<(MatchResult & { coinsEarned: number; isChampion?: boolean }) | null>(null);

  const [hud, setHud] = useState<HudSnapshot>({
    p1Hp: initialP1Hp ?? p1Profile.maxHp,
    p1MaxHp: p1Profile.maxHp,
    p1Energy: 35,
    p1Rounds: 0,
    p1Combo: 0,
    p2Hp: p2Profile.maxHp,
    p2MaxHp: p2Profile.maxHp,
    p2Energy: 35,
    p2Rounds: 0,
    p2Combo: 0,
    timer: 99,
    currentRound: 1,
    bannerText: mode === 'survival' ? `WAVE ${survivalWave}` : 'ROUND 1',
  });

  const inputRef = useRef<{ p1: PlayerInputState; p2: PlayerInputState }>({
    p1: emptyInput(),
    p2: emptyInput(),
  });

  // Reset result & inputs on new matchKey
  useEffect(() => {
    setMatchResult(null);
    setIsPaused(false);
    inputRef.current = { p1: emptyInput(), p2: emptyInput() };
  }, [matchKey]);

  // Start / stop arena music
  useEffect(() => {
    if (settings.musicEnabled && !isPaused && !matchResult) {
      soundEngine.startMusic();
    } else {
      soundEngine.stopMusic();
    }
    return () => {
      soundEngine.stopMusic();
    };
  }, [settings.musicEnabled, isPaused, matchResult]);

  // Keyboard bindings for P1 & P2
  useEffect(() => {
    const handleKey = (e: KeyboardEvent, down: boolean) => {
      if (e.key === 'Escape' && down && !matchResult) {
        setIsPaused((prev) => !prev);
        return;
      }

      const key = e.key.toLowerCase();
      const p1 = inputRef.current.p1;
      const p2 = inputRef.current.p2;

      // Player 1: WASD + F/G/H (+ Space for Jump, Arrows in 1P mode)
      if (key === 'a') p1.left = down;
      if (key === 'd') p1.right = down;
      if (key === 'w' || key === ' ') p1.jump = down;
      if (key === 's') p1.block = down;
      if (key === 'f') p1.punch = down;
      if (key === 'g') p1.kick = down;
      if (key === 'h' || key === 't') p1.special = down;

      if (mode !== 'two_player') {
        if (e.key === 'ArrowLeft') p1.left = down;
        if (e.key === 'ArrowRight') p1.right = down;
        if (e.key === 'ArrowUp') p1.jump = down;
        if (e.key === 'ArrowDown') p1.block = down;
      } else {
        // Player 2: Arrows + J/K/L
        if (e.key === 'ArrowLeft') p2.left = down;
        if (e.key === 'ArrowRight') p2.right = down;
        if (e.key === 'ArrowUp') p2.jump = down;
        if (e.key === 'ArrowDown') p2.block = down;
        if (key === 'j') p2.punch = down;
        if (key === 'k') p2.kick = down;
        if (key === 'l' || key === 'i') p2.special = down;
      }
    };

    const onDown = (e: KeyboardEvent) => handleKey(e, true);
    const onUp = (e: KeyboardEvent) => handleKey(e, false);
    window.addEventListener('keydown', onDown);
    window.addEventListener('keyup', onUp);
    return () => {
      window.removeEventListener('keydown', onDown);
      window.removeEventListener('keyup', onUp);
    };
  }, [mode, matchResult]);

  const setTouch = useCallback((player: 'p1' | 'p2', action: keyof PlayerInputState, pressed: boolean) => {
    inputRef.current[player][action] = pressed;
  }, []);

  const handleMatchEnd = useCallback(
    (res: MatchResult) => {
      const reward = onMatchFinished(res);
      setMatchResult({ ...res, ...reward });
    },
    [onMatchFinished]
  );

  const touchBtn = (
    player: 'p1' | 'p2',
    action: keyof PlayerInputState,
    label: string,
    icon: React.ReactNode,
    variant: 'move' | 'punch' | 'kick' | 'block' | 'special' = 'move',
    disabled = false
  ) => {
    const styles = {
      move: 'bg-zinc-900/90 border-white/15 text-zinc-100 active:bg-zinc-700',
      punch: 'bg-red-600/90 border-red-400/40 text-white active:bg-red-500',
      kick: 'bg-orange-600/90 border-orange-400/40 text-white active:bg-orange-500',
      block: 'bg-zinc-800/90 border-sky-400/40 text-sky-300 active:bg-zinc-700',
      special: disabled
        ? 'bg-zinc-900/60 border-white/10 text-zinc-500'
        : 'bg-gradient-to-br from-amber-500 to-red-600 border-amber-300 text-white shadow-lg shadow-orange-500/35 active:scale-95',
    }[variant];

    return (
      <button
        type="button"
        aria-label={label}
        onPointerDown={(e) => {
          e.preventDefault();
          setTouch(player, action, true);
        }}
        onPointerUp={(e) => {
          e.preventDefault();
          setTouch(player, action, false);
        }}
        onPointerLeave={() => setTouch(player, action, false)}
        onPointerCancel={() => setTouch(player, action, false)}
        className={`touch-none select-none min-h-[50px] min-w-[50px] rounded-2xl border flex flex-col items-center justify-center gap-0.5 transition-transform active:scale-95 ${styles}`}
      >
        {icon}
        <span className="text-[10px] font-bold tracking-tight">{label}</span>
      </button>
    );
  };

  const p1Pct = Math.max(0, Math.min(100, (hud.p1Hp / hud.p1MaxHp) * 100));
  const p2Pct = Math.max(0, Math.min(100, (hud.p2Hp / hud.p2MaxHp) * 100));

  return (
    <div className="min-h-screen bg-[#09090b] text-zinc-100 flex flex-col justify-between select-none">
      {/* Top Arena HUD */}
      <header className="w-full max-w-6xl mx-auto px-3 sm:px-6 pt-safe py-2.5 space-y-2">
        <div className="flex items-center justify-between gap-2 text-xs text-zinc-400">
          <span className="font-semibold text-orange-400 truncate">{stageLabel} · {stage.name}</span>
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => {
                soundEngine.playClick();
                onToggleSound();
              }}
              aria-label="Toggle Sound"
              className="min-h-[40px] min-w-[40px] rounded-lg bg-zinc-900 border border-white/10 flex items-center justify-center text-zinc-300 hover:text-white"
            >
              {settings.soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4 text-zinc-500" />}
            </button>
            <button
              onClick={() => {
                soundEngine.playClick();
                setIsPaused(true);
              }}
              aria-label={t.pause}
              className="min-h-[40px] px-3 rounded-lg bg-zinc-900 border border-white/10 flex items-center gap-1.5 text-xs font-semibold text-zinc-200 hover:bg-zinc-800"
            >
              <Pause className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{t.pause}</span>
            </button>
          </div>
        </div>

        {/* Fighters Health & Timer Row */}
        <div className="grid grid-cols-11 gap-2 sm:gap-4 items-center">
          {/* Player 1 Meter */}
          <div className="col-span-5 flex items-center gap-2.5">
            <FighterAvatar fighter={p1Profile} size={46} className="hidden sm:block shrink-0" />
            <div className="flex-1 min-w-0 space-y-1">
              <div className="flex items-center justify-between gap-1 text-xs">
                <span className="font-display text-base sm:text-lg font-extrabold text-white truncate">
                  {p1Profile.name}
                </span>
                <div className="flex items-center gap-1.5 shrink-0 font-mono-num">
                  <span className="text-[11px] text-zinc-300">{hud.p1Hp}/{hud.p1MaxHp}</span>
                  {mode !== 'survival' && (
                    <span className="text-red-500 text-xs">
                      {'●'.repeat(hud.p1Rounds)}{'○'.repeat(Math.max(0, 2 - hud.p1Rounds))}
                    </span>
                  )}
                </div>
              </div>
              <div className="h-3.5 rounded-md bg-zinc-900 border border-white/15 overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-red-600 to-orange-500 transition-all duration-150"
                  style={{ width: `${p1Pct}%` }}
                />
              </div>
              <div className="flex items-center gap-2">
                <div className="flex-1 h-1.5 rounded-full bg-zinc-900 overflow-hidden">
                  <div
                    className={`h-full transition-all duration-150 ${
                      hud.p1Energy >= 100 ? 'bg-amber-400' : 'bg-orange-500/80'
                    }`}
                    style={{ width: `${hud.p1Energy}%` }}
                  />
                </div>
                <span className="font-mono-num text-[10px] text-amber-400 font-bold">
                  {hud.p1Energy >= 100 ? 'SPECIAL' : `${hud.p1Energy}%`}
                </span>
              </div>
            </div>
          </div>

          {/* Center Countdown Clock */}
          <div className="col-span-1 flex flex-col items-center justify-center">
            <div className="w-11 h-11 sm:w-14 sm:h-14 rounded-xl bg-zinc-900 border border-orange-500/40 flex flex-col items-center justify-center shadow-lg">
              <span className="font-mono-num text-lg sm:text-2xl font-bold text-white leading-none">
                {hud.timer}
              </span>
              <span className="text-[9px] text-zinc-400 leading-none mt-0.5">
                {mode === 'survival' ? `W${survivalWave}` : `R${hud.currentRound}`}
              </span>
            </div>
          </div>

          {/* Player 2 Meter */}
          <div className="col-span-5 flex items-center gap-2.5 flex-row-reverse">
            <FighterAvatar fighter={p2Profile} size={46} mirrored className="hidden sm:block shrink-0" />
            <div className="flex-1 min-w-0 space-y-1">
              <div className="flex items-center justify-between gap-1 text-xs flex-row-reverse">
                <span className="font-display text-base sm:text-lg font-extrabold text-white truncate">
                  {p2Profile.name}
                </span>
                <div className="flex items-center gap-1.5 shrink-0 font-mono-num">
                  {mode !== 'survival' && (
                    <span className="text-orange-400 text-xs">
                      {'●'.repeat(hud.p2Rounds)}{'○'.repeat(Math.max(0, 2 - hud.p2Rounds))}
                    </span>
                  )}
                  <span className="text-[11px] text-zinc-300">{hud.p2Hp}/{hud.p2MaxHp}</span>
                </div>
              </div>
              <div className="h-3.5 rounded-md bg-zinc-900 border border-white/15 overflow-hidden flex justify-end">
                <div
                  className="h-full bg-gradient-to-l from-red-600 to-orange-500 transition-all duration-150"
                  style={{ width: `${p2Pct}%` }}
                />
              </div>
              <div className="flex items-center gap-2 flex-row-reverse">
                <div className="flex-1 h-1.5 rounded-full bg-zinc-900 overflow-hidden flex justify-end">
                  <div
                    className={`h-full transition-all duration-150 ${
                      hud.p2Energy >= 100 ? 'bg-amber-400' : 'bg-orange-500/80'
                    }`}
                    style={{ width: `${hud.p2Energy}%` }}
                  />
                </div>
                <span className="font-mono-num text-[10px] text-amber-400 font-bold">
                  {hud.p2Energy >= 100 ? 'SPECIAL' : `${hud.p2Energy}%`}
                </span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main 2D Fighting Stage */}
      <main className="relative flex-1 flex items-center justify-center px-2 sm:px-6 my-1">
        <div className="relative w-full max-w-5xl rounded-2xl overflow-hidden border border-white/15 bg-black shadow-2xl">
          <FightCanvas
            key={matchKey}
            p1Profile={p1Profile}
            p2Profile={p2Profile}
            stage={stage}
            mode={mode}
            difficulty={difficulty}
            p1Skills={p1Skills}
            initialP1Hp={initialP1Hp}
            survivalWave={survivalWave}
            isPaused={isPaused || !!matchResult}
            inputRef={inputRef}
            onHudUpdate={setHud}
            onMatchEnd={handleMatchEnd}
          />

          {/* Center Round / Fight / KO Callout */}
          {hud.bannerText && !matchResult && (
            <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
              <div className="font-display text-6xl sm:text-8xl font-black tracking-wider text-white drop-shadow-[0_6px_18px_rgba(220,38,38,0.9)]">
                {hud.bannerText}
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Bottom Ergonomic Touch Controls (Android Mobile & Tablet) */}
      {settings.showTouchControls && (
        <section className="w-full max-w-5xl mx-auto px-3 sm:px-6 pb-safe py-2">
          {mode !== 'two_player' ? (
            <div className="flex items-end justify-between gap-4">
              {/* Left Thumb Zone: Movement & Jump */}
              <div className="grid grid-cols-3 gap-2 w-[178px] sm:w-[210px]">
                <div />
                {touchBtn('p1', 'jump', t.jump, <ArrowUp className="w-5 h-5" />)}
                <div />
                {touchBtn('p1', 'left', 'Left', <ArrowLeft className="w-5 h-5" />)}
                {touchBtn('p1', 'block', t.block, <Shield className="w-5 h-5" />, 'block')}
                {touchBtn('p1', 'right', 'Right', <ArrowRight className="w-5 h-5" />)}
              </div>

              {/* Desktop Keyboard Hint */}
              <div className="hidden lg:flex flex-col items-center text-[11px] text-zinc-500 pb-2 text-center">
                <span>Move: A/D · Jump: W · Block: S</span>
                <span>Punch: F · Kick: G · Special: H</span>
              </div>

              {/* Right Thumb Zone: Attacks & Special */}
              <div className="grid grid-cols-2 gap-2 w-[156px] sm:w-[190px]">
                {touchBtn('p1', 'punch', t.punch, <Hand className="w-5 h-5" />, 'punch')}
                {touchBtn('p1', 'kick', t.kick, <Zap className="w-5 h-5" />, 'kick')}
                <div className="col-span-2">
                  {touchBtn(
                    'p1',
                    'special',
                    hud.p1Energy >= 100 ? `${t.special} READY!` : `${t.special} (${hud.p1Energy}%)`,
                    <Sparkles className="w-5 h-5" />,
                    'special',
                    hud.p1Energy < 100
                  )}
                </div>
              </div>
            </div>
          ) : (
            /* Dual Touch Controls for Local 2-Player Mode */
            <div className="grid grid-cols-2 gap-4">
              <div className="rounded-xl bg-zinc-950/90 border border-red-500/25 p-2 space-y-1.5">
                <div className="text-[10px] font-bold text-red-400 text-center">P1 (WASD + F/G/H)</div>
                <div className="grid grid-cols-4 gap-1.5">
                  {touchBtn('p1', 'left', 'L', <ArrowLeft className="w-4 h-4" />)}
                  {touchBtn('p1', 'right', 'R', <ArrowRight className="w-4 h-4" />)}
                  {touchBtn('p1', 'jump', 'JMP', <ArrowUp className="w-4 h-4" />)}
                  {touchBtn('p1', 'block', 'BLK', <Shield className="w-4 h-4" />, 'block')}
                  {touchBtn('p1', 'punch', 'PCH', <Hand className="w-4 h-4" />, 'punch')}
                  {touchBtn('p1', 'kick', 'KCK', <Zap className="w-4 h-4" />, 'kick')}
                  <div className="col-span-2">
                    {touchBtn('p1', 'special', `SPC ${hud.p1Energy}%`, <Flame className="w-4 h-4" />, 'special', hud.p1Energy < 100)}
                  </div>
                </div>
              </div>

              <div className="rounded-xl bg-zinc-950/90 border border-orange-500/25 p-2 space-y-1.5">
                <div className="text-[10px] font-bold text-orange-400 text-center">P2 (Arrows + J/K/L)</div>
                <div className="grid grid-cols-4 gap-1.5">
                  {touchBtn('p2', 'left', 'L', <ArrowLeft className="w-4 h-4" />)}
                  {touchBtn('p2', 'right', 'R', <ArrowRight className="w-4 h-4" />)}
                  {touchBtn('p2', 'jump', 'JMP', <ArrowUp className="w-4 h-4" />)}
                  {touchBtn('p2', 'block', 'BLK', <ArrowDown className="w-4 h-4" />, 'block')}
                  {touchBtn('p2', 'punch', 'PCH', <Hand className="w-4 h-4" />, 'punch')}
                  {touchBtn('p2', 'kick', 'KCK', <Zap className="w-4 h-4" />, 'kick')}
                  <div className="col-span-2">
                    {touchBtn('p2', 'special', `SPC ${hud.p2Energy}%`, <Flame className="w-4 h-4" />, 'special', hud.p2Energy < 100)}
                  </div>
                </div>
              </div>
            </div>
          )}
        </section>
      )}

      {/* Pause Modal */}
      {isPaused && !matchResult && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
          <div className="w-full max-w-sm rounded-2xl bg-[#141418] border border-white/10 p-6 space-y-4 shadow-2xl">
            <h2 className="font-display text-3xl font-black text-white text-center tracking-wide">
              {t.pause}
            </h2>

            <div className="rounded-xl bg-zinc-950 border border-white/10 p-3 text-xs text-zinc-300 space-y-1">
              <div className="font-bold text-orange-400">Combo Tip</div>
              <div>Tap Punch + Punch + Kick rapidly to chain a 3-Hit Finisher Combo!</div>
            </div>

            <div className="space-y-2.5">
              <button
                onClick={() => {
                  soundEngine.playClick();
                  setIsPaused(false);
                }}
                className="w-full min-h-[48px] rounded-xl bg-gradient-to-r from-red-600 to-orange-600 text-white font-bold text-sm flex items-center justify-center gap-2"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>{t.resume}</span>
              </button>

              <div className="grid grid-cols-2 gap-2.5">
                <button
                  onClick={onToggleSound}
                  className="min-h-[44px] rounded-xl bg-zinc-900 border border-white/10 text-xs font-semibold text-zinc-200"
                >
                  SFX: {settings.soundEnabled ? 'ON' : 'OFF'}
                </button>
                <button
                  onClick={onToggleMusic}
                  className="min-h-[44px] rounded-xl bg-zinc-900 border border-white/10 text-xs font-semibold text-zinc-200"
                >
                  Music: {settings.musicEnabled ? 'ON' : 'OFF'}
                </button>
              </div>

              <button
                onClick={() => {
                  soundEngine.playClick();
                  onRestart();
                }}
                className="w-full min-h-[44px] rounded-xl bg-zinc-800 text-zinc-100 font-semibold text-sm flex items-center justify-center gap-2 hover:bg-zinc-700"
              >
                <RotateCcw className="w-4 h-4" />
                <span>{t.restart}</span>
              </button>

              <button
                onClick={() => {
                  soundEngine.playClick();
                  onQuit();
                }}
                className="w-full min-h-[44px] rounded-xl bg-zinc-950 border border-white/10 text-zinc-400 font-semibold text-sm hover:text-white"
              >
                {t.quitToMenu}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Match Victory / Defeat Summary Modal */}
      {matchResult && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl bg-[#141418] border border-white/15 p-6 space-y-5 shadow-2xl text-center">
            <div className="space-y-1">
              {matchResult.isChampion && (
                <div className="flex items-center justify-center gap-2 text-amber-400 text-xs font-bold">
                  <Trophy className="w-4 h-4" />
                  <span>CHAMPIONSHIP BELT CLAIMED</span>
                </div>
              )}
              <h2
                className={`font-display text-5xl font-black tracking-wide ${
                  matchResult.winner === 'p1' ? 'text-orange-400' : 'text-red-500'
                }`}
              >
                {mode === 'two_player'
                  ? matchResult.winner === 'p1'
                    ? 'PLAYER 1 WINS'
                    : 'PLAYER 2 WINS'
                  : matchResult.winner === 'p1'
                    ? t.victory
                    : t.defeat}
              </h2>
              <p className="text-xs text-zinc-400">
                {matchResult.winner === 'p1' ? p1Profile.name : p2Profile.name} takes the bout
              </p>
            </div>

            <div className="grid grid-cols-3 gap-2.5 rounded-xl bg-zinc-950 border border-white/10 p-3.5">
              <div>
                <div className="text-[11px] text-zinc-400">Score</div>
                <div className="font-mono-num text-lg font-bold text-white">
                  {matchResult.score.toLocaleString()}
                </div>
              </div>
              <div>
                <div className="text-[11px] text-zinc-400">Max Combo</div>
                <div className="font-mono-num text-lg font-bold text-orange-400">
                  {matchResult.maxCombo} Hits
                </div>
              </div>
              <div>
                <div className="text-[11px] text-zinc-400">Earned</div>
                <div className="font-mono-num text-lg font-bold text-amber-400 flex items-center justify-center gap-1">
                  <Coins className="w-4 h-4" />+{matchResult.coinsEarned}
                </div>
              </div>
            </div>

            <div className="space-y-2.5">
              {hasNextBout && matchResult.winner === 'p1' ? (
                <button
                  onClick={() => {
                    soundEngine.playClick();
                    onNextBout();
                  }}
                  className="w-full min-h-[50px] rounded-xl bg-gradient-to-r from-red-600 to-orange-600 text-white font-display text-2xl font-extrabold tracking-wide flex items-center justify-center gap-2 hover:from-red-500 hover:to-orange-500"
                >
                  <Play className="w-5 h-5 fill-current" />
                  <span>{t.nextRound}</span>
                </button>
              ) : (
                <button
                  onClick={() => {
                    soundEngine.playClick();
                    onRestart();
                  }}
                  className="w-full min-h-[50px] rounded-xl bg-gradient-to-r from-red-600 to-orange-600 text-white font-display text-2xl font-extrabold tracking-wide flex items-center justify-center gap-2 hover:from-red-500 hover:to-orange-500"
                >
                  <RotateCcw className="w-5 h-5" />
                  <span>{t.playAgain}</span>
                </button>
              )}

              <button
                onClick={() => {
                  soundEngine.playClick();
                  onQuit();
                }}
                className="w-full min-h-[44px] rounded-xl bg-zinc-900 border border-white/10 text-zinc-300 font-semibold text-sm hover:text-white"
              >
                {t.quitToMenu}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
