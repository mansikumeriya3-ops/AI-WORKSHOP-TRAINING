import { Language } from '../types/game';

export interface TranslationStrings {
  appName: string;
  tagline: string;
  startGame: string;
  selectFighter: string;
  gameModes: string;
  leaderboard: string;
  settings: string;
  installApp: string;
  back: string;
  coins: string;
  wins: string;
  fighters: string;
  strength: string;
  speed: string;
  health: string;
  skill: string;
  specialMove: string;
  unlockFor: string;
  selected: string;
  select: string;
  opponent: string;
  arenaStage: string;
  combatSkills: string;
  equipped: string;
  equip: string;
  enterArena: string;
  soundFx: string;
  music: string;
  difficulty: string;
  language: string;
  easy: string;
  normal: string;
  hard: string;
  brutal: string;
  pause: string;
  resume: string;
  restart: string;
  quitToMenu: string;
  punch: string;
  kick: string;
  jump: string;
  block: string;
  special: string;
  round: string;
  fight: string;
  ko: string;
  victory: string;
  defeat: string;
  nextRound: string;
  playAgain: string;
  resetProgress: string;
  confirmReset: string;
  cancel: string;
  noRecords: string;
  modeSingle: string;
  modeSingleDesc: string;
  modePvc: string;
  modePvcDesc: string;
  modeTwoPlayer: string;
  modeTwoPlayerDesc: string;
  modeTournament: string;
  modeTournamentDesc: string;
  modeSurvival: string;
  modeSurvivalDesc: string;
}

export const TRANSLATIONS: Record<Language, TranslationStrings> = {
  en: {
    appName: 'Ultimate Fight Arena',
    tagline: '2D Championship Combat',
    startGame: 'Start Game',
    selectFighter: 'Select Fighter',
    gameModes: 'Game Modes',
    leaderboard: 'Leaderboard',
    settings: 'Settings',
    installApp: 'Install App',
    back: 'Back',
    coins: 'Coins',
    wins: 'Wins',
    fighters: 'Roster',
    strength: 'Strength',
    speed: 'Speed',
    health: 'Health',
    skill: 'Skill',
    specialMove: 'Special Ability',
    unlockFor: 'Unlock',
    selected: 'Selected',
    select: 'Select',
    opponent: 'Opponent',
    arenaStage: 'Arena Stage',
    combatSkills: 'Combat Skills',
    equipped: 'Equipped',
    equip: 'Equip',
    enterArena: 'Enter Arena',
    soundFx: 'Sound Effects',
    music: 'Arena Music',
    difficulty: 'Difficulty',
    language: 'Language',
    easy: 'Easy',
    normal: 'Normal',
    hard: 'Hard',
    brutal: 'Brutal',
    pause: 'Pause',
    resume: 'Resume',
    restart: 'Restart',
    quitToMenu: 'Main Menu',
    punch: 'Punch',
    kick: 'Kick',
    jump: 'Jump',
    block: 'Block',
    special: 'Special',
    round: 'Round',
    fight: 'FIGHT!',
    ko: 'K.O.!',
    victory: 'VICTORY',
    defeat: 'DEFEAT',
    nextRound: 'Next Bout',
    playAgain: 'Play Again',
    resetProgress: 'Reset Save Data',
    confirmReset: 'Confirm Reset',
    cancel: 'Cancel',
    noRecords: 'No battles recorded yet. Step into the arena to claim a spot.',
    modeSingle: 'Single Player Mode',
    modeSingleDesc: 'Battle 4 escalating arena challengers to win the Championship.',
    modePvc: 'Player vs Computer',
    modePvcDesc: 'Custom 1v1 showdown against any fighter at your chosen difficulty.',
    modeTwoPlayer: 'Two Player Mode',
    modeTwoPlayerDesc: 'Local head-to-head duel with dual touch controls or keyboard.',
    modeTournament: 'Tournament Mode',
    modeTournamentDesc: '8-fighter knockout bracket. Three straight wins crown the champion.',
    modeSurvival: 'Survival Mode',
    modeSurvivalDesc: 'Endless wave gauntlet with partial recovery. How long can you last?',
  },
  es: {
    appName: 'Ultimate Fight Arena',
    tagline: 'Combate 2D de Campeonato',
    startGame: 'Iniciar Juego',
    selectFighter: 'Elegir Luchador',
    gameModes: 'Modos de Juego',
    leaderboard: 'Clasificación',
    settings: 'Ajustes',
    installApp: 'Instalar App',
    back: 'Volver',
    coins: 'Monedas',
    wins: 'Victorias',
    fighters: 'Plantel',
    strength: 'Fuerza',
    speed: 'Velocidad',
    health: 'Salud',
    skill: 'Habilidad',
    specialMove: 'Ataque Especial',
    unlockFor: 'Desbloquear',
    selected: 'Elegido',
    select: 'Elegir',
    opponent: 'Oponente',
    arenaStage: 'Escenario',
    combatSkills: 'Habilidades',
    equipped: 'Equipado',
    equip: 'Equipar',
    enterArena: 'Entrar a la Arena',
    soundFx: 'Efectos de Sonido',
    music: 'Música de Arena',
    difficulty: 'Dificultad',
    language: 'Idioma',
    easy: 'Fácil',
    normal: 'Normal',
    hard: 'Difícil',
    brutal: 'Brutal',
    pause: 'Pausa',
    resume: 'Reanudar',
    restart: 'Reiniciar',
    quitToMenu: 'Menú Principal',
    punch: 'Puño',
    kick: 'Patada',
    jump: 'Saltar',
    block: 'Cubrir',
    special: 'Especial',
    round: 'Asalto',
    fight: '¡PELEA!',
    ko: '¡K.O.!',
    victory: 'VICTORIA',
    defeat: 'DERROTA',
    nextRound: 'Siguiente Combate',
    playAgain: 'Jugar de Nuevo',
    resetProgress: 'Reiniciar Progreso',
    confirmReset: 'Confirmar Reinicio',
    cancel: 'Cancelar',
    noRecords: 'Sin combates registrados. Entra en la arena para marcar un récord.',
    modeSingle: 'Modo Un Jugador',
    modeSingleDesc: 'Derrota a 4 rivales crecientes para ganar el Campeonato.',
    modePvc: 'Jugador vs Computadora',
    modePvcDesc: 'Duelo 1v1 personalizado contra cualquier luchador y dificultad.',
    modeTwoPlayer: 'Modo Dos Jugadores',
    modeTwoPlayerDesc: 'Duelo local cara a cara con controles táctiles dobles o teclado.',
    modeTournament: 'Modo Torneo',
    modeTournamentDesc: 'Llave eliminatoria de 8 luchadores. Tres victorias para ser campeón.',
    modeSurvival: 'Modo Supervivencia',
    modeSurvivalDesc: 'Oleadas infinitas con recuperación parcial. ¿Cuánto resistirás?',
  },
  ja: {
    appName: 'Ultimate Fight Arena',
    tagline: '2D格闘チャンピオンシップ',
    startGame: 'ゲーム開始',
    selectFighter: 'ファイター選択',
    gameModes: 'ゲームモード',
    leaderboard: 'ランキング',
    settings: '設定',
    installApp: 'アプリ導入',
    back: '戻る',
    coins: 'コイン',
    wins: '勝利',
    fighters: 'ファイター',
    strength: '攻撃力',
    speed: 'スピード',
    health: '体力',
    skill: '技術',
    specialMove: '必殺技',
    unlockFor: '解放する',
    selected: '選択中',
    select: '選択',
    opponent: '対戦相手',
    arenaStage: 'ステージ',
    combatSkills: 'バトルスキル',
    equipped: '装備中',
    equip: '装備',
    enterArena: 'アリーナへ',
    soundFx: '効果音',
    music: 'BGM',
    difficulty: '難易度',
    language: '言語',
    easy: 'イージー',
    normal: 'ノーマル',
    hard: 'ハード',
    brutal: 'ブルータル',
    pause: '一時停止',
    resume: '再開',
    restart: 'やり直す',
    quitToMenu: 'メインメニュー',
    punch: 'パンチ',
    kick: 'キック',
    jump: 'ジャンプ',
    block: 'ガード',
    special: '必殺技',
    round: 'ラウンド',
    fight: 'FIGHT!',
    ko: 'K.O.!',
    victory: '勝利',
    defeat: '敗北',
    nextRound: '次の対戦',
    playAgain: 'もう一度',
    resetProgress: 'セーブ初期化',
    confirmReset: '初期化を確認',
    cancel: 'キャンセル',
    noRecords: 'まだ記録がありません。アリーナで勝利を掴もう。',
    modeSingle: 'シングルプレイヤー',
    modeSingleDesc: '4人の強敵を打ち破りチャンピオンベルトを勝ち取れ。',
    modePvc: 'プレイヤー vs CPU',
    modePvcDesc: '好きな相手と難易度を選んで1対1のカスタム対戦。',
    modeTwoPlayer: '2プレイヤー対戦',
    modeTwoPlayerDesc: '画面分割タッチ操作またはキーボードでのローカル対戦。',
    modeTournament: 'トーナメント',
    modeTournamentDesc: '8人勝ち抜き戦。3連勝で王者に輝け。',
    modeSurvival: 'サバイバル',
    modeSurvivalDesc: '連戦サバイバルバトル。何人抜きできるか挑戦しよう。',
  },
  hi: {
    appName: 'Ultimate Fight Arena',
    tagline: '2D चैंपियनशिप मुकाबला',
    startGame: 'गेम शुरू करें',
    selectFighter: 'फाइटर चुनें',
    gameModes: 'गेम मोड',
    leaderboard: 'लीडरबोर्ड',
    settings: 'सेटिंग्स',
    installApp: 'ऐप इंस्टॉल करें',
    back: 'वापस',
    coins: 'सिक्के',
    wins: 'जीत',
    fighters: 'फाइटर्स',
    strength: 'ताकत',
    speed: 'रफ्तार',
    health: 'सेहत',
    skill: 'कौशल',
    specialMove: 'स्पेशल हमला',
    unlockFor: 'अनलॉक',
    selected: 'चुना गया',
    select: 'चुनें',
    opponent: 'प्रतिद्वंद्वी',
    arenaStage: 'अखाड़ा',
    combatSkills: 'युद्ध कौशल',
    equipped: 'लैस',
    equip: 'चुनें',
    enterArena: 'मुकाबला शुरू',
    soundFx: 'साउंड इफेक्ट्स',
    music: 'म्यूजिक',
    difficulty: 'कठिनाई',
    language: 'भाषा',
    easy: 'आसान',
    normal: 'सामान्य',
    hard: 'कठिन',
    brutal: 'क्रूर',
    pause: 'रोकें',
    resume: 'जारी रखें',
    restart: 'फिर से शुरू',
    quitToMenu: 'मुख्य मेनू',
    punch: 'पंच',
    kick: 'किक',
    jump: 'कूदें',
    block: 'ब्लॉक',
    special: 'स्पेशल',
    round: 'राउंड',
    fight: 'लड़ो!',
    ko: 'नॉकआउट!',
    victory: 'जीत',
    defeat: 'हार',
    nextRound: 'अगला मैच',
    playAgain: 'फिर खेलें',
    resetProgress: 'डेटा रीसेट करें',
    confirmReset: 'रीसेट की पुष्टि',
    cancel: 'रद्द करें',
    noRecords: 'अभी तक कोई रिकॉर्ड नहीं। लीडरबोर्ड में आने के लिए मैच खेलें।',
    modeSingle: 'सिंगल प्लेयर मोड',
    modeSingleDesc: 'चैंपियनशिप जीतने के लिए 4 दमदार विरोधियों को हराएं।',
    modePvc: 'प्लेयर बनाम कंप्यूटर',
    modePvcDesc: 'अपनी पसंद के फाइटर और कठिनाई स्तर के साथ 1v1 मुकाबला।',
    modeTwoPlayer: 'टू प्लेयर मोड',
    modeTwoPlayerDesc: 'डुअल टच कंट्रोल या कीबोर्ड से आमने-सामने लोकल फाइट।',
    modeTournament: 'टूर्नामेंट मोड',
    modeTournamentDesc: '8-फाइटर नॉकआउट ब्रैकेट। लगातार 3 जीत से चैंपियन बनें।',
    modeSurvival: 'सर्वाइवल मोड',
    modeSurvivalDesc: 'बिना रुके लगातार फाइट। देखें आप कितनी लहरों तक टिकते हैं।',
  },
};
