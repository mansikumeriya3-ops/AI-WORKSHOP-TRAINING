import { useCallback, useEffect, useMemo, useState } from 'react';
import { ArenaScreen } from './components/ArenaScreen';
import { CharacterSelectScreen } from './components/CharacterSelectScreen';
import { GameModesScreen } from './components/GameModesScreen';
import { HomeScreen } from './components/HomeScreen';
import { LeaderboardScreen } from './components/LeaderboardScreen';
import { OfflineIndicator } from './components/PWAInstallButton';
import { SettingsScreen } from './components/SettingsScreen';
import { ARENA_STAGES, FIGHTERS } from './data/fighters';
import { TRANSLATIONS } from './data/i18n';
import { MatchResult } from './engine/FightCanvas';
import {
  FighterProfile,
  GameMode,
  GameSettings,
  LeaderboardEntry,
  PlayerProgress,
  ScreenRoute,
  SkillId,
  TournamentMatch,
} from './types/game';
import { soundEngine } from './utils/audio';
import {
  DEFAULT_PROGRESS,
  loadLeaderboard,
  loadProgress,
  loadSettings,
  recordLeaderboardEntry,
  resetAllData,
  saveProgress,
  saveSettings,
} from './utils/storage';

function buildTournamentBracket(playerId: string): TournamentMatch[] {
  const others = FIGHTERS.filter((f) => f.id !== playerId)
    .sort(() => Math.random() - 0.5)
    .map((f) => f.id);
  const seeded = [playerId, ...others.slice(0, 7)];

  return [
    { id: 'qf1', round: 1, p1Id: seeded[0], p2Id: seeded[1], winnerId: null },
    { id: 'qf2', round: 1, p1Id: seeded[2], p2Id: seeded[3], winnerId: null },
    { id: 'qf3', round: 1, p1Id: seeded[4], p2Id: seeded[5], winnerId: null },
    { id: 'qf4', round: 1, p1Id: seeded[6], p2Id: seeded[7], winnerId: null },
    { id: 'sf1', round: 2, p1Id: null, p2Id: null, winnerId: null },
    { id: 'sf2', round: 2, p1Id: null, p2Id: null, winnerId: null },
    { id: 'final', round: 3, p1Id: null, p2Id: null, winnerId: null },
  ];
}

export default function App() {
  const [route, setRoute] = useState<ScreenRoute>('home');
  const [progress, setProgress] = useState<PlayerProgress>(() => loadProgress());
  const [settings, setSettings] = useState<GameSettings>(() => loadSettings());
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>(() => loadLeaderboard());
  const [activeMode, setActiveMode] = useState<GameMode>('single');

  // Progression state for multi-bout modes
  const [matchKey, setMatchKey] = useState(1);
  const [arcadeStageIdx, setArcadeStageIdx] = useState(0);
  const [arcadeOpponents, setArcadeOpponents] = useState<string[]>(['vex', 'maya', 'raiden', 'abyss']);
  const [survivalWave, setSurvivalWave] = useState(1);
  const [survivalHp, setSurvivalHp] = useState<number | undefined>(undefined);
  const [survivalScore, setSurvivalScore] = useState(0);
  const [tournamentBracket, setTournamentBracket] = useState<TournamentMatch[]>(() =>
    buildTournamentBracket(loadProgress().selectedFighterId)
  );
  const [tournamentRound, setTournamentRound] = useState<1 | 2 | 3>(1);

  const t = TRANSLATIONS[settings.language];

  useEffect(() => {
    soundEngine.setSettings(settings.soundEnabled, settings.musicEnabled);
  }, [settings.soundEnabled, settings.musicEnabled]);

  const updateProgress = useCallback((updater: (prev: PlayerProgress) => PlayerProgress) => {
    setProgress((prev) => {
      const next = updater(prev);
      saveProgress(next);
      return next;
    });
  }, []);

  const updateSettings = useCallback((patch: Partial<GameSettings>) => {
    setSettings((prev) => {
      const next = { ...prev, ...patch };
      saveSettings(next);
      return next;
    });
  }, []);

  const activeFighter = useMemo(
    () => FIGHTERS.find((f) => f.id === progress.selectedFighterId) || FIGHTERS[0],
    [progress.selectedFighterId]
  );

  const activeStage = useMemo(() => {
    if (activeMode === 'single') {
      return ARENA_STAGES[arcadeStageIdx % ARENA_STAGES.length];
    }
    if (activeMode === 'survival') {
      return ARENA_STAGES[(survivalWave - 1) % ARENA_STAGES.length];
    }
    if (activeMode === 'tournament') {
      return ARENA_STAGES[(tournamentRound - 1) % ARENA_STAGES.length];
    }
    return ARENA_STAGES.find((s) => s.id === progress.selectedStageId) || ARENA_STAGES[0];
  }, [activeMode, arcadeStageIdx, survivalWave, tournamentRound, progress.selectedStageId]);

  const currentOpponent = useMemo(() => {
    if (activeMode === 'single') {
      const id = arcadeOpponents[arcadeStageIdx] || 'abyss';
      return FIGHTERS.find((f) => f.id === id) || FIGHTERS[7];
    }
    if (activeMode === 'survival') {
      const pool = FIGHTERS.filter((f) => f.id !== activeFighter.id);
      return pool[(survivalWave - 1) % pool.length];
    }
    if (activeMode === 'tournament') {
      const playerMatch = tournamentBracket.find(
        (m) => m.round === tournamentRound && (m.p1Id === activeFighter.id || m.p2Id === activeFighter.id)
      );
      const oppId = playerMatch
        ? playerMatch.p1Id === activeFighter.id
          ? playerMatch.p2Id
          : playerMatch.p1Id
        : 'vex';
      return FIGHTERS.find((f) => f.id === oppId) || FIGHTERS[1];
    }
    return FIGHTERS.find((f) => f.id === progress.selectedOpponentId) || FIGHTERS[1];
  }, [activeMode, arcadeOpponents, arcadeStageIdx, activeFighter.id, survivalWave, tournamentBracket, tournamentRound, progress.selectedOpponentId]);

  const startModeMatch = useCallback(
    (modeToLaunch: GameMode) => {
      setActiveMode(modeToLaunch);
      if (modeToLaunch === 'single') {
        const ladder = FIGHTERS.filter((f) => f.id !== progress.selectedFighterId && f.id !== 'abyss')
          .sort(() => Math.random() - 0.5)
          .slice(0, 3)
          .map((f) => f.id);
        setArcadeOpponents([...ladder, 'abyss']);
        setArcadeStageIdx(0);
      } else if (modeToLaunch === 'survival') {
        setSurvivalWave(1);
        setSurvivalHp(undefined);
        setSurvivalScore(0);
      } else if (modeToLaunch === 'tournament') {
        setTournamentBracket(buildTournamentBracket(progress.selectedFighterId));
        setTournamentRound(1);
      }
      setMatchKey((k) => k + 1);
      setRoute('arena');
    },
    [progress.selectedFighterId]
  );

  const handleMatchFinished = useCallback(
    (result: MatchResult): { coinsEarned: number; isChampion?: boolean } => {
      const diffMult = { easy: 1, normal: 1.25, hard: 1.5, brutal: 2 }[settings.difficulty];
      const baseCoins = result.winner === 'p1' ? 60 : 15;
      let isChampion = false;

      if (activeMode === 'single' && result.winner === 'p1' && arcadeStageIdx === 3) {
        isChampion = true;
      }
      if (activeMode === 'tournament' && result.winner === 'p1' && tournamentRound === 3) {
        isChampion = true;
      }

      const bonusCoins = isChampion ? 150 : 0;
      const coinsEarned = Math.round(baseCoins * diffMult) + bonusCoins;

      updateProgress((prev) => ({
        ...prev,
        coins: prev.coins + coinsEarned,
        totalMatches: prev.totalMatches + 1,
        totalWins: prev.totalWins + (result.winner === 'p1' ? 1 : 0),
        totalKOs: prev.totalKOs + result.kos,
        bestSurvivalWave:
          activeMode === 'survival'
            ? Math.max(prev.bestSurvivalWave, result.winner === 'p1' ? survivalWave : survivalWave - 1)
            : prev.bestSurvivalWave,
        tournamentChampionships:
          activeMode === 'tournament' && isChampion
            ? prev.tournamentChampionships + 1
            : prev.tournamentChampionships,
      }));

      // Advance bracket or record leaderboard
      if (activeMode === 'tournament' && result.winner === 'p1') {
        setTournamentBracket((prev) => {
          const next = prev.map((m) => ({ ...m }));
          if (tournamentRound === 1) {
            const qfMatches = next.filter((m) => m.round === 1);
            qfMatches.forEach((m) => {
              if (m.p1Id === activeFighter.id || m.p2Id === activeFighter.id) {
                m.winnerId = activeFighter.id;
              } else if (!m.winnerId) {
                m.winnerId = Math.random() < 0.5 ? m.p1Id : m.p2Id;
              }
            });
            const sf1 = next.find((m) => m.id === 'sf1');
            const sf2 = next.find((m) => m.id === 'sf2');
            if (sf1) {
              sf1.p1Id = qfMatches[0].winnerId;
              sf1.p2Id = qfMatches[1].winnerId;
            }
            if (sf2) {
              sf2.p1Id = qfMatches[2].winnerId;
              sf2.p2Id = qfMatches[3].winnerId;
            }
          } else if (tournamentRound === 2) {
            const sfMatches = next.filter((m) => m.round === 2);
            sfMatches.forEach((m) => {
              if (m.p1Id === activeFighter.id || m.p2Id === activeFighter.id) {
                m.winnerId = activeFighter.id;
              } else if (!m.winnerId) {
                m.winnerId = Math.random() < 0.5 ? m.p1Id : m.p2Id;
              }
            });
            const fin = next.find((m) => m.id === 'final');
            if (fin) {
              fin.p1Id = sfMatches[0].winnerId;
              fin.p2Id = sfMatches[1].winnerId;
            }
          } else if (tournamentRound === 3) {
            const fin = next.find((m) => m.id === 'final');
            if (fin) fin.winnerId = activeFighter.id;
          }
          return next;
        });
      }

      if (activeMode === 'survival') {
        const nextAccum = survivalScore + result.score;
        setSurvivalScore(nextAccum);
        if (result.winner === 'p2') {
          const updated = recordLeaderboardEntry({
            id: `${Date.now()}`,
            fighterId: activeFighter.id,
            fighterName: activeFighter.name,
            mode: 'survival',
            score: nextAccum,
            wavesOrRounds: survivalWave,
            difficulty: settings.difficulty,
            won: false,
            timestamp: Date.now(),
          });
          setLeaderboard(updated);
        } else {
          // Carry over HP + 25% heal
          const healed = Math.min(
            activeFighter.maxHp,
            result.p1HpRemaining + Math.round(activeFighter.maxHp * 0.25)
          );
          setSurvivalHp(healed);
        }
      } else {
        const shouldRecord =
          activeMode === 'pvc' ||
          activeMode === 'two_player' ||
          result.winner === 'p2' ||
          isChampion;
        if (shouldRecord) {
          const updated = recordLeaderboardEntry({
            id: `${Date.now()}`,
            fighterId: activeFighter.id,
            fighterName: activeFighter.name,
            mode: activeMode,
            score: result.score + (isChampion ? 1500 : 0),
            wavesOrRounds:
              activeMode === 'single'
                ? arcadeStageIdx + 1
                : activeMode === 'tournament'
                  ? tournamentRound
                  : 1,
            difficulty: settings.difficulty,
            won: result.winner === 'p1',
            timestamp: Date.now(),
          });
          setLeaderboard(updated);
        }
      }

      return { coinsEarned, isChampion };
    },
    [
      settings.difficulty,
      activeMode,
      arcadeStageIdx,
      tournamentRound,
      survivalWave,
      survivalScore,
      activeFighter.id,
      activeFighter.name,
      activeFighter.maxHp,
      updateProgress,
    ]
  );

  const hasNextBout =
    (activeMode === 'single' && arcadeStageIdx < 3) ||
    (activeMode === 'tournament' && tournamentRound < 3) ||
    activeMode === 'survival';

  const handleNextBout = () => {
    if (activeMode === 'single' && arcadeStageIdx < 3) {
      setArcadeStageIdx((s) => s + 1);
    } else if (activeMode === 'tournament' && tournamentRound < 3) {
      setTournamentRound((r) => (r === 1 ? 2 : 3));
    } else if (activeMode === 'survival') {
      setSurvivalWave((w) => w + 1);
    }
    setMatchKey((k) => k + 1);
  };

  const handleUnlockFighter = (fighter: FighterProfile) => {
    if (progress.coins < fighter.unlockCost || progress.unlockedFighters.includes(fighter.id)) return;
    updateProgress((prev) => ({
      ...prev,
      coins: prev.coins - fighter.unlockCost,
      unlockedFighters: [...prev.unlockedFighters, fighter.id],
      selectedFighterId: fighter.id,
    }));
  };

  const handleUnlockSkill = (skillId: SkillId, cost: number) => {
    if (progress.coins < cost || progress.unlockedSkills.includes(skillId)) return;
    updateProgress((prev) => ({
      ...prev,
      coins: prev.coins - cost,
      unlockedSkills: [...prev.unlockedSkills, skillId],
      equippedSkills: [...prev.equippedSkills, skillId],
    }));
  };

  const handleToggleSkill = (skillId: SkillId) => {
    updateProgress((prev) => {
      const exists = prev.equippedSkills.includes(skillId);
      return {
        ...prev,
        equippedSkills: exists
          ? prev.equippedSkills.filter((s) => s !== skillId)
          : [...prev.equippedSkills, skillId],
      };
    });
  };

  const stageLabel =
    activeMode === 'single'
      ? `Single Player · Bout ${arcadeStageIdx + 1}/4`
      : activeMode === 'tournament'
        ? tournamentRound === 1
          ? 'Tournament · Quarterfinal'
          : tournamentRound === 2
            ? 'Tournament · Semifinal'
            : 'Tournament · Grand Final'
        : activeMode === 'survival'
          ? `Survival · Wave ${survivalWave}`
          : activeMode === 'two_player'
            ? 'Two Player Versus'
            : `Player vs CPU · ${settings.difficulty.toUpperCase()}`;

  return (
    <>
      {route === 'home' && (
        <HomeScreen
          t={t}
          progress={progress}
          activeFighter={activeFighter}
          activeMode={activeMode}
          onNavigate={setRoute}
          onQuickStart={() => startModeMatch(activeMode)}
        />
      )}

      {route === 'fighters' && (
        <CharacterSelectScreen
          t={t}
          progress={progress}
          activeMode={activeMode}
          onBack={() => setRoute('home')}
          onSelectFighter={(id) => updateProgress((p) => ({ ...p, selectedFighterId: id }))}
          onUnlockFighter={handleUnlockFighter}
          onSelectOpponent={(id) => updateProgress((p) => ({ ...p, selectedOpponentId: id }))}
          onSelectStage={(id) => updateProgress((p) => ({ ...p, selectedStageId: id }))}
          onUnlockSkill={handleUnlockSkill}
          onToggleSkill={handleToggleSkill}
          onStartFight={() => startModeMatch(activeMode)}
        />
      )}

      {route === 'modes' && (
        <GameModesScreen
          t={t}
          activeMode={activeMode}
          tournamentBracket={tournamentBracket}
          onBack={() => setRoute('home')}
          onSelectMode={(m) => {
            setActiveMode(m);
            if (m === 'tournament') {
              setTournamentBracket(buildTournamentBracket(progress.selectedFighterId));
            }
          }}
          onLaunchMode={startModeMatch}
        />
      )}

      {route === 'arena' && (
        <ArenaScreen
          t={t}
          p1Profile={activeFighter}
          p2Profile={currentOpponent}
          stage={activeStage}
          mode={activeMode}
          difficulty={settings.difficulty}
          settings={settings}
          p1Skills={progress.equippedSkills}
          matchKey={matchKey}
          stageLabel={stageLabel}
          initialP1Hp={activeMode === 'survival' ? survivalHp : undefined}
          survivalWave={survivalWave}
          hasNextBout={hasNextBout}
          onToggleSound={() => updateSettings({ soundEnabled: !settings.soundEnabled })}
          onToggleMusic={() => updateSettings({ musicEnabled: !settings.musicEnabled })}
          onMatchFinished={handleMatchFinished}
          onNextBout={handleNextBout}
          onRestart={() => startModeMatch(activeMode)}
          onQuit={() => setRoute('home')}
        />
      )}

      {route === 'leaderboard' && (
        <LeaderboardScreen
          t={t}
          entries={leaderboard}
          progress={progress}
          onBack={() => setRoute('home')}
        />
      )}

      {route === 'settings' && (
        <SettingsScreen
          t={t}
          settings={settings}
          onUpdateSettings={updateSettings}
          onResetProgress={() => {
            resetAllData();
            setProgress(DEFAULT_PROGRESS);
            setLeaderboard([]);
          }}
          onBack={() => setRoute('home')}
        />
      )}

      <OfflineIndicator />
    </>
  );
}
