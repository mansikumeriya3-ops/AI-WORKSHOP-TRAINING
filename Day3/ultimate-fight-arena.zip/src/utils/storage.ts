import { GameSettings, LeaderboardEntry, PlayerProgress } from '../types/game';

const PROGRESS_KEY = 'ufa_player_progress_v1';
const SETTINGS_KEY = 'ufa_game_settings_v1';
const LEADERBOARD_KEY = 'ufa_leaderboard_v1';

export const DEFAULT_PROGRESS: PlayerProgress = {
  coins: 150,
  totalWins: 0,
  totalMatches: 0,
  totalKOs: 0,
  bestSurvivalWave: 0,
  tournamentChampionships: 0,
  unlockedFighters: ['ryuji', 'vex', 'kronos', 'maya', 'drago'],
  unlockedSkills: [],
  equippedSkills: [],
  selectedFighterId: 'ryuji',
  selectedOpponentId: 'vex',
  selectedStageId: 'dojo',
};

export const DEFAULT_SETTINGS: GameSettings = {
  soundEnabled: true,
  musicEnabled: true,
  difficulty: 'normal',
  language: 'en',
  showTouchControls: true,
};

export function loadProgress(): PlayerProgress {
  try {
    const raw = localStorage.getItem(PROGRESS_KEY);
    if (!raw) return DEFAULT_PROGRESS;
    const parsed = JSON.parse(raw) as Partial<PlayerProgress>;
    return {
      ...DEFAULT_PROGRESS,
      ...parsed,
      unlockedFighters: Array.isArray(parsed.unlockedFighters) && parsed.unlockedFighters.length > 0
        ? parsed.unlockedFighters
        : DEFAULT_PROGRESS.unlockedFighters,
      unlockedSkills: Array.isArray(parsed.unlockedSkills) ? parsed.unlockedSkills : [],
      equippedSkills: Array.isArray(parsed.equippedSkills) ? parsed.equippedSkills : [],
    };
  } catch {
    return DEFAULT_PROGRESS;
  }
}

export function saveProgress(progress: PlayerProgress): void {
  try {
    localStorage.setItem(PROGRESS_KEY, JSON.stringify(progress));
  } catch {
    // Ignore storage quota errors
  }
}

export function loadSettings(): GameSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...(JSON.parse(raw) as Partial<GameSettings>) };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: GameSettings): void {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch {
    // Ignore storage errors
  }
}

export function loadLeaderboard(): LeaderboardEntry[] {
  try {
    const raw = localStorage.getItem(LEADERBOARD_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as LeaderboardEntry[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function recordLeaderboardEntry(entry: LeaderboardEntry): LeaderboardEntry[] {
  const existing = loadLeaderboard();
  const next = [entry, ...existing]
    .sort((a, b) => b.score - a.score)
    .slice(0, 30);
  try {
    localStorage.setItem(LEADERBOARD_KEY, JSON.stringify(next));
  } catch {
    // Ignore storage errors
  }
  return next;
}

export function resetAllData(): void {
  try {
    localStorage.removeItem(PROGRESS_KEY);
    localStorage.removeItem(LEADERBOARD_KEY);
  } catch {
    // Ignore
  }
}
