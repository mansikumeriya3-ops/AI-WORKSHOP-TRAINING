import React, { useEffect, useRef } from 'react';
import {
  ArenaStage,
  Difficulty,
  FighterProfile,
  GameMode,
  SkillId,
} from '../types/game';
import { soundEngine } from '../utils/audio';

export interface PlayerInputState {
  left: boolean;
  right: boolean;
  jump: boolean;
  block: boolean;
  punch: boolean;
  kick: boolean;
  special: boolean;
}

export interface HudSnapshot {
  p1Hp: number;
  p1MaxHp: number;
  p1Energy: number;
  p1Rounds: number;
  p1Combo: number;
  p2Hp: number;
  p2MaxHp: number;
  p2Energy: number;
  p2Rounds: number;
  p2Combo: number;
  timer: number;
  currentRound: number;
  bannerText: string | null;
}

export interface MatchResult {
  winner: 'p1' | 'p2';
  p1HpRemaining: number;
  p1MaxHp: number;
  score: number;
  kos: number;
  maxCombo: number;
}

interface FightCanvasProps {
  p1Profile: FighterProfile;
  p2Profile: FighterProfile;
  stage: ArenaStage;
  mode: GameMode;
  difficulty: Difficulty;
  p1Skills: SkillId[];
  initialP1Hp?: number;
  survivalWave?: number;
  isPaused: boolean;
  inputRef: React.MutableRefObject<{ p1: PlayerInputState; p2: PlayerInputState }>;
  onHudUpdate: (hud: HudSnapshot) => void;
  onMatchEnd: (result: MatchResult) => void;
}

type FighterState =
  | 'idle'
  | 'walk'
  | 'jump'
  | 'block'
  | 'punch'
  | 'kick'
  | 'combo'
  | 'special'
  | 'hit'
  | 'ko'
  | 'victory';

interface FighterEntity {
  slot: 'p1' | 'p2';
  profile: FighterProfile;
  x: number;
  y: number;
  vx: number;
  vy: number;
  facing: 1 | -1;
  hp: number;
  maxHp: number;
  energy: number;
  roundsWon: number;
  state: FighterState;
  stateTimer: number;
  attackDuration: number;
  hasHitThisAttack: boolean;
  comboStep: number;
  comboWindow: number;
  comboCount: number;
  maxCombo: number;
  hitFlash: number;
  prevPunch: boolean;
  prevKick: boolean;
  prevJump: boolean;
  prevSpecial: boolean;
  damageScale: number;
  defenseScale: number;
  energyGainScale: number;
}

interface Projectile {
  owner: 'p1' | 'p2';
  x: number;
  y: number;
  vx: number;
  radius: number;
  damage: number;
  color: string;
  accent: string;
  type: FighterProfile['specialType'];
  life: number;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  alpha: number;
  life: number;
  maxLife: number;
}

interface FloatingText {
  x: number;
  y: number;
  text: string;
  color: string;
  life: number;
  scale: number;
}

const ARENA_W = 960;
const ARENA_H = 500;
const GROUND_Y = 428;
const GRAVITY = 0.72;
const JUMP_VY = -16.2;

export const FightCanvas: React.FC<FightCanvasProps> = ({
  p1Profile,
  p2Profile,
  stage,
  mode,
  difficulty,
  p1Skills,
  initialP1Hp,
  survivalWave = 1,
  isPaused,
  inputRef,
  onHudUpdate,
  onMatchEnd,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const pausedRef = useRef(isPaused);
  pausedRef.current = isPaused;

  const onHudRef = useRef(onHudUpdate);
  onHudRef.current = onHudUpdate;
  const onEndRef = useRef(onMatchEnd);
  onEndRef.current = onMatchEnd;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Load stage image
    const bgImg = new Image();
    let bgLoaded = false;
    bgImg.onload = () => {
      bgLoaded = true;
    };
    bgImg.src = stage.imagePath;

    const createFighter = (
      slot: 'p1' | 'p2',
      profile: FighterProfile,
      startX: number,
      facing: 1 | -1,
      skills: SkillId[],
      overrideHp?: number
    ): FighterEntity => {
      const hasIronGuard = skills.includes('iron_guard');
      const hasComboMastery = skills.includes('combo_mastery');
      const hasHyperSurge = skills.includes('hyper_surge');
      const maxHp = profile.maxHp;

      return {
        slot,
        profile,
        x: startX,
        y: GROUND_Y,
        vx: 0,
        vy: 0,
        facing,
        hp: overrideHp !== undefined ? Math.min(maxHp, overrideHp) : maxHp,
        maxHp,
        energy: 35,
        roundsWon: 0,
        state: 'idle',
        stateTimer: 0,
        attackDuration: 0,
        hasHitThisAttack: false,
        comboStep: 0,
        comboWindow: 0,
        comboCount: 0,
        maxCombo: 0,
        hitFlash: 0,
        prevPunch: false,
        prevKick: false,
        prevJump: false,
        prevSpecial: false,
        damageScale: profile.damageScale * (hasComboMastery ? 1.18 : 1),
        defenseScale: hasIronGuard ? 0.85 : 1,
        energyGainScale: hasHyperSurge ? 1.35 : 1,
      };
    };

    const p1 = createFighter('p1', p1Profile, 240, 1, p1Skills, initialP1Hp);
    // Scale CPU slightly in higher survival waves
    const cpuHpScale = mode === 'survival' ? 1 + (survivalWave - 1) * 0.08 : 1;
    const p2 = createFighter('p2', p2Profile, 720, -1, []);
    p2.maxHp = Math.round(p2.maxHp * cpuHpScale);
    p2.hp = p2.maxHp;

    const projectiles: Projectile[] = [];
    const particles: Particle[] = [];
    const floatingTexts: FloatingText[] = [];

    // Ambient stage particles
    const ambientParticles: { x: number; y: number; vy: number; vx: number; r: number; a: number }[] = [];
    for (let i = 0; i < 24; i++) {
      ambientParticles.push({
        x: Math.random() * ARENA_W,
        y: Math.random() * ARENA_H,
        vy: stage.particleType === 'ember' ? -(0.5 + Math.random() * 1.2) : 0.3 + Math.random() * 0.7,
        vx: (Math.random() - 0.5) * 0.5,
        r: 1.5 + Math.random() * 2.5,
        a: 0.25 + Math.random() * 0.55,
      });
    }

    let currentRound = 1;
    const roundsToWin = mode === 'survival' ? 1 : 2;
    let roundTimer = 99;
    let timerTick = 0;
    let phase: 'intro' | 'fight' | 'round_end' | 'match_end' = 'intro';
    let phaseTicks = 85;
    let bannerText: string | null = mode === 'survival' ? `WAVE ${survivalWave}` : 'ROUND 1';
    let hitStop = 0;
    let screenShake = 0;
    let totalScore = 0;
    let totalKOs = 0;
    let globalTick = 0;

    let aiDecisionCooldown = 0;
    let aiAction: 'idle' | 'approach' | 'retreat' | 'block' | 'jump' | 'punch' | 'kick' | 'special' = 'idle';

    soundEngine.playBell();

    const spawnSparks = (x: number, y: number, color: string, count = 12, speed = 6) => {
      for (let i = 0; i < count; i++) {
        const angle = Math.random() * Math.PI * 2;
        const spd = (0.35 + Math.random() * 0.85) * speed;
        particles.push({
          x,
          y,
          vx: Math.cos(angle) * spd,
          vy: Math.sin(angle) * spd - 1.5,
          size: 2.5 + Math.random() * 4,
          color,
          alpha: 1,
          life: 18 + Math.floor(Math.random() * 14),
          maxLife: 32,
        });
      }
    };

    const spawnText = (x: number, y: number, text: string, color: string, scale = 1) => {
      floatingTexts.push({ x, y, text, color, life: 42, scale });
    };

    const resetForNextRound = () => {
      p1.x = 240;
      p1.y = GROUND_Y;
      p1.vx = 0;
      p1.vy = 0;
      p1.facing = 1;
      p1.hp = p1.maxHp;
      p1.state = 'idle';
      p1.stateTimer = 0;
      p1.comboStep = 0;
      p1.comboCount = 0;

      p2.x = 720;
      p2.y = GROUND_Y;
      p2.vx = 0;
      p2.vy = 0;
      p2.facing = -1;
      p2.hp = p2.maxHp;
      p2.state = 'idle';
      p2.stateTimer = 0;
      p2.comboStep = 0;
      p2.comboCount = 0;

      projectiles.length = 0;
      roundTimer = 99;
      timerTick = 0;
      phase = 'intro';
      phaseTicks = 85;
      bannerText = `ROUND ${currentRound}`;
      soundEngine.playBell();
    };

    const computeAiInput = (): PlayerInputState => {
      const inp: PlayerInputState = {
        left: false,
        right: false,
        jump: false,
        block: false,
        punch: false,
        kick: false,
        special: false,
      };
      if (phase !== 'fight') return inp;

      const dist = Math.abs(p1.x - p2.x);
      const towardsLeft = p1.x < p2.x;

      const diffStats = {
        easy: { react: 22, aggro: 0.38, blockProb: 0.18 },
        normal: { react: 14, aggro: 0.62, blockProb: 0.36 },
        hard: { react: 8, aggro: 0.82, blockProb: 0.56 },
        brutal: { react: 4, aggro: 0.94, blockProb: 0.74 },
      }[difficulty];

      // Check incoming projectile
      const incomingProj = projectiles.find(
        (pr) => pr.owner === 'p1' && Math.abs(pr.x - p2.x) < 160
      );
      if (incomingProj && Math.random() < diffStats.blockProb) {
        if (Math.random() < 0.45 && p2.y >= GROUND_Y - 1) {
          inp.jump = true;
        } else {
          inp.block = true;
        }
        return inp;
      }

      if (aiDecisionCooldown <= 0) {
        aiDecisionCooldown = diffStats.react + Math.floor(Math.random() * 8);
        const r = Math.random();

        if (p2.energy >= 100 && dist < 440 && r < diffStats.aggro) {
          aiAction = 'special';
        } else if (
          (p1.state === 'punch' || p1.state === 'kick' || p1.state === 'combo' || p1.state === 'special') &&
          dist < 130 &&
          r < diffStats.blockProb
        ) {
          aiAction = 'block';
        } else if (dist > 115) {
          aiAction = r < 0.78 ? 'approach' : r < 0.9 ? 'jump' : 'idle';
        } else {
          if (r < diffStats.aggro * 0.55) aiAction = 'punch';
          else if (r < diffStats.aggro) aiAction = 'kick';
          else if (r < 0.88) aiAction = 'block';
          else aiAction = 'retreat';
        }
      } else {
        aiDecisionCooldown--;
      }

      if (aiAction === 'approach') {
        if (towardsLeft) inp.left = true;
        else inp.right = true;
      } else if (aiAction === 'retreat') {
        if (towardsLeft) inp.right = true;
        else inp.left = true;
      } else if (aiAction === 'block') {
        inp.block = true;
      } else if (aiAction === 'jump') {
        inp.jump = true;
        if (towardsLeft) inp.left = true;
        else inp.right = true;
        aiAction = 'approach';
      } else if (aiAction === 'punch') {
        inp.punch = true;
        aiAction = 'idle';
      } else if (aiAction === 'kick') {
        inp.kick = true;
        aiAction = 'idle';
      } else if (aiAction === 'special') {
        inp.special = true;
        aiAction = 'idle';
      }

      return inp;
    };

    const applyHit = (
      attacker: FighterEntity,
      defender: FighterEntity,
      baseDamage: number,
      knockback: number,
      isHeavy: boolean,
      isSpecial = false
    ) => {
      const isBlocking = defender.state === 'block' && !isSpecial;
      const dmgRaw = baseDamage * attacker.damageScale * defender.defenseScale;
      const dmg = Math.max(2, Math.round(isBlocking ? dmgRaw * 0.2 : dmgRaw));

      defender.hp = Math.max(0, defender.hp - dmg);
      defender.hitFlash = isBlocking ? 4 : 8;

      if (isBlocking) {
        defender.vx = attacker.facing * (knockback * 0.45);
        soundEngine.playBlock();
        spawnSparks(defender.x, defender.y - 75, '#38bdf8', 9, 5);
        spawnText(defender.x, defender.y - 125, `BLOCK -${dmg}`, '#93c5fd', 0.85);
        defender.energy = Math.min(100, defender.energy + 8 * defender.energyGainScale);
      } else {
        defender.state = 'hit';
        defender.stateTimer = isHeavy ? 18 : 12;
        defender.vx = attacker.facing * knockback;
        if (isHeavy) {
          defender.vy = -4.5;
        }
        attacker.comboCount += 1;
        if (attacker.comboCount > attacker.maxCombo) {
          attacker.maxCombo = attacker.comboCount;
        }
        if (attacker.slot === 'p1') {
          totalScore += dmg * 10 + (attacker.comboCount > 1 ? attacker.comboCount * 40 : 0);
        }

        soundEngine.playHit(isHeavy);
        hitStop = isHeavy ? 5 : 2;
        screenShake = isHeavy ? 10 : 4;
        spawnSparks(
          (attacker.x + defender.x) / 2,
          defender.y - 75,
          isSpecial ? attacker.profile.palette.accent : '#f97316',
          isHeavy ? 18 : 10,
          isHeavy ? 8 : 5
        );
        spawnText(
          defender.x,
          defender.y - 130,
          `-${dmg}`,
          isHeavy ? '#fbbf24' : '#f87171',
          isHeavy ? 1.2 : 1
        );
        if (attacker.comboCount >= 2) {
          spawnText(
            attacker.x,
            attacker.y - 155,
            `${attacker.comboCount} HIT COMBO!`,
            '#fb923c',
            1.1
          );
        }
      }

      attacker.energy = Math.min(100, attacker.energy + (isSpecial ? 0 : 14 * attacker.energyGainScale));
      defender.energy = Math.min(100, defender.energy + 10 * defender.energyGainScale);

      if (defender.hp <= 0 && phase === 'fight') {
        defender.state = 'ko';
        defender.stateTimer = 120;
        defender.vy = -8;
        defender.vx = attacker.facing * 9;
        attacker.state = 'victory';
        attacker.roundsWon += 1;
        totalKOs += attacker.slot === 'p1' ? 1 : 0;
        totalScore += attacker.slot === 'p1' ? 500 : 0;
        phase = 'round_end';
        phaseTicks = 120;
        bannerText = 'K.O.!';
        hitStop = 10;
        screenShake = 16;
        soundEngine.playKO();
      }
    };

    const updateFighter = (f: FighterEntity, other: FighterEntity, input: PlayerInputState) => {
      if (f.hitFlash > 0) f.hitFlash--;
      if (f.comboWindow > 0) f.comboWindow--;

      const punchPressed = input.punch && !f.prevPunch;
      const kickPressed = input.kick && !f.prevKick;
      const jumpPressed = input.jump && !f.prevJump;
      const specialPressed = input.special && !f.prevSpecial;

      f.prevPunch = input.punch;
      f.prevKick = input.kick;
      f.prevJump = input.jump;
      f.prevSpecial = input.special;

      // Gravity & Vertical motion
      if (f.y < GROUND_Y || f.vy < 0) {
        f.y += f.vy;
        f.vy += GRAVITY;
        if (f.y >= GROUND_Y) {
          f.y = GROUND_Y;
          f.vy = 0;
          if (f.state === 'jump') {
            f.state = 'idle';
          }
          spawnSparks(f.x, GROUND_Y, '#71717a', 5, 2.2);
        }
      }

      // Horizontal damping
      if (f.state === 'hit' || f.state === 'ko' || f.state === 'victory') {
        f.x += f.vx;
        f.vx *= 0.86;
      }

      if (f.state === 'ko' || f.state === 'victory') {
        f.x = Math.max(55, Math.min(ARENA_W - 55, f.x));
        return;
      }

      if (f.state === 'hit') {
        f.stateTimer--;
        if (f.stateTimer <= 0) {
          f.state = f.y < GROUND_Y ? 'jump' : 'idle';
          other.comboCount = 0;
        }
        f.x = Math.max(55, Math.min(ARENA_W - 55, f.x));
        return;
      }

      // Always face opponent when neutral
      if (f.state === 'idle' || f.state === 'walk' || f.state === 'block') {
        f.facing = other.x >= f.x ? 1 : -1;
      }

      // Active attack states
      if (f.state === 'punch' || f.state === 'kick' || f.state === 'combo' || f.state === 'special') {
        f.stateTimer--;
        const progress = 1 - f.stateTimer / f.attackDuration;

        // Slight forward lunge
        if (f.state === 'combo' || f.state === 'special') {
          f.x += f.facing * (f.profile.specialType === 'meteor' && f.state === 'special' ? 7.5 : 2.2);
        } else if (f.state === 'kick') {
          f.x += f.facing * 1.6;
        }

        // Hitbox check during active frames (30% to 75%)
        if (!f.hasHitThisAttack && progress >= 0.28 && progress <= 0.78) {
          const reach =
            f.state === 'special'
              ? f.profile.specialType === 'beam'
                ? 360
                : f.profile.specialType === 'shockwave'
                  ? 190
                  : 145
              : f.state === 'combo'
                ? 112
                : f.state === 'kick'
                  ? 104
                  : 88;

          const dx = (other.x - f.x) * f.facing;
          const dy = Math.abs(other.y - f.y);

          // Melee & non-projectile specials check direct hit
          const isProjectileSpecial =
            f.state === 'special' &&
            ['fireball', 'kunai', 'lightning', 'slash', 'frost'].includes(f.profile.specialType);

          if (!isProjectileSpecial && dx > -20 && dx <= reach && dy < 95 && other.state !== 'ko') {
            f.hasHitThisAttack = true;
            const dmg = f.state === 'special' ? 38 : f.state === 'combo' ? 24 : f.state === 'kick' ? 16 : 11;
            const kb = f.state === 'special' ? 14 : f.state === 'combo' ? 12 : f.state === 'kick' ? 8 : 5;
            applyHit(f, other, dmg, kb, f.state === 'combo' || f.state === 'special', f.state === 'special');
          }
        }

        // Allow chaining punch -> combo
        if (
          (f.state === 'punch' || f.state === 'kick') &&
          f.stateTimer <= 6 &&
          (punchPressed || kickPressed) &&
          f.comboStep >= 1
        ) {
          f.state = 'combo';
          f.attackDuration = 22;
          f.stateTimer = 22;
          f.hasHitThisAttack = false;
          f.comboStep = 0;
          soundEngine.playWhoosh(0.8);
        }

        if (f.stateTimer <= 0) {
          f.state = f.y < GROUND_Y ? 'jump' : 'idle';
        }
        f.x = Math.max(55, Math.min(ARENA_W - 55, f.x));
        return;
      }

      if (phase !== 'fight') {
        f.state = 'idle';
        return;
      }

      // Trigger Special Attack
      if (specialPressed && f.energy >= 100) {
        f.energy = 0;
        f.state = 'special';
        f.attackDuration = 28;
        f.stateTimer = 28;
        f.hasHitThisAttack = false;
        soundEngine.playSpecial();
        screenShake = 8;
        spawnText(f.x, f.y - 145, f.profile.specialName.toUpperCase(), f.profile.palette.accent, 1.05);
        spawnSparks(f.x + f.facing * 20, f.y - 68, f.profile.palette.aura, 18, 7);

        if (['fireball', 'kunai', 'lightning', 'slash', 'frost'].includes(f.profile.specialType)) {
          projectiles.push({
            owner: f.slot,
            x: f.x + f.facing * 48,
            y: f.y - 72,
            vx: f.facing * (f.profile.specialType === 'kunai' ? 13 : 10.5),
            radius: f.profile.specialType === 'slash' ? 28 : 22,
            damage: 34,
            color: f.profile.palette.primary,
            accent: f.profile.palette.accent,
            type: f.profile.specialType,
            life: 95,
          });
        }
        return;
      }

      // Trigger Punch / Combo / Kick
      if (punchPressed) {
        if (f.comboWindow > 0 && f.comboStep >= 1) {
          f.state = 'combo';
          f.attackDuration = 22;
          f.stateTimer = 22;
          f.comboStep = 0;
        } else {
          f.state = 'punch';
          f.attackDuration = 14;
          f.stateTimer = 14;
          f.comboStep = 1;
          f.comboWindow = 28;
        }
        f.hasHitThisAttack = false;
        soundEngine.playWhoosh(1.2);
        return;
      }

      if (kickPressed) {
        if (f.comboWindow > 0 && f.comboStep >= 1) {
          f.state = 'combo';
          f.attackDuration = 22;
          f.stateTimer = 22;
          f.comboStep = 0;
        } else {
          f.state = 'kick';
          f.attackDuration = 18;
          f.stateTimer = 18;
          f.comboStep = 1;
          f.comboWindow = 28;
        }
        f.hasHitThisAttack = false;
        soundEngine.playWhoosh(0.95);
        return;
      }

      // Jump
      if (jumpPressed && f.y >= GROUND_Y - 1) {
        f.vy = JUMP_VY;
        f.y = GROUND_Y - 2;
        f.state = 'jump';
        soundEngine.playJump();
        spawnSparks(f.x, GROUND_Y, '#a1a1aa', 6, 2.5);
      }

      // Block (ground only)
      if (input.block && f.y >= GROUND_Y - 1) {
        f.state = 'block';
        f.vx = 0;
        return;
      }

      // Movement
      let moveDir = 0;
      if (input.left) moveDir -= 1;
      if (input.right) moveDir += 1;

      if (moveDir !== 0) {
        f.x += moveDir * f.profile.moveSpeed;
        if (f.y >= GROUND_Y - 1) f.state = 'walk';
      } else if (f.y >= GROUND_Y - 1) {
        f.state = 'idle';
      }

      f.x = Math.max(55, Math.min(ARENA_W - 55, f.x));
    };

    const drawFighter = (f: FighterEntity) => {
      const { palette, gear } = f.profile;
      const t = globalTick * 0.14;
      const isKO = f.state === 'ko';

      ctx.save();
      ctx.translate(f.x, f.y);

      // Ground shadow
      const heightRatio = Math.max(0.35, 1 - (GROUND_Y - f.y) / 220);
      ctx.fillStyle = 'rgba(0,0,0,0.48)';
      ctx.beginPath();
      ctx.ellipse(0, GROUND_Y - f.y + 4, 34 * heightRatio, 9 * heightRatio, 0, 0, Math.PI * 2);
      ctx.fill();

      ctx.scale(f.facing, 1);

      if (isKO) {
        ctx.translate(0, -18);
        ctx.rotate(-Math.PI / 2);
      }

      // Energy ready aura
      if (f.energy >= 100 && !isKO) {
        ctx.save();
        ctx.strokeStyle = palette.aura;
        ctx.lineWidth = 3;
        ctx.globalAlpha = 0.45 + Math.sin(globalTick * 0.25) * 0.3;
        ctx.beginPath();
        ctx.ellipse(0, -64, 36, 68, 0, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      }

      // Hit flash tint
      const flash = f.hitFlash > 0 && f.hitFlash % 2 === 0;
      const primary = flash ? '#ffffff' : palette.primary;
      const secondary = flash ? '#fecaca' : palette.secondary;
      const skin = flash ? '#ffffff' : palette.skin;
      const accent = flash ? '#ffffff' : palette.accent;

      const bob = f.state === 'idle' ? Math.sin(t) * 2.5 : f.state === 'walk' ? Math.abs(Math.sin(t * 1.6)) * -4 : 0;
      const walkSwing = f.state === 'walk' ? Math.sin(t * 1.6) * 16 : 0;
      const atkProg = f.attackDuration > 0 ? Math.sin((1 - f.stateTimer / f.attackDuration) * Math.PI) : 0;

      // Back Leg
      ctx.lineCap = 'round';
      ctx.lineWidth = 13;
      ctx.strokeStyle = secondary;
      ctx.beginPath();
      ctx.moveTo(-8, -46 + bob);
      ctx.lineTo(-14 - walkSwing * 0.7, -22);
      ctx.lineTo(-18 - walkSwing, -4);
      ctx.stroke();

      // Front Leg (animated during Kick / Combo)
      ctx.strokeStyle = primary;
      ctx.beginPath();
      ctx.moveTo(8, -46 + bob);
      if (f.state === 'kick' || f.state === 'combo') {
        const kickReach = 46 * atkProg;
        ctx.lineTo(22 + kickReach * 0.5, -52 - 14 * atkProg);
        ctx.lineTo(26 + kickReach, -56 - 18 * atkProg);
      } else if (f.state === 'jump') {
        ctx.lineTo(18, -28);
        ctx.lineTo(6, -12);
      } else {
        ctx.lineTo(14 + walkSwing * 0.7, -22);
        ctx.lineTo(18 + walkSwing, -4);
      }
      ctx.stroke();

      // Torso / Gi / Armor
      ctx.fillStyle = primary;
      ctx.beginPath();
      ctx.roundRect(-18, -94 + bob, 36, 50, 8);
      ctx.fill();

      // Waist Sash
      ctx.fillStyle = accent;
      ctx.fillRect(-19, -54 + bob, 38, 7);

      // Flowing Sash Tail
      ctx.strokeStyle = accent;
      ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.moveTo(-16, -50 + bob);
      ctx.quadraticCurveTo(-28, -40 + Math.sin(t * 1.4) * 5, -34, -28 + Math.cos(t) * 4);
      ctx.stroke();

      // Back Arm
      ctx.strokeStyle = skin;
      ctx.lineWidth = 10;
      ctx.beginPath();
      ctx.moveTo(-14, -84 + bob);
      if (f.state === 'block') {
        ctx.lineTo(14, -78 + bob);
        ctx.lineTo(18, -98 + bob);
      } else {
        ctx.lineTo(-22, -66 + bob);
        ctx.lineTo(-10, -58 + bob);
      }
      ctx.stroke();

      // Head
      ctx.fillStyle = skin;
      ctx.beginPath();
      ctx.arc(2, -108 + bob, 16, 0, Math.PI * 2);
      ctx.fill();

      // Hair / Headgear
      ctx.fillStyle = palette.hair;
      if (gear !== 'monk') {
        ctx.beginPath();
        ctx.arc(1, -112 + bob, 16, Math.PI, 0);
        ctx.fill();
      }
      if (gear === 'headband') {
        ctx.fillStyle = primary;
        ctx.fillRect(-14, -117 + bob, 32, 5);
        ctx.beginPath();
        ctx.moveTo(-14, -115 + bob);
        ctx.lineTo(-32, -120 + Math.sin(t) * 4 + bob);
        ctx.lineTo(-28, -110 + bob);
        ctx.fill();
      } else if (gear === 'mask') {
        ctx.fillStyle = secondary;
        ctx.fillRect(-12, -108 + bob, 29, 13);
      } else if (gear === 'horns') {
        ctx.fillStyle = accent;
        ctx.beginPath();
        ctx.moveTo(6, -120 + bob);
        ctx.lineTo(18, -136 + bob);
        ctx.lineTo(14, -116 + bob);
        ctx.fill();
      } else if (gear === 'visor') {
        ctx.fillStyle = accent;
        ctx.fillRect(4, -113 + bob, 14, 5);
      } else if (gear === 'kabuto') {
        ctx.fillStyle = primary;
        ctx.beginPath();
        ctx.moveTo(-18, -114 + bob);
        ctx.lineTo(2, -132 + bob);
        ctx.lineTo(20, -114 + bob);
        ctx.closePath();
        ctx.fill();
      } else if (gear === 'crown') {
        ctx.fillStyle = accent;
        ctx.beginPath();
        ctx.moveTo(-12, -121 + bob);
        ctx.lineTo(-8, -135 + bob);
        ctx.lineTo(0, -125 + bob);
        ctx.lineTo(8, -135 + bob);
        ctx.lineTo(14, -121 + bob);
        ctx.closePath();
        ctx.fill();
      }

      // Fierce Eye
      if (gear !== 'visor') {
        ctx.fillStyle = accent;
        ctx.fillRect(8, -111 + bob, 5, 3);
      }

      // Front Arm (Punch / Special / Victory / Guard)
      ctx.strokeStyle = skin;
      ctx.lineWidth = 11;
      ctx.beginPath();
      ctx.moveTo(10, -84 + bob);
      if (f.state === 'punch' || f.state === 'combo' || f.state === 'special') {
        const punchReach = (f.state === 'special' ? 48 : 38) * atkProg;
        ctx.lineTo(26 + punchReach, -84 + bob);
        // Glowing fist
        ctx.stroke();
        ctx.fillStyle = f.state === 'special' ? accent : primary;
        ctx.beginPath();
        ctx.arc(28 + punchReach, -84 + bob, f.state === 'special' ? 12 : 8, 0, Math.PI * 2);
        ctx.fill();
      } else if (f.state === 'block') {
        ctx.lineTo(20, -76 + bob);
        ctx.lineTo(18, -104 + bob);
        ctx.stroke();
        // Energy Guard Shield
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 3;
        ctx.globalAlpha = 0.75;
        ctx.beginPath();
        ctx.arc(24, -76 + bob, 32, -Math.PI * 0.45, Math.PI * 0.45);
        ctx.stroke();
      } else if (f.state === 'victory') {
        ctx.lineTo(18, -112 + bob);
        ctx.lineTo(20, -132 + bob);
        ctx.stroke();
      } else {
        ctx.lineTo(22, -70 + bob);
        ctx.lineTo(28, -82 + bob);
        ctx.stroke();
        ctx.fillStyle = primary;
        ctx.beginPath();
        ctx.arc(28, -82 + bob, 6.5, 0, Math.PI * 2);
        ctx.fill();
      }

      // Special melee beam / shockwave visual
      if (f.state === 'special') {
        if (f.profile.specialType === 'beam') {
          ctx.fillStyle = accent;
          ctx.globalAlpha = 0.8;
          ctx.fillRect(36, -96 + bob, 340 * atkProg, 28);
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(36, -88 + bob, 340 * atkProg, 12);
        } else if (f.profile.specialType === 'shockwave') {
          ctx.strokeStyle = accent;
          ctx.lineWidth = 6;
          ctx.globalAlpha = 1 - atkProg * 0.6;
          ctx.beginPath();
          ctx.ellipse(30, -6, 170 * atkProg, 24 * atkProg, 0, 0, Math.PI * 2);
          ctx.stroke();
        } else if (f.profile.specialType === 'meteor') {
          ctx.fillStyle = accent;
          ctx.globalAlpha = 0.65;
          ctx.beginPath();
          ctx.arc(26, -72 + bob, 44 * atkProg, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      ctx.restore();
    };

    let animId = 0;
    let lastHudPush = 0;

    const loop = () => {
      animId = requestAnimationFrame(loop);

      if (!pausedRef.current) {
        globalTick++;

        if (hitStop > 0) {
          hitStop--;
        } else {
          // Phase progression
          if (phase === 'intro') {
            phaseTicks--;
            if (phaseTicks === 35) {
              bannerText = 'FIGHT!';
              soundEngine.playBell();
            }
            if (phaseTicks <= 0) {
              phase = 'fight';
              bannerText = null;
            }
          } else if (phase === 'fight') {
            timerTick++;
            if (timerTick >= 60) {
              timerTick = 0;
              roundTimer = Math.max(0, roundTimer - 1);
              if (roundTimer === 0) {
                // Time up! Higher HP % wins
                const p1Ratio = p1.hp / p1.maxHp;
                const p2Ratio = p2.hp / p2.maxHp;
                if (p1Ratio >= p2Ratio) {
                  p1.roundsWon++;
                  p1.state = 'victory';
                  p2.state = 'ko';
                } else {
                  p2.roundsWon++;
                  p2.state = 'victory';
                  p1.state = 'ko';
                }
                phase = 'round_end';
                phaseTicks = 110;
                bannerText = 'TIME UP';
                soundEngine.playBell();
              }
            }
          } else if (phase === 'round_end') {
            phaseTicks--;
            if (phaseTicks <= 0) {
              if (p1.roundsWon >= roundsToWin || p2.roundsWon >= roundsToWin) {
                phase = 'match_end';
                const winner = p1.roundsWon >= roundsToWin ? 'p1' : 'p2';
                bannerText = winner === 'p1' ? 'VICTORY' : 'DEFEAT';
                if (winner === 'p1') soundEngine.playVictory();
                onEndRef.current({
                  winner,
                  p1HpRemaining: p1.hp,
                  p1MaxHp: p1.maxHp,
                  score: totalScore + (winner === 'p1' ? p1.hp * 5 : 0),
                  kos: totalKOs,
                  maxCombo: p1.maxCombo,
                });
              } else {
                currentRound++;
                resetForNextRound();
              }
            }
          }

          // Update fighters
          const p1Inp = inputRef.current.p1;
          const p2Inp = mode === 'two_player' ? inputRef.current.p2 : computeAiInput();

          updateFighter(p1, p2, p1Inp);
          updateFighter(p2, p1, p2Inp);

          // Prevent fighter overlap
          if (p1.state !== 'ko' && p2.state !== 'ko') {
            const minSep = 48;
            const dist = Math.abs(p1.x - p2.x);
            if (dist < minSep && Math.abs(p1.y - p2.y) < 70) {
              const push = (minSep - dist) / 2;
              if (p1.x <= p2.x) {
                p1.x = Math.max(55, p1.x - push);
                p2.x = Math.min(ARENA_W - 55, p2.x + push);
              } else {
                p1.x = Math.min(ARENA_W - 55, p1.x + push);
                p2.x = Math.max(55, p2.x - push);
              }
            }
          }

          // Update projectiles
          for (let i = projectiles.length - 1; i >= 0; i--) {
            const pr = projectiles[i];
            pr.x += pr.vx;
            pr.life--;
            if (globalTick % 2 === 0) {
              particles.push({
                x: pr.x,
                y: pr.y + (Math.random() - 0.5) * 10,
                vx: -pr.vx * 0.15,
                vy: (Math.random() - 0.5) * 1.5,
                size: 3.5,
                color: pr.accent,
                alpha: 0.9,
                life: 14,
                maxLife: 14,
              });
            }

            const target = pr.owner === 'p1' ? p2 : p1;
            const attacker = pr.owner === 'p1' ? p1 : p2;
            if (
              target.state !== 'ko' &&
              Math.abs(pr.x - target.x) < pr.radius + 24 &&
              pr.y > target.y - 125 &&
              pr.y < target.y + 10
            ) {
              applyHit(attacker, target, pr.damage, 11, true, true);
              projectiles.splice(i, 1);
              continue;
            }

            if (pr.life <= 0 || pr.x < -40 || pr.x > ARENA_W + 40) {
              projectiles.splice(i, 1);
            }
          }

          // Particles & texts
          for (let i = particles.length - 1; i >= 0; i--) {
            const pt = particles[i];
            pt.x += pt.vx;
            pt.y += pt.vy;
            pt.vy += 0.12;
            pt.life--;
            pt.alpha = Math.max(0, pt.life / pt.maxLife);
            if (pt.life <= 0) particles.splice(i, 1);
          }
          for (let i = floatingTexts.length - 1; i >= 0; i--) {
            const ft = floatingTexts[i];
            ft.y -= 0.9;
            ft.life--;
            if (ft.life <= 0) floatingTexts.splice(i, 1);
          }
        }
      }

      // Render Scene
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const targetW = ARENA_W * dpr;
      const targetH = ARENA_H * dpr;
      if (canvas.width !== targetW || canvas.height !== targetH) {
        canvas.width = targetW;
        canvas.height = targetH;
      }

      ctx.save();
      ctx.scale(dpr, dpr);

      if (screenShake > 0) {
        const sx = (Math.random() - 0.5) * screenShake;
        const sy = (Math.random() - 0.5) * screenShake;
        ctx.translate(sx, sy);
        screenShake *= 0.82;
        if (screenShake < 0.5) screenShake = 0;
      }

      // Stage Background
      if (bgLoaded) {
        ctx.drawImage(bgImg, 0, 0, ARENA_W, ARENA_H);
        ctx.fillStyle = 'rgba(9, 9, 11, 0.28)';
        ctx.fillRect(0, 0, ARENA_W, ARENA_H);
      } else {
        const grad = ctx.createLinearGradient(0, 0, 0, ARENA_H);
        grad.addColorStop(0, '#18181b');
        grad.addColorStop(1, '#09090b');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, ARENA_W, ARENA_H);
      }

      // Combat Floor Strip & Depth Line
      ctx.fillStyle = 'rgba(0,0,0,0.42)';
      ctx.fillRect(0, GROUND_Y, ARENA_W, ARENA_H - GROUND_Y);
      ctx.strokeStyle = stage.accentColor;
      ctx.globalAlpha = 0.35;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(0, GROUND_Y);
      ctx.lineTo(ARENA_W, GROUND_Y);
      ctx.stroke();
      ctx.globalAlpha = 1;

      // Ambient embers / sparks
      for (const ap of ambientParticles) {
        ap.x += ap.vx;
        ap.y += ap.vy;
        if (ap.y < 0) ap.y = ARENA_H;
        if (ap.y > ARENA_H) ap.y = 0;
        if (ap.x < 0) ap.x = ARENA_W;
        if (ap.x > ARENA_W) ap.x = 0;
        ctx.fillStyle = stage.accentColor;
        ctx.globalAlpha = ap.a;
        ctx.beginPath();
        ctx.arc(ap.x, ap.y, ap.r, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;

      // Draw Fighters
      drawFighter(p1);
      drawFighter(p2);

      // Draw Projectiles
      for (const pr of projectiles) {
        ctx.save();
        ctx.translate(pr.x, pr.y);
        ctx.fillStyle = pr.color;
        ctx.shadowColor = pr.accent;
        ctx.shadowBlur = 16;
        if (pr.type === 'kunai' || pr.type === 'slash') {
          ctx.scale(pr.vx >= 0 ? 1 : -1, 1);
          ctx.beginPath();
          ctx.moveTo(-18, -10);
          ctx.lineTo(22, 0);
          ctx.lineTo(-18, 10);
          ctx.closePath();
          ctx.fill();
        } else {
          ctx.beginPath();
          ctx.arc(0, 0, pr.radius, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#ffffff';
          ctx.beginPath();
          ctx.arc(0, 0, pr.radius * 0.45, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
      }

      // Draw Particles
      for (const pt of particles) {
        ctx.save();
        ctx.globalAlpha = pt.alpha;
        ctx.fillStyle = pt.color;
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, pt.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      // Floating Damage & Combo Text
      for (const ft of floatingTexts) {
        ctx.save();
        ctx.globalAlpha = Math.min(1, ft.life / 16);
        ctx.font = `800 ${Math.round(20 * ft.scale)}px "Big Shoulders Display", sans-serif`;
        ctx.textAlign = 'center';
        ctx.strokeStyle = '#09090b';
        ctx.lineWidth = 4;
        ctx.strokeText(ft.text, ft.x, ft.y);
        ctx.fillStyle = ft.color;
        ctx.fillText(ft.text, ft.x, ft.y);
        ctx.restore();
      }

      ctx.restore();

      // Throttle HUD updates (~15Hz or immediate on banner)
      const now = performance.now();
      if (now - lastHudPush > 60) {
        lastHudPush = now;
        onHudRef.current({
          p1Hp: p1.hp,
          p1MaxHp: p1.maxHp,
          p1Energy: Math.round(p1.energy),
          p1Rounds: p1.roundsWon,
          p1Combo: p1.comboCount,
          p2Hp: p2.hp,
          p2MaxHp: p2.maxHp,
          p2Energy: Math.round(p2.energy),
          p2Rounds: p2.roundsWon,
          p2Combo: p2.comboCount,
          timer: roundTimer,
          currentRound,
          bannerText,
        });
      }
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [p1Profile, p2Profile, stage, mode, difficulty, p1Skills, initialP1Hp, survivalWave]);

  return (
    <canvas
      ref={canvasRef}
      className="w-full h-full object-contain select-none touch-none block"
      style={{ aspectRatio: '960 / 500' }}
    />
  );
};
