export type GameMode =
  | 'single'
  | 'pvc'
  | 'two_player'
  | 'tournament'
  | 'survival';

export type Difficulty = 'easy' | 'normal' | 'hard' | 'brutal';

export type Language = 'en' | 'es' | 'ja' | 'hi';

export type ScreenRoute =
  | 'home'
  | 'fighters'
  | 'modes'
  | 'arena'
  | 'leaderboard'
  | 'settings';

export type SkillId = 'iron_guard' | 'combo_mastery' | 'hyper_surge';

export interface CombatSkill {
  id: SkillId;
  name: string;
  description: string;
  cost: number;
  bonusLabel: string;
}

export interface FighterProfile {
  id: string;
  name: string;
  title: string;
  style: string;
  specialName: string;
  specialDesc: string;
  specialType: 'fireball' | 'kunai' | 'shockwave' | 'meteor' | 'lightning' | 'slash' | 'frost' | 'beam';
  stats: {
    strength: number; // 1-100
    speed: number;    // 1-100
    health: number;   // 1-100
    skill: number;    // 1-100
  };
  maxHp: number;
  moveSpeed: number;
  damageScale: number;
  unlockCost: number;
  palette: {
    primary: string;
    secondary: string;
    accent: string;
    skin: string;
    hair: string;
    aura: string;
  };
  gear: 'headband' | 'mask' | 'horns' | 'bandana' | 'visor' | 'kabuto' | 'monk' | 'crown';
}

export interface ArenaStage {
  id: string;
  name: string;
  subtitle: string;
  imagePath: string;
  floorColor: string;
  accentColor: string;
  particleType: 'lantern' | 'spark' | 'ember';
}

export interface GameSettings {
  soundEnabled: boolean;
  musicEnabled: boolean;
  difficulty: Difficulty;
  language: Language;
  showTouchControls: boolean;
}

export interface LeaderboardEntry {
  id: string;
  fighterId: string;
  fighterName: string;
  mode: GameMode;
  score: number;
  wavesOrRounds: number;
  difficulty: Difficulty;
  won: boolean;
  timestamp: number;
}

export interface PlayerProgress {
  coins: number;
  totalWins: number;
  totalMatches: number;
  totalKOs: number;
  bestSurvivalWave: number;
  tournamentChampionships: number;
  unlockedFighters: string[];
  unlockedSkills: SkillId[];
  equippedSkills: SkillId[];
  selectedFighterId: string;
  selectedOpponentId: string;
  selectedStageId: string;
}

export interface TournamentMatch {
  id: string;
  round: 1 | 2 | 3; // 1=QF, 2=SF, 3=Final
  p1Id: string | null;
  p2Id: string | null;
  winnerId: string | null;
}
